<?php
/*
	dsu_paulsign Helper By shy9000[DSU Team] 2011-06-19
*/
!defined('IN_DISCUZ') && exit('Access Denied');
!defined('IN_ADMINCP') && exit('Access Denied');
include template('dsu_paulsign:sign_helper');
?>