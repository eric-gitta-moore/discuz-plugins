<?php
// ajax请求
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
if(isset($_GET['isdel']) && trim($_GET['bookarray'])){
	$bookarray = array();
	$bookarray = explode(',',trim($_GET['bookarray']));
	$success = $error = 0;
	foreach ($bookarray as $value) {
		if(C::t('#jameson_read#jamesonread_books')->delete($value)){
			$success++;
		}else{
			$error++;
		}
	}
	echo lang('plugin/jameson_read','deletebooksuccess').$success.lang('plugin/jameson_read','ben').'.'.lang('plugin/jameson_read','deletebookerror').$error.lang('plugin/jameson_read','ben');
}