<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
require_once './source/plugin/jameson_read/class/page.class.php';
$text = addslashes(dhtmlspecialchars(trim($_GET['srchtxt'])));
$count = C::t('#jameson_read#jamesonread_books')->count_search($text);
if($count){
	$page = new Page($count,10,'./plugin.php?id=jameson_read&srchtxt='.$text);
	$books = C::t('#jameson_read#jamesonread_books')->fetch_search($text,$page->getStart(),$page->getSize());
	$pageshow = $page->show();
	/*取得10条排行榜数据*/
	$saleorder = C::t('#jameson_read#jamesonread_books')->fetch_readorder(0,10);
	$scoresorder = C::t('#jameson_read#jamesonread_books')->fetch_by_scores(0,10);
	$favoresorder = C::t('#jameson_read#jamesonread_books')->fetch_by_favores(0,10);
}else{
	$books = null;
}
$navtitle = $text.'-'.lang('plugin/jameson_read','searchres');
include template("diy:search",0,'./source/plugin/jameson_read/template');