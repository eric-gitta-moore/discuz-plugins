<?php
// 书籍批量编辑、添加编辑模块入口
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
require_once './source/plugin/jameson_read/class/page.class.php';
/*判断是否是显示某一分类下的图书,记下分类id，作为跳转和按照分类查看图书的参数*/
$getcategory_id = intval($_GET['category_id'])?intval($_GET['category_id']):0;
switch (trim($_GET['opbook'])) {
	case 'delbook':
		if ($_GET['formhash'] == FORMHASH && ($book_id = intval($_GET['book_id']))) {
			C::t('#jameson_read#jamesonread_books#')->delete($book_id);
				cpmsg(lang('plugin/jameson_read','deletebooksuccess'), 'action=plugins&operation=config&identifier=jameson_read&pmod=addbook&category_id='.$getcategory_id, 'succeed');
		}else{
			cpmsg(lang('plugin/jameson_read','deletebookerror'), 'action=plugins&operation=config&identifier=jameson_read&pmod=addbook&category_id='.$getcategory_id, 'error');
		}
		break;
	case 'delzhangjie':
		//如果是删除章节
		C::t('#jameson_read#jamesonread_colums')->delete(intval($_GET['colum_id']));
		C::t('forum_thread')->delete(intval($_GET['tid']));
		cpmsg(lang('plugin/jameson_read','deletebooksuccess'), 'action=plugins&operation=config&identifier=jameson_read&pmod=addbook&opbook=addoredit&book_id='.intval($_GET['book_id']), 'succeed');
		break;
	case 'addoredit':
		//如果是添加或编辑单本图书页面
		require './source/plugin/jameson_read/addoredit.inc.php';
		break;
	default:
		loadcache('plugin');
		$morenbankuai = 0;
		$bankuai = unserialize($_G['cache']['plugin']['jameson_read']['bankuaiforbook']);
		if($bankuai[0]){
			foreach ($bankuai as $fid) {
				$forumname = C::t('forum_forum')->fetch_all_name_by_fid($fid);
				$postbookselect .='<option value='.$fid.'>'.$forumname[$fid]['name'].'</option>';
			}
			$morenbankuai = $bankuai[0];//默认添加新章节使用的版块fid
		}else{
			$morenbankuai = lang('plugin/jameson_read','weishezhibankuai');
		}
		// 否则显示图书列表批量编辑页面
		if(!submitcheck('editsubmit')) {
		 	// 如果未提交表单，则显示书籍管理
			$select = C::t('#jameson_read#jamesonread_categorys')->fetch_all_cate();
			if($getcategory_id){
				$count = C::t('#jameson_read#jamesonread_books')->count_by_cid($getcategory_id);
			}else{
				$count = C::t('#jameson_read#jamesonread_books')->count();
			}
			$page = new Page($count,10,'admin.php?action=plugins&operation=config&identifier=jameson_read&pmod=addbook');
			$pageshow = $page->show();
			if($getcategory_id){
				$books = C::t('#jameson_read#jamesonread_books')->fetch_bookscolums($getcategory_id,$page->getStart(),$page->getSize());
			}else{
				$books = C::t('#jameson_read#jamesonread_books')->fetch_bookscolums(0,$page->getStart(),$page->getSize());
			}
			$do = intval($_GET['do']);
			include template('jameson_read:booklist');
		}else {
			/*如果有提交动作*/
			$getcategory_id = isset($_GET['referid'])?intval($_GET['referid']):0;//来源页是否按分类查看
			/*提交时更新所有*/
			if(isset($_GET['bookname']) && !empty($_GET['bookname']) && is_array($_GET['bookname'])){
				foreach ($_GET['bookname'] as $key => $value) {
					$updatedata = array();
					$book_id = $key;
					$updatedata['book_name'] = addslashes(dhtmlspecialchars($value));
					$updatedata['desco'] = addslashes(dhtmlspecialchars($_GET['desco'][$key]));
					$updatedata['fletter'] = addslashes(dhtmlspecialchars($_GET['fletter'][$key]));//首字母
					$updatedata['category_id'] = intval($_GET['categoryId2'][$key]);
					$updatedata['ordernum'] = intval($_GET['order'][$key]);
					$updatedata['author'] = addslashes(dhtmlspecialchars($_GET['author'][$key]));
					$updatedata['is_top'] = (trim($_GET['checktop'][$key]) == 'on')?1:0;
					C::t('#jameson_read#jamesonread_books')->update($key,$updatedata);
				}
			}
			cpmsg(lang('plugin/jameson_read','addbooksuccess').$message, 'action=plugins&operation=config&identifier=jameson_read&pmod=addbook&category_id='.$getcategory_id, 'succeed');
		}
		break;
}