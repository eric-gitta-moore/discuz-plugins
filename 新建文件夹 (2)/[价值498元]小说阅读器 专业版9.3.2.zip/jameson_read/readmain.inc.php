<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
/*排序字段*/
$orderfield = isset($_GET['orderfield']) && trim($_GET['orderfield'])?trim($_GET['orderfield']):'views';
/*小说首页页面*/
// 图书必须设置为推荐才显示
if(!isset($_GET['category_id']) || empty($_GET['category_id'])){
	/*获取6条精品推荐书籍*/
	$recomendarray = array();
	//取得已经设置为推荐，并且排序数字最大的6本图书
	$recomendarray = C::t('#jameson_read#jamesonread_books')->fetch_readorder(0,6,true);
	$categoryarray = array();
	$categoryquery = C::t('#jameson_read#jamesonread_categorys')->fetch_all_parent(0);
	// 排序字段，默认
	while (list(,$row) = each($categoryquery)) {
		$categoryarray[$row['category_id']]['rootname'] = $row['category_name'];
		$subquery = C::t('#jameson_read#jamesonread_categorys')->fetch_all_parent($row['category_id']);
		while (list(,$subrow) = each($subquery)) {
			$categoryarray[$row['category_id']]['sub'][$subrow['category_id']]['subname'] = $subrow['category_name'];
			$categoryarray[$row['category_id']]['sub'][$subrow['category_id']]['book'] = C::t('#jameson_read#jamesonread_books')->fetch_by_get($subrow['category_id'],4,$orderfield,1);
			// 阅读榜,不论是否推荐
			$categoryarray[$row['category_id']]['sub'][$subrow['category_id']]['saleorder'] = C::t('#jameson_read#jamesonread_books')->fetch_readorder($subrow['category_id'],8,false);
			// 阅读榜,必须推荐
			$categoryarray[$row['category_id']]['sub'][$subrow['category_id']]['tjsaleorder'] = C::t('#jameson_read#jamesonread_books')->fetch_readorder($subrow['category_id'],8,true);
			//好评榜，不论是否推荐
			$categoryarray[$row['category_id']]['sub'][$subrow['category_id']]['scoresorder'] = C::t('#jameson_read#jamesonread_books')->fetch_by_scores($subrow['category_id'],8);
			//好评榜，必须是推荐
			$categoryarray[$row['category_id']]['sub'][$subrow['category_id']]['tjscoresorder'] = C::t('#jameson_read#jamesonread_books')->fetch_by_scores($subrow['category_id'],8,true);
			//收藏帮，不论是否推荐
			$categoryarray[$row['category_id']]['sub'][$subrow['category_id']]['favoresorder'] = C::t('#jameson_read#jamesonread_books')->fetch_by_favores($subrow['category_id'],8);
			//收藏帮，必须推荐
			$categoryarray[$row['category_id']]['sub'][$subrow['category_id']]['tjfavoresorder'] = C::t('#jameson_read#jamesonread_books')->fetch_by_favores($subrow['category_id'],8,true);
			//最新添加的书，必须推荐
			$categoryarray[$row['category_id']]['sub'][$subrow['category_id']]['tjnewbookorder'] = C::t('#jameson_read#jamesonread_books')->fetch_by_addtime($subrow['category_id'],8,true);
		}
	}
	$navtitle = trim($_G['cache']['plugin']['jameson_read']['hometitle'])?trim($_G['cache']['plugin']['jameson_read']['hometitle']):lang('plugin/jameson_read','readcenter');
	include template("diy:main",0,"./source/plugin/jameson_read/template");
} else if($category_id = intval($_GET['category_id'])){
	/*子分类页面*/
	require_once './source/plugin/jameson_read/class/page.class.php';
	/*获取6条本类精品推荐书籍*/
	$recomendarray = array();
	$recomendarray = C::t('#jameson_read#jamesonread_books')->fetch_readorder($category_id,6,true);
	/*子分类页面*/
	$subarray = array();
	//本类下图书数量
	$countarr = C::t('#jameson_read#jamesonread_books')->fetch_by_id("category_id",$category_id);
	/*获得本分类下本页的书籍*/
	$page = new Page($countarr,10,'./plugin.php?id=jameson_read:readmain&category_id='.$category_id);
	$pageshow = $page->show();
	$subarray = C::t('#jameson_read#jamesonread_books')->fetch_by_getnotop($category_id,$orderfield,$page->getStart(),$page->getSize());
	/*获取5条本类下排行榜书籍*/
	$saleorder = C::t('#jameson_read#jamesonread_books')->fetch_readorder($category_id,5,false);
	$scoresorder = C::t('#jameson_read#jamesonread_books')->fetch_by_scores($category_id,5);
	$favoresorder = C::t('#jameson_read#jamesonread_books')->fetch_by_favores($category_id,5);
	/*取得全部图书中20条排行榜数据*/
	$allsaleorder = C::t('#jameson_read#jamesonread_books')->fetch_readorder(0,20);
	$allscoresorder = C::t('#jameson_read#jamesonread_books')->fetch_by_scores(0,20);
	$allfavoresorder = C::t('#jameson_read#jamesonread_books')->fetch_by_favores(0,20);
	$category_namearray = C::t('#jameson_read#jamesonread_categorys')->fetch($category_id);
	$navtitle = $category_name = $category_namearray['category_name'];
	include template("diy:category_main",0,'./source/plugin/jameson_read/template');
}