<?php
// ajax请求
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
if(isset($_GET['category_id']) && (intval($_GET['category_id'])>0)){
	//返回本类下的所有图书
	$book_id = !isset($_GET['book_id']) || empty($_GET['book_id'])?0:intval($_GET['book_id']);
	$category_id = intval($_GET['category_id']);
	$query = C::t('#jameson_read#jamesonread_books')->fetch_by_id('category_id',$category_id,true);
	$message = lang('plugin/jameson_read','selectbook');
	$result = '';
	$count = 0;
	while (list(,$row) = each($query)) {
		$count++;
		$selected = $book_id == $row['book_id']?'selected':'';
		$result .= '<option value="'.$row['book_id'].'"   '.$selected.'>'.$row['book_name'].'</option>';
	}
	if($count<1){
		$message = lang('plugin/jameson_read','thiscatenobook');
	}
	$head = "<option value='0'>$message</option>";
	echo $head.$result;
}else if(isset($_GET['field'])){
	// 后台和作者中心处 不刷新页面更新章节 售价、标题、章节号
	$pk = intval($_GET['pk']);
	$field = trim($_GET['field']);
	switch ($field) {
		case 'zhangjie':
			$value = floatval($_GET['value']);
			$res = C::t('#jameson_read#jamesonread_colums')->update($pk,array('zhangjie'=>$value));
			break;
		case 'price':
			$value = intval($_GET['value']);
			if(($_G['uid'] != 1) && ((!$_G['cache']['plugin']['jameson_read']['allowuserset']) || ($value>$_G['cache']['plugin']['jameson_read']['danzhangjieshoujia']))){
				echo 0;
			}else{
				$res = C::t('forum_thread')->update($pk,array('price'=>$value));
			}
			break;
		case 'subject':
			$value = addslashes($_GET['value']);
			$res = C::t('forum_thread')->update($pk,array('subject'=>$value));
			break;
	}
	echo $res;
}else if(isset($_GET['shoucang']) && intval($_GET['shoucang']) == 1){
	// 进行收藏或者取消收藏
	// 请求来时状态为1则进行取消操作
	if(intval($_GET['status']) == 1){
		$newstat = 0; 
	}else{
		$newstat = 1;
	}
	$book_id = intval($_GET['book_id']);
	$data = array(
		'book_id'=>$book_id,
		'uid' => intval($_GET['uid']),
		'status'=>$newstat
		);
	$res = C::t('#jameson_read#jamesonread_favores')->updateorinsert(intval($_GET['book_id']),$data);
	if($res){
		// 操作成功后修改收藏数量
		if($newstat){
			C::t('#jameson_read#jamesonread_books')->update_favores($book_id,1);
		}else{
			C::t('#jameson_read#jamesonread_books')->update_favores($book_id,0);
		}
	}
	echo intval($res);
}