<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
/**
*普通页面嵌入 发帖页面、阅读页面处理
*
*
*/
class plugin_jameson_read {
		public $extcredits;//积分选用字段
		public $trame_name; // 选用的积分名称
		public $trame;
		public $total;//当前用户的总金币
		public $hassub = false;//判断是否已扣除金币
		public $tipjs = '';//扣除金币成功后输出js
		public $price;//帖子价格

	function  common(){
		global $_G;
		loadcache('plugin');
		//允许发布图书主题的用户组和版块
		$group = unserialize($_G['cache']['plugin']['jameson_read']['usegroupbook']);
		$bankuai = unserialize($_G['cache']['plugin']['jameson_read']['bankuaiforbook']);
		//插件后台必须同时设置允许的用户组和版块，否则没有发图书主题权限
		if($group[0] && $bankuai[0]){
				//取出common_setting中allowthreadplugin的值，反序列化为数组$a
				$allowthread = C::t('common_setting')->fetch('allowthreadplugin',true);
				//判断$allowthread中的键是否存在与group中，如果存在于（即拥有了发布图书主题权限），但这个值中不存在jameson_read，则 $allowthread[$key][] = 'jameson_read';
				//如果键值不存在于group中，即没有发布图书主题的权限，但这个值中有 jameson_read，则删掉unset($allowthread[$key][]) 目的是确保在插件设置组的都有图书主题权限，不在的都删掉权限
				foreach ($allowthread as $key => $value) {
					if(in_array($key,$group) && (array_search('jameson_read',$value) === false)){
						$allowthread[$key][] = 'jameson_read';
					}else if(!in_array($key,$gorup) && (array_search('jameson_read',$group) !== false)){
						unset($allowthread[$key][array_search('jameson_read',$group)]);
					}
				}

				//再判断group中的值即会员组id是否存在与allowthread中，如果不存在或者存在但没有jameson_read。则赋值  目的在判断是否插件设置的用户组都设置了图书主题权限
				foreach ($group as $value) {
					if(!array_key_exists($value, $allowthread) || (array_search('jameson_read',$allowthread[$value]) === false)){
						$allowthread[$value][] = 'jameson_read';
					}
				}
					//将allowthread序列化后插入common_setting表，即为用户组 发布图书主题 设置值
				C::t('common_setting')->update('allowthreadplugin',serialize($allowthread));
					foreach ($bankuai as $fid) {
						//根据fid从forum_forumfield表中取出threadplugin 反序列化$thread['threadplugin'] $th，如果不是数组或不存在值jameson_read则直接插入
						$threadplugin = C::t('forum_forumfield')->fetch($fid);
						$th = unserialize($threadplugin['threadplugin']);
						if( !is_array($th) || (array_search('jameson_read',$th) === false)){
							$th[] = 'jameson_read';
						}
						C::t('forum_forumfield')->update($fid,array('threadplugin'=>serialize($th)));
					}
		}else{
			//如果后台未设置允许发布文章的用户组，则将所有用户组图书主题权限删除
			$common_setting = C::t('common_setting')->fetch('allowthreadplugin',true);
			foreach ($common_setting as $key => $value) {
				if(array_search('jameson_read',$value) !== false){
					unset($common_setting[$key][array_search('jameson_read',$value)]);
				}
			}
			C::t('common_setting')->update('allowthreadplugin',serialize($common_setting));
		}
		return '';
	}
}

class plugin_jameson_read_forum extends plugin_jameson_read {

	function post_bottom_output(){
		if(isset($_GET['specialextra']) && $_GET['specialextra'] == 'jameson_read'){
		$res =<<<EOF
			<script>
				function selectbooks(e){
					var category_id = this.value;
					var ajax = new Ajax("html");
					ajax.getHTML("./plugin.php?id=jameson_read:ajax&category_id="+category_id,resulthandler);
					function resulthandler(res){
						$("postbook").innerHTML = res;
					}
				}
				if($('categoryId') != null){
			 		_attachEvent($("categoryId"),'change',selectbooks);
			 	}
			 	function zhangjiehao(){
			 		var zhangjie = $("zhangjiehao").getElementsByTagName("input")[1];
			 		if(zhangjie.value>0){
			 			zhangjie.removeAttribute("class");
			 		}
			 	}
			 	if($("zhangjiehao").getElementsByTagName("input")[1]){
			 		_attachEvent($("zhangjiehao").getElementsByTagName("input")[1],"blur",zhangjiehao);
			 	}
			</script>
			<style>
				#categoryId,#postbook {margin-right: 8px;border:1px solid #ddd; height:25px;line-height:25px;}
				#zhangjiehao input { border:1px solid #ccc;  display:inline-block; line-height:25px;height:25px;width:250px; }
				#zhangjiehao input.red { border-color:#f00;}
				#zhangjiehao label{display:inline-block; margin:5px auto;} </style>
EOF;
		return $res; 
	}
	}

	function viewthread_top(){
		global $_G;
		loadcache('plugin');
		$count = C::t('#jameson_read#jamesonread_colums')->count_by_id('tid',$_G['tid']);
		// 如果当前帖子是图书章节，并且不是当前用户发布的，并且price>0 并且没有购买过
		if($count > 0){
			if(!$_G['uid']){
				$url = urlencode('http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);
				header("location:./member.php?mod=logging&action=login&referer=".$url);
			}
			// 积分使用地段extcredits$trame 默认为extcredits2
			$this->trame = $_G['cache']['plugin']['jameson_read']['trame']?$_G['cache']['plugin']['jameson_read']['trame']:2;
			$this->extcredits = 'extcredits'.$this->trame;
			// 取得积分名称 默认为金钱
			$this->trame_name = $_G['setting']['extcredits'][$this->trame]['title'];
			$thread = C::t('forum_thread')->fetch($_G['tid']);
			$isbuy = C::t('#jameson_read#jamesonread_users')->count_by_id('uid',$_G['uid'],true);
			$isbuy = unserialize($isbuy[0]['tid']);
			if(($thread['authorid'] != $_G['uid']) && ($thread['price'] > 0) && !$isbuy[$_G['tid']]){
				// 获取当前用户的金钱数
				//用户设置的图书使用积分
				// 用户拥有的金钱数
				$currentext = C::t('common_member_count')->fetch($_G['uid']);
				$this->total = $currentext[$this->extcredits];
				$this->price = $thread['price'];
				if($this->total < $thread['price']){
					// 如果用户的金币不足以支付本贴
					showmessage($this->trame_name.lang('plugin/jameson_read','qingchongzhi'),'home.php?mod=spacecp&ac=credit&op=buy');
				}else{
					// 进行扣除
					if($res = C::t('#jameson_read#jamesonread_users')->trans($_G['uid'],$thread['authorid'],$thread['price'],$this->extcredits)){
							// 记录入用户购买表
							C::t('#jameson_read#jamesonread_users')->updateorinsert(intval($_G['uid']),intval($_G['tid']),$thread['price']);
							$this->hassub = true;//扣除成功
							$html = '<style>
										#messageajax {position: fixed;z-index:9999;top:0;width: 200px;height:50px;line-height: 50px; text-align:center;font-size:14px; left: 50%;margin-left: -50px; border-radius: 15px;color: #fff;display: none;}
								.success { background: #669933;}
							.error { background: #f00;}</style><div style="" id="messageajax"></div>';
					}else{
						// 扣除失败
						showmessage(lang('plugin/jameson_read','kouchu').$this->trame_name.lang('plugin/jameson_read','shibaiqingchongshi'));
					}
				}
			}//不需要扣除操作，可能购买过或者是自己的图书
		/*如果开启了简洁阅读模式，并且是图书章节则隐藏原内容*/
			if($_G['cache']['plugin']['jameson_read']['simpleread']){
				$html .= '<style>#postlist > div:nth-of-type(2){display:none;}</style>';
			}
			return $html;
		}//不是图书章节
	}
	function viewthread_bottom_output(){
		global $_G;
		loadcache('plugin');
		/*根据本帖tid获取章节和书籍id*/
		$selftid = C::t('#jameson_read#jamesonread_colums')->count_by_id('tid',$_G['tid'],true);
		$nextpage = $prepage = '';
		if(is_array($selftid) && is_array($selftid[0])){
			$selfzhangjie = $selftid[0]['zhangjie'];
			/*查询比本帖子章节大的作为下一页*/
			$nextarray = C::t('#jameson_read#jamesonread_colums')->fetch_next_pre($selftid[0]['book_id'],$selfzhangjie,$_G['tid'],'>');
			if(is_array($nextarray) && is_array($nextarray[0])){
				$nextpage = '<a class="next" href="./forum.php?mod=viewthread&tid='.$nextarray[0]['tid'].'">'.lang('plugin/jameson_read','nextpage');
				if($nextarray[0]['price']){
					$nextpage .= '<em class="xg0 fctrl">['.lang('plugin/jameson_read','shoujia').']'.$nextarray[0]['price'].$this->trame_name.'</em>&gt;</a>';
				}else{
					$nextpage .= '&gt;</a>';
				}
			}else{
				$nextpage = '<span class="next">'.lang('plugin/jameson_read','nonextpage').'&gt;</span>';
			}
			/*查询比本帖子章节小的作为上一页*/
			$prearray = C::t('#jameson_read#jamesonread_colums')->fetch_next_pre($selftid[0]['book_id'],$selfzhangjie,$_G['tid'],'<');
			if(is_array($prearray) && is_array($prearray[0])){
				$prepage = '<a class="pre" href="./forum.php?mod=viewthread&tid='.$prearray[0]['tid'].'">&lt;'.lang('plugin/jameson_read','prepage');
				if($prearray[0]['price']){
					$prepage .= '<em class="xg0 fctrl">['.lang('plugin/jameson_read','shoujia').']'.$prearray[0]['price'].$this->trame_name.'</em></a>';
				}else{
					$prepage .= '</a>';
				}
			}else{
				$prepage = '<span class="pre">&lt;'.lang('plugin/jameson_read','noprepage').'</span>';
			}
			/*添加阅读量*/
			C::t('#jameson_read#jamesonread_books')->update_views($selftid[0]['book_id']);
			//面包屑
			$booknav = C::t('#jameson_read#jamesonread_books')->fetch_nav_bybid($selftid[0]['book_id']);
			$jsnav =<<<EOF
			<script>
				var nav = '<a href="./plugin.php?id=jameson_read:readmain&category_id={$booknav[1]['cid']}">{$booknav[1]['name']}</a><em>&gt;</em><a href="./plugin.php?id=jameson_read:readmain&category_id={$booknav[2]['cid']}">{$booknav[2]['name']}</a><em>&gt;</em><a href="./plugin.php?id=jameson_read:bookcontent&book_id={$booknav[3]['bid']}">{$booknav[3]['name']}</a>';
				$("pt").innerHTML = "<div class='z'><a class='nvhm'></a><em>&gt;</em>"+nav+"</div>";
			</script>
EOF;
			/*阅读页面下方固定导航*/
			$content = $prepage.'<a class="content" href="./plugin.php?id=jameson_read:bookcontent&book_id='.$selftid[0]['book_id'].'">'.lang('plugin/jameson_read','bookcontent').'</a>'.$nextpage;
			$js = '';
			if($_G['cache']['plugin']['jameson_read']['simpleread']){
				// 如果已经开启了简洁阅读模式
				$js =<<<EOF
				<script type="text/javascript">
					var html = $("postmessage_"+{$_G['forum_firstpid']}).innerHTML;
					var head = '<h2>'+$("thread_subject").innerText+'</h2><p class="topreadnav">$content</p><div id="simplereadcontent">';
					var div = document.createElement('div');
					div.setAttribute('id','simpleread');
					div.innerHTML = head+html+'</div>';
					$("postlist").insertBefore(div,$("postlist").firstChild);
				</script>
EOF;
			}
				$css =<<<END
				#bookviewnav {
					position:fixed;z-index:9999;bottom:0;left:50%;width:960px;margin-left:-480px;text-align:center;height:45px;line-height:45px;background:#ebffeb;border:1px solid #eee;}
				#bookviewnav a, #bookviewnav span { position:absolute;top:0;bottom:0;width:33%; font-size:18px; font-family:"misoft yahei";color:#666;text-align:center;}
				#bookviewnav a:hover, #bookviewnav a:hover em, #bookviewnav span:hover { background:#f26c4f; color:#fff;text-decoration:none; }
				#bookviewnav .pre{left:0;}
				#bookviewnav .content{left:33.5%; }
				#bookviewnav .next{left:67%;}
				#bookviewnav em { color:#999; font-size:12px;}
				#simpleread > h2 {text-align: center; font-size:18px; margin-top: 40px; }
				#simpleread > .topreadnav { text-align: center; }
				#simpleread > .topreadnav a,#simpleread > .topreadnav span { text: center; display:inline-block; margin:8px;  }
				#simplereadcontent { padding: 40px; line-height: 2em; font-size: 14px;  border-bottom: 2px solid #ddd;}
				#simplereadcontent p { margin: 10px; }
				body #postlist{ display:block;}
END;
			
			if($this->hassub){
				// 如果已扣除金币
				$this->tipjs = '<script>
						function resulthandler(price,name){
							$("messageajax").style.display = "block";
							$("messageajax").innerText = "'.lang('plugin/jameson_read','yikouchu').'"+price+name;
							$("messageajax").setAttribute("class","success");
								setTimeout(function(){
									$("messageajax").style.display = "none";
								},3000);
						}
						_attachEvent(window,"load",resulthandler('.$this->price.',"'.$this->trame_name.'"));
					</script>';
			}
			return $jsnav.$js.'<div id="bookviewnav">'.$content.'</div><style>'.$css.'</style>'.$this->tipjs;
		}
	}
}