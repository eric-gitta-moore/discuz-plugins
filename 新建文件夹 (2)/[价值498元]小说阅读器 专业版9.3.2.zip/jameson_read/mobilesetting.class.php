<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
/**
* 
*/
class mobileplugin_jameson_read 
{
}

/**
* 
*/
class mobileplugin_jameson_read_forum extends mobileplugin_jameson_read
{
	function index_top_mobile(){
		global $_G;
		loadcache('plugin');
		if(trim($_G['cache']['plugin']['jameson_read']['shoujimobilecss'])){
			$css = trim($_G['cache']['plugin']['jameson_read']['shoujimobilecss']);
		}else{
			$css = 'display:block;height:40px;line-height:40px; margin: 5px auto; width:90%; text-align:center;clear:both;border:2px solid #dcdcdc;background:#f5f5f5;font-size:1.4em;box-shadow:1px 1px 2px rgba(100,100,100,.5);border-radius:5px; ';
		}
		$return = '
		<a href="./plugin.php?id=jameson_read:mbmain" id="jameson_hookbutton" style="'.$css.'" >'.trim($_G['cache']['plugin']['jameson_read']['hometitle']).'</a>';
		return $return;
	}
}