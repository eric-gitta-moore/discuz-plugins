<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
/**
*图书主题
*/
class threadplugin_jameson_read {
	var $name = 'book';			//主题类型名称
	var $iconfile = '';		//发布主题链接中的前缀图标
	var $buttontext = 'post book';	//发帖时按钮文字
	var $select = '';
	function __construct(){
		$this->name = lang('plugin/jameson_read','threadname');
		$this->buttontext = lang('plugin/jameson_read','postbookbutton');
	}
	function newthread($fid) {
			global $_G;
			$categoryquery = C::t('#jameson_read#jamesonread_categorys')->fetch_all_parent(0);
			$this->select = '<select id="categoryId" name="selectCategoryId">
		  			<option value selected>'.lang('plugin/jameson_read','selectbookcategory').'</option>';
			while(list(,$row) = each($categoryquery)) {
				$this->select .= '<optgroup label="'.$row['category_name'].'">';
				$subquery = C::t('#jameson_read#jamesonread_categorys')->fetch_all_parent($row['category_id']);
				while(list(,$subrow) = each($subquery)) {
					$selected = $subrow['category_id'] == intval($_GET['category_id'])?'selected':'';
					$this->select .= '<option '.$selected.' value="'.$subrow['category_id'].'">'.$subrow['category_name'].'</option>';
				}
				$this->select .= '</optgroup>';
			}
			$this->select .= '</select>';
		return '<div id="zhangjiehao" class="message green">
					<label>'.lang('plugin/jameson_read','shoujia').
						':<input class="px" type="text" name="price">
					</label>'.
					'<label >'.lang('plugin/jameson_read','zhangjiedescolabel').
						'<input placeholder="'.lang('plugin/jameson_read','zhangjiedesco').'" type="text" class="red" name="zhangjie">
					</label>
					<br />'.$this->select.
					'<select id="postbook" name="selectBookId">
						<option>'.lang('plugin/jameson_read','selectbook').
						'</option>
					</select>
				</div>
				<script>
					function editselectbooks(){
						var ajax = new Ajax("html");
						ajax.getHTML("./plugin.php?id=jameson_read:ajax&category_id='.intval($_GET['category_id']).'&book_id='.intval($_GET['book_id']).'",resulthandler);
						function resulthandler(res){
							$("postbook").innerHTML = res;
						}
					}
					_attachEvent(window,"load",editselectbooks);
				</script>';
	}

	function newthread_submit($fid) {}

	function newthread_submit_end($fid, $tid) {
		global $_G;
		$category_id = intval($_GET['selectCategoryId']);
		$book_id = intval($_GET['selectBookId']);
		$zhangjie = floatval($_GET['zhangjie']);
		if($zhangjie<0.01){
			$zhangjie = floatval(C::t("#jameson_read#jamesonread_colums")->fetch_zhangjie($book_id));
			$zhangjie = $zhangjie < 0.01 ? 1:$zhangjie;
		}
		C::t('#jameson_read#jamesonread_colums')->insert(array('category_id'=>$category_id,'uid'=>$_G['uid'],'fid'=>$fid,'book_id'=>$book_id,'tid'=>$tid,'addtime'=>time(),'zhangjie'=>$zhangjie));
	}

	function editpost($fid, $tid) {
			global $_G;
			$columinfo = C::t('#jameson_read#jamesonread_colums')->fetch_bytid($tid);
			$price = C::t('forum_thread')->fetch($tid);
			$price = $price['price'];
			$categoryquery = C::t('#jameson_read#jamesonread_categorys')->fetch_all_parent(0);
			$book = C::t('#jameson_read#jamesonread_colums')->fetch_bytid($tid);
			$this->select = '<select id="categoryId" name="selectCategoryId">
		  			<option>'.lang('plugin/jameson_read','selectbookcategory').'</option>';
			while(list(,$row) = each($categoryquery)) {
				$this->select .= '<optgroup label="'.$row['category_name'].'">';
				$subquery = C::t('#jameson_read#jamesonread_categorys')->fetch_all_parent($row['category_id']);
				while(list(,$subrow) = each($subquery)) {
					if($columinfo['category_id'] == $subrow['category_id']) {
						$selected = ' selected ';
					}else{
						$selected = '';
					}
					$this->select .= '<option '.$selected.' value="'.$subrow['category_id'].'">'.$subrow['category_name'].'</option>';
				}
				$this->select .= '</optgroup>';
			}
			$this->select .= '</select>';
		return '<div class="message green" id="zhangjiehao">
					<label>'.lang('plugin/jameson_read','shoujia').':
						<input type="text" name="price" value="'.$price.'">
					</label>
					<label>'.lang('plugin/jameson_read','zhangjiedescolabel').
						'<input placeholder="'.lang('plugin/jameson_read','zhangjiedesco').'" type="text" class="red" name="zhangjie" value='.$columinfo['zhangjie'].'>
					</label>
					<br />'.$this->select.
					'<select id="postbook" name="selectBookId">
						<option>'.lang('plugin/jameson_read','selectbook').
						'</option>
					</select>
					</div>
					<script>
						function editselectbooks(){
							var zhangjie = $("zhangjiehao").getElementsByTagName("input")[1];
							if(zhangjie && zhangjie.value>0){
								zhangjie.removeAttribute("class");
							}
							var ajax = new Ajax("html");
							ajax.getHTML("./plugin.php?id=jameson_read:ajax&category_id='.$columinfo['category_id'].'&book_id='.$book['book_id'].'",resulthandler);
						function resulthandler(res){
							$("postbook").innerHTML = res;
						}
						}
						_attachEvent(window,"load",editselectbooks);
					</script>';
	}

	function editpost_submit($fid, $tid) {}

	function editpost_submit_end($fid, $tid) {
		global $_G;
		$category_id = intval($_GET['selectCategoryId']);
		$book_id = intval($_GET['selectBookId']);
		$zhangjie = floatval($_GET['zhangjie']);


		if(C::t('#jameson_read#jamesonread_colums')->count_by_id('tid',$tid)){
			C::t('#jameson_read#jamesonread_colums')->update_bytid($tid,array('category_id'=>$category_id,'book_id'=>$book_id,'zhangjie'=>$zhangjie));
		}else{
			C::t('#jameson_read#jamesonread_colums')->insert(array('category_id'=>$category_id,'book_id'=>$book_id,'zhangjie'=>$zhangjie,'uid'=>intval($_G['uid']),'addtime'=>time(),'fid'=>$fid));
		}
		C::t('forum_thread')->update($tid,array('price'=>intval($_GET['price'])));
	}

	function newreply_submit_end($fid, $tid) {}

	function viewthread($tid) {}
}