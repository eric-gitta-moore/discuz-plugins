<?php
// 手机版
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
if(isset($_GET['op']) && $_GET['nav_id']>0){
	C::t('#jameson_read#jamesonread_navs')->delete(intval($_GET['nav_id']));
	cpmsg(lang('plugin/jameson_read','deletesuccess'),'action=plugins&operation=config&identifier=jameson_read&pmod=setnav', 'succeed');
}

if(!submitcheck('editsubmit')) {
	//获取导航数据
	$navs = C::t('#jameson_read#jamesonread_navs')->fetch_all();
	include include template('jameson_read:setnav');
}else{
	if(isset($_GET['name'])){
		C::t('#jameson_read#jamesonread_navs')->update_or_insert($_GET['order'],$_GET['name'],$_GET['href'],'update');
	}
	if(isset($_GET['addname'])){
		C::t('#jameson_read#jamesonread_navs')->update_or_insert($_GET['addorder'],$_GET['addname'],$_GET['addhref'],'insert');
	}
	cpmsg(lang('plugin/jameson_read','updatesuccess'),'action=plugins&operation=config&identifier=jameson_read&pmod=setnav', 'succeed');
}