<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
// 手机首页
if(trim($_GET['operation']) == 'catelist'){
	//全部分类
	$category = C::t('#jameson_read#jamesonread_categorys')->fetch_all_cate();
	$navtitle = lang('plugin/jameson_read','fenleimb').'-'.$_G['cache']['plugin']['jameson_read']['hometitle'];
	include template("jameson_read:touch/catelist");
}else if(trim($_GET['operation']) == 'paihang'){
	$books = C::t('#jameson_read#jamesonread_books')->fetch_readorder(0,20);
	$navtitle = lang('plugin/jameson_read','paihangmb').'-'.$_G['cache']['plugin']['jameson_read']['hometitle'];
	include template("jameson_read:touch/paihang");
}else if(isset($_GET['category_id']) && intval($_GET['category_id']) >0){
	//分类页面
	$category_id = intval($_GET['category_id']);
	$category_name = C::t('#jameson_read#jamesonread_categorys')->fetch_name($category_id);
	$navtitle = $category_name.'-'.$_G['cache']['plugin']['jameson_read']['hometitle'];
	require './source/plugin/jameson_read/class/page.class.php';
	$count = C::t('#jameson_read#jamesonread_books')->fetch_by_id('category_id',$category_id);
	$page = new Page($count,2,'./plugin.php?id=jameson_read:mbmain&category_id='.$category_id);
	$pageshow = $page->showprenext();
	$books = C::t('#jameson_read#jamesonread_books')->fetch_by_id('category_id',$category_id,true,$page->getStart(),$page->getSize());
	include template("jameson_read:touch/category");
}else if(isset($_GET['book_id']) && intval($_GET['book_id']) >0){
	//书籍目录和阅读页面
	$book_id = intval($_GET['book_id']);
	$book = C::t('#jameson_read#jamesonread_books')->fetch($book_id);
	$navtitle = $book['book_name'].'-'.$_G['cache']['plugin']['jameson_read']['hometitle'];
	$category_name = C::t('#jameson_read#jamesonread_categorys')->fetch_name($book['category_id']);
	$colums = C::t('#jameson_read#jamesonread_colums')->fetch_thread_bybid($book_id);
	$thistidprice = $colums[$_GET['tid']]['price'];
	$trame = $_G['cache']['plugin']['jameson_read']['trame']?$_G['cache']['plugin']['jameson_read']['trame']:2;
	//积分名称
	$trame_name = $_G['setting']['extcredits'][$trame]['title'];
	if($_GET['tid'] && $_GET['pid']){
		// 判断扣除
		// 用户拥有的金钱数
		$navtitle = $colums[$_GET['tid']]['subject'];
		$currentext = C::t('common_member_count')->fetch($_G['uid']);
		$currentext = intval($currentext['extcredits'.$trame]);
		$isbuy = C::t('#jameson_read#jamesonread_users')->count_by_id('uid',$_G['uid'],true);
		$isbuy = unserialize($isbuy[0]['tid']);
		$allowread =1;
			// 只有当当前用户不等于作者时并且在price大于0并且用户没有购买过才判断
			if(($_G['uid'] != $colums[$_GET['tid']]['authorid']) && !$isbuy[$_GET['tid']] && ($thistidprice>0)){
				if($currentext < $thistidprice){
					// 如果当前用户的金钱小于帖子价格
					$errormessage = $trame_name.lang('plugin/jameson_read','qingchongzhi');
					$allowread = 0;
					include template("jameson_read:touch/shibai");
				}else{
					// 扣除
					if($res = C::t('#jameson_read#jamesonread_users')->trans($_G['uid'],$colums[$_GET['tid']]['authorid'],$colums[$_GET['tid']]['price'],'extcredits'.$trame)){
						// 扣除成功
						C::t('#jameson_read#jamesonread_users')->updateorinsert(intval($_G['uid']),intval($_GET['tid']),$colums[$_GET['tid']]['price']);
						$yikouchu = 1;
					}else{
						$yikouchu = $allowread = 0;
						$errormessage = lang('plugin/jameson_read','kouchu').$trame_name.lang('plugin/jameson_read','shibaiqingchongshi');
						include template("jameson_read:touch/shibai");
					}
				}
			}
			if($allowread){
				$alltid = array_keys($colums);//所有tid组成的索引数组
				$currenttid = array_search($_GET['tid'],$alltid);//当前tid的索引
				$nexttid = $currenttid<count($alltid)-1?$alltid[$currenttid+1]:null;//下一个索引对应的tid
				$nextpid = $nexttid !== null ? intval($colums[$nexttid]['pid']):0;
				$pretid = $currenttid>0?$alltid[$currenttid-1]:null;
				$prepid = $pretid !== null ?intval($colums[$pretid]['pid']):0;
				C::t('#jameson_read#jamesonread_books')->update_views($book_id);//更新阅读量
				include './source/function/function_discuzcode.php';
				$body = C::t("forum_post")->fetch('tid:'.intval($_GET['tid']),intval($_GET['pid']),true);
				$body['message'] = nl2br(preg_replace("/jameson_read/",'',discuzcode($body["message"],0,0)));

				$_G['forum_attachpids'][] = $_GET['pid'];
				if(preg_match_all("/\[attach\](\d+)\[\/attach\]/i", $body['message'], $matchaids)) {
					$_G['forum_attachtags'][$_GET['pid']] = $matchaids[1];
				}
				$tupianfujian = array();
				require_once libfile('function/attachment');
				$_G['tid'] = $_GET['tid'];
				parseattach(array($_GET['pid']), $_G['forum_attachtags'], $tupianfujian);
				if($tupianfujian[$_GET['pid']]['attachments']){
					foreach ($tupianfujian[$_GET['pid']]['attachments'] as $key => $value) {
						if($value['ext'] == 'jpg'){
							$img = '<img src="'.$value['url'].$value['attachment'].'" />';
							$patt = "/\[attach\](".$key.")\[\/attach\]/i";
							$body['message'] = preg_replace($patt,$img,$body['message']);
						}
					}
				}
				include template("jameson_read:touch/thead");
			}else{
				$errormessage = $trame_name.lang('plugin/jameson_read','qingchongzhi');
				include template("jameson_read:touch/thead");
			}
		// 判断扣除end
	}else{
		include template("jameson_read:touch/book");
	}
}else{
	//取得所有
	$books = C::t('#jameson_read#jamesonread_books')->fetch_readorder(0,10,true);
	$navtitle = $_G['cache']['plugin']['jameson_read']['hometitle'];
	include template("jameson_read:touch/main");
}