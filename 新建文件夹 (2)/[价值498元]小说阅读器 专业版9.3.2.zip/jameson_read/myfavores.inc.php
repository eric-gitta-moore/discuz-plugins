<?php
// 我的收藏
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
require './source/plugin/jameson_read/class/page.class.php';
$mycount = C::t('#jameson_read#jamesonread_favores')->countbyuid($_G['uid']);
if($mycount){
	$page = new Page($mycount,10,'./home.php?mod=spacecp&ac=plugin&id=jameson_read:myfavores');
	$pageshow = $page->show();
	//用户的所有收藏图书
	$mybooks = C::t('#jameson_read#jamesonread_favores')->fetchbookbyuid($_G['uid'],$page->getStart(),$page->getSize());
}else{
	$mybooks = null;
}