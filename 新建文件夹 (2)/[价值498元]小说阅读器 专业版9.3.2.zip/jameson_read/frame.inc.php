<?php
// 点评ajax请求
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
include template("jameson_read:tuijian");