<?php
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_jamesonread_books`;
DROP TABLE IF EXISTS `cdb_jamesonread_colums`;
DROP TABLE IF EXISTS `cdb_jamesonread_categorys`;
DROP TABLE IF EXISTS `cdb_jamesonread_navs`;
DROP TABLE IF EXISTS `cdb_jamesonread_users`;
DROP TABLE IF EXISTS `cdb_jamesonread_dianping`;
DROP TABLE IF EXISTS `cdb_jamesonread_favores`;
EOF;
runquery($sql);
$finish = TRUE;