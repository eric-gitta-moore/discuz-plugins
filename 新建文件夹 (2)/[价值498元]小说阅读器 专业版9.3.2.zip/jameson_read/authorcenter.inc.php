<?php
// 作者中心
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
if(isset($_GET['opbook']) && ($_GET['opbook'] == 'delbook') && ($_GET['formhash'] == FORMHASH && ($book_id = intval($_GET['book_id'])))){
	// 删除图书
	if(C::t('#jameson_read#jamesonread_books')->delete($book_id)){
		showmessage(lang('plugin/jameson_read','deletebooksuccess'),'home.php?mod=spacecp&ac=plugin&id=jameson_read:authorcenter');
	}else{
		showmessage(lang('plugin/jameson_read','deletebookerror'),'home.php?mod=spacecp&ac=plugin&id=jameson_read:authorcenter');
	}
	
}else if(isset($_GET['opbook']) && ($_GET['opbook'] =='delzhangjie') && ($_GET['formhash'] == FORMHASH)){
	// 删除章节
	C::t('#jameson_read#jamesonread_colums')->delete(intval($_GET['colum_id']));
	C::t('forum_thread')->delete(intval($_GET['tid']));
	showmessage(lang('plugin/jameson_read','deletesuccess'),'./home.php?mod=spacecp&ac=plugin&id=jameson_read:authorcenter&formhash='.FORMHASH.'&opbook=addoredit&book_id='.$_GET['book_id'],'succeed');
}
loadcache('plugin');
$group = unserialize($_G['cache']['plugin']['jameson_read']['usegroupbook']);
if(!$group[0] || !in_array($_G['groupid'],$group)){
	//如果无发布图书权限
	$perm = 0;
	$message = lang('plugin/jameson_read','nopermpost');
}else{
	require './source/plugin/jameson_read/class/page.class.php';
	//如果有发布图书权限
	$perm = 1;
	$message = lang('plugin/jameson_read','welcomeauthorcenter');
	//用户设置的图书使用积分
	// 积分使用地段extcredits$trame 默认为extcredits2
	$trame = $_G['cache']['plugin']['jameson_read']['trame']?$_G['cache']['plugin']['jameson_read']['trame']:2;
	// 用户拥有的金钱数
	$currentext = C::t('common_member_count')->fetch($_G['uid']);
	$currentext = $currentext['extcredits'.$trame];
	//积分名称
	$trame_name = $_G['setting']['extcredits'][$trame]['title'];
	//当前用户通过出售图书赚取的金币
	$uidjinbi = ($jinbi = C::t('#jameson_read#jamesonread_users')->fetch_price($_G['uid']))?$jinbi:0;
	//获取用户已发布的图书信息
	$hascolumscount  = C::t('#jameson_read#jamesonread_colums')->count_by_id('uid',intval($_G['uid']),false);
	$bankuai = unserialize($_G['cache']['plugin']['jameson_read']['bankuaiforbook']);
	$morenbankuai = $bankuai[0];//默认添加新章节使用的版块fid

	$getcategory_id = intval($_GET['category_id'])?intval($_GET['category_id']):0;
	$hasbookscount = C::t('#jameson_read#jamesonread_books')->count_by_uid(intval($_G['uid']));
	// 是否允许用户设置售价 及最高售价，插件后管理员不限制
	$allowuserset = $_G['cache']['plugin']['jameson_read']['allowuserset'];
	$danzhangjieshoujia = intval($_G['cache']['plugin']['jameson_read']['danzhangjieshoujia']);
	if($_GET['opbook'] == 'addoredit'){
		// 单本图书的添加或编辑页面
		$book_id = intval($_GET['book_id'])?intval($_GET['book_id']):0;
		if(!submitcheck('editsubmit')){
			// 未提交，显示管理
			$select = C::t('#jameson_read#jamesonread_categorys')->fetch_all_cate();
			if($book_id){
				// 编辑图书
				$book = C::t('#jameson_read#jamesonread_books')->fetch_bookandcolum($book_id);
				$count = C::t('#jameson_read#jamesonread_colums')->count_by_id('book_id',$book_id,false);
				$page = new Page($count,50,'./home.php?mod=spacecp&ac=plugin&id=jameson_read:authorcenter&opbook=addoredit&formhash='.FORMHASH.'&book_id='.$book_id);
				$colums = C::t('#jameson_read#jamesonread_colums')->fetch_thread_bybid($book_id,$page->getStart(),$page->getSize());
				$pageshow = $page->show();
			}
		}else{
			/*如果有提交动作*/
				$data = array();
				$data['book_name'] = addslashes(dhtmlspecialchars(trim($_GET['addbookname'])));
				$data['category_id'] = intval($_GET['categoryId']);
				$data['author'] = addslashes(dhtmlspecialchars(trim($_GET['addbookauthor'])));
				$data['addtime'] = time();
				$data['ordernum'] = intval($_GET['addbookorder']);
				$data['plan'] = intval($_GET['addbookplan']);
				$data['uid'] = intval($_G['uid']);
				$data['desco'] = addslashes(dhtmlspecialchars(trim($_GET['addbookdesco'])));
				$data['fletter'] = addslashes(dhtmlspecialchars(trim($_GET['addbookfletter'])));
				$data['image'] = $message = '';
				/*如果有上传图片则处理*/
				if(isset($_FILES['addbookimage'])){
					$upload = new discuz_upload();
					$upload->init($_FILES['addbookimage'],'forum');
					if($upload->is_image_ext($upload->fileext($_FILES['addbookimage']['name']))){
						if($upload->save()){
							$data['image'] = $upload->attach['attachment'];
						}else{
							$message = '#'.lang('plugin/jameson_read','addbookerror');
						}
					}else{
						$message = '#'.lang('plugin/jameson_read','imggeshierror');
					}
					unset($upload);
				}
				// 更新
				if($book_id>0){
						C::t('#jameson_read#jamesonread_books')->update($book_id,$data);
					/*提交时更新所有*/
					showmessage(lang('plugin/jameson_read','addbooksuccess').$message, './home.php?mod=spacecp&ac=plugin&id=jameson_read:authorcenter&opbook=addoredit&formhash='.FORMHASH.'&book_id='.$book_id, 'succeed');
				}else{
					//插入
					C::t('#jameson_read#jamesonread_books')->insert($data);
					showmessage(lang('plugin/jameson_read','addbooksuccess').$message, './home.php?mod=spacecp&ac=plugin&id=jameson_read:authorcenter','succeed');
				}
		}
	}else if(!isset($_GET['opbook'])){
		// 默认图书列表管理
		if(!submitcheck('editsubmit')) {
			$select = C::t('#jameson_read#jamesonread_categorys')->fetch_all_cate();
			$count = $getcategory_id?C::t('#jameson_read#jamesonread_books')->count_by_cid($getcategory_id,$_G['uid']):C::t('#jameson_read#jamesonread_books')->count_by_uid($_G['uid']);
			$page = new Page($count,10,'home.php?mod=spacecp&ac=plugin&id=jameson_read:authorcenter');
			$pageshow = $page->show();
			$books = $getcategory_id?C::t('#jameson_read#jamesonread_books')->fetch_bookscolums($getcategory_id,$page->getStart(),$page->getSize(),$_G['uid']):C::t('#jameson_read#jamesonread_books')->fetch_bookscolums(0,$page->getStart(),$page->getSize(),$_G['uid']);
		}else {
			// /*如果有提交动作*/
			$getcategory_id = isset($_GET['referid'])?intval($_GET['referid']):0;
			// /*提交时更新所有*/
			if(isset($_GET['bookname']) && !empty($_GET['bookname']) && is_array($_GET['bookname'])){
				foreach ($_GET['bookname'] as $key => $value) {
					if($value){
						$updatedata = array();
						$book_id = $key;
						$updatedata['book_name'] = addslashes(dhtmlspecialchars($value));
						$updatedata['desco'] = addslashes(dhtmlspecialchars($_GET['desco'][$key]));
						$updatedata['category_id'] = intval($_GET['categoryId2'][$key]);
						$updatedata['ordernum'] = intval($_GET['order'][$key]);
						$updatedata['author'] = addslashes(dhtmlspecialchars($_GET['author'][$key]));
						$updatedata['fletter'] = addslashes(dhtmlspecialchars($_GET['fletter'][$key]));
						C::t('#jameson_read#jamesonread_books')->update($key,$updatedata);
					}
				}
			}
			showmessage(lang('plugin/jameson_read','addbooksuccess'), './home.php?mod=spacecp&ac=plugin&id=jameson_read:authorcenter&category_id='.$getcategory_id, 'succeed');
		}
	}
}