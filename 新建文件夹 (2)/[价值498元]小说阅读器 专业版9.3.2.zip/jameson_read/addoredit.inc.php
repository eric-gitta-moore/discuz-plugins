<?php
// 单个书籍添加或编辑
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
loadcache('plugin');
$book_id = intval($_GET['book_id'])?intval($_GET['book_id']):0;
$getcategory_id = intval($_GET['category_id'])?intval($_GET['category_id']):0;
// 如果未提交表单，则显示书籍管理
if(!submitcheck('editsubmit')) {
	$select = C::t('#jameson_read#jamesonread_categorys')->fetch_all_cate();
	if($book_id){
		// 存在book_id是编辑图书
		$trame = $_G['cache']['plugin']['jameson_read']['trame']?$_G['cache']['plugin']['jameson_read']['trame']:2;//选用的货币id
		$extcredits = C::t('common_setting')->fetch('extcredits',true);
		$trame_name = $extcredits[$trame]['title'];//货币名称
		$book = C::t('#jameson_read#jamesonread_books')->fetch_bookandcolum($book_id);
		$count = C::t('#jameson_read#jamesonread_colums')->count_by_id('book_id',$book_id,false);
		$page = new Page($count,50,'./admin.php?action=plugins&operation=config&identifier=jameson_read&pmod=addbook&opbook=addoredit&formhash='.FORMHASH.'&book_id='.$book_id);//章节分页
		$colums = C::t('#jameson_read#jamesonread_colums')->fetch_thread_bybid($book_id,$page->getStart(),$page->getSize());
		$pageshow = $page->show();
	}
	include template('jameson_read:addoredit');
}else {
	/*如果有提交动作*/
		$data = array();
		$data['book_name'] = addslashes(dhtmlspecialchars(trim($_GET['addbookname'])));
		$data['category_id'] = intval($_GET['categoryId']);
		$data['author'] = addslashes(dhtmlspecialchars(trim($_GET['addbookauthor'])));
		$data['addtime'] = time();
		$data['ordernum'] = intval($_GET['addbookorder']);
		$data['plan'] = intval($_GET['addbookplan']);
		$data['desco'] = addslashes(dhtmlspecialchars(trim($_GET['addbookdesco'])));
		$data['fletter'] = addslashes(dhtmlspecialchars(trim($_GET['addbookfletter'])));
		$data['image'] = $message = '';
		$data['is_top'] = trim($_GET['is_top']) == 'on'?1:0;
		$data['views'] = intval($_GET['addbookviews'])?intval($_GET['addbookviews']):100;
		$data['favores'] = intval($_GET['addfavores'])?intval($_GET['addfavores']):100;
		/*如果有上传图片则处理*/
		if(isset($_FILES['addbookimage'])){
			$upload = new discuz_upload();
			$upload->init($_FILES['addbookimage'],'forum');
			if($upload->is_image_ext($upload->fileext($_FILES['addbookimage']['name']))){
				if($upload->save()){
					$data['image'] = $upload->attach['attachment'];
				}else{
					$message = '#'.lang('plugin/jameson_read','addbookerror');
				}
			}else{
				$message = '#'.lang('plugin/jameson_read','imggeshierror');
			}
			unset($upload);
		}
		// 更新
		if($book_id>0){
			C::t('#jameson_read#jamesonread_books')->update($book_id,$data);
		}else{
			//插入
			C::t('#jameson_read#jamesonread_books')->insert($data);
		}
	/*提交时更新所有*/
	cpmsg(lang('plugin/jameson_read','addbooksuccess').$message, 'action=plugins&operation=config&identifier=jameson_read&pmod=addbook', 'succeed');
}