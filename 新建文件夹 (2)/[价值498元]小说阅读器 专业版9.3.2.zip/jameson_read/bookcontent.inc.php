<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
require_once './source/plugin/jameson_read/class/page.class.php';
/**
*书籍目录页
*
*/
$book_id = intval($_GET['book_id']);
//取得金币信息
$trame = $_G['cache']['plugin']['jameson_read']['trame']?$_G['cache']['plugin']['jameson_read']['trame']:2;
$trame_name = $_G['setting']['extcredits'][$trame]['title'];
$allcolums = intval(C::t('#jameson_read#jamesonread_colums')->count_by_id('book_id',$book_id));
$page = new Page($allcolums,10,'./plugin.php?id=jameson_read:bookcontent&book_id='.$book_id);
$pageshow = $page->show();
/*获得本书中所有的章节号和帖子tid*/
$tidarray = C::t('#jameson_read#jamesonread_colums#')->fetch_by_book($book_id,'tid,zhangjie',0,$page->getStart(),$page->getSize());
/*获得本书最近发布的5篇章节帖子tid*/
$newtidarray = C::t('#jameson_read#jamesonread_colums#')->fetch_by_newmulu($book_id,'tid,zhangjie',5);
//默认点评发布在目录排序第一的帖子中
$morendianpingtid = $tidarray[0]['tid'];
// 允许点评的用户组
$usegroupdianping = unserialize($_G['cache']['plugin']['jameson_read']['usegroupdianping']);
//用户已登录，用户组允许发布点评、存在至少一个章节才允许发布
if($_G['uid'] && in_array($_G['groupid'],$usegroupdianping) && $morendianpingtid){
	$allowdianping = true; //是否允许点评
}else{
	$allowdianping = false;
}

/*获得本书的信息*/
$booknamearray = C::t('#jameson_read#jamesonread_books')->fetch($book_id);
$navtitle = $booknamearray['book_name'];
if($_G['uid']){
	// 收藏状态
	$bookfavorestat = C::t('#jameson_read#jamesonread_favores')->getstatusbybid($book_id,$_G['uid']);
	$booknamearray['favorestat'] = $bookfavorestat?$bookfavorestat:0;
}else{
	$booknamearray['favorestat'] = 0;
}
/*取得10条排行榜数据*/
$saleorder = C::t('#jameson_read#jamesonread_books')->fetch_readorder(0,10);
$scoresorder = C::t('#jameson_read#jamesonread_books')->fetch_by_scores(0,10);
$favoresorder = C::t('#jameson_read#jamesonread_books')->fetch_by_favores(0,10);
/*取得本书的分类信息*/
$categoryarray = C::t('#jameson_read#jamesonread_categorys')->fetch($booknamearray['category_id']);
//取得10条本类下图书
$thiscate = C::t('#jameson_read#jamesonread_books')->fetch_samebook($booknamearray['category_id'],10);
$subjectarray = array();/*组装目录数据*/
if(is_array($tidarray) && !empty($tidarray)){
	while (list($key,$value) = each($tidarray)) {
		$tid = $value['tid'];
		$subjectarray[$key]['tid'] = $tid;
		$subjectarray[$key]['zhangjie'] = $value['zhangjie'];
		$tmp = C::t('forum_thread')->fetch($tid);
		if(is_array($tmp)){
			$subjectarray[$key]['subject'] = $tmp['subject'];
			$subjectarray[$key]['price'] = $tmp['price'];
		}else{
			$subjectarray[$key]['subject'] = lang('plugin/jameson_read','thiszhangjienoexists');
		}
	}
}
// 组装最新5条目录
$newsubjectarray = array();/*组装目录数据*/
if(is_array($newtidarray) && !empty($newtidarray)){
	while (list($key,$value) = each($newtidarray)) {
		$tid = $value['tid'];
		$newsubjectarray[$key]['tid'] = $tid;
		$newsubjectarray[$key]['zhangjie'] = $value['zhangjie'];
		$tmp = C::t('forum_thread')->fetch($tid);
		if(is_array($tmp)){
			$newsubjectarray[$key]['subject'] = $tmp['subject'];
			$newsubjectarray[$key]['price'] = $tmp['price'];
		}else{
			$newsubjectarray[$key]['subject'] = lang('plugin/jameson_read','thiszhangjienoexists');
		}
	}
}
//点评数据
$hasdp = 1;//
$dianpings = array();
if($morendianpingtid){
	// 最新10条
	$dianpings = C::t('#jameson_read#jamesonread_books')->fetch_dianpingdata($morendianpingtid);
	// 最热10条
	$hotdianpings = C::t('#jameson_read#jamesonread_books')->fetch_dianpingdata_byzhcihi($morendianpingtid);
	$scores = C::t('#jameson_read#jamesonread_books')->fetchscorebytid($morendianpingtid);
	$dppid = C::t('#jameson_read#jamesonread_books')->getpidbytid($morendianpingtid);
	if($allowdianping){
		if(intval(C::t('#jameson_read#jamesonread_books')->hasdp($_G['uid'],$morendianpingtid,$dppid))<intval($_G['cache']['plugin']['jameson_read']['dianpingnums'])){
			// 如果已经点评小于允许，则置为0，允许继续点评
			$hasdp = 0;
		}
	}
}
include template("diy:bookcontent",0,'./source/plugin/jameson_read/template');