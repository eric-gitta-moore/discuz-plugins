<?php
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
$sqlcreate = <<<EOF
	CREATE TABLE IF NOT EXISTS `cdb_jamesonread_users` (
	 `user_id` int(11) NOT NULL auto_increment,
	 `uid` int(11) NOT NULL,
	 `tid` text,
	 `book_id` int(11),
	 `addtime` int(11) NOT NULL,
	 `price` int(11) NOT NULL,
	 PRIMARY KEY (`user_id`)
	) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `cdb_jamesonread_dianping` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `authorid` int(11) NOT NULL,
  `zhichi` int(10) NOT NULL default '0',
  `fandui` int(10) NOT NULL default '0',
  `addtime` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
CREATE TABLE  IF NOT EXISTS `cdb_jamesonread_navs` (
  `nav_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `href` varchar(255) NOT NULL,
  `bei1` varchar(255) DEFAULT NULL,
  `bei2` varchar(255) DEFAULT NULL,
  `order` int(2) unsigned NOT NULL DEFAULT '1' ,
  PRIMARY KEY (`nav_id`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `cdb_jamesonread_favores` (
  `favore_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `book_id` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`favore_id`)
) ENGINE=MyISAM;
EOF;
runquery($sqlcreate);
$res = DB::fetch_first("select * from ".DB::table('jamesonread_books'));
if(!empty($res)){
	if(!isset($res['plan'])){
		runquery("alter table cdb_jamesonread_books add `plan` int(8) default '10'");
	}
	if(!isset($res['uid'])){
		runquery("alter table cdb_jamesonread_books add `uid` int(11) NOT NULL");
	}
	if(!isset($res['favores'])){
		runquery("alter table cdb_jamesonread_books add `favores` int(11) default '100'");
	}
	if(!isset($res['scores'])){
		runquery("alter table cdb_jamesonread_books add `scores` int(11) not null default '0'");
	}
	if(!isset($res['dpcount'])){
		runquery("alter table cdb_jamesonread_books add `dpcount` int(11) not null default '0'");
	}
	if(!isset($res['fletter'])){
		runquery("alter table cdb_jamesonread_books add `fletter` char(20)");
	}
}else{
	$newbook =<<<NEWBOOK
		DROP TABLE IF EXISTS `cdb_jamesonread_books`;
		CREATE TABLE IF NOT EXISTS `cdb_jamesonread_books` (
		  `book_id` int(11) NOT NULL auto_increment,
		  `ordernum` int(6) NOT NULL default '1',
		  `uid` int(11) NOT NULL default '1',
		  `category_id` int(11) NOT NULL,
		  `book_name` char(255) NOT NULL,
		  `views` int(8) NOT NULL default '100',
		  `author` char(255) NOT NULL,
		  `desco` text,
		  `addtime` int(11) NOT NULL,
		  `image` char(255),
		  `is_display` tinyint(1) NOT NULL default '1',
		  `is_top` tinyint(1) NOT NULL default '0',
		  `plan` int(8) NOT NULL default '10',
		  `favores` int(11) NOT NULL default '100',
		  `scores` int(11) NOT NULL default '1',
		  `dpcount` int(11) NOT NULL default '1',
		  `fletter` char(20),
		  PRIMARY KEY  (`book_id`)
		) ENGINE=MyISAM;
NEWBOOK;
}
runquery($newbook);
updatecache();
$file = array('SC_GBK','SC_UTF8','TC_BIG5','TC_UTF8');
foreach ($file as $value) {
	if(is_file('./source/plugin/jameson_read/install.php')){
		@unlink('./source/plugin/jameson_read/install.php');
	}
	@unlink('./source/plugin/jameson_read/upgrade.php');
	if(is_file('./source/plugin/jameson_read/discuz_plugin_jameson_read_'.$value.'.xml')){
		@unlink('./source/plugin/jameson_read/discuz_plugin_jameson_read_'.$value.'.xml');
	}
}
$finish =true;