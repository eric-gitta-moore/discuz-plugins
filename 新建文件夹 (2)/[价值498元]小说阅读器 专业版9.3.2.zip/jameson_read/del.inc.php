<?php
// 点评ajax请求
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
// 删除请求
if($_GET['formhash'] != FORMHASH || ($_G['uid'] != 1)){
	echo 0;
	exit;
}
switch ($_GET['type']) {
	case 'dp':
		$dpid = intval($_GET['dpid']);
		if($dpid && C::t('forum_postcomment')->delete($dpid)){
			C::t('#jameson_read#jamesonread_dianping')->delete($dpid);
			echo 1;
		}else{
			echo 0;
		}
		break;
}