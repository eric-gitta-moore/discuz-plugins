<?php
// 点评ajax请求
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
if(!isset($_GET['zhichi']) && intval($_GET['tid']) && trim($_GET['comment'])){
		$book_id = intval($_GET['book_id']);
		$data = array();
		$data['tid'] = intval($_GET['tid']);
		$data['pid'] = intval($_GET['pid']);
		$data['author'] = $_G['username'];
		$data['authorid'] = $_G['uid'];
		$data['comment'] = addslashes(dhtmlspecialchars(trim($_GET['comment'])));
		$data['score'] = intval($_GET['score']);
		$data['dateline'] = time();
		if($newid = C::t('forum_postcomment')->insert($data,true)){
			C::t("#jameson_read#jamesonread_dianping")->insert(array(
				'id'=>$newid,
				'addtime'=>time(),
				'tid'=>$data['tid'],
				'pid'=>$data['pid'],
				'authorid'=>$data['authorid']
				));
			C::t("#jameson_read#jamesonread_books")->update_scores($book_id,$data['score']);
			C::t("#jameson_read#jamesonread_books")->update_dpcount($book_id);
			echo '<a href="./home.php?mod=space&uid='.$_G['uid'].'" class="z">
				<img src="./uc_server/avatar.php?uid='.$_G['uid'].'&size=small">
				</a>
				<div class="z fctrl">
				<span class="xg2">'.lang('plugin/jameson_read','shijianganggang').'</span>
				<span class="pipe"> | </span>
				<span class="xg2">'.lang('plugin/jameson_read','zuozhewo').'</span>
				<span class="rate"><span style="width:'.($data['score']*20).'%">&nbsp;</span></span>
				<span class="pipe"> | </span>
				<span class="zhichi" onclick="zhichi('.$newid.',this,1)">'.lang('plugin/jameson_read','ding').'<em>0</em></span>
				<span class="fandui" onclick="zhichi('.$newid.',this,0)">'.lang('plugin/jameson_read','cai').'<em>0</em></span>
				<p>'.dhtmlspecialchars($_GET['comment']).'</p>
				</div>';
		}else{
			echo 0;
		}
}else {
	$id = intval($_GET['dpid']);
	$action = intval($_GET['action']);
	if($action){
		$res = C::t("#jameson_read#jamesonread_dianping")->update_zhichi($id);
		if(!$res){
			C::t("#jameson_read#jamesonread_dianping")->insert(array('id'=>$id,'zhichi'=>1,'fandui'=>0),true);
			$res = 1;
		}
	}else{
		$res = C::t("#jameson_read#jamesonread_dianping")->update_fandui($id);
		if(!$res){
			C::t("#jameson_read#jamesonread_dianping")->insert(array('id'=>$id,'zhichi'=>0,'fandui'=>1),true);
			$res = 1;
		}
	}
	echo intval($res);
}