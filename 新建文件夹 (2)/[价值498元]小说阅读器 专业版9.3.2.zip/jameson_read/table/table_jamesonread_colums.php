<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denid');
}
/**
* 
*/
class table_jamesonread_colums extends discuz_table
{
	
	function __construct()
	{
		$this->_table = 'jamesonread_colums';
		$this->_pk = 'colum_id';
		parent::__construct();
	}

	function fetch_by_book($book_id,$field,$uid=0,$start=0,$size=10){
		if($uid>0){
			return DB::fetch_all("SELECT %i FROM %t WHERE book_id=%d AND uid=%d ORDER BY zhangjie ASC,addtime ASC LIMIT %d,%d",array($field,$this->_table,$book_id,$uid,$start,$size));
		}
		return DB::fetch_all("SELECT %i FROM %t WHERE book_id=%d ORDER BY zhangjie ASC,addtime ASC LIMIT %d,%d",array($field,$this->_table,$book_id,$start,$size));
	}

	function fetch_by_newmulu($book_id,$field,$num){
		
		return DB::fetch_all("SELECT %i FROM %t WHERE book_id=%d ORDER BY addtime DESC LIMIT %d",array($field,$this->_table,$book_id,$num));
	}
	function count_by_id($idkey,$idvalue,$res=false){
		if($res){
			return DB::fetch_all("SELECT * FROM %t WHERE %i=%d",array($this->_table,$idkey,$idvalue));
		}
		return DB::result_first("SELECT count(*) FROM %t WHERE %i=%d",array($this->_table,$idkey,$idvalue));
	}

	function fetch_next_pre($book_id,$zhangjie,$tid,$compare='>'){
		if($compare == '>'){
			$res = DB::fetch_all("SELECT tid,zhangjie FROM %t WHERE book_id=%d AND zhangjie ".$compare." $zhangjie AND tid !=%d ORDER BY zhangjie,addtime LIMIT 1",array($this->_table,$book_id,$tid));
		}else{
			$res = DB::fetch_all("SELECT tid,zhangjie FROM %t WHERE book_id=%d AND zhangjie ".$compare." $zhangjie AND tid !=%d ORDER BY zhangjie DESC,addtime DESC LIMIT 1",array($this->_table,$book_id,$tid));
		}
		
		foreach ($res as $key => $value) {
			$res[$key]['price'] = DB::result_first("SELECT price FROM %t WHERE tid=%d",array('forum_thread',$value['tid']));
		}
		return $res;
	}
	function update_bytid($tid,$data){
		$pkid = $this->getpkid_bytid($tid);
		return $this->update($pkid,$data);
	}
	function getpkid_bytid($tid){
		return DB::result_first("SELECT colum_id FROM %t WHERE tid=%d",array($this->_table,$tid));
	}
	function fetch_bytid($tid){
		$pkid = $this->getpkid_bytid($tid);
		return $this->fetch($pkid);
	}
	function getpidbytid($tid){
		return DB::result_first("SELECT pid FROM %t WHERE tid=%d AND first=1",array('forum_post',$tid));
	}

	function fetch_thread_bybid($book_id,$start=0,$size=0){
		if($size){
			$tid = $this->fetch_by_book($book_id,'*',0,$start,$size);
		}else{
			$tid = DB::fetch_all("SELECT * FROM %t WHERE book_id=%d ORDER BY zhangjie ASC,addtime ASC",array($this->_table,$book_id));
		}
		$thread = array();
		foreach ($tid as $key => $value) {

			if($value['tid']>0){
				$thread[$value['tid']] = $value;
				$thread[$value['tid']]['subject'] = DB::result_first("SELECT subject FROM %t WHERE tid=%d",array('forum_thread',$value['tid']));
				if(!$thread[$value['tid']]['subject']){
					unset($thread[$value['tid']]);
					$this->delete($value['colum_id']);
					continue;
				}
				$thread[$value['tid']]['price'] = DB::result_first("SELECT price FROM %t WHERE tid=%d",array('forum_thread',$value['tid']));
				$thread[$value['tid']]['fid'] = DB::result_first("SELECT fid FROM %t WHERE tid=%d",array('forum_thread',$value['tid']));
				$thread[$value['tid']]['authorid'] = DB::result_first("SELECT authorid FROM %t WHERE tid=%d",array('forum_thread',$value['tid']));
				$thread[$value['tid']]['pid'] = $this->getpidbytid($value['tid']);
			}
		}
		return $thread;
	}

	function fetch_zhangjie($book_id){
		return floatval(DB::result_first("SELECT zhangjie FROM %t WHERE book_id=%d ORDER BY zhangjie DESC",array($this->_table,$book_id)))+1;
	}
}