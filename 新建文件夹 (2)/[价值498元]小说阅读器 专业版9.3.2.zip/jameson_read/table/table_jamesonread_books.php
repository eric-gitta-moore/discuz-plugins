<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denid');
}
/**
* 
*/
class table_jamesonread_books extends discuz_table
{
	
	function __construct()
	{
		$this->_table = 'jamesonread_books';
		$this->_pk = 'book_id';
		parent::__construct();
	}

	// 如果第三个参数为false，则统计条数返回int，否则查询记录返回数组；如果存在第一个和第二个参数则添加where，
	function fetch_by_id($field,$contind,$res=false,$start=0,$size=10,$uid=1){
		//如果只是获取记录条数
		if(!$res){
			if(!empty($field) && !empty($contind)){
				if($uid > 1){
					return DB::result_first("SELECT count(*) FROM %t WHERE %i=%d AND uid=%d",array($this->_table,$field,$contind,$uid));
				}
				return DB::result_first("SELECT count(*) FROM %t WHERE %i=%d",array($this->_table,$field,$contind));
			}
			if($uid > 1){
				return DB::result_first("SELECT count(*) FROM %t WHERE uid=%d",array($this->_table,$uid));
			}
			return DB::result_first("SELECT count(*) FROM %t",array($this->_table));
		}
		//获取记录返回数组
		if(!empty($field) && !empty($contind)){
			//有条件获取
			if($uid > 1){
				return DB::fetch_all("SELECT * FROM %t WHERE %i=%d AND uid=%d ORDER BY ordernum DESC LIMIT %d,%d",array($this->_table,$field,$contind,$uid,$start,$size));
			}
			return DB::fetch_all("SELECT * FROM %t WHERE %i=%d ORDER BY ordernum DESC LIMIT %d,%d",array($this->_table,$field,$contind,$start,$size));
		}
		//获取所有
		if($uid > 1){
			return DB::fetch_all("SELECT * FROM %t  WHERE uid=%d ORDER BY ordernum DESC LIMIT %d,%d",array($this->_table,$uid,$start,$size));
		}
		return DB::fetch_all("SELECT * FROM %t ORDER BY ordernum DESC LIMIT %d,%d",array($this->_table,$start,$size));
	}

	// 根据category_id获取分页图书记录
	function fetch_by_cid($cid,$start=0,$size){
		if($size){
			if($cid){
				return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d ORDER BY ordernum DESC,addtime DESC LIMIT %d,%d",array($this->_table,$cid,$start,$size));
			}
				return DB::fetch_all("SELECT * FROM %t  ORDER BY ordernum DESC,addtime DESC  LIMIT %d,%d",array($this->_table,$start,$size));
		}
		if($cid){
			return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d  ORDER BY ordernum DESC,addtime DESC ",array($this->_table));
		}
			return DB::fetch_all("SELECT * FROM %t  ORDER BY ordernum DESC,addtime DESC ",array($this->_table));
	}

	// 获取相似图书
	function fetch_samebook($cid,$num){
		return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d ORDER BY views DESC,scores DESC LIMIT %d",array($this->_table,$cid,$num));
	}

	// 根据category_id获取分页图书记录
	function fetch_by_ciduid($cid,$start=0,$size,$uid){
		if($size){
			if($cid){
				return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d AND uid=%d ORDER BY ordernum DESC,addtime DESC LIMIT %d,%d",array($this->_table,$cid,$uid,$start,$size));
			}
				return DB::fetch_all("SELECT * FROM %t  WHERE uid=%d ORDER BY ordernum DESC,addtime DESC  LIMIT %d,%d",array($this->_table,$uid,$start,$size));
		}
		if($cid){
			return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d  AND uid=%d ORDER BY ordernum DESC,addtime DESC ",array($this->_table,$cid,$uid));
		}
			return DB::fetch_all("SELECT * FROM %t WHERE uid=%d ORDER BY ordernum DESC,addtime DESC ",array($this->_table,$uid));
	}
// 对获取到的图书记录组装已有章节书
	function fetch_bookscolums($cid,$start,$size,$uid=0){
		if($uid){
			$tmp = $this->fetch_by_ciduid($cid,$start,$size,$uid);
		}else{
			$tmp = $this->fetch_by_cid($cid,$start,$size);
		}
		foreach ($tmp as $key => $value) {
			$tmp[$key]['hascolums'] = C::t('#jameson_read#jamesonread_colums')->count_by_id('book_id',$value['book_id'],false);
		}
		return $tmp;
	}
// 对单条图书记录组装已有章节书
	function fetch_bookandcolum($book_id){
		$book = $this->fetch($book_id);
		$book['hascolums'] = DB::result_first('SELECT count(*) FROM %t WHERE book_id=%d',array('jamesonread_colums',$book_id));
		return $book;
	}


	function count_by_cid($cid,$uid=0){
		if($uid){
			return DB::result_first("SELECT count(*) FROM %t WHERE category_id=%d AND uid=%d",array($this->_table,$cid,$uid));
		}
		return DB::result_first("SELECT count(*) FROM %t WHERE category_id=%d",array($this->_table,$cid));
	}
	function fetch_readorder($cate=0,$num,$recomend=false)
	{
		if($cate > 0){
			if($recomend){
				return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d ORDER BY is_top DESC,ordernum DESC LIMIT %d",array($this->_table,$cate,$num));
			}
			return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d ORDER BY views DESC LIMIT %d",array($this->_table,$cate,$num));
		}
		if($recomend){
			return DB::fetch_all("SELECT * FROM %t WHERE is_top=1 ORDER BY ordernum DESC LIMIT %d",array($this->_table,$num));
		}
		return DB::fetch_all("SELECT * FROM %t ORDER BY views DESC LIMIT %d",array($this->_table,$num));
	}

	function fetch_by_get($cate=0,$num,$orderfield){
		return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d AND is_top=1 ORDER BY %i DESC,ordernum DESC LIMIT %d",array($this->_table,$cate,$orderfield,$num));
	}
	function fetch_by_getnotop($cate=0,$orderfield,$start,$size){
		if($orderfield == 'fletter'){
			return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d ORDER BY %i,ordernum DESC LIMIT %d,%d",array($this->_table,$cate,$orderfield,$start,$size));
		}
		return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d ORDER BY %i DESC,ordernum DESC LIMIT %d,%d",array($this->_table,$cate,$orderfield,$start,$size));
	}


	function fetch_by_scores($cate=0,$num,$recom=false){
		if(!$recom){
			if(!$cate){
				return DB::fetch_all("SELECT * FROM %t ORDER BY scores DESC LIMIT %d",array($this->_table,$num));
			}
			return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d ORDER BY scores DESC LIMIT %d",array($this->_table,$cate,$num));
		}else{
			if(!$cate){
				return DB::fetch_all("SELECT * FROM %t WHERE is_top=1 ORDER BY scores DESC LIMIT %d",array($this->_table,$num));
			}
			return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d AND is_top=1 ORDER BY scores DESC LIMIT %d",array($this->_table,$cate,$num));
		}
	}
	function fetch_by_favores($cate=0,$num,$recom=false){
		if(!$recom){
			if(!$cate){
				return DB::fetch_all("SELECT * FROM %t ORDER BY favores DESC LIMIT %d",array($this->_table,$num));
			}
			return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d ORDER BY favores DESC LIMIT %d",array($this->_table,$cate,$num));
		}else{
			if(!$cate){
				return DB::fetch_all("SELECT * FROM %t WHERE is_top=1 ORDER BY favores  DESC LIMIT %d",array($this->_table,$num));
			}
			return DB::fetch_all("SELECT * FROM %t WHERE is_top=1 AND  category_id=%d ORDER BY favores DESC LIMIT %d",array($this->_table,$cate,$num));
		}
	}

	function fetch_by_addtime($cate=0,$num,$recom=false){
		if(!$recom){
			if(!$cate){
				return DB::fetch_all("SELECT * FROM %t ORDER BY addtime DESC LIMIT %d",array($this->_table,$num));
			}
			return DB::fetch_all("SELECT * FROM %t WHERE category_id=%d ORDER BY addtime DESC LIMIT %d",array($this->_table,$cate,$num));
		}else{
			if(!$cate){
				return DB::fetch_all("SELECT * FROM %t WHERE is_top=1 ORDER BY addtime  DESC LIMIT %d",array($this->_table,$num));
			}
			return DB::fetch_all("SELECT * FROM %t WHERE is_top=1 AND  category_id=%d ORDER BY addtime DESC LIMIT %d",array($this->_table,$cate,$num));
		}
	}
	function update_views($book_id){
		return DB::query("UPDATE ".DB::table($this->_table)." SET views=views+1 WHERE ".DB::field($this->_pk,$book_id));
	}
	function update_dpcount($book_id){
		return DB::query("UPDATE ".DB::table($this->_table)." SET dpcount=dpcount+1 WHERE ".DB::field($this->_pk,$book_id));
	}
	function update_scores($book_id,$score){
		$score = intval($score);
		return DB::query("UPDATE ".DB::table($this->_table)." SET scores=scores+$score WHERE ".DB::field($this->_pk,$book_id));
	}
	function update_favores($book_id,$action){
		if($action){
			return DB::query("UPDATE ".DB::table($this->table)." SET favores=favores+1");
		}else{
			return DB::query("UPDATE ".DB::table($this->table)." SET favores=favores-1 WHERE ".DB::field($this->_pk,$book_id));
		}
	}

	function fetch_name($book_id){
		return DB::result_first("SELECT book_name FROM %t WHERE book_id=%d",array($this->_table,$book_id));
	}

	// 根据用户获取
	function fetch_by_uid($uid,$start,$size){
		if($size){
			return DB::fetch_all("SELECT * FROM %t WHERE uid=%d LIMIT %d,%d",array($this->_table,$uid,$start,$size));
		}
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d ORDER BY ordernum DESC,addtime DESC",array($this->_table,$uid));
	}

	function count_by_uid($uid){
		return DB::result_first("SELECT count(*) FROM %t WHERE uid=%d",array($this->_table,$uid));
	}

	function getpidbytid($tid){
		return DB::result_first("SELECT pid FROM %t WHERE tid=%d AND first=1",array('forum_post',$tid));
	}
	function fetch_dianpingdata($tid,$orderfield='dateline'){
		$did = $this->getpidbytid($tid);
		if(!$did){
			return false;
		}
		$data = DB::fetch_all("SELECT * FROM %t WHERE tid=%d AND pid=%d ORDER BY %i DESC LIMIT 10",array('forum_postcomment',$tid,$did,$orderfield));
		foreach ($data as $key => $value) {
			$tmp = DB::fetch_first("SELECT zhichi,fandui FROM %t WHERE id=%d",array('jamesonread_dianping',$value['id']));
			$data[$key]['zhichi'] = intval($tmp['zhichi']);
			$data[$key]['fandui'] = intval($tmp['fandui']);
		}
		return $data;
	}
	function fetch_dianpingdata_byzhcihi($tid,$orderfield='zhichi'){
		$did = $this->getpidbytid($tid);
		if(!$did){
			return false;
		}
		$dp = array();
		$data = DB::fetch_all("SELECT * FROM %t WHERE tid=%d AND pid=%d ORDER BY %i DESC LIMIT 10",array('jamesonread_dianping',$tid,$did,$orderfield));
		foreach ($data as $key => $value) {
			$tmp = DB::fetch_first("SELECT * FROM %t WHERE id=%d",array('forum_postcomment',$value['id']));
			$dp[$key] = array_merge($tmp,$value);
		}
		return $dp;
	}
	function fetchscorebytid($tid){
		$did = $this->getpidbytid($tid);
		if(!$did){
			return false;
		}
		$allscore = DB::fetch_all("SELECT score FROM %t WHERE tid=%d AND pid=%d",array('forum_postcomment',$tid,$did));
		$count = count($allscore)?count($allscore):1;
		$sumscore = 0;
		$one = $two = $three = $four = $five = 0;
		foreach ($allscore as $key => $value) {
			$sumscore += $value['score'];
			switch ($value['score']) {
				case '1':
					$one++;
					break;
				case '2':
					$two++;
					break;
				case '3':
					$three++;
					break;
				case '4':
					$four++;
					break;
				case '5':
					$five++;
					break;
			}
		}
		return array(
			0=>array('num'=>$count,'scores'=>$sumscore),
			1=>array('num'=>$one,  'bili'=>round($one/$count,4)*100),
			2=>array('num'=>$two,  'bili'=>round($two/$count,4)*100),
			3=>array('num'=>$three,'bili'=>round($three/$count,4)*100),
			4=>array('num'=>$four, 'bili'=>round($four/$count,4)*100),
			5=>array('num'=>$five, 'bili'=>round($five/$count,4)*100),
			);
	}

	// 查询是否点评过
	function hasdp($authorid,$tid,$pid){
		return DB::result_first("SELECT count(*) FROM %t WHERE authorid=%d AND tid=%d AND pid=%d",array('forum_postcomment',$authorid,$tid,$pid));
	}

	//根据book_id获取一级分类二级分类及书名
	function fetch_nav_bybid($book_id){
		$data = array();
		$book_name = DB::fetch_first("SELECT book_name,category_id FROM %t WHERE book_id=%d",array($this->_table,$book_id));
		$tmp1 = DB::fetch_first("SELECT category_id,category_name,parent_id FROM %t WHERE category_id=%d",array('jamesonread_categorys',$book_name['category_id']));
		$tmp2 = DB::fetch_first("SELECT category_id,category_name FROM %t WHERE category_id=%d",array('jamesonread_categorys',$tmp1['parent_id']));
		return array(1=>array('cid'=>$tmp2['category_id'],'name'=>$tmp2['category_name']),2=>array('cid'=>$tmp1['category_id'],'name'=>$tmp1['category_name']),3=>array('bid'=>$book_id,'name'=>$book_name['book_name']));

	}

	function count_search($text){
		return intval(DB::result_first("SELECT count(*) FROM 
		".DB::table($this->_table)." WHERE book_name like '%".$text."%'"));
	}
	function fetch_search($text,$start,$size){
		return DB::fetch_all("SELECT * FROM ".DB::table($this->_table)." WHERE book_name like '%".$text."%' LIMIT ".$start.",".$size);
	}
}