<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denid');
} 
/**
* 
*/
class table_jamesonread_navs extends discuz_table
{
	
	function __construct()
	{
		$this->_table = 'jamesonread_navs';
		$this->_pk = 'nav_id';
		parent::__construct();
	}

	function fetch_all(){
		return DB::fetch_all("SELECT * FROM %t ORDER BY `order` DESC",array($this->_table));
	}
	function update_or_insert($order,$name,$href,$action){
		foreach ($name as $key => $value) {
			if($action == 'update'){
				if(!$value){
					$this->delete($key);
				}
				$this->update($key,array('order'=>intval($order[$key]),'name'=>addslashes($value),'href'=>addslashes($href[$key]) ));
			}else{
				if($value){
					$this->insert(array('order'=>intval($order[$key]),'name'=>addslashes($value),'href'=>addslashes($href[$key]) ));
				}
			}
		}
	}
}