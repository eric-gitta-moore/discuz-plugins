<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denid');
}
/**
* 
*/
class table_jamesonread_users extends discuz_table
{
	
	function __construct()
	{
		$this->_table = 'jamesonread_users';
		$this->_pk = 'user_id';
		parent::__construct();
	}


	function count_by_id($idkey,$idvalue,$res=false){
		if($res){
			return DB::fetch_all("SELECT * FROM %t WHERE %i=%d",array($this->_table,$idkey,$idvalue));
		}
		return DB::result_first("SELECT count(*) FROM %t WHERE %i=%d",array($this->_table,$idkey,$idvalue));
	}

	function getpk_byuid($uid){
		return DB::result_first("SELECT user_id FROM %t WHERE uid=%d",array($this->_table,$uid));
	}

	function updateorinsert($uid,$tid,$price){
		$count = DB::result_first("SELECT count(*) FROM %t WHERE uid=%d",array($this->_table,$uid));
		$pk = $this->getpk_byuid($uid);
		if($count){
			// 存在则更新
			// 先取出原有数据组装
			$old 	= $this->fetch($pk);
			$tidarr = unserialize($old['tid']);
			$tidarr[$tid] = 1;
			return $this->update($pk,array('price'=>$old['price']+$price,'tid'=>serialize($tidarr)));
		}else{
			// 否则则插入
			return $this->insert(array('uid'=>$uid,'tid'=>serialize(array($tid=>1)),'addtime'=>time(),'book_id'=>0,'price'=>$price));
		}
	}

	function trans($buy,$author,$price,$extcredits){
		// echo "UPDATE ".DB::table('common_member_count')." SET ".$extcredits."=".$extcredits."-".$price." WHERE uid=".$buy;
		$res1 = DB::query("UPDATE ".DB::table('common_member_count')." SET ".$extcredits."=".$extcredits."-".$price." WHERE uid=".$buy);
		// echo '<br>';
		// echo "UPDATE ".DB::table('common_member_count')." SET ".$extcredits."=".$extcredits."+".$price." WHERE uid=".$author;
		$res2 = DB::query("UPDATE ".DB::table('common_member_count')." SET ".$extcredits."=".$extcredits."+".$price." WHERE uid=".$author);
		return $res1 && $res2;
	}

	function fetch_price($uid){
		return DB::result_first("SELECT price FROM %t WHERE uid=%d",array($this->_table,$uid));
	}
}