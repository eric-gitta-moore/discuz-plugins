<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denid');
}
/**
* 
*/
class table_jamesonread_categorys extends discuz_table
{
	
	function __construct()
	{
		$this->_table = 'jamesonread_categorys';
		$this->_pk = 'category_id';
		parent::__construct();
	}

	function fetch_all_parent($parentid){
		return DB::fetch_all("SELECT * FROM %t WHERE parent_id=%d ORDER BY ordernum DESC",array($this->_table,$parentid));
	}

	function fetch_all_cate(){
		$tmp = $this->fetch_all_parent(0);
		foreach ($tmp as $key => $value) {
			
			$tmp[$key]['sub'] = $this->fetch_all_parent($value['category_id']);
		}
		return $tmp;
	}

	function fetch_name($category_id){
		return DB::result_first("SELECT category_name FROM %t WHERE category_id=%d",array($this->_table,$category_id));
	}
}