<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denid');
}
/**
* 
*/
class table_jamesonread_favores extends discuz_table
{
	
	function __construct()
	{
		$this->_table = 'jamesonread_favores';
		$this->_pk = 'favore_id';
		parent::__construct();
	}

	function getpkbybid($book_id){
		return DB::result_first("SELECT favore_id FROM %t WHERE book_id=%d",array($this->_table,$book_id));
	}

	function updateorinsert($book_id,$data){
		if($pk = $this->getpkbybid($book_id)){
			return $this->update($pk,$data);
		}else{
			return $this->insert($data);
		}
	}

	function getstatusbybid($book_id,$uid){
		return DB::result_first("SELECT status FROM %t WHERE book_id=%d AND uid=%d",array($this->_table,$book_id,$uid));
	}

	function countbyuid($uid){
		return DB::result_first("SELECT count(*) FROM %t WHERE uid=%d AND status=1",array($this->_table,$uid));
	}

	function fetchbookbyuid($uid){
		$bid = DB::fetch_all("SELECT book_id FROM %t WHERE uid=%d AND status=1",array($this->_table,$uid));
		$res = array();
		foreach ($bid as $book_id) {
			$res[$book_id['book_id']] = DB::fetch_first("SELECT book_name,author,desco,plan FROM %t WHERE book_id=%d",array('jamesonread_books',$book_id['book_id']));
		}
		return $res;
	}
}