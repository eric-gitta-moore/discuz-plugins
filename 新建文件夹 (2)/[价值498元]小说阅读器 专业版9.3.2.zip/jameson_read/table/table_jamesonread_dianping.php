<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denid');
}
/**
* 
*/
class table_jamesonread_dianping extends discuz_table
{
	
	function __construct()
	{
		$this->_table = 'jamesonread_dianping';
		$this->_pk = 'id';
		parent::__construct();
	}
	function update_zhichi($id){
		return DB::query("UPDATE ".DB::table($this->_table)." SET zhichi=zhichi+1 WHERE ".DB::field($this->_pk,$id));
		
	}
	function update_fandui($id){
		return DB::query("UPDATE ".DB::table($this->_table)." SET fandui=fandui+1 WHERE ".DB::field($this->_pk,$id));
	}
}