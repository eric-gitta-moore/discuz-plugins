<?php
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')) {
	exit('Access Denied');
}
// 删除分类操作
if(isset($_GET['operation']) && (trim($_GET['operation']) == 'del') && $_GET['formhash'] == FORMHASH  && ($category_id = intval($_GET['category_id']))) {
		C::t('#jameson_read#jamesonread_categorys')->delete($category_id);
		cpmsg(lang('plugin/jameson_read','deletecategorysuccess'), 'action=plugins&operation=config&identifier=jameson_read&pmod=category', 'succeed');
}
  // 显示分类
if(!submitcheck('editsubmit')) {
	$categorys = C::t('#jameson_read#jamesonread_categorys')->fetch_all_cate();
	include template('jameson_read:admincate');
}else {
	/*增加子类*/
	if(isset($_GET['newsubcate']) && is_array($_GET['newsubcate'])){
		foreach ($_GET['newsubcate'] as $key => $value) {
			if(is_array($value) && !empty($value)){
				/*只针对填写了分类名字的input*/
				foreach ($value as $key2 => $value2) {
					if($value2){
						C::t('#jameson_read#jamesonread_categorys')->insert(array('category_name'=>addslashes(dhtmlspecialchars($value2)),'ordernum'=>intval($_GET['newsuborder'][$key][$key2]),'parent_id'=>$key,'is_top'=>'0','is_display'=>'1','addtime'=>time()));
					}
				}
			}
		}
	}

	/*增加父类*/
	if(isset($_GET['newroot']) && is_array($_GET['newroot'])){
		foreach ($_GET['newroot'] as $key => $value) {
			if(!empty($value)){
				/*只针对填写了分类名字的input*/
				C::t('#jameson_read#jamesonread_categorys')->insert(array('category_name'=>addslashes(dhtmlspecialchars($value)),'ordernum'=>intval($_GET['newrootorder'][$key]),'parent_id'=>'0','is_top'=>'0','is_display'=>'1','addtime'=>time()));
			}
		}
	}
	/*点击提交时更新所有*/
	if(is_array($_GET['name']) && !empty($_GET['name'])){
		foreach ($_GET['name'] as $key => $value) {
			$category_id = intval($key);
			$category_name = addslashes(dhtmlspecialchars($value));
			$ordernum = intval($_GET['order'][$key]);
			C::t('#jameson_read#jamesonread_categorys')->update($key,array('category_name'=>$category_name,'ordernum'=>$ordernum));
		}
	}
	cpmsg(lang('plugin/jameson_read','addnewcategorysuccess'), 'action=plugins&operation=config&identifier=jameson_read&pmod=category', 'succeed');
}