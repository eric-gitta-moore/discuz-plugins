<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

/**
* 
*/
class Page
{
	var $size = 10;
	var $total;
	var $pagenum;
	var $curpage;
	var $url;
	function __construct($total,$size,$url)
	{
		$this->total = $total;
		$this->size = $size;
		$this->pagenum = ceil($this->total/$this->size);
		$this->url = $url;
		$this->curpage = isset($_GET['p']) && intval($_GET['p'])>0?intval($_GET['p']):1;
	}

	function getStart(){
		return ($this->curpage-1)*$this->size;
	}

	function getSize(){
		return $this->size;
	}

	function  show(){
		$pageshow = '';
		for($i=1;$i<=$this->pagenum;$i++){
			if($this->curpage == $i){
				$pageshow .= '<strong>'.$i.'</strong>';
			}else{
				$pageshow .= '<a href="./'.$this->url.'&p='.$i.'">'.$i.'</a>';
			}
		}
		return $pageshow;
	}

	function showprenext(){
		$pre  = '<a class="prev"  href="./'.$this->url.'&p='.($this->curpage-1).'">'.lang('plugin/jameson_read','pre').'</a>';
		$next  = '<a class="nxt" href="./'.$this->url.'&p='.($this->curpage+1).'">'.lang('plugin/jameson_read','next').'</a>';
		if($this->curpage == 1){
			$pre = '<span class="prev">'.lang('plugin/jameson_read','noprepage').'</span>';
		}
		if($this->curpage == $this->pagenum){
			$next = '<span  class="nxt">'.lang('plugin/jameson_read','nonextpage').'</span>';
		}
		return $pre.$next;
	}

}