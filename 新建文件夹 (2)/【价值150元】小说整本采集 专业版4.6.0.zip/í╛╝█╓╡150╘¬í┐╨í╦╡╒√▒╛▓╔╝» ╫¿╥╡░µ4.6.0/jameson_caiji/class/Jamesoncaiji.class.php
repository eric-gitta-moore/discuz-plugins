<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

class Jamesoncaiji
{
	// ��ʼ��
	public static function run(){
		$classname = (isset($_GET['contrl']) && !empty($_GET['contrl'])) ? ucfirst(trim($_GET['contrl'])).'Contrl' : 'IndexContrl';
		$method = (isset($_GET['act']) && !empty($_GET['act'])) ? strtolower(trim($_GET['act'])) : 'index';
		require_once './source/plugin/jameson_caiji/class/'.$classname.'.class.php';
		init_jamesoncaiji();
		$obj = new $classname();
		$obj->$method();
	}
}