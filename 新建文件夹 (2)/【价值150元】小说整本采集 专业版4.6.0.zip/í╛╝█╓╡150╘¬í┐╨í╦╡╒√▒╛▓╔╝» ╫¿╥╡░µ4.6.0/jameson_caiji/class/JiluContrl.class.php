<?php
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
class JiluContrl
{
	function index(){
		global $_G;
		// 首先判断是否存在未采集正文内容的记录
		require_once './source/plugin/jameson_caiji/class/Page.class.php';
		$count = C::t("#jameson_caiji#jamesoncaiji_jilu")->count();
		$page = new Page($count,50,'./admin.php?action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=jilu&act=index');
		$jilus = C::t("#jameson_caiji#jamesoncaiji_jilu")->fetch_all($page->getStart(),$page->getSize());
		foreach ($jilus as $key => $value) {
			if(preg_match("/^\w+$/i", trim($value['guize']))){
				$jilus[$key]['web'] = $this->getsite($value['guize']);
			}else{
				$jilus[$key]['guize'] = '';
			}
		}
		$pageshow = $page->show();
		if($_G['jameson_caiji']['makebook']){
			$categorys = C::t('#jameson_caiji#jamesoncaiji_caijiku')->allcategorys();
		}else{
			$categorys = array();
		}
		include template('jameson_caiji:jilu_index');
	}
	function getsite($guize){
		switch ($guize) {
			case 'qidian':
				return lang('plugin/jameson_caiji','qidian');
				break;
			case 'blnovel':
				return lang('plugin/jameson_caiji','blnovel');
				break;
			case 'xiaoshuotxt':
				return lang('plugin/jameson_caiji','xiaoshuotxt');
				break;
			case 'baishuku':
				return lang('plugin/jameson_caiji','baishuku');
				break;
			case 'qingdiba':
				return lang('plugin/jameson_caiji','qingdiba');
				break;
			case 'bookbao':
				return lang('plugin/jameson_caiji','bookbao');
				break;
			case 'booksuixw':
				return lang('plugin/jameson_caiji','booksuixw');
				break;
			case 'hongxiu':
				return lang('plugin/jameson_caiji','hongxiu');
				break;
			case 'k6uk':
				return lang('plugin/jameson_caiji','k6uk');
				break;
			case 'kanunu8':
				return lang('plugin/jameson_caiji','kanunu8');
				break;
			case 'qb5200':
				return lang('plugin/jameson_caiji','qb5200');
				break;
			case 'tiandizw':
				return lang('plugin/jameson_caiji','tiandizw');
				break;
			case 'wx79':
				return lang('plugin/jameson_caiji','wx79');
				break;
			case 'xs8':
				return lang('plugin/jameson_caiji','xs8');
				break;
			case 'xxsy':
				return lang('plugin/jameson_caiji','xxsy');
				break;
			case 'yiqik':
				return lang('plugin/jameson_caiji','yiqik');
				break;
			case 'bxwx':
				return lang('plugin/jameson_caiji','bxwx');
				break;
			case 'quanshuwang':
				return lang('plugin/jameson_caiji','quanshuwang');
				break;
			case 'dddbbb':
				return lang('plugin/jameson_caiji','dddbbb');
				break;
		}
	}
	function clear(){
		global $_G;
		if(FORMHASH == $_GET['formhash']){
			C::t('#jameson_caiji#jamesoncaiji_jilu')->clear();
			cpmsg(lang('plugin/jameson_caiji','caozuowancheng'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=jilu&act=index', 'succeed');
		}else{
			cpmsg(lang('plugin/jameson_caiji','laiyuanfeifa'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=jilu&act=index', 'error');
		}
	}
	public function delid(){
		global $_G;
		if(FORMHASH == $_GET['formhash'] && $_GET['pkid']){
			if(C::t('#jameson_caiji#jamesoncaiji_jilu')->delete(intval($_GET['pkid']))){
				cpmsg(lang('plugin/jameson_caiji','caozuowancheng'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=jilu&act=index', 'succeed');
			}else{
				cpmsg(lang('plugin/jameson_caiji','caozuoshibai'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=jilu&act=index', 'error');
			}
		}else{
			cpmsg(lang('plugin/jameson_caiji','laiyuanfeifa'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=jilu&act=index', 'error');
		}
	}
}