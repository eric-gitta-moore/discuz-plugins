<?php
set_time_limit(0);
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
class CaijiContrl
{
	function index(){
		global $_G;
		// 如果满足生成图书条件则获取图书分类
		if($_G['jameson_caiji']['makebook']){
			$categorys = C::t('#jameson_caiji#jamesoncaiji_caijiku')->allcategorys();
		}else{
			$categorys = array();
		}
		include template('jameson_caiji:caiji_index');
	}
	// 第一步处理程序,将所有章节链接如caijiku
	function step1 (){
		global $_G;
		if(submitcheck('editsubmit') || (FORMHASH==$_GET['formhash'])){
			$guize = trim($_GET['sites']);
			$autoupdate = $_GET['autoupdate']?1:0;

			if(isset($_GET['iscf']) && $_GET['iscf']){
				// 说明是重新采集的单个章节图书目录页地址
				$url = urldecode(trim($_GET['cxcjsiteurl']));
			}else if(isset($_GET['isnext'])){
				// 如果是多个目录地址同时采集，上一个采集完毕，进行下一个采集
				$holdurls = (array) unserialize(getcookie('holdurls'));
				if($holdurls){
					$url = array_shift($holdurls);
					if($holdurls){
						dsetcookie('holdurls',serialize($holdurls), 0);
					}else{
						dsetcookie('holdurls','', -1000);
					}
				}
			}else{
				// 正常表单提交采集
				$urltmps = explode(PHP_EOL,trim($_GET['siteurl']));
				$holdurls = array();
				$thefirst = 0;
				foreach ($urltmps as $key => $value) {
					$value = trim($value);
					if($value && preg_match("/^http/i",$value)){
						if($thefirst < 1){
							$url = $value;
							$thefirst++;
						}else{
							$holdurls[] = $value;
						}
					}
				}
				if($holdurls){
					dsetcookie('holdurls',serialize($holdurls), 0);
				}
			}
			if(!preg_match("/^http/i",$url) || ($guize == 'no')){
				cpmsg(lang('plugin/jameson_caiji','wangzhiweikong'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=caiji&act=index', 'error');
			}
			// 选择的图书分类
			$category_id = intval($_GET['category_id'])?intval($_GET['category_id']):4;
			// 采集规则是否存在
			if(!is_file('./source/plugin/jameson_caiji/regx/'.$guize.'mulu.php')){
				cpmsg(lang('plugin/jameson_caiji','meizhaodaoguizewenjian'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=caiji&act=index', 'error');
			}
			require_once './source/plugin/jameson_caiji/class/simple_html_dom.php';
			$html = str_get_html(dfsockopen($url));
			if(!$html || !is_object($html)){
				cpmsg(lang('plugin/jameson_caiji','wangzhicuowu'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=caiji&act=index', 'error');
			}
			$articles = array();
			// 加载目录采集规则，生成目录链接列表
			require_once  './source/plugin/jameson_caiji/regx/'.$guize.'mulu.php';
			// 将章节标题 等入库
			if($res = C::t('#jameson_caiji#jamesoncaiji_caijiku')->addku($articles,$guize,$category_id,$url)){
				// 插入记录表
				$sourceid = C::t('#jameson_caiji#jamesoncaiji_jilu')->insert(array(
					'bookurl'=>$url,
					'bookname'=>$articles[1]['bookname']?$articles[1]['bookname']:$articles[0]['bookname'],
					'autoupdate'=>$autoupdate,
					'addtime'=>time(),
					'stattext'=>lang('plugin/jameson_caiji','yicaijimululianjie'),
					'guize'=>$guize,
					'lastid'=>$articles[1]['lastid']
					),true);
				$pages = ceil($res/$_G['jameson_caiji']['evernum']);
				$this->step2($guize,$category_id,$pages,$sourceid,$autoupdate);
			}else{
				cpmsg(lang('plugin/jameson_caiji','caijishibai'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=caiji&act=index', 'error');
			}
		}else{
			cpmsg(lang('plugin/jameson_caiji','laiyuanfeifa'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=caiji&act=index', 'error');
		}
	}
	// 第二步，采集正文内容
	function step2($guize='',$category_id='',$pages='',$sourceid='',$autoupdate){
		global $_G;
		$sourceid = $sourceid>0?$sourceid:$_GET['sourceid'];
		$autoupdate = $autoupdate>0?$autoupdate:$_GET['autoupdate'];
		$guize = trim($_GET['guize'])?trim($_GET['guize']):trim($guize);
		$category_id = intval($_GET['category_id'])?intval($_GET['category_id']):intval($category_id);
		$pages = intval($_GET['pages'])?intval($_GET['pages']):intval($pages);
		// 当前页数
		if(intval($_GET['pagenum'])){
			$currentp = intval($_GET['pagenum']);
		}else{
			$currentp = 1;
		}
		// 下一页
		$nextp = $currentp+1;
		// 采集开始结尾
		$datastart = ($currentp-1)*$_G['jameson_caiji']['evernum'];
		$datasize = $_G['jameson_caiji']['evernum'];
		// 目录页网址
		$bookurl = DB::result_first('SELECT bookurl FROM %t LIMIT 1',array('jamesoncaiji_caijiku'));
		// 如果不存在规则
		if(!is_file('./source/plugin/jameson_caiji/regx/'.$guize.'content.php')){
			cpmsg(lang('plugin/jameson_caiji','meizhaodaoguizewenjian'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=caiji&act=index', 'error');
		}
		$data = C::t('#jameson_caiji#jamesoncaiji_caijiku')->fetch_bypage($datastart,$datasize);
		include_once './source/plugin/jameson_caiji/class/simple_html_dom.php';
			// 根据相应规则获取正文内容
		include_once  './source/plugin/jameson_caiji/regx/'.$guize.'content.php';
		// 挨个更新message字段
		$shibaitotlal = 0;
		foreach ($data as $key => $value) {
			$html = dfsockopen(trim($value['url']));
			if(!$html){
				$shibaitotlal++;
				continue;
			}
			$update = array();
			if($guize =='xsdmzj'){
				$thistext = '';
				$update['message'] = getbodycontent($html,$value['url'],1);
			}else{
				$update['message'] = getbodycontent($html);
			}
			if(dstrlen($update['message'])>10){
				// 采集成功插入数据库
				$res = C::t('#jameson_caiji#jamesoncaiji_caijiku')->update($value['zhangjieid'],$update);
			}else{
				$shibaitotlal++;
			}
		}
		if($nextp > $pages){
			$this->step3($category_id,$shibaitotlal,$sourceid,$autoupdate,$guize);
		}else{
			echo 
			'<h3>'.lang('plugin/jameson_caiji','meiluncaiji').$_G['jameson_caiji']['evernum'].lang('plugin/jameson_caiji','meiluncaijijige').','.lang('plugin/jameson_caiji','tiaozhuandaoxiayiye1').$nextp.lang('plugin/jameson_caiji','tiaozhuandaoxiayiye2').$pages.lang('plugin/jameson_caiji','lun').'<span id="yongshitime" style="color:#f00">0</span></h3>
			<script type="text/javascript">
				setInterval(function(){
					$("yongshitime").innerText = parseInt($("yongshitime").innerText)+1;
				},1000);
				location.href = "./admin.php?action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=caiji&act=step2&category_id='.$category_id.'&guize='.$guize.'&pages='.$pages.'&pagenum='.$nextp.'&sourceid='.$sourceid.'&autoupdate='.$autoupdate.'";
			</script>';
		}
	}
	// 生成图书
	function step3($category_id,$shibaitotlal,$sourceid,$autoupdate,$guize){
		global $_G;
		loadcache('plugin');
		// 取得所有已采集完毕待生成图书的章节
		$data = C::t('#jameson_caiji#jamesoncaiji_caijiku')->fetch_all_message();
		// 章节条数
		$count = C::t('#jameson_caiji#jamesoncaiji_caijiku')->count();
		// 取得图书名字
		$bookname = C::t('#jameson_caiji#jamesoncaiji_caijiku')->fetch_bookname();
		//默认的发布用户
		$postuid = $_G['cache']['plugin']['jameson_caiji']['uid']?intval($_G['cache']['plugin']['jameson_caiji']['uid']):1;
		$postusername = ($postuid > 1)?DB::result_first('SELECT username FROM %t WHERE uid=%d',array('common_member',$postuid)):$_G['username'];
		$book_id = $zishu = 0;
		if($_G['jameson_caiji']['makebook']){
			$book_id = C::t('#jameson_read#jamesonread_books')->insert(array(
				'ordernum'=>1,
				'uid'=>$postuid,
				'category_id'=>$category_id,
				'book_name'=>$bookname,
				'views'=>1,
				'hascol'=>$count,
				'author'=>$_G['jameson_caiji']['author'],
				'addtime'=>time(),
				'is_top'=>1,
				'is_jingxuan'=>1,
				'is_display'=>1,
				'plan'=>0,
				'status'=>1,
				'shuxing'=>lang('plugin/jameson_caiji','shuxingtext')
			),true);
		}
		$jidarr = array();
		$jid = 0;
		if($_G['jameson_caiji']['makebook']){
			$specialthread = 127;
			$statusthread = 544;
		}else{
			$statusthread = 32;
			$specialthread = 0;
		}
		foreach ($data as $key => $value) {
			if($_G['jameson_caiji']['makebook']){
				$messagethread = preg_replace(array("/&nbsp;/i","/script/i"), array("",""),$value['message'])."\r\n\0\0\0jameson_read";
			}else{
				$messagethread = preg_replace(array("/&nbsp;/i","/script/i"), array("",""),$value['message']);
			}
			// 如果满足条件则插入分卷
			if($_G['jameson_caiji']['makebook']){
				if(!in_array($value['juanid'],$jidarr)){
					$jid = C::t('#jameson_read#jamesonread_fenjuan')->insert(array(
						'j_title'=>$value['juantitle'],
						'order_num'=>$value['juanid'],
						'book_id'=>$book_id
						),true);
					$jidarr[] = $value['juanid'];
				}
			}
			if(dstrlen(trim($value['message']))<10){
				continue;
			}
			// 首先插入  thread
			$tid = C::t("forum_thread")->insert(array(
				'fid'=>intval($_G['jameson_caiji']['readfid']),
				'author'=>$postusername,
				'authorid'=>$postuid,
				'subject'=>$value['zhangjietitle'],
				'dateline'=>time(),
				'lastpost'=>time(),
				'lastposter'=>$_G['username'],
				'special'=>$specialthread,
				'status'=>$statusthread,
			),true);
			// 再插入post表
			$pid = C::t('forum_post_tableid')->insert(array('pid'=>''),true);
			C::t('forum_post')->insert('tid:0',array(
				'tid'=>$tid,
				'pid'=>$pid,
				'fid'=>intval($_G['jameson_caiji']['readfid']),
				'first'=>1,
				'author'=>$postusername,
				'authorid'=>$postuid,
				'subject'=>$value['zhangjietitle'],
				'message'=>$messagethread,
				'dateline'=>time(),
				'useip'=>$_G['clientip'],
				'port'=>4995,
				'bbcodeoff'=>-1,
				'smileyoff'=>-1,
				'position'=>1,
			),true);
			$messagelength=ceil(intval(dstrlen($messagethread))/2);
			$zishu += $messagelength;
			// 插入newthread
			C::t('forum_newthread')->insert(array(
					'tid'=>$tid,
					'dateline'=>time(),
					'fid'=>$_G['jameson_caiji']['readfid']
			));
			// 满足条件则插入章节
			if($_G['jameson_caiji']['makebook']){
				C::t('#jameson_read#jamesonread_colums')->insert(array(
					'book_id'=>$book_id,
					'category_id'=>$category_id,
					'uid'=>$postuid,
					'fid'=>intval($_G['jameson_caiji']['readfid']),
					'tid'=>$tid,
					'pid'=>$pid,
					'zhangjie'=>$value['zhangjieid'],
					'addtime'=>time(),
					'j_id'=>$jid,
					'subject'=>$value['zhangjietitle'],
					'length'=>$messagelength
				));
			}
		}
		// 更新记录
		if($_G['jameson_caiji']['makebook']){
			C::t('#jameson_caiji#jamesoncaiji_jilu')->updatejilu(array('stattext'=>lang('plugin/jameson_caiji','yishengchengtushu'),'book_id'=>$book_id),$sourceid);
		}else{
			C::t('#jameson_caiji#jamesoncaiji_jilu')->updatejilu(array('stattext'=>lang('plugin/jameson_caiji','yishengchengtiezi')),$sourceid);
		}
		if($_G['jameson_caiji']['makebook'] && $book_id){
			DB::update('jamesonread_books',array('zishu'=>$zishu),"book_id='".$book_id."'");
		}
		C::t('#jameson_caiji#jamesoncaiji_caijiku')->truncate();
		$holdurls = (array) unserialize(getcookie('holdurls'));
		if($holdurls && $holdurls[0]){
			echo 
			'<h3>'.lang('plugin/jameson_caiji','kaishixiayiben').'<span id="yongshitime" style="color:#f00">0</span></h3>
			<script type="text/javascript">
				setInterval(function(){
					$("yongshitime").innerText = parseInt($("yongshitime").innerText)+1;
				},1000);
				location.href = "'.'./admin.php?action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=caiji&act=step1&formhash='.FORMHASH.'&isnext=1&sites='.$guize.'&category_id='.$category_id.'&autoupdate='.$autoupdate.'";
			</script>';
			// end
		}else{
			cpmsg(lang('plugin/jameson_caiji','yishengchengshibai').$shibaitotlal.']','action=plugins&operation=config&do='.$_GET['do'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=caiji&act=index', 'succeed');
		}

	}
	function getguize($guize){
		switch ($guize) {
			case 'qidian':
				return lang('plugin/jameson_caiji','qidian');
				break;
			case 'blnovel':
				return lang('plugin/jameson_caiji','blnovel');
				break;
			case 'xiaoshuotxt':
				return lang('plugin/jameson_caiji','xiaoshuotxt');
				break;
			case 'baishuku':
				return lang('plugin/jameson_caiji','baishuku');
				break;
			case 'qingdiba':
				return lang('plugin/jameson_caiji','qingdiba');
				break;
			case 'bookbao':
				return lang('plugin/jameson_caiji','bookbao');
				break;
			case 'booksuixw':
				return lang('plugin/jameson_caiji','booksuixw');
				break;
			case 'hongxiu':
				return lang('plugin/jameson_caiji','hongxiu');
				break;
			case 'k6uk':
				return lang('plugin/jameson_caiji','k6uk');
				break;
			case 'kanunu8':
				return lang('plugin/jameson_caiji','kanunu8');
				break;
			case 'qb5200':
				return lang('plugin/jameson_caiji','qb5200');
				break;
			case 'tiandizw':
				return lang('plugin/jameson_caiji','tiandizw');
				break;
			case 'wx79':
				return lang('plugin/jameson_caiji','wx79');
				break;
			case 'xs8':
				return lang('plugin/jameson_caiji','xs8');
				break;
			case 'xxsy':
				return lang('plugin/jameson_caiji','xxsy');
				break;
			case 'yiqik':
				return lang('plugin/jameson_caiji','yiqik');
				break;
			case 'bxwx':
				return lang('plugin/jameson_caiji','bxwx');
				break;
			case 'quanshuwang':
				return lang('plugin/jameson_caiji','quanshuwang');
				break;
			case 'dddbbb':
				return lang('plugin/jameson_caiji','dddbbb');
				break;
		}
	}
}