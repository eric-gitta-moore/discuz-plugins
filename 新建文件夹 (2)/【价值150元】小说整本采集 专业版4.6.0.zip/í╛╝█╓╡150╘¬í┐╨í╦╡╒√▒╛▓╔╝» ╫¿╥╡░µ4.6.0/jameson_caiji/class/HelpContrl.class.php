<?php
// ��̨ר��ͷ��
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}

/**
* 
*/
class HelpContrl
{
	
	function tuijian(){
		global $_G;
		include template('jameson_caiji:help_tuijian');
	}
	function faq(){
		global $_G;
		include template('jameson_caiji:help_faq');
	}
}