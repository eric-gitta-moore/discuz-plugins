<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
require_once libfile('function/jameson','plugin/jameson_caiji');
require_once './source/plugin/jameson_caiji/class/Jamesoncaiji.class.php';
Jamesoncaiji::run();