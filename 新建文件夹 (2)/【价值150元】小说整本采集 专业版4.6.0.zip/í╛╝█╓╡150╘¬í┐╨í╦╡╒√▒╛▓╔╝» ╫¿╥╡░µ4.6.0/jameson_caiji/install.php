<?php
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
$sql =<<<EOF
DROP TABLE IF EXISTS `cdb_jamesoncaiji_jilu`;
CREATE TABLE `cdb_jamesoncaiji_jilu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bookname` varchar(255) NOT NULL,
  `bookurl` varchar(255) NOT NULL,
  `guize` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL,
  `stattext` varchar(255) NOT NULL,
  `autoupdate` int(2) DEFAULT '0',
  `lastid` int(11) DEFAULT '1',
  `book_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
);
DROP TABLE IF EXISTS `cdb_jamesoncaiji_caijiku`;
CREATE TABLE `cdb_jamesoncaiji_caijiku` (
  `zhangjieid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `juanid` int(11) NOT NULL,
  `juantitle` varchar(255) NOT NULL,
  `zhangjietitle` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `message` longtext,
  `bookname` varchar(255) NOT NULL,
  `guize` varchar(255) DEFAULT NULL,
  `category_id` int(11) unsigned NOT NULL,
  `bookurl` varchar(255) NOT NULL,
  PRIMARY KEY (`zhangjieid`)
);
EOF;
runquery($sql);
$finish =true;