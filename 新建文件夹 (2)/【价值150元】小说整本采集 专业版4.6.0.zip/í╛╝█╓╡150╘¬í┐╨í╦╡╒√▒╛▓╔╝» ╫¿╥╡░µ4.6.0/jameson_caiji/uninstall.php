<?php
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_jamesoncaiji_caijiku`;
DROP TABLE IF EXISTS `cdb_jamesoncaiji_jilu`;
EOF;
runquery($sql);
$finish = TRUE;