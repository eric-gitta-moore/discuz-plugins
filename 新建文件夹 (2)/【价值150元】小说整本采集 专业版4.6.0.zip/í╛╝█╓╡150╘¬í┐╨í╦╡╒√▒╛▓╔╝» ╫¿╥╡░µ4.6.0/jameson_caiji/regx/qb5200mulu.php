<?php
/**
 * @Project_name :  
 * @Author: 刘绪 jameson
 * @Date:   2016-02-15 17:36:43
 * @Email: jameson512@outlook.com
 * @Web:http://addon.discuz.com/?@58212.developer
 * @Last Modified by:   刘绪 jameson
 * @Last Modified time: 2016-02-23 13:48:59
 */
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
//遍历所有的文章块元素
$count = $zhangjienum = $lastid = 0;
// 书名
if($_G['charset'] !='utf-8'){
  $thisbookname = diconv($html->find('h1',0)->plaintext,'utf-8',$_G['charset']);
}else{
  $thisbookname = $html->find('h1',0)->plaintext;
}
if(($pos = strpos($url,'index.html')) > 1 ){
   $tmpurl = trim(substr($url,0,$pos),'/');
}else{
   $tmpurl = trim($url,'/');
}
foreach($html->find('table')  as $key=>$article) {
  if($key == 1){
    $count++;
    $articles[$count]['j_title'] = lang('plugin/jameson_caiji','diyijuan');
    $articles[$count]['bookname'] = $thisbookname;
    // 章节
    foreach ($article->find('a') as $key2=>$href) {
      if(isset($startzhangjiekey) && $startzhangjiekey>1){
              // 计划任务中的更新
              if($key2>$startzhangjiekey){
                // 从这里开始采集新章节
                $zhangjienum++;
                $articles[$count]['zhangjie'][$zhangjienum]['href'] = $tmpurl.'/'.trim($href->href);
                // 章节标题
                if($_G['charset'] !='utf-8'){
                  $articles[$count]['zhangjie'][$zhangjienum]['text'] = diconv($href->plaintext,'utf-8',$_G['charset']);
                }else{
                  $articles[$count]['zhangjie'][$zhangjienum]['text'] = $href->plaintext;
                }
              }
            }else{
              $zhangjienum++;
              $lastid++;
              $articles[$count]['zhangjie'][$zhangjienum]['href'] = $tmpurl.'/'.trim($href->href);
              // 章节标题
              if($_G['charset'] !='utf-8'){
                $articles[$count]['zhangjie'][$zhangjienum]['text'] = diconv($href->plaintext,'utf-8',$_G['charset']);
              }else{
                $articles[$count]['zhangjie'][$zhangjienum]['text'] = $href->plaintext;
              }
            }
    }
  }
}
if(isset($startzhangjiekey) && $startzhangjiekey>1){
  $articles[1]['lastid'] = $key2;
}else{
  $articles[1]['lastid'] = $lastid;
}