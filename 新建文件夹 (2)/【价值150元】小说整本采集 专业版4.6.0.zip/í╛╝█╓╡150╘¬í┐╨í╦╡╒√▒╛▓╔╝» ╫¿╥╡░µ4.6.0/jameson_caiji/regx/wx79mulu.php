<?php
/**
 * @Project_name :  
 * @Author: 刘绪 jameson
 * @Date:   2016-02-15 17:36:43
 * @Email: jameson512@outlook.com
 * @Web:http://addon.discuz.com/?@58212.developer
 * @Last Modified by:   刘绪 jameson
 * @Last Modified time: 2016-02-23 13:49:29
 */
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
//遍历所有的文章块元素
$count = $zhangjienum = $lastid = 0;
// 书名
if($_G['charset'] !='utf-8'){
  $thisbookname = diconv($html->find('div.boxtitle',0)->plaintext,'utf-8',$_G['charset']);
}else{
  $thisbookname = $html->find('div.boxtitle',0)->plaintext;
}
$tmpurl = trim($url,'/');
$isjuan = false;
foreach($html->find('div.index',0)->find('dt,dd')  as $key=>$value) {
   if($value->tag == 'dt'){
    // 存在分卷
      $count++;
      $isjuan = true;//设定标识，至少有一个分卷
      if($_G['charset'] != 'utf-8'){
        $articles[$count]['j_title'] = diconv($value->find('h2')->plaintext,'utf-8',$_G['charset']);
      }else{
        $articles[$count]['j_title'] = $value->find('h2')->plaintext;
      }
      $articles[$count]['bookname'] = $thisbookname;
   }else{
     if(!$isjuan){
      // 一个分卷也不存在
        $count = 1;
        $articles[$count]['j_title'] = lang('plugin/jameson_caiji','diyijuan');
        $articles[$count]['bookname'] = $thisbookname;
     }
      foreach ($value->find('a') as $key2=>$href) {
        if(isset($startzhangjiekey) && $startzhangjiekey>1){
          // 计划任务中的更新
          if($key2>$startzhangjiekey){
            // 从这里开始采集新章节
            $zhangjienum++;
            $articles[$count]['zhangjie'][$zhangjienum]['href'] = $tmpurl.'/'.trim($href->href);
            // 章节标题
            if($_G['charset'] !='utf-8'){
              $articles[$count]['zhangjie'][$zhangjienum]['text'] = diconv($href->plaintext,'utf-8',$_G['charset']);
            }else{
              $articles[$count]['zhangjie'][$zhangjienum]['text'] = $href->plaintext;
            }
          }
        }else{
        // 章节
          $zhangjienum++;
          $lastid++;
          $articles[$count]['zhangjie'][$zhangjienum]['href'] = $tmpurl.'/'.trim($href->href);
          // 章节标题
          if($_G['charset'] !='utf-8'){
            $articles[$count]['zhangjie'][$zhangjienum]['text'] = diconv($href->plaintext,'utf-8',$_G['charset']);
          }else{
            $articles[$count]['zhangjie'][$zhangjienum]['text'] = $href->plaintext;
          }
        }
      }
   }
  }
if(isset($startzhangjiekey) && $startzhangjiekey>1){
  $articles[1]['lastid'] = $key2;
}else{
  $articles[1]['lastid'] = $lastid;
}