<?php
/**
 * @Project_name :  
 * @Author: 刘绪 jameson
 * @Date:   2016-02-15 17:36:43
 * @Email: jameson512@outlook.com
 * @Web:http://addon.discuz.com/?@58212.developer
 * @Last Modified by:   刘绪 jameson
 * @Last Modified time: 2016-02-21 16:36:01
 */
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
//遍历所有的文章块元素
function getbodycontent($html){
	global $_G;
	$html = str_get_html($html);
	if($_G['charset'] !='utf-8'){
		$text = diconv(trim($html->find('div[id=content]',0)->plaintext),'utf-8',$_G['charset']);
	}else{
		$text = trim($html->find('div[id=content]',0)->plaintext);
	}
	return $text;
}