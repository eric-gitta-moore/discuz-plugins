<?php
/**
 * @Project_name :  
 * @Author: 刘绪 jameson
 * @Date:   2016-02-15 17:36:43
 * @Email: jameson512@outlook.com
 * @Web:http://addon.discuz.com/?@58212.developer
 * @Last Modified by:   刘绪 jameson
 * @Last Modified time: 2016-02-21 13:21:19
 */
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
//遍历所有的文章块元素
function getbodycontent($html){
	global $_G;
	$html = str_get_html($html);
	foreach ($html->find('div[id=chapterContentWapper]') as $key => $value) {
		if($_G['charset'] !='utf-8'){
			$text = diconv($value->plaintext,'utf-8',$_G['charset']);
		}else{
			$text = $value->plaintext;
		}
	}
	return $text;
}