<?php
/**
 * @Project_name :  
 * @Author: 刘绪 jameson
 * @Date:   2016-02-15 17:36:43
 * @Email: jameson512@outlook.com
 * @Web:http://addon.discuz.com/?@58212.developer
 * @Last Modified by:   刘绪 jameson
 * @Last Modified time: 2016-02-23 13:49:37
 */
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
//遍历所有的文章块元素
$count = $zhangjienum = $lastid = $zhangjietotal = 0;
// 书名
if($_G['charset'] !='utf-8'){
  $thisbookname = diconv($html->find('h1',0)->plaintext,'utf-8',$_G['charset']);
}else{
  $thisbookname = $html->find('h1',0)->plaintext;
}
$thisbookname = substr($thisbookname,0,stripos($thisbookname,'txt'));
foreach($html->find('div[id=yuedu] table') as $key=>$value) {
    // 存在分卷
      $count++;
      if($_G['charset'] != 'utf-8'){
        $articles[$count]['j_title'] = diconv($value->find('th',0)->plaintext,'utf-8',$_G['charset']);
      }else{
        $articles[$count]['j_title'] = $value->find('th',0)->plaintext;
      }
      $articles[$count]['bookname'] = $thisbookname;
      foreach ($value->find('td',0)->find('a') as $tdkey=>$href) {
      // 章节
        $zhangjienum = (($tdkey+1)*3-2)+$zhangjietotal;
        $articles[$count]['zhangjie'][$zhangjienum]['href'] = 'http://www.xiaoshuotxt.com'.trim($href->href);
        // 章节标题
        if($_G['charset'] !='utf-8'){
          $articles[$count]['zhangjie'][$zhangjienum]['text'] = diconv($href->plaintext,'utf-8',$_G['charset']);
        }else{
          $articles[$count]['zhangjie'][$zhangjienum]['text'] = $href->plaintext;
        }
      }
      foreach ($value->find('td',1)->find('a') as $tdkey=>$href) {
      // 章节
        $zhangjienum = (($tdkey+1)*3-1)+$zhangjietotal;
        $articles[$count]['zhangjie'][$zhangjienum]['href'] = 'http://www.xiaoshuotxt.com'.trim($href->href);
        // 章节标题
        if($_G['charset'] !='utf-8'){
          $articles[$count]['zhangjie'][$zhangjienum]['text'] = diconv($href->plaintext,'utf-8',$_G['charset']);
        }else{
          $articles[$count]['zhangjie'][$zhangjienum]['text'] = $href->plaintext;
        }
      }
      foreach ($value->find('td',2)->find('a') as $tdkey=>$href) {
      // 章节
        $zhangjienum = (($tdkey+1)*3)+$zhangjietotal;
        $articles[$count]['zhangjie'][$zhangjienum]['href'] = 'http://www.xiaoshuotxt.com'.trim($href->href);
        // 章节标题
        if($_G['charset'] !='utf-8'){
          $articles[$count]['zhangjie'][$zhangjienum]['text'] = diconv($href->plaintext,'utf-8',$_G['charset']);
        }else{
          $articles[$count]['zhangjie'][$zhangjienum]['text'] = $href->plaintext;
        }
      }
      $zhangjietotal = $zhangjienum;
      ksort($articles[$count]['zhangjie']);
  }
$articles[1]['lastid'] = $lastid;