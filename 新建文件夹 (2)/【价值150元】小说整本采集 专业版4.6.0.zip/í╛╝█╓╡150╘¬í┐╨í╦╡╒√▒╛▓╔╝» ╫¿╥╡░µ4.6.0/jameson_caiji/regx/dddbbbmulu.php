<?php
/**
 * @Project_name :  
 * @Author: 刘绪 jameson
 * @Date:   2016-02-15 17:36:43
 * @Email: jameson512@outlook.com
 * @Web:http://addon.discuz.com/?@58212.developer
 * @Last Modified by:   刘绪 jameson
 * @Last Modified time: 2016-02-23 15:52:16
 */
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
//遍历所有的文章块元素
$count = $zhangjienum = $lastid = 0;
// 书名
if($_G['charset'] !='utf-8'){
  $thisbookname = diconv($html->find('div.mytitle',0)->plaintext,'utf-8',$_G['charset']);
}else{
  $thisbookname = $html->find('div.mytitle',0)->plaintext;
}
// 默认第一卷
$articles[$count]['j_title'] = lang('plugin/jameson_caiji','diyijuan');
$articles[$count]['bookname'] = $thisbookname;
foreach($html->find('div.opf') as $key=>$article) {
    foreach ($article->find('a') as $key2=>$href) {
      if(isset($startzhangjiekey) && $startzhangjiekey>1){
              // 计划任务中的更新
              if($key2>$startzhangjiekey){
                // 从这里开始采集新章节
                $zhangjienum++;
                $articles[$count]['zhangjie'][$zhangjienum]['href'] = 'http://www.dddbbb.net'.trim($href->href);
                // 章节标题
                if($_G['charset'] !='utf-8'){
                    $articles[$count]['zhangjie'][$zhangjienum]['text'] = diconv($href->plaintext,'utf-8',$_G['charset']);
                }else{
                    $articles[$count]['zhangjie'][$zhangjienum]['text'] = $href->plaintext;
                }
              }
            }else{
              $zhangjienum++;
              $lastid++;
              $articles[$count]['zhangjie'][$zhangjienum]['href'] = 'http://www.dddbbb.net'.trim($href->href);
              // 章节标题
              if($_G['charset'] !='utf-8'){
                  $articles[$count]['zhangjie'][$zhangjienum]['text'] = diconv($href->plaintext,'utf-8',$_G['charset']);
              }else{
                  $articles[$count]['zhangjie'][$zhangjienum]['text'] = $href->plaintext;
              }
            }
    }
}
if(isset($startzhangjiekey) && $startzhangjiekey>1){
  $articles[1]['lastid'] = $key2;
}else{
  $articles[1]['lastid'] = $lastid;
}