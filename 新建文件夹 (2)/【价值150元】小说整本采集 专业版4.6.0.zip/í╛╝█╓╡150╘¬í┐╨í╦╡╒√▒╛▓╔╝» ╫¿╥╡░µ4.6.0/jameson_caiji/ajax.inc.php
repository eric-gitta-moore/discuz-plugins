<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
global $_G;
// 比对提交来的后台hash数值和生成的后台hash值,以及提交的页面地址是否是本站的后台地址
if(($_G['uid'] != 1) || (formhash('Only For Discuz! Admin Control Panel')!= $_GET['hashadmin']) || ($_SERVER['HTTP_REFERER']!="http://".$_SERVER['SERVER_NAME'].'/admin.php?action=plugins&operation=config&do='.$_GET['isdo'].'&identifier=jameson_caiji&pmod=jameson_caiji&contrl=jilu&act=index')){
	echo  'error';
	exit;
}
$optype = trim($_GET['optype']);
switch ($optype) {
	case 'changeauto':
		$id = intval($_GET['pkid']);
		if($id<1){
			echo 'error';
		}else{
			$autoupdate = intval($_GET['autoupdate']);
			C::t('#jameson_caiji#jamesoncaiji_jilu')->update($id,array(
					'autoupdate'=>$autoupdate
			));
			echo 'succeed';
			exit;
		}
	break;
}