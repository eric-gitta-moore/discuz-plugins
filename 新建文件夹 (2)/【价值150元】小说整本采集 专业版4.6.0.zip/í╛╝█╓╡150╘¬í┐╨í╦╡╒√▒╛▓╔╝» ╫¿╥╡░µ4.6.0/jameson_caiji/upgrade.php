<?php
if(!defined('IN_ADMINCP') || !defined('IN_DISCUZ')){
	exit('Access Denied');
}
// 增加广告联盟代码
$field = C::t('#jameson_caiji#jamesoncaiji_jilu')->fetch_all_field();
if(!$field['autoupdate']){
	runquery("alter table cdb_jamesoncaiji_jilu add `autoupdate` int(2) default '0'");
}
if(!$field['lastid']){
	runquery("alter table cdb_jamesoncaiji_jilu add `lastid` int(11) default '1'");
}
if(!$field['book_id']){
	runquery("alter table cdb_jamesoncaiji_jilu add `book_id` int(11) default '0'");
}
$file = array('SC_GBK','SC_UTF8','TC_BIG5','TC_UTF8');
foreach ($file as $value) {
	if(is_file('./source/plugin/jameson_caiji/'.$value.'.php')){
		@unlink('./source/plugin/jameson_caiji/'.$value.'.php');
	}
	if(is_file('./source/plugin/jameson_caiji/discuz_plugin_jameson_caiji_'.$value.'.xml')){
		@unlink('./source/plugin/jameson_caiji/discuz_plugin_jameson_caiji_'.$value.'.xml');
	}
}
@unlink('./source/plugin/jameson_caiji/upgrade.php');
$finish =true;