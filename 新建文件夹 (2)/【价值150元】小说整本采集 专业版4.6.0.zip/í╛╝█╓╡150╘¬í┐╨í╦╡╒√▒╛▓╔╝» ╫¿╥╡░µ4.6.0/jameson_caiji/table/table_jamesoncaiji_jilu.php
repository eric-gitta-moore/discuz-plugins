<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denid');
}
/**
* 
*/
class table_jamesoncaiji_jilu extends discuz_table
{
	
	function __construct()
	{
		$this->_table = 'jamesoncaiji_jilu';
		$this->_pk = 'id';
		parent::__construct();
	}
	function fetch_all($start,$size){
		return DB::fetch_all('SELECT * FROM %t ORDER BY addtime DESC LIMIT %d,%d',array($this->_table,$start,$size));
	}
	function updatejilu($data,$id){
		DB::update($this->_table,$data,"id='".$id."'");
		return ture;
	}
	function clear(){
		$this->truncate();
	}
}