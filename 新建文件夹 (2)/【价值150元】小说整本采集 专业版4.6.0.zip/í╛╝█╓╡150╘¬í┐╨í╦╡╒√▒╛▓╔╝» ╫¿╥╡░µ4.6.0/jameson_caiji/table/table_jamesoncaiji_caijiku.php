<?php
if(!defined('IN_DISCUZ')){
	exit('Access Denid');
}
/**
* 
*/
class table_jamesoncaiji_caijiku extends discuz_table
{
	
	function __construct()
	{
		$this->_table = 'jamesoncaiji_caijiku';
		$this->_pk = 'zhangjieid';
		parent::__construct();
	}
	// 采集后的章节url入库
	function addku($data,$guize,$category_id,$bookurl){
		if(!$data){
			return false;
		}
		// 清空原有的
		$this->truncate();
		$res = 0;
		foreach ($data as $key => $value) {
			// 第一层 是 卷
			$data2 = array();
			$data2['juantitle'] = daddslashes($value['j_title']);
			$data2['bookname'] = daddslashes($value['bookname']);
			$data2['juanid'] = $key;
			$data2['bookurl'] = $bookurl;
			$data2['guize'] = $guize;
			$data2['category_id'] = $category_id;
			$data2['message'] = '0';
			foreach ($value['zhangjie'] as $value) {
				$data2['zhangjietitle'] = daddslashes($value['text']);
				$data2['url'] = $value['href'];
				if($this->insert($data2,true)){
					$res++;
				}
			}
		}
		return $res;
	}
	// 当前所有待采集正文内容的目录链接
	function fetch_all($size=0){
		if($size){
			return DB::fetch_all("SELECT zhangjieid,url,zhangjietitle FROM %t WHERE TRIM(message) = %s OR TRIM(message)=%s ORDER BY message  LIMIT %d",array($this->_table,'0','',$size));
		}
		return DB::fetch_all("SELECT zhangjieid,url,zhangjietitle FROM %t WHERE TRIM(message) = %s OR TRIM(message)=%s ORDER BY message ",array($this->_table,'0',''));
	}
	// 当前所有待采集正文内容的目录链接
	function fetch_bypage($start,$size){
		
			return DB::fetch_all("SELECT zhangjieid,url,zhangjietitle FROM %t ORDER BY zhangjieid  LIMIT %d,%d",array($this->_table,$start,$size));
		
	}
	// 尚未采集正文的目录链接条数
	function count_null(){
		return DB::result_first('SELECT count(*) FROM %t WHERE TRIM(message)=%s OR TRIM(message) = %s ',array($this->_table,'0',''));
	}
	// 已采集完毕等待生成图书的章节条数
	function count_body(){
		return DB::result_first('SELECT count(*) FROM %t WHERE message !=%s',array($this->_table,'0'));
	}
	// 取得 采用的规则
	function fetch_guize(){
		return DB::result_first('SELECT guize FROM %t LIMIT 1',array($this->_table));
	}
	// 取得图书分类id
	function fetch_categoryid(){
		return DB::result_first('SELECT category_id FROM %t LIMIT 1',array($this->_table));
	}

	// 所有采集完毕的正文内容
	function fetch_all_message(){
		return DB::fetch_all('SELECT * FROM %t ORDER BY zhangjieid',array($this->_table));
	}
	// 获取书名
	function fetch_bookname(){
		return DB::result_first('SELECT bookname FROM %t LIMIT 1',array($this->_table));
	}
	/*取得子分类*/
	function fetch_all_parent($parentid){
		return DB::fetch_all("SELECT * FROM %t WHERE parent_id=%d ORDER BY ordernum DESC",array('jamesonread_categorys',$parentid));
	}
	// 获取所有图书分类
	/*取得所有分类*/
		function allcategorys(){
			// 所有一级分类
			$tmp = $this->fetch_all_parent(0);
			foreach ($tmp as $key => $value) {
				$tmp[$key]['sub'] = $this->fetch_all_parent($value['category_id']);
			}
			return $tmp;
		}
}