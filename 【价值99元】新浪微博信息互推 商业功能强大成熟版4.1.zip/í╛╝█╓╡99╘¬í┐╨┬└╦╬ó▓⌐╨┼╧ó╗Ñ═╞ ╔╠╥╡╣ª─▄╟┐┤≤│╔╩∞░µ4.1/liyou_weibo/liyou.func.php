<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function db_insert($arr) {
	$values='VALUES (';
	$attr='(';
	foreach($arr as $key=>$val)
	{
		$attr.=" `{$key}`,";
		$values.=" '$val',";
	}
	$attr=substr($attr,0,-1);
	$attr.=")";
	$values=substr($values,0,-1);
	$values.=")";
	return $attr." ".$values;
}


function db_update($arr) {
	$values='';
	foreach($arr as $key=>$val)
	{
		$values.="{$key}='{$val}',";
	}
	$values=substr($values,0,-1);
	return $values;
}

function liyou_strlength($str,$charset='utf-8'){
    if($charset=='utf-8') $str = iconv('utf-8','gb2312',$str);
    $num = strlen($str);
    $cnNum = 0;
    for($i=0;$i<$num;$i++){
        if(ord(substr($str,$i+1,1))>127){
            $cnNum++;
            $i++;
        }
    }
    $enNum = $num-($cnNum*2);
    $number = ($enNum/2)+$cnNum;
    return ceil($number);
}

function _substr($str, $length) {
		
		if( strlen($str) > $length + 600 ){
			$str = substr($str, 0, $length + 600);
		}
		
		$p = '/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/';
		preg_match_all($p,$str,$o);
		$size = sizeof($o[0]);
		$count = 0;
		for ($i=0; $i<$size; $i++) {
			if (strlen($o[0][$i]) > 1) {
				$count += 1;
			} else {
				$count += 0.5;
			}
			
			if ($count  > $length) {
				$i-=1;
				break;
			}
			
		}
		return implode('', array_slice($o[0],0, $i));
}


function liyou_substr($string, $sublen, $start = 0, $code = 'UTF-8') 
{ 
	if($code == 'UTF-8') 
	{ 
		$pa ="/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/"; 
		preg_match_all($pa, $string, $t_string); 

		if(count($t_string[0]) - $start > $sublen) return join('', array_slice($t_string[0], $start, $sublen))."..."; 
		return join('', array_slice($t_string[0], $start, $sublen)); 
	} 
	else 
	{ 
		$start = $start*2; 
		$sublen = $sublen*2; 
		$strlen = strlen($string); 
		$tmpstr = ''; 
		for($i=0; $i<$strlen; $i++) 
		{ 
			if($i>=$start && $i<($start+$sublen)) 
			{ 
				if(ord(substr($string, $i, 1))>129) 
				{ 
					$tmpstr.= substr($string, $i, 2); 
				} 
				else 
				{ 
					$tmpstr.= substr($string, $i, 1); 
				} 
			} 
			if(ord(substr($string, $i, 1))>129) $i++; 
		} 
		//if(strlen($tmpstr)<$strlen ) ; 
		return $tmpstr; 
	}
}

function liyou_is_utf8($str) 
{ 
	if (preg_match("/^([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}/",$str) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}$/",$str) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){2,}/",$str) == true) 
	{ 
	return true; 
	} 
	else 
	{ 
	return false; 
	}
}

if (!function_exists('json_encode')) {
	function json_encode($array = array()) {
		if(!is_array($array)) return null;
		$json = "";
		$i = 1;
		$comma = ",";
		$count = count($array);
		foreach($array as $k=>$v){
		if($i==$count) $comma = "";
		if(!is_array($v)){
		$v = addslashes($v);
		$json .= '"'.$k.'":"'.$v.'"'.$comma;
		}
		else{
		$json .= '"'.$k.'":'.json_encode($v).$comma;
		}
		$i++;
		}
		$json = '{'.$json.'}';
		return $json;
	}
}

if (!function_exists('json_decode')) {
	function json_decode($json, $assoc = true) {
		$comment = false;
		$out     = '$x=';
		$json = preg_replace('/:([^"}]+?)([,|}])/i', ':"\1"\2',$json);
		for ($i=0; $i<strlen($json); $i++) {
		if (!$comment) {
		if (($json[$i] == '{') || ($json[$i] == '[')) {
		$out .= 'array(';
		}
		elseif (($json[$i] == '}') || ($json[$i] == ']')) {
		$out .= ')';
		}
		elseif ($json[$i] == ':') {
		$out .= '=>';
		}
		elseif ($json[$i] == ',') {
		$out .= ',';
		}
		elseif ($json[$i] == '"') {
		$out .= '"';
		}
		}
		else $out .= $json[$i] == '$' ? '\$' : $json[$i];
		if ($json[$i] == '"' && $json[($i-1)] != '\\')  $comment = !$comment;
		}
		eval($out. ';');
		return $x;
	}
}
if (!function_exists('liyou_addmember')) {
function liyou_addmember($uid, $username, $password, $email, $ip, $groupid, $extdata, $adminid = 0) {
	$credits = isset($extdata['credits']) ? $extdata['credits'] : array();
	$profile = isset($extdata['profile']) ? $extdata['profile'] : array();
	$base = array(
		'uid' => $uid,
		'username' => $username,
		'password' => $password,
		'email' => $email,
		'adminid' => intval($adminid),
		'groupid' => intval($groupid),
		'regdate' => TIMESTAMP,
		'emailstatus' => intval($extdata['emailstatus']),
		'credits' => intval($credits[0]),
		'timeoffset' => 9999
	);
	$status = array(
		'uid' => $uid,
		'regip' => $ip,
		'lastip' => $ip,
		'lastvisit' => TIMESTAMP,
		'lastactivity' => TIMESTAMP,
		'lastpost' => 0,
		'lastsendmail' => 0
	);
	$count = array(
		'uid' => $uid,
		'extcredits1' => intval($credits[1]),
		'extcredits2' => intval($credits[2]),
		'extcredits3' => intval($credits[3]),
		'extcredits4' => intval($credits[4]),
		'extcredits5' => intval($credits[5]),
		'extcredits6' => intval($credits[6]),
		'extcredits7' => intval($credits[7]),
		'extcredits8' => intval($credits[8])
	);
	$profile['uid'] = $uid;
	$field_forum['uid'] = $uid;
	$field_home['uid'] = $uid;
	DB::insert('common_member', $base, true);
	DB::insert('common_member_status', $status, true);
	DB::insert('common_member_count', $count, true);
	DB::insert('common_member_profile', $profile, true);
	DB::insert('common_member_field_forum', $field_forum, true);
	DB::insert('common_member_field_home', $field_home, true);
	DB::insert('common_setting', array('skey' => 'lastmember', 'svalue' => $username), false, true);
	manyoulog('user', $uid, 'add');
	$totalmembers = DB::result_first("SELECT COUNT(*) FROM ".DB::table('common_member'));
	$userstats = array('totalmembers' => $totalmembers, 'newsetuser' => stripslashes($username));
	save_syscache('userstats', $userstats);
}
}

if (!function_exists('liyou_updateusername')) {
	function liyou_updateusername($newname,$oldname){
	$member = DB::fetch_first("SELECT * FROM " . DB::table('common_member') . " WHERE username='$oldname'");
	if($member){
		DB::query("UPDATE " . DB::table('common_adminnote') . " SET admin='$newname' WHERE admin='$oldname'");
		DB::query("UPDATE " . DB::table('common_block') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('common_block_item') . " SET title='$newname' WHERE title='$oldname'");
		DB::query("UPDATE " . DB::table('common_block_item_data') . " SET title='$newname' WHERE title='$oldname'");
		DB::query("UPDATE " . DB::table('common_card_log') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('common_failedlogin') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('common_grouppm') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('common_invite') . " SET fusername='$newname' WHERE fusername='$oldname'");
		DB::query("UPDATE " . DB::table('common_member') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('common_member_security') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('common_member_validate') . " SET admin='$newname' WHERE admin='$oldname'");
		DB::query("UPDATE " . DB::table('common_member_verify_info') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('common_member_security') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('common_mytask') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('common_report') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('common_session') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('common_word') . " SET admin='$newname' WHERE admin='$oldname'");
		DB::query("UPDATE " . DB::table('forum_activityapply') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_announcement') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('forum_collection') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_collectioncomment') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_collectionfollow') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_collectionteamworker') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_forumrecommend') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('forum_groupuser') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_imagetype') . " SET name='$newname' WHERE name='$oldname'");
		DB::query("UPDATE " . DB::table('forum_order') . " SET buyer='$newname' WHERE buyer='$oldname'");
		DB::query("UPDATE " . DB::table('forum_order') . " SET admin='$newname' WHERE admin='$oldname'");
		DB::query("UPDATE " . DB::table('forum_pollvoter') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_post') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('forum_postcomment') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('forum_promotion') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_ratelog') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_rsscache') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('forum_thread') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('forum_threadmod') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_trade') . " SET seller='$newname' WHERE seller='$oldname'");
		DB::query("UPDATE " . DB::table('forum_tradelog') . " SET seller='$newname' WHERE seller='$oldname'");
		DB::query("UPDATE " . DB::table('forum_tradelog') . " SET buyer='$newname' WHERE buyer='$oldname'");
		DB::query("UPDATE " . DB::table('forum_warning') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('home_album') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_blog') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_clickuser') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_comment') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('home_docomment') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_doing') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_feed') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_feed_app') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_follow') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_follow') . " SET fusername='$newname' WHERE fusername='$oldname'");
		DB::query("UPDATE " . DB::table('home_follow_feed') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_follow_feed_archiver') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_friend') . " SET fusername='$newname' WHERE fusername='$oldname'");
		DB::query("UPDATE " . DB::table('home_friend_request') . " SET fusername='$newname' WHERE fusername='$oldname'");
		DB::query("UPDATE " . DB::table('home_notification') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('home_pic') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_poke') . " SET fromusername='$newname' WHERE fromusername='$oldname'");
		DB::query("UPDATE " . DB::table('home_share') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_show') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_specialuser') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_visitor') . " SET vusername='$newname' WHERE vusername='$oldname'");
		DB::query("UPDATE " . DB::table('home_specialuser') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('portal_article_title') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('portal_comment') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('portal_rsscache') . " SET author='$newname' WHERE author='$oldname'");
		DB::query("UPDATE " . DB::table('portal_topic') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('portal_topic_pic') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_collection') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_collectioncomment') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_collectionfollow') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('forum_collectionteamworker') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_follow') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_follow') . " SET username='$fusername' WHERE username='$fusername'");
		DB::query("UPDATE " . DB::table('home_follow_feed') . " SET username='$newname' WHERE username='$oldname'");
		DB::query("UPDATE " . DB::table('home_follow_feed_archiver') . " SET username='$newname' WHERE username='$oldname'");
	}
	DB::query("UPDATE " . UC_DBTABLEPRE . "admins SET username='$newname' WHERE username='$oldname'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "badwords SET admin='$newname' WHERE admin='$oldname'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "feeds SET username='$newname' WHERE username='$oldname'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "members SET username='$newname' WHERE username='$oldname'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "mergemembers SET username='$newname' WHERE username='$oldname'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "protectedmembers SET username='$newname' WHERE username='$oldname'");
	return $member;
	}
}

//From:www_YMG6_COM
?>