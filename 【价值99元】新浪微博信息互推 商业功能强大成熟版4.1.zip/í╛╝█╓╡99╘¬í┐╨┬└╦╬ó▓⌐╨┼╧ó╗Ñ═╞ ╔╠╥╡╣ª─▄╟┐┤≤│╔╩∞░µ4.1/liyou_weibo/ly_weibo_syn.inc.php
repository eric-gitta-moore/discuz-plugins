<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$_G['uid'])
{
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}


$syn_reply=isset($_REQUEST['syn_reply'])?intval($_REQUEST['syn_reply']):'0';
$syn_thread=isset($_REQUEST['syn_thread'])?intval($_REQUEST['syn_thread']):'0';
$syn_blog=isset($_REQUEST['syn_blog'])?intval($_REQUEST['syn_blog']):'0';
$syn_portal=isset($_REQUEST['syn_portal'])?intval($_REQUEST['syn_portal']):'0';
$syn_doing=isset($_REQUEST['syn_doing'])?intval($_REQUEST['syn_doing']):'0';
$syn_share=isset($_REQUEST['syn_share'])?intval($_REQUEST['syn_share']):'0';
$syn_broadcast=isset($_REQUEST['syn_broadcast'])?intval($_REQUEST['syn_broadcast']):'0';

$arrUpdate=array(
		'syn_reply'=>intval($syn_reply),
		'syn_thread'=>intval($syn_thread),
		'syn_blog'=>intval($syn_blog),
		'syn_portal'=>intval($syn_portal),
		'syn_doing'=>intval($syn_doing),
		'syn_share'=>intval($syn_share),
		'syn_broadcast'=>intval($syn_broadcast)
		);
C::t('#liyou_weibo#ly_weibo_bind')->update($_G['uid'],$arrUpdate);
showmessage('liyou_weibo:save_syn_success', dreferer());

?>