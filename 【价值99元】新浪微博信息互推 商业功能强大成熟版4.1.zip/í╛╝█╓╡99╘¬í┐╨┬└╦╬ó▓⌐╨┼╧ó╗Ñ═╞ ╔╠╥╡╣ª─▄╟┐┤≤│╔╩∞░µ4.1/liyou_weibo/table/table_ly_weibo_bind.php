<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_ly_weibo_bind extends discuz_table {
	
	public function __construct() {
		$this->_table='ly_weibo_bind';
		$this->_pk='uid';
		parent::__construct();
	}

	public function fetch_by_weibo_uid($weibo_uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE weibo_uid=%d", array($this->_table, $weibo_uid));
	}

	public function fetch_by_discuz_uid($weibo_uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $weibo_uid));
	}

	public function fetch_all_by_discuz_uid($uid) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
	}

	public function randfetch_by_discuz_uid($num) {
		return DB::fetch_all("SELECT weibo_uid FROM %t ORDER BY rand() LIMIT %d", array($this->_table, $num));
	}

	public function fetch_by_discuz_uid_onekey($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d and is_onkey=1", array($this->_table, $uid));
	}

	public function fetch_by_discuz_and_weibo_uid($uid,$weibo_uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d and weibo_uid=%d", array($this->_table, $uid,$weibo_uid));
	}

	public function delete($con,$unbuffered = false)
	{
		if (is_array($con)) {
			return DB::delete($this->_table,$con);
		}else{
			return parent::delete($con,$unbuffered);
		}
	}

}
//WWW.fx8.cc
?>