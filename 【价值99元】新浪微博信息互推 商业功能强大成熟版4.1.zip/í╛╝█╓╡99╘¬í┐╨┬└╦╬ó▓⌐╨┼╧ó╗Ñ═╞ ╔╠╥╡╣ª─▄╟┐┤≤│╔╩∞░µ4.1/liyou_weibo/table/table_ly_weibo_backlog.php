<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_ly_weibo_backlog extends discuz_table {
	
	public function __construct() {
		$this->_table='ly_weibo_backlog';
		$this->_pk='bbsid';
		parent::__construct();
	}

	public function get_by_cid($cid) {
		return DB::result_first("SELECT cid FROM %t WHERE cid=%s", array($this->_table, $cid));
	}

}
//WWW.fx8.cc
?>