<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_ly_weibo_threadlog extends discuz_table {
	
	public function __construct() {
		$this->_table='ly_weibo_threadlog';
		$this->_pk='wbid';
		parent::__construct();
	}

	public function fetch_max_updatetime_by_tid($tid) {
		return DB::fetch_first('SELECT * FROM %t WHERE tid=%d LIMIT 1', array($this->_table, $tid));
	}

	public function fetch_threadlog_by_tid($tid,$type) {
		return DB::fetch_first('SELECT * FROM %t WHERE tid=%d AND type=%s LIMIT 1', array($this->_table, $tid,$type));
	}

	public function fetch_all_threadlog_by_tid($tid,$type) {
		return DB::fetch_all('SELECT * FROM %t WHERE tid=%d AND type=%s', array($this->_table, $tid,$type));
	}

	public function fetch_update_doinglog() {
		return DB::fetch_first('SELECT * FROM %t WHERE type=%s order by updateline ASC LIMIT 1', array($this->_table,'doing'));
	}

	public function fetch_update_10doinglog() {
		return DB::fetch_all('SELECT * FROM %t WHERE type=%s order by updateline ASC LIMIT 8', array($this->_table,'doing'));
	}

	public function fetch_update_broadcastlog() {
		return DB::fetch_first('SELECT * FROM %t WHERE type=%s order by updateline ASC LIMIT 1', array($this->_table,'broadcast'));
	}
	public function fetch_update_sharelog() {
		return DB::fetch_first('SELECT * FROM %t WHERE type=%s order by updateline ASC LIMIT 1', array($this->_table,'share'));
	}
	public function fetch_update_10broadcastlog() {
		return DB::fetch_all('SELECT * FROM %t WHERE type=%s order by updateline ASC LIMIT 8', array($this->_table,'broadcast'));
	}
	public function fetchall() {
		return DB::fetch_all('SELECT * FROM %t  order by updateline ASC ', array($this->_table));
	}
	public function fetchtop1($time) {
		return DB::fetch_first('SELECT * FROM %t WHERE updateline>%d order by updateline ASC LIMIT 1', array($this->_table,$time));
	}

	public function get_list($time,$i,$size=10){
		return DB::fetch_all('SELECT type,tid FROM %t  WHERE dateline>%d and updateline<%d limit %d', array($this->_table,$i,$time,$size));
	}
}
//WWW.fx8.cc
?>