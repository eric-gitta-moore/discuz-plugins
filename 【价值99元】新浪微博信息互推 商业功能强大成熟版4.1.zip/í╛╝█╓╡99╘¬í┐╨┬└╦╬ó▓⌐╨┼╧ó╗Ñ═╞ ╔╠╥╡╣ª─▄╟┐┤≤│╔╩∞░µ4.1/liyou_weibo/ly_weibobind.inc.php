<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/config/config.php';
require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/sina_api/saetv2.ex.class.php';

if(!$_G['uid'])
{
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}

$uids=explode(",",trim(LY_RECUID));
$lastnum=$uids[count($uids)-1];
if($lastnum<0 || $lastnum>20){
	$lastnum=10;
}else
{
	unset($uids[count($uids)-1]);
}

$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->randfetch_by_discuz_uid($lastnum);
foreach($discuzUserInfo as $key=>$val)
{
	$uids[]=$val['weibo_uid'];
}
$reuids=implode(",",$uids);

$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid_onekey($_G['uid']);

if(empty($discuzUserInfo))  $discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
$user=getuserbyuid($_G['uid']);
$usertips=lang('plugin/liyou_weibo','ly_weibo_btn_tip8',array('username'=>$user['username']));
$syn_reply=$discuzUserInfo['syn_reply'];
$syn_thread=$discuzUserInfo['syn_thread'];
$syn_blog=$discuzUserInfo['syn_blog'];
$syn_portal=$discuzUserInfo['syn_portal'];
$syn_doing=$discuzUserInfo['syn_doing'];
$syn_share=$discuzUserInfo['syn_share'];
$syn_broadcast=$discuzUserInfo['syn_broadcast'];
$expire=$discuzUserInfo['expires_in']+$discuzUserInfo['dateline']-$_G['timestamp'];
$multi = in_array($_G['groupid'],$aallowg);
if($expire<=0)
{
	$expire=-$expire;
	$day=floor($expire/(60*60*24));
	$hour=floor(($expire%(60*60*24))/(60*60));
	$min=floor(($expire%(60*60))/60);
	$sec=$expire%60;
	$authTips=lang('plugin/liyou_weibo','ly_weibo_gauthtip',array('weibouid'=>$discuzUserInfo['weibo_uid'],'weibousername'=>$discuzUserInfo['weibo_username'],'day'=>$day,'hour'=>$hour,'min'=>$min,'sec'=>$sec));
}else{
	$day=floor($expire/(60*60*24));
	$hour=floor(($expire%(60*60*24))/(60*60));
	$min=floor(($expire%(60*60))/60);
	$sec=$expire%60;
	$authTips=lang('plugin/liyou_weibo','ly_weibo_authtip',array('weibouid'=>$discuzUserInfo['weibo_uid'],'weibousername'=>$discuzUserInfo['weibo_username'],'day'=>$day,'hour'=>$hour,'min'=>$min,'sec'=>$sec));
}

$bindlist=C::t('#liyou_weibo#ly_weibo_bind')->fetch_all_by_discuz_uid($_G['uid']);

function weibo_time_format($discuzUserInfo){
	global $_G;
	$expire=$discuzUserInfo['expires_in']+$discuzUserInfo['dateline']-$_G['timestamp'];
	$tips='ly_weibo_authtip';
	if($expire<=0){
		$expire=-$expire;
		$tips='ly_weibo_gauthtip';
	}
	$day=floor($expire/(60*60*24));
	$hour=floor(($expire%(60*60*24))/(60*60));
	$min=floor(($expire%(60*60))/60);
	$sec=$expire%60;
	$authTips=lang('plugin/liyou_weibo',$tips,array('weibouid'=>$discuzUserInfo['weibo_uid'],'weibousername'=>$discuzUserInfo['weibo_username'],'day'=>$day,'hour'=>$hour,'min'=>$min,'sec'=>$sec));
	return $authTips;
}
//WWW.fx8.cc
?>