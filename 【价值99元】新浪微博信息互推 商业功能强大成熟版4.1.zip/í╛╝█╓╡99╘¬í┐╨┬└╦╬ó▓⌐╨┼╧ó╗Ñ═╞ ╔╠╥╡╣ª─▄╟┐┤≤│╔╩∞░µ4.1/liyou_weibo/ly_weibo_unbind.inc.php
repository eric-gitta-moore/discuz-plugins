<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/liyou.func.php';
$weibo_uid = intval($_GET['wuid']);

if(!$_G['uid'])
{
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
if(!isset($_GET['op']))
{
	showmessage('not_loggedin');
}
$op=trim($_GET['op']);
$arrop=array('unbind','changename');
if(!in_array($op,$arrop))
{
	showmessage('not_loggedin');
}
if($op=='unbind')
{
	$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_and_weibo_uid($_G['uid'],$weibo_uid);
	if(!empty($discuzUserInfo))
	{
		if($discuzUserInfo['is_onkey']==1)
		{
			showmessage('liyou_weibo:setpassword');
		}
		$con['uid']=$_G['uid'];
		$con['weibo_uid']=$weibo_uid;
		C::t('#liyou_weibo#ly_weibo_bind')->delete($con);
		showmessage('liyou_weibo:unbind_success', dreferer());
	}else
	{
		showmessage('liyou_weibo:unbind_fail', dreferer());
	}
}else if($op=='changename')
{
	$binduser=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid_onekey($_G['uid']);
	if(empty($binduser) || $binduser['is_onkey']==0)
	{
		showmessage('liyou_weibo:illegalop', dreferer());
	}
	$newusername=addslashes(trim($_POST['username']));
	$email=trim($_POST['email']);
	$pass1=addslashes(trim($_POST['password1']));
	$pass2=addslashes(trim($_POST['password2']));
	if($newusername == '') {
		showmessage('liyou_weibo:nousername', dreferer());
	}
	
	if(empty($email) || !isemail($email))
	{
		showmessage('liyou_weibo:illegalemail', dreferer());
	}

	if(empty($pass1) || $pass1!=$pass2)
	{
		showmessage('liyou_weibo:pass1pass2', dreferer());
	}

	loaducenter();
	$check = uc_user_checkname($newusername);
	
	$error= array(
		'-1' => lang('plugin/liyou_weibo', 'illegalusername'),
		'-2' => lang('plugin/liyou_weibo', 'illegalusername'),
		'-3' => lang('plugin/liyou_weibo', 'usernameexists')
	);
	
	if ($check != 1) {
		//showmessage($error[$check], dreferer());
	}else{
		$oldusername=$_G['username'];
		liyou_updateusername($newusername,$oldusername);
	}
	$result='';

	$member = DB::fetch_first("SELECT * FROM " . DB::table('common_member') . " WHERE uid=$_G[uid]");	
	if($newusername!=$member['username'])
	{
		$result.=lang('plugin/liyou_weibo', 'updateusernamefail').'('.$error[$check].')';
	}
	uc_user_edit($member['username'],'', $pass1, $email, 1);
	$member1 = DB::fetch_first("SELECT * FROM " . DB::table('common_member') . " WHERE uid=$_G[uid]");
/*
	if($email!=$member1['email'])
	{
		$result.=lang('plugin/liyou_weibo', 'updateemailfail');
	}*/
	$status=uc_user_login($newusername, $pass1);
	if($status[0]==-2)
	{
		$result.=lang('plugin/liyou_weibo', 'updatepassfail');
	}else
	{
		$arrUpdate=array('is_onkey'=>'2');
		C::t('#liyou_weibo#ly_weibo_bind')->update($_G['uid'],$arrUpdate);
	}
	if($result=='')
	{
		showmessage(lang('plugin/liyou_weibo', 'updateuserinfosuccess'), dreferer());
	}else
	{
		showmessage($result);
	}
}
//WWW.fx8.cc
?>