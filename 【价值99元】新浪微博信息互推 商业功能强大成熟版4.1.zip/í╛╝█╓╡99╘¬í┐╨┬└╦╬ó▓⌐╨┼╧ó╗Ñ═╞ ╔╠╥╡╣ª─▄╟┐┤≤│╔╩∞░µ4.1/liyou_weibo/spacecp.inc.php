<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/config/config.php';
require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/sina_api/saetv2.ex.class.php';
require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/liyou.func.php';

$allow = array('back','syn','index');
$action = isset($_GET['a']) && in_array($_GET['a'], $allow)?$_GET['a']:'index';
$instance = LywbFactory::get_enter();
$instance->$action();

