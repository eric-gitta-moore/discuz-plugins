<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/config/config.php';
require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/sina_api/saetv2.ex.class.php';
require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/liyou.func.php';

class plugin_liyou_weibo {

	public function plugin_liyou_weibo() {
		global $_G;
		if($this->_check_user_bind())
		{
			$_G['liyou_weibo']=true;
		}
	}

	public function global_login_extra() {
		global $_G;
		$loginbtn=$_G['cache']['plugin']['liyou_weibo']['ly_nologinbtn'];
		if($loginbtn) return '';
		include template('liyou_weibo:global_login_extra');
		return $return;
	}

	public function global_usernav_extra1() {
		global $_G;
		$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
		if($_G['uid'] && empty($discuzUserInfo))
		{
			include template('liyou_weibo:global_usernav_extra1');
			return $return;
		}
	}

	public function global_login_text() {
		global $_G;
		$loginbtn=$_G['cache']['plugin']['liyou_weibo']['ly_nologinbtn'];
		if($loginbtn) return '';
		$return="<a href=\"plugin.php?id=liyou_weibo:login\" class=\"xi2\"><img src=\"source/plugin/liyou_weibo/image/login_btn.png\" style=\"vertical-align:middle;\"/></a>";
		return $return;
	}

	public function  global_cpnav_extra1() {
		if(LY_NOTICE==1 && LY_UID>0 && LY_POSITION==1)
		{
			$return='<iframe width="121" scrolling="no" height="24" style="  padding:4px 0 0 0" class="z" frameborder="0" src="http://widget.weibo.com/relationship/followbutton.php?language=zh_cn&amp;width=136&amp;height=24&amp;uid='.LY_UID.'&amp;style=2&amp;btn=red&amp;dpc=1" border="0" marginheight="0" marginwidth="0" allowtransparency="true"></iframe>';
			return $return;
		}
	}
	public function  index_status_extra() {
		if(LY_NOTICE==1 && LY_UID>0 && LY_POSITION==2)
		{
			$return='<style>#connectlike{ float:left;width:281px}</style><iframe width="121" scrolling="no" height="24" style="padding:4px 0 0 0;" frameborder="0" src="http://widget.weibo.com/relationship/followbutton.php?language=zh_cn&amp;width=136&amp;height=24&amp;uid='.LY_UID.'&amp;style=2&amp;btn=red&amp;dpc=1" border="0" marginheight="0" marginwidth="0" allowtransparency="true"></iframe>';
			return $return;
		}else if(LY_NOTICE==1 && LY_UID>0 && LY_POSITION==4)
		{
			$return='<style>#connectlike{ float:left;width:141px}</style><iframe width="121" scrolling="no" height="24" style="padding:4px 0 0 0;" frameborder="0" src="http://widget.weibo.com/relationship/followbutton.php?language=zh_cn&amp;width=136&amp;height=24&amp;uid='.LY_UID.'&amp;style=2&amp;btn=red&amp;dpc=1" border="0" marginheight="0" marginwidth="0" allowtransparency="true"></iframe>';
			return $return;
		}
	}
	public function  global_cpnav_top() {
		if(LY_NOTICE==1 && LY_UID>0 && LY_POSITION==3)
		{
			$return='<iframe width="121" scrolling="no" height="24" frameborder="0" src="http://widget.weibo.com/relationship/followbutton.php?language=zh_cn&amp;width=136&amp;height=24&amp;uid='.LY_UID.'&amp;style=2&amp;btn=red&amp;dpc=1" border="0" marginheight="0" marginwidth="0" allowtransparency="true"></iframe>';
			return $return;
		}
	}

	public function global_footer()
	{
		global $_G;
		$return='';
		$jsurl ='';
		$bindurl =  $_G['siteurl'].'plugin.php?id=liyou_weibo:login';
		if($_G['uid'])
		{
			$uids=array();
			$bind=0;
			$expire=0;
			$binduser=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
			if(!empty($binduser)) 
			{
				$bind=1;
				$expired=$binduser['expires_in']+$binduser['dateline']-$_G['timestamp'];
				if($expired<0) $expire=1;
			}
			include template('liyou_weibo:ly_fixedtips');
		}
		$t=$_G['liyou_weibo_setting']['model']/60;
		$tm = $t*10;
		if($_G['uid']==1 || ($_G['uid']>0 && $_G['uid']%$tm==0)){
			Lywb::i();
		}
		return $return;
	}

	public function _check_user_bind() {
		global $_G;
		if($_G['uid'])
		{
			$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
			if(!empty($discuzUserInfo))
			{
				dsetcookie('bind_weibo_token',serialize($discuzUserInfo),86400);
				$_G['liyou_weibo_user_setting']=$discuzUserInfo;
				return true;
			}
		}
		return false;
	}


	public function _check_user_exists() {
		global $_G;
		if($_G['cookie']['bind_weibo_token']) {
			$token = dunserialize($_G['cookie']['bind_weibo_token']);
			$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$token['access_token']);
			$weiboUserInfo=$oClient->show_user_by_id($token['weibo_uid']);
		$arrData=array();
		if(!empty($weiboUserInfo))
			$arrData=array('allow_thread'=>$token['syn_thread'],'allow_reply'=>$token['syn_reply']);
		return $arrData;
		}
	}
	public function _get_weibo_client() {
		global $_G;
		if($_G['cookie']['bind_weibo_token']) {
			$token = dunserialize($_G['cookie']['bind_weibo_token']);
			$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$token['access_token']);
		}else if($_G['cookie']['weibo_token']){
			$token = dunserialize($_G['cookie']['weibo_token']);
			$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$token['access_token']);
		}else
		{
			$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
			$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$discuzUserInfo['access_token']);
		}
		return $oClient;
	}

	public function _ly_weibo_comment($tid,$lcmessage,$type,$bbsid=0)
	{
		global $_G;
		if($this->_check_user_bind()==false) return '';
		Lywb::c($tid,$lcmessage,$type,$bbsid); return ;
	}
}

class plugin_liyou_weibo_member extends plugin_liyou_weibo {

	function register_top(){
		global $_G;
		if($_G['cookie']['weibo_token']) {
			$_G['setting']['reglinkname'] = lang('plugin/liyou_weibo', 'complete_profile');
			$referer=rawurlencode($_GET['referer']);
			include template('liyou_weibo:register_top');
			return $return;
		}
	}

	function register_bottom(){
		global $_G;
		if($_G['cookie']['weibo_token']) {
			return $return;
		}
	}

	function logging_top(){
		global $_G;
		if($_G['cookie']['weibo_token']) {
			$referer=rawurlencode($_GET['referer']);
			include template('liyou_weibo:logging_top');
			return $return;
		}
	}

	function register_logging_method() {
		global $_G;
		$loginbtn=$_G['cache']['plugin']['liyou_weibo']['ly_nologinbtn'];
		if($loginbtn) return '';
		return '<a href="'.$_G['siteurl'].'plugin.php?id=liyou_weibo:login"><img src="'.$_G['siteurl'].'source/plugin/liyou_weibo/image/login_btn.png" alt="'.lang('plugin/liyou_weibo', 'weibo_login').'" class="vm"></a>';
	}
	
	function logging_method() {
		global $_G;
		$loginbtn=$_G['cache']['plugin']['liyou_weibo']['ly_nologinbtn'];
		if($loginbtn) return '';
		return '<a href="'.$_G['siteurl'].'plugin.php?id=liyou_weibo:login"><img src="'.$_G['siteurl'].'source/plugin/liyou_weibo/image/login_btn.png" alt="'.lang('plugin/liyou_weibo', 'weibo_login').'" class="vm"></a>';
	}

	function register_liyou_message($param) {
		global $_G;
		if(($param['param'][0] == 'register_succeed' || $param['param'][0] == 'register_email_verify' || $param['param'][0] == 'register_manual_verify') && $_G['cookie']['weibo_token']) {
			$this->_insert_bind();
		}
	}
	function logging_liyou_message($param) {
		global $_G;
		if($param['param'][0] == 'location_login_succeed' && $_G['cookie']['weibo_token']) {
			$this->_insert_bind();
		}
	}

	function _insert_bind(){
		global $_G;
		$token = dunserialize($_G['cookie']['weibo_token']);
		$oClient=$this->_get_weibo_client();
		$weibouserinfo=$oClient->show_user_by_id($token['uid']);
		if(empty($weibouserinfo))
		{
			showmessage('liyou_weibo:auth_fail');
		}else if(isset($weibouserinfo['screen_name']) && !empty($weibouserinfo['screen_name'])){
			$weibouserinfo=LywbFunc::toWeibo($weibouserinfo);
		}
		Lywb::bind_user($token,$weibouserinfo,$_G['uid']);
	}
}


class plugin_liyou_weibo_forum extends plugin_liyou_weibo {
		function post_newthread_message($param) {
			global $_G;
			$sinareturn=null;
			if(!isset($_REQUEST['syn_thread'])) return ;
			if(($param['param'][0]=='post_newthread_succeed' || ($_G['action'] == 'newthread'  && submitcheck('topicsubmit')) )&& isset($param['param'][2]['tid']) && $param['param'][2]['tid']>0 )
			{
				if($this->_check_user_bind()==false) return;
				if($_G['liyou_weibo_user_setting']['syn_thread']==0 || $_G['liyou_weibo_setting']['thread']==0) return ;
				$arrData=$this->_check_user_exists();
				$fid=intval($param['param'][2]['fid']);
				$tid=intval($param['param'][2]['tid']);
				$exter=array();
				$exter['fid']=$fid;
				$exter['tid']=$tid;
				Lywb::s('thread',$exter);
			}
		}

		function post_reply_message($param) {
			global $_G;
			$sinareturn=null;
			if(($param['param'][0]=='post_reply_succeed' || ($_G['action'] == 'reply'  && submitcheck('replysubmit')))&& isset($param['param'][2]['pid']) && $param['param'][2]['pid']>0 )
			{
				if($this->_check_user_bind()==false) return;
				$arrData=$this->_check_user_exists();
				//if($arrData['allow_reply']==0) return;
				$fid=intval($param['param'][2]['fid']);
				$tid=intval($param['param'][2]['tid']);
				$pid=intval($param['param'][2]['pid']);
				$exter['fid']=$fid;
				$exter['tid']=$tid;
				$exter['pid']=$pid;
				$exter['syn']= isset($_REQUEST['syn_reply']) && $_G['liyou_weibo_user_setting']['syn_reply']==1 && $_G['liyou_weibo_setting']['reply']==1;
				$exter['csyn']=$_G['liyou_weibo_setting']['comthread']==1 || $_G['liyou_weibo_setting']['combroadcast']==1;
				Lywb::s('reply',$exter);
			}
		}

		public function post_infloat_btn_extra() {
				global $_G;
				if($_G['uid'] && !empty($_GET['tid']) && $_G['liyou_weibo_setting']['reply']==1)
				{   
					if(LY_SYN_REPLY==0) return ;
					$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
					$check='';if(empty($discuzUserInfo)) return '';
					if($discuzUserInfo['syn_reply'])
					{
						$check='checked="checked"';
					}
					$return='<label for="syn_reply" class="z"><input class="z" type="checkbox" id="syn_reply" name="syn_reply" '."$check".'>'.lang('plugin/liyou_weibo','syn_reply').'</label>';
					return $return;
				}else if($_G['liyou_weibo_setting']['thread']==1)
				{
					if(LY_SYN_THREAD==0) return ;
					$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
					$check='';if(empty($discuzUserInfo)) return '';
					if($discuzUserInfo['syn_thread'])
					{
						$check='checked="checked"';
					}
					$return='<label for="syn_thread"><input class="pc" type="checkbox" id="syn_thread" name="syn_thread" '."$check".'>'.lang('plugin/liyou_weibo','syn_thread').'</label>';
					return $return;
				}
		}

		public function post_btn_extra() {
				global $_G;
				if($_G['uid'] && !isset($_GET['tid']) && $_G['liyou_weibo_setting']['thread']==1){	
					if(LY_SYN_THREAD==0) return ;
					$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
					$check='';if(empty($discuzUserInfo)) return '';
					if($discuzUserInfo['syn_thread'])
					{
						$check='checked="checked"';
					}
					$return='<label for="syn_thread"><input class="pc" type="checkbox" id="syn_thread" name="syn_thread" '."$check".'>'.lang('plugin/liyou_weibo','syn_thread').'</label>';
					return $return;
				}else if($_G['liyou_weibo_setting']['reply']==1){	
					if(LY_SYN_REPLY==0) return ;
					$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
					$check='';if(empty($discuzUserInfo)) return '';
					if($discuzUserInfo['syn_reply'])
					{
						$check='checked="checked"';
					}
					$return='<label for="syn_reply"><input class="pc" type="checkbox" id="syn_reply" name="syn_reply" '."$check".'>'.lang('plugin/liyou_weibo','syn_reply').'</label>';
					return $return;
				}
		}
		
		function viewthread_fastpost_btn_extra() {
				global $_G;
				if(LY_SYN_REPLY==0) return ;
				if($_G['uid'] && $_G['liyou_weibo_setting']['reply']==1)
				{
					$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
					$check='';if(empty($discuzUserInfo)) return '';
					if($discuzUserInfo['syn_reply'])
					{
						$check='checked="checked"';
					}
					$return='<label for="syn_reply"><input class="pc" type="checkbox" id="syn_reply" name="syn_reply" '."$check".'>'.lang('plugin/liyou_weibo','syn_reply').'</label>';
					return $return;
				}
		}

		function forumdisplay_fastpost_btn_extra(){
				global $_G;
				if(LY_SYN_THREAD==0) return ;
				if($_G['uid'] && $_G['liyou_weibo_setting']['thread']==1)
				{
					$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
					$check='';if(empty($discuzUserInfo)) return '';
					if($discuzUserInfo['syn_thread'])
					{
						$check='checked="checked"';
					}
					$return='<label for="syn_thread"><input class="pc" type="checkbox" id="syn_thread" name="syn_thread" '."$check".'>'.lang('plugin/liyou_weibo','syn_thread').'</label>';
					return $return;
				}
		}

		function viewthread_share_method_output() {
			global $_G;
			$share='';
			if(LY_AUTOSHARE)
			{
			$share='<!-- Baidu Button BEGIN -->
			<style type="text/css">#bdshare{float:none;}</style>
				<div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare" style="display:inline-block;">
				
				<a class="bds_tsina"><img src="source/plugin/liyou_weibo/image/logo.png" align="absmiddle" style="margin:4px 3px 0 0" />'.lang('plugin/liyou_weibo','ly_weibo').'</a>
				</div>
				<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=2028724" ></script>
				<script type="text/javascript" id="bdshell_js"></script>
				<script type="text/javascript">
				var bds_config={"snsKey":{"tsina":"'.APP_KEY.'"}};
				document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000);
				</script>
				<!-- Baidu Button END -->';
			}
			return $share;
		}

		function viewthread_bottom_output(){
			global $_G, $thread, $rushreply, $postlist, $page;
			$uids = $openids = array();
			foreach($postlist as $pid => $post) {
				if($post['anonymous']) {
					continue;
				}
				if($post['authorid']) {
					$uids[$post['authorid']] = $post['authorid'];
				}
			}

			foreach($postlist as $pid => $post) {
				$matches = array();
				preg_match('/\[threadlog=(.+?),(.+?)\](.*?)\[\/threadlog\]/', $post['message'], $matches);
				if(count($matches)>0) {
					if($matches[1] && $matches[2]) {
						//$post['message'] = preg_replace('/\[threadlog=(.+?)\](.*?)\[\/threadlog\]/', $_G['liyou_weibo']['tips'], $post['message']);
						$post['message'] =preg_replace('/\[threadlog=(.+?)\](.*?)\[\/threadlog\]/', lang('plugin/liyou_weibo','threadlog_message',array('userweibo'=>$matches[1],'nick'=>$matches[2])), $post['message']);
					}
					$post['authorid'] = 0;
					$post['author'] = lang('plugin/liyou_weibo','liyou_weibo_comment');
					$post['avatar'] = $matches[3] ? '<img src="'.$matches[3].'" height="120" width="120">' : '<img src="'.$_G['siteurl'].'/static/image/common/tavatar.gif">';
					$post['groupid'] = '7';
					$postlist[$pid] = $post;
					continue;
				}
				if($post['authorid']==0){
					$post['author'] = lang('plugin/liyou_weibo','liyou_weibo_comment');
					$post['avatar'] = '<img src="'.$_G['siteurl'].'/static/image/common/tavatar.gif">';
					$post['groupid'] = '7';
					$postlist[$pid] = $post;
				}
				if($post['anonymous']) {
					continue;
				}
				if($openids[$post['authorid']]) {
					
				}
				
			}
			if($page == 1 && $postlist[$_G['forum_firstpid']]['invisible'] == 0 && $_G['liyou_weibo_setting']['synthread']==1) {
				Lywb::u('thread',$thread['tid']);
				return $return;
			}
		}

	function  viewthread_sidetop_output()
	{
		global $_G, $thread, $rushreply, $postlist, $page;
		if(!LY_CLUB) return '';
		$img=$_G['siteurl'].'source/plugin/liyou_weibo/image/club.png';
		$arr=array();
		foreach($postlist as $key=>$value)
		{
			$duser='';
			if($value['authorid']>0)
			{
				$duser=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($value['authorid']);
			}
			if(!empty($duser))
			{
				$arr[]="<div style=\"text-align:center;margin-bottom:10px;\"><img src=\"$img\" /></div>";
			}else
			{
				$arr[]="<div style=\"text-align:center;\"></div>";
			}
		}
		return $arr;
	}

	function post_top()
	{

	}
}
class plugin_liyou_weibo_group extends plugin_liyou_weibo_forum {
	
}
class plugin_liyou_weibo_home extends plugin_liyou_weibo {
	public function spacecp_doing_message($param)
	{
		global $_G,$newdoid,$newid,$updo;
		if($param['param'][0]=='do_success')
		{
			if($this->_check_user_bind()==false) return '';
			$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
			if(submitcheck('addsubmit') && isset($newdoid) && $newdoid>0 && isset($discuzUserInfo['syn_doing']) && $discuzUserInfo['syn_doing']==1 && $_G['liyou_weibo_setting']['doing']==1)
			{
				$exter=array();
				$exter['id']=intval($newdoid);
				$exter['x']=1;
				Lywb::s('doing',$exter);
			}else if(submitcheck('commentsubmit') && isset($newid) && $newid>0 && isset($updo['doid']) && $updo['doid']>0 && $_G['liyou_weibo_setting']['comdoing']==1)
			{
				$exter=array();
				$exter['id']=intval($newid);
				$exter['x']=2;
				Lywb::s('doing',$exter);
			}
		}
	}

	public function space_doing_bottom_output()
	{
		global $_G,$page,$doids,$doid,$dolist,$showdoinglist,$clist;
		$doingid=$doid;
		if($doid==0){
			$doinglog = C::t('#liyou_weibo#ly_weibo_threadlog')->fetch_update_doinglog();
			$doingid=$doinglog['tid'];
		}
		$recordweibo=array();
		foreach($showdoinglist as $key=>$val)
		{
			$recordweibo[]=$key;
			$showdoinglist[$key]=1;
		}

		foreach($clist as $key=>$val)
		{
			if(in_array($key,$recordweibo))
			{
				foreach($val as $key1=>$val1)
				{
					if($val1['uid']>0) continue;
					$val1['uid']='9999999';
					$val1['username']=lang('plugin/liyou_weibo','liyou_weibo_comment');
					
					$matches = array();
					preg_match('/\[doinglog=(.+?),(.+?)\](.*?)\[\/doinglog\]/', $val1['message'], $matches);
					if(count($matches)>0) {
						if($matches[1] && $matches[2]) {
							$val1['message'] = preg_replace('/\[doinglog=(.+?)\](.*?)\[\/doinglog\]/', lang('plugin/liyou_weibo','doinglog_message',array('userweibo'=>$matches[1],'nick'=>$matches[2])), $val1['message']);
						}
					}
					$val[$key1]=$val1;
				}
				$clist[$key]=$val;
			}
		}

		if($doingid>0 && $_G['liyou_weibo_setting']['syndoing']==1) {
			$jsurl = '';
			Lywb::u('doing',$doingid);
		}
	}
	
	public function spacecp_follow_message($param)
	{
		global $_G;
		if($param['param'][0]=='post_newthread_succeed')
		{
			if($this->_check_user_bind()==false) return '';
			$fid=intval($param['param'][2]['fid']);
			$tid=intval($param['param'][2]['tid']);
			$pid=intval($param['param'][2]['pid']);
			if($fid>0 && $tid>0 && $pid>0 && LY_SYN_BROADCAST && $_G['liyou_weibo_user_setting']['syn_broadcast']==1 && $_G['liyou_weibo_setting']['broadcast']==1)
			{
				$exter=array();
				$exter['fid']=$fid;
				$exter['tid']=$tid;
				Lywb::s('broadcast',$exter);
			}
		}
	}
	public function follow_top_output()
	{
		global $_G,$page;
		$broadcastid='0';
		$lyflag=true;
		while($lyflag)
		{
			$arrbroadcast = C::t('#liyou_weibo#ly_weibo_threadlog')->fetch_update_broadcastlog();
			if(empty($arrbroadcast)){ $lyflag=false; return;}
			$broadcastid=$arrbroadcast['tid'];
			$arrThread=C::t('forum_post')->fetch_threadpost_by_tid_invisible($broadcastid);
			if(empty($arrThread))
			{
				 C::t('#liyou_weibo#ly_weibo_threadlog')->delete($arrbroadcast['wbid']);
				 $lyflag=false; 
				 return;
			}else
			{
				$setarr['updateline'] = $_G['timestamp']-$_G['liyou_weibo_setting']['model'];
				C::t('#liyou_weibo#ly_weibo_threadlog')->update($arrbroadcast['wbid'], $setarr);
				$lyflag=false;
			}
		}

		if(isset($page) && $page==1 && $broadcastid>0 && $_G['liyou_weibo_setting']['synbroadcast']==1) {
			Lywb::u('broadcast',$broadcastid);
			return '';
		}
	}
	function spacecp_blog_middle_output(){
		global $_G;
		$return = '';
		if( 'blog' != $_GET['ac'] || !$_G['uid']){
					return $return;
		}
		if($this->_check_user_bind()==false || $_G['liyou_weibo_setting']['blog']==0) return $return;
		$return='<label for="blog_syn"><input class="pc" type="checkbox" id="blog_syn" name="blog_syn" '."$check".'>'.lang('plugin/liyou_weibo','blog_syn').'</label>';
		return $return;
	}
	public function spacecp_blog_message($param)
	{
		global $_G,$newblog,$idtype,$cidarr;
		if($param['param'][0]=='do_success')
		{
			$return = '';
			if($this->_check_user_bind()==false) return '';
			if('blog' == $_GET['ac'] && $_POST['blogsubmit']=true && isset($_POST['blog_syn']) && $_POST['blog_syn']=='on' && isset($newblog) && !empty($newblog) && $_G['liyou_weibo_user_setting']['syn_blog']==1 && $_G['liyou_weibo_setting']['blog']==1){
				$exter=array();
				$exter['id']=intval($newblog['blogid']);
				Lywb::s('blog',$exter);
			}else{
				return $return;
			}
		}
	}
	public function spacecp_comment_message($param)
	{
		global $_G,$newblog,$idtype,$cidarr;

		if($param['param'][0]=='do_success')
		{
			$return = '';
			if($this->_check_user_bind()==false) return '';
			 if('comment' == $_GET['ac'] && submitcheck('commentsubmit') && $idtype=='blogid' && !empty($cidarr) && $_G['liyou_weibo_setting']['comblog']==1){
				$blog=C::t('home_comment')->fetch($cidarr['cid']);
				$this->_ly_weibo_comment($blog['id'],$blog['message'],'blog');
			}else if('comment' == $_GET['ac'] && submitcheck('commentsubmit') && $idtype=='sid' && !empty($cidarr) && $_G['liyou_weibo_setting']['comshare']==1){
				$share=C::t('home_comment')->fetch($cidarr['cid']);
				$this->_ly_weibo_comment($share['id'],$share['message'],'share');
			}else{
				return $return;
			}
		}
	}
	public function _getblog_picture($id)
	{
		global $_G;
		$attach=C::t('home_blog')->fetch_by_id_idtype($id);
		$picUrl='';
		if(!empty($attach) && $attach['picflag']==1)
		{
				$attach1=C::t('home_blogfield')->fetch($id);
				$attach['attachment']=trim(str_replace('.thumb.jpg','',$attach1['pic']));
				if($attach['remote']) {
					$picUrl= $_G['setting']['ftp']['attachurl'].'album/'.$attach['attachment'];
				} else {
					$picUrl = $_G['setting']['attachurl'].'album/'.$attach['attachment'];
					if(strpos($picUrl, $_G['siteurl'])==false) {
						$picUrl = $_G['siteurl'].$picUrl;
					}
				}
		}
		return $picUrl;	
	}
	public function space_blog_face_extra_output()
	{
		global $_G,$page,$blog,$list;
		foreach($list as $pid => $post) {
			$matches = array();
			preg_match('/\[bloglog=(.+?),(.+?)\](.*?)\[\/bloglog\]/', $post['message'], $matches);
			if(count($matches)>0) {
				if($matches[1] && $matches[2]) {
					$post['message'] = preg_replace('/\[bloglog=(.+?)\](.*?)\[\/bloglog\]/', lang('plugin/liyou_weibo','bloglog_message',array('userweibo'=>$matches[1],'nick'=>$matches[2])), $post['message']);
				}
				$list[$pid] = $post;
				continue;
			}

			if ($post['authorid']==0) {
				$post['message']=Lywb::weibo_tips($post['message']);
				$list[$pid] = $post;
			}
		}
		if( isset($page) && $page==1 && isset($blog) && !empty($blog) && $blog['noreply']==0 && $blog['status']==0 && $_G['liyou_weibo_setting']['synblog']==1) {
			Lywb::u('blog',$blog['blogid']);
			return '';
		}
	}
	public function spacecp_share_message($param)
	{
		global $_G;
		if($param['param'][0]=='do_success')
		{
			if($this->_check_user_bind()==false) return '';
			$sid=intval($param['param'][2]['sid']);
			if($sid>0 && LY_SYN_SHARE && $_G['liyou_weibo_user_setting']['syn_share']==1 && $_G['liyou_weibo_setting']['share']==1)
			{
				$exter=array();
				$exter['id']=$sid;
				Lywb::s('share',$exter);
			}
		}
	}
	public function space_share_comment_bottom_output()
	{
		global $_G,$page,$list;
		$shareid=(isset($_GET['id']) && intval($_GET['id'])>0)?intval($_GET['id']):'0';
		if($shareid==0)
		{
			$arrshare = C::t('#liyou_weibo#ly_weibo_threadlog')->fetch_update_sharelog();
			if(empty($arrshare)){ $lyflag=false; return;}
			$shareid=$arrshare['tid'];
		}else{
			foreach($list as $pid => $post) {
				$matches = array();
				preg_match('/\[sharelog=(.+?),(.+?)\](.*?)\[\/sharelog\]/', $post['message'], $matches);
				if(count($matches)>0) {
					if($matches[1] && $matches[2]) {
						$post['message'] = preg_replace('/\[sharelog=(.+?)\](.*?)\[\/sharelog\]/', lang('plugin/liyou_weibo','sharelog_message',array('userweibo'=>$matches[1],'nick'=>$matches[2])), $post['message']);
					}
					$list[$pid] = $post;
					continue;
				}
				if ($post['authorid']==0) {
					$post['message']=Lywb::weibo_tips($post['message']);
					$list[$pid] = $post;
				}
			}
		}

		if( isset($page) && $page==1 && $shareid>0 && $_G['liyou_weibo_setting']['synshare']==1) {
			$jsurl = '';
			Lywb::u('share',$shareid);
			return '';
		}
	}

}
class plugin_liyou_weibo_portal extends plugin_liyou_weibo{
	function portalcp_bottom_output(){
		global $_G;
		$return = '';
		if( 'article' != $_GET['ac'] || !$_G['uid'] || (!isset($GLOBALS['op']) || 'add' != $GLOBALS['op'])){
					return $return;
		}
		if($this->_check_user_bind()==false || $_G['liyou_weibo_setting']['article']==0) return $return;
		$return='<label for="article_syn"><input class="pc" type="checkbox" id="article_syn" name="article_syn" '."$check".'>'.lang('plugin/liyou_weibo','article_syn').'</label>';
		return $return;
	}
	function portalcp_ly_synarticle_output(){
		global $_G,$op,$aid;
		$return = '';
		if($this->_check_user_bind()==false) return '';
		if( 'article' != $_GET['ac'] || !$_G['uid'] ){
			return $return;
		}else if($_GET['articlesubmit']=true && isset($op) && $op=="add_success" && isset($_GET['article_syn']) && $_GET['article_syn']=='on' && isset($aid) && $aid>0 && $_G['liyou_weibo_user_setting']['syn_portal']==1 && $_G['liyou_weibo_setting']['article']==1){
			
			$exter=array();
			$exter['id']=$aid;
			Lywb::s('article',$exter);
		}else{
			return $return;
		}
	}
	public function view_article_summary_output()
	{
		global $_G,$article,$page,$commentlist;
		foreach($commentlist as $pid => $post) {
			$matches = array();
			preg_match('/\[articlelog=(.+?),(.+?)\](.*?)\[\/articlelog\]/', $post['message'], $matches);
			if(count($matches)>0) {
				if($matches[1] && $matches[2]) {
					$post['message'] = preg_replace('/\[articlelog=(.+?)\](.*?)\[\/articlelog\]/', lang('plugin/liyou_weibo','articlelog_message',array('userweibo'=>$matches[1],'nick'=>$matches[2])), $post['message']);
				}
				$post['username'] = lang('plugin/liyou_weibo','article_comment');
				$commentlist[$pid] = $post;
				continue;
			}
			if($post['anonymous']) {
				continue;
			}
			if ($post['uid']==0) {
				$post['message']=Lywb::weibo_tips($post['message']);
				$commentlist[$pid] = $post;
			}
			if($openids[$post['authorid']]) {
				
			}
	
		}
		if(isset($page) && $page==1 && isset($article) && !empty($article) && $article['allowcomment'] && !$article['status'] && $_G['liyou_weibo_setting']['synarticle']==1) {
			$jsurl = '';
			Lywb::u('article',$article['aid']);
		}
	}
	public function  portalcp_comment_message($param)
	{
		global $_G,$id,$message;

		if($param['param'][0]=='do_success')
		{
			$return = '';
			if($this->_check_user_bind()==false) return '';
			 if('comment' == $_GET['ac'] && submitcheck('commentsubmit') && $id>0 && $_G['liyou_weibo_setting']['comarticle']==1){
				$this->_ly_weibo_comment($id,$message,'article');
			}
		}
	}
	public function  comment_view_output()
	{
		global $_G,$commentlist,$page,$id;
		foreach($commentlist as $pid => $post) {
			$matches = array();
			preg_match('/\[articlelog=(.+?),(.+?)\](.*?)\[\/articlelog\]/', $post['message'], $matches);
			if(count($matches)>0) {
				if($matches[1] && $matches[2]) {
					$post['message'] = preg_replace('/\[articlelog=(.+?)\](.*?)\[\/articlelog\]/', lang('plugin/liyou_weibo','articlelog_message',array('userweibo'=>$matches[1],'nick'=>$matches[2])), $post['message']);
				}
				$post['username'] = lang('plugin/liyou_weibo','article_comment');
				$commentlist[$pid] = $post;
				continue;
			}
			if($post['anonymous']) {
				continue;
			}
			if($openids[$post['authorid']]) {
				
			}
	
		}
		if(isset($page) && $page==1 && $id>0 && $_G['liyou_weibo_setting']['synarticle']==1) {
			$jsurl = '';
			Lywb::u('article',$id);
		}
	}
}
//WWW.fx8.cc
?>