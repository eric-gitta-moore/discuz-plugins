<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class Liyouweibo extends Lywbsyn{

	protected function thread($data,$exter){
		global $_G;
		$tid = $exter['tid'];
		$uid = $exter['uid'];
		$arrThread=C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
		$subject=$arrThread['subject'];
		$message=$arrThread['message'];
		$url = $_G['siteurl']."forum.php?mod=viewthread&tid=$tid";
		$tpl = $_G['liyou_weibo_setting']['contenttemplate'];
		$message=Lywb::_make_message($tpl,$message,$subject,$url);
		$pic=Lywb::_get_picture($arrThread['pid']);
		$this->send($message,$pic,$uid,$tid,'thread');
	}

	protected function share($data,$exter){
		global $_G;
		$weibotips=lang('plugin/liyou_weibo','ly_weibo_source');
		$weibotips=LywbFunc::toWeibo($weibotips);
		$urlLink=$weibotips.$urlLink;
		$id = $exter['id'];
		$uid = $exter['uid'];
		$arrShare=C::t('home_share')->fetch($id);
		$arrShare['body_data']=unserialize($arrShare['body_data']);
		$subject='';
		$message=$arrShare['body_general'];
		if(!empty($arrShare['body_data']['data'])) 
		{
			$message.=$arrShare['body_data']['data'];
		}
		$tpl='';
		$pic='';
		$url=$_G['siteurl'].'home.php?mod=space&uid='.$uid.'&do=share&id='.$id;
		$message=Lywb::_make_message($tpl,$message,$subject,$url);
		$this->send($message,$pic,$uid,$id,'share');
	}

	protected function reply($data,$exter){
		global $_G;
		$tpl = $_G['liyou_weibo_setting']['replytemplate'];
		$tid = $exter['tid'];
		$pid = $exter['pid'];
		$uid = $exter['uid'];
		$arrThread=C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
		$arrPost=C::t('forum_post')->fetch_by_pid_condition('0:0',$pid);
		$subject=$arrThread['subject'];
		$message=$arrPost['message'];
		if($exter['syn'])
		{
			$url = $_G['siteurl']."forum.php?mod=viewthread&tid=$tid";
			$message=Lywb::_make_message($tpl,$message,$subject,$url);
			$pic=Lywb::_get_picture($pid);
			$this->send($message,$pic,$uid,$tid,'reply',false);
		}
		if($exter['csyn'])
		{
			$type = $exter['fid']==$_G['setting']['followforumid'] ?'broadcast':'thread';
			Lywb::_ly_weibo_comment($tid,$arrPost['message'],$type,$uid);
		}
	}

	protected function doing($data,$exter){
		global $_G;
			$x = $exter['x'];
			$id = $exter['id'];
			$uid = $exter['uid'];
			if($x==1){
				$sinareturn='';
				$subject='';
				$ldoing=C::t('home_doing')->fetch($id);
				$message=$ldoing['message'];
				$message=strip_tags($message);
				$pic='';
				$tpl='';
				$url = $_G['siteurl'].'home.php?mod=space&uid='.$uid.'&do=doing&from=space';
				$message=Lywb::_make_message($tpl,$message,$subject,$url);
				$this->send($message,$pic,$uid,$id,'doing');
			}else if($x==2){
				$doing=C::t('home_docomment')->fetch($id);
				Lywb::_ly_weibo_comment($doing['doid'],$doing['message'],'doing',$uid);
			}
	}

	protected function article($data,$exter){
		global $_G;
		$id = $exter['id'];
		$uid = $exter['uid'];
		$tpl = $_G['liyou_weibo_setting']['articletemplate'];
		$c=C::t('portal_article_content')->fetch($id);
		$t=C::t('portal_article_title')->fetch($id);
		$subject=$t['title'];
		$message=$c['content'];
		$url = $_G['siteurl']."portal.php?mod=view&aid=$id";
		$message=Lywb::_make_message($tpl,$message,$subject,$url);
		$pic = Lywb::_get_portal_picture($id);
		$this->send($message,$pic,$uid,$id,'article');
	}

	protected function blog($data,$exter){
		global $_G;
		$id = $exter['id'];
		$uid = $exter['uid'];
		$tpl = $_G['liyou_weibo_setting']['blogtemplate'];
		$attach=C::t('home_blog')->fetch_by_id_idtype($id);
		$attach1=C::t('home_blogfield')->fetch($id);
		$pic=Lywb::_get_blog_picture($attach,$attach1);
		$message=$attach1['message'];
		$subject=$attach['subject'];
		$url = $_G['siteurl'].'home.php?mod=space&uid='.$uid.'&do=blog&quickforward=1&id='.$id;
		$message=Lywb::_make_message($tpl,$message,$subject,$url);
		$this->send($message,$pic,$uid,$id,'blog');
	}

	protected function broadcast($data,$exter){
		global $_G;
		$tid = $exter['tid'];
		$uid = $exter['uid'];
		$tpl = '';
		$arrThread=C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
		$subject=$arrThread['subject'];
		$message=$arrThread['message'];
		$url = $_G['siteurl'].'home.php?mod=follow&uid='.$uid.'&do=view';
		$message=Lywb::_make_message($tpl,$message,$subject,$url);
		$pic=Lywb::_get_picture($arrThread['pid']);
		$this->send($message,$pic,$uid,$tid,'broadcast');
	}
}
