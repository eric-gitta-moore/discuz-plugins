<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//ini_set('display_errors', 'On');
//error_reporting(E_ALL);
define('APP_KEY',$_G['cache']['plugin']['liyou_weibo']['app_key']);
define('APP_SECRET',$_G['cache']['plugin']['liyou_weibo']['app_secret']);
define('LY_NOTICE',$_G['cache']['plugin']['liyou_weibo']['ly_notice']);
define('LY_UID',$_G['cache']['plugin']['liyou_weibo']['ly_weibo_uid']);
define('LY_POSITION',$_G['cache']['plugin']['liyou_weibo']['ly_btn_position']);
define('APP_CALLBACK',$_G['siteurl'].'plugin.php?id=liyou_weibo:callback');

define('LY_SYN_THREAD',$_G['cache']['plugin']['liyou_weibo']['syn_thread']);
define('LY_SYN_REPLY',$_G['cache']['plugin']['liyou_weibo']['syn_reply']);
define('LY_SYN_BLOG','1');
define('LY_SYN_DOING','1');
define('LY_SYN_SHARE','1');
define('LY_SYN_BROADCAST','1');
define('LY_SYN_PORTAL','1');
define('LY_ONEKEY',$_G['cache']['plugin']['liyou_weibo']['ly_is_onkey']);
define('LY_USERGROUP',$_G['cache']['plugin']['liyou_weibo']['ly_user_group']);
define('LY_USERPRE','Wb');

define('LY_INFO_HUATI',$_G['cache']['plugin']['liyou_weibo']['info_huati']);
define('LY_LOGIN_INFO',$_G['cache']['plugin']['liyou_weibo']['login_info']);
define('LY_MESSAGE',$_G['cache']['plugin']['liyou_weibo']['info_fomat']);

define('LY_AUTOFAN',$_G['cache']['plugin']['liyou_weibo']['auto_fans']);
define('LY_AUTOSHARE',$_G['cache']['plugin']['liyou_weibo']['auto_shares']);
define('LY_CLUB',$_G['cache']['plugin']['liyou_weibo']['ly_club']);
define('LY_AUTHEX',$_G['cache']['plugin']['liyou_weibo']['ly_authexpire']);
define('LY_BINDTIPS',$_G['cache']['plugin']['liyou_weibo']['ly_bindtips']);
define('LY_RECUID',$_G['cache']['plugin']['liyou_weibo']['ly_recuid']);
define('LY_BOTTOMSTYLE',trim($_G['cache']['plugin']['liyou_weibo']['ly_bottomtip_style']));
define('LY_MULTIW',$_G['cache']['plugin']['liyou_weibo']['ly_multi_weibo']);

$aallowg=dunserialize($_G['cache']['plugin']['liyou_weibo']['ly_multi_weibog']);

define('IS_GBK', strtoupper(CHARSET) == 'GBK');
defined('WEIBO_PATH') || define('WEIBO_PATH', DISCUZ_ROOT.'source/plugin/liyou_weibo/');

define('REURL',$_G['siteurl'].'plugin.php?id=liyou_weibo:spacecp');

require_once(WEIBO_PATH.'config/global.func.php');
LywbFunc::_init();

checkEnviroment();

$logo=$_G['siteurl'].$_G['style']['boardimg'];

$liyou_weibo_setting=Array(
'blog' => 1,
'article' => 1,
'doing' => 1,
'broadcast' => 1,
'share' => 1,
'thread' => 1,
'reply' => 1,
'synthread' => 1,
'synblog' => 1,
'syndoing' => 1,
'synshare' => 1,
'synarticle' => 1,
'synbroadcast' => 1,
'comthread' => 1,
'comblog' => 1,
'comdoing' => 1,
'comshare' => 1,
'comarticle' => 1,
'combroadcast' => 1,
'model' => 10,
'contenttemplate' => '#{bbsname}# {subject} {content}{subjecturl}',
'replytemplate' => '#{bbsname}# {subject} {content}{subjecturl}',
);
$liyouWeiboSetting=C::t('#liyou_weibo#ly_weibo_setting') -> fetchAll();
foreach($liyouWeiboSetting as $key=>$value)
{
	$liyou_weibo_setting[$value['skey']]=$value['svalue'];
}
if(isset($liyou_weibo_setting['model']))
{
	$liyou_weibo_setting['model']=intval($liyou_weibo_setting['model'])*60;
}else
{
	$liyou_weibo_setting['model']=60*3;
}
$_G['liyou_weibo_setting']=$liyou_weibo_setting;

function checkEnviroment()
{
	$checkEnviroment= DISCUZ_ROOT.'./source/plugin/liyou_weibo/enviroment.php';
	if(file_exists($checkEnviroment))
	{
		$newname=$checkEnviroment.'.lock';
		if(file_exists($checkEnviroment)) @unlink($newname);
		require_once libfile('function/plugin');
		if(function_exists('runquery'))
		{
			include  $checkEnviroment;
			@unlink($checkEnviroment);
		}
	}
}

//From:www_YMG6_COM
?>