<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/sina_api/saetv2.ex.class.php';
class LywbFunc{

	protected static $_set=array();

	static function _init(){
		global $_G;
		self::$_set=$_G['cache']['plugin']['liyou_weibo'];
	}

	static function get_set(){
		return self::$_set;
	}

	static function fromWeibo($arr){
		if(!IS_GBK){
			return $arr;
		}
		return self::_iconv($arr,'gbk');
	}

	static function toWeibo($arr){
		if(!IS_GBK){
			return $arr;
		}
		return self::_iconv($arr,'utf-8');
	}

	static function _iconv($arr,$to){
		if (is_array($arr)) {
			foreach ($arr as $k => $val) {
				$arr[$k]=self::_iconv($val,$to);
			}
		}else{
			if ($to=='utf-8') {
				$arr=iconv("GBK","UTF-8//IGNORE",$arr);
			}else{
				$arr=iconv("UTF-8","GB2312//IGNORE",$arr);
			}
		}
		return $arr;
	}

	static function sm($m,$url_forward = '', $values = array(), $extraparam = array(), $custom = 0){
		global $_G;
		if(substr($url_forward,0,5)=='weibo'){
			$rdata=$values;
			$values = array();
			$call_back=substr($url_forward,6);
			if (method_exists('LywbFunc', $call_back)) {
				call_user_func_array(array('LywbFunc',$call_back), array($rdata));
			}
			switch ($call_back) {
				case 'updatebind_s':
				case 'bind_s':
					$url_forward=dreferer();
					break;
				default:
					$url_forward=$_G['siteurl'];
					break;
			}
		}
		showmessage($m,$url_forward,$values,$extraparam,$custom);
	}

	static function login_s($data){

	}

	static function bind_s($data){

	}

	static function updatebind_s($data){

	}

	static function aotulogin_s($data){
		
	}



	static function tb_json_encode($value, $options = 0)
	{
	  return json_encode(self::tb_json_convert_encoding($value, "GBK", "UTF-8"));
	}

	static function tb_json_decode($str, $assoc = false, $depth = 512)
	{
	  return self::tb_json_convert_encoding(json_decode($str, $assoc), "UTF-8", "GBK");
	}

	static function tb_json_convert_encoding($m, $from, $to)
	{
	  switch(gettype($m)) {
	    case 'integer':
	    case 'boolean':
	    case 'float':
	    case 'double':
	    case 'NULL':
	      return $m;
	    case 'string':
	      if (function_exists('mb_convert_encoding')) {
	      	return mb_convert_encoding($m, $to, $from);
	      }else{
	      	return iconv($from,$to.'//IGNORE',$m);
	      }
	    case 'object':
	      $vars = array_keys(get_object_vars($m));
	      foreach($vars as $key) {
	        $m->$key = self::tb_json_convert_encoding($m->$key, $from ,$to);
	      }
	      return $m;
	    case 'array':
	      foreach($m as $k => $v) {
	      	//$k=self::tb_json_convert_encoding($k, $from, $to);
	        $m[$k] = self::tb_json_convert_encoding($v, $from, $to);
	      }
	      return $m;
	    default:
	  }
	  return $m;
	}

	static function todecode($arr){
		if (is_array($arr)) {
			foreach ($arr as $k => $val) {
				$arr[$k]=self::todecode($val);
			}
		}else{
			$arr=iconv("UTF-8","GB2312//IGNORE",$arr);
		}
		return $arr;
	}

	static function C($uid,$credit,$num,$title='',$desc=''){
		if(DZVERSION=='X2.5'){
			return updatemembercount($uid, array('extcredits'.$credit =>$num), true, '', 0, '');
		}else{
			return updatemembercount($uid, array('extcredits'.$credit => $num), true, '', 0, '',$title,$desc);
		}
	}

	static function notify($uid,$m,$data){
		notification_add($uid, 'system',$m, array('name' =>$data['title'],'answer' =>$data['content'],'url' =>$data['url']), 1);		
	}

	static function cache($name){
		global $_G;
		$list ='';

		return $list;
	}

	static function loadcache($name){
	    global $_G;
		if(!isset($_G['cache']['liyou_weibo_'.$name])) {
			loadcache('liyou_weibo_'.$name);
		}
		if (!isset($_G['cache']['liyou_weibo_'.$name])) {
			$list=LywdFunc::cache($name);
			$_G['cache']['liyou_weibo_'.$name]=$list;
		}
		$cache = &$_G['cache']['liyou_weibo_'.$name];
		if (isset($cache['expiretime']) && $cache['expiretime']<TIMESTAMP) {
			$cache=LywdFunc::cache($name);
		}
		unset($cache['cachetime']);
		unset($cache['expiretime']);
		return $cache;
	}

	static function getIds($arr,$field='id'){
	    $f1= 'return "$k['.$field.']";';
	    $newfunc = create_function('$k,$v',$f1);
	    return array_map($newfunc, $arr);
	}

	static function keyToid($arr,$field='id'){
	    $tmp = array();
	    foreach ($arr as $key => $value) {
	        $index = $value[$field];
	        $tmp[$index]=$value;
	    }
	    return $tmp;
	}

	static function substr($string, $sublen, $start = 0, $code = '') 
	{
		$code = strtolower($code)=='utf-8'?true:self::is_utf8($string);
		if($code) 
		{ 
			$pa ="/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/"; 
			preg_match_all($pa, $string, $t_string); 
			if(count($t_string[0]) - $start > $sublen) return join('', array_slice($t_string[0], $start, $sublen))."..."; 
			return join('', array_slice($t_string[0], $start, $sublen)); 
		} 
		else 
		{ 
			$start = $start*2; 
			$sublen = $sublen*2; 
			$strlen = strlen($string); 
			$tmpstr = ''; 
			for($i=0; $i<$strlen; $i++) 
			{ 
				if($i>=$start && $i<($start+$sublen)) 
				{ 
					if(ord(substr($string, $i, 1))>129) 
					{ 
						$tmpstr.= substr($string, $i, 2); 
					} 
					else 
					{ 
						$tmpstr.= substr($string, $i, 1); 
					} 
				} 
				if(ord(substr($string, $i, 1))>129) $i++; 
			} 
			if(strlen($tmpstr)<$strlen) return $tmpstr.'...'; 
			return $tmpstr; 
		}
	}

	static function is_utf8($str) 
	{ 
		if (preg_match("/^([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}/",$str) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}$/",$str) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){2,}/",$str) == true) 
		{ 
		return true; 
		} 
		else 
		{ 
		return false; 
		}
	}

	static function length($str,$charset='utf-8'){
	    if(strtolower($charset)=='utf-8') $str = iconv('utf-8','gb2312',$str);
	    $num = strlen($str);
	    $cnNum = 0;
	    for($i=0;$i<$num;$i++){
	        if(ord(substr($str,$i+1,1))>127){
	            $cnNum++;
	            $i++;
	        }
	    }
	    $enNum = $num-($cnNum*2);
	    $number = ($enNum/2)+$cnNum;
	    return ceil($number);
	}

	static function request($url,$data=array(),$cookie=array(),$method='GET',$r=false,$timeout=15){
		$urlinfo = parse_url($url);
		$port = isset($urlinfo['port'])?$urlinfo['port']:'80';
		$urlinfo['host'] = isset($urlinfo['host'])?$urlinfo['host']:'127.0.0.1';

		if(function_exists('fsockopen')) {
			$fp = @fsockopen($urlinfo['host'], $port, $errno, $errstr, $timeout);
		} elseif(function_exists('pfsockopen')) {
			$fp = @pfsockopen($urlinfo['host'], $port, $errno, $errstr, $timeout);
		} elseif(function_exists('stream_socket_client')) {
			$fp = @stream_socket_client($urlinfo['host'].':'.$port, $errno, $errstr, $timeout);
		}

		if(!$fp) return false;
		$pathandquery=$urlinfo['path'].'?'.$urlinfo['query'];
		if(!empty($data)) $method='POST';

		$header = $method." ".$pathandquery." HTTP/1.1\r\n";
		$header .="Host: {$urlinfo['host']}"."\r\n";
		$header .="Connection: Close"."\r\n";
		if (!empty($cookie)) {
			$_cookie='';
			foreach ($cookie as $key => $val) {
				$_cookie .= $key.'='.$val.';';
			}
			$header .=  "Cookie: " . base64_encode($_cookie) ." \r\n";
		}
		if (!empty($data)) {
			$_data='';
			foreach ($data as $key => $val) {
				$_data .= $key.'='.$val.'&';
			}
			$post_str  = "Content-Type: application/x-www-form-urlencoded\r\n";
			$post_str .= "Content-Length: ". strlen($_post) ." \r\n";
			$post_str .= $_data."\r\n";
			$header .=$post_str;
		}
		$header .="\r\n";
		fwrite($fp, $header);
		$status = $r?stream_get_meta_data($fp):'';
		$return='';
		if ($r && !$status['timed_out']) {
			while (!feof($fp)) {
				$head = @fgets($fp);
				$findstr = 'Content-Length:';
				if(strpos($head, $findstr) !== false){
				    $limit = intval(substr($head, strlen($findstr)));
				}
			    if($head == "\r\n" ||  $head == "\n") {
			        break;
			    }
			}
			$stop = false;
	      	while(!feof($fp) && !$stop) {
	                $data = fread($fp, ($limit == 0 || $limit > 8192 ? 8192 : $limit));
	                $return .= $data;
	                if($limit) {
	                    $limit -= strlen($data);
	                    $stop = $limit <= 0;
	                }
	         }
     	}
		fclose($fp);
		return true;
	}
}



if (!function_exists('json_encode')) {
	function json_encode($array = array()) {
		if(!is_array($array)) return null;
		$json = "";
		$i = 1;
		$comma = ",";
		$count = count($array);
		foreach($array as $k=>$v){
		if($i==$count) $comma = "";
		if(!is_array($v)){
		$v = addslashes($v);
		$json .= '"'.$k.'":"'.$v.'"'.$comma;
		}
		else{
		$json .= '"'.$k.'":'.json_encode($v).$comma;
		}
		$i++;
		}
		$json = '{'.$json.'}';
		return $json;
	}
}

if (!function_exists('json_decode')) {
	function json_decode($json, $assoc = true) {
		$comment = false;
		$out     = '$x=';
		$json = preg_replace('/:([^"}]+?)([,|}])/i', ':"\1"\2',$json);
		for ($i=0; $i<strlen($json); $i++) {
		if (!$comment) {
		if (($json[$i] == '{') || ($json[$i] == '[')) {
		$out .= 'array(';
		}
		elseif (($json[$i] == '}') || ($json[$i] == ']')) {
		$out .= ')';
		}
		elseif ($json[$i] == ':') {
		$out .= '=>';
		}
		elseif ($json[$i] == ',') {
		$out .= ',';
		}
		elseif ($json[$i] == '"') {
		$out .= '"';
		}
		}
		else $out .= $json[$i] == '$' ? '\$' : $json[$i];
		if ($json[$i] == '"' && $json[($i-1)] != '\\')  $comment = !$comment;
		}
		eval($out. ';');
		return $x;
	}
}

class Lywb{
	static function bind_user($token,$weibouserinfo,$uid,$auto=0){
		global $_G;
		$member=getuserbyuid($uid);
		$insertUpdate=array(
				'uid'=>$uid,
				'weibo_uid'=>addslashes(trim($token['uid'])),
				'username'=>addslashes(trim($member['username'])),
				'weibo_username'=>addslashes(trim($weibouserinfo['screen_name'])),
				'access_token'=>addslashes(trim($token['access_token'])),
				'expires_in'=>intval($token['expires_in']),
				'remind_in'=>intval($token['remind_in']),
				'dateline'=>TIMESTAMP,
				'syn_thread'=>intval(LY_SYN_THREAD),
				'syn_reply'=>intval(LY_SYN_REPLY),
				'syn_blog'=>intval(LY_SYN_BLOG),
				'syn_doing'=>intval(LY_SYN_DOING),
				'syn_share'=>intval(LY_SYN_SHARE),
				'syn_broadcast'=>intval(LY_SYN_BROADCAST),
				'syn_portal'=>intval(LY_SYN_PORTAL),
				'is_onkey'=>$auto
		);
		$re=C::t('#liyou_weibo#ly_weibo_bind')->insert($insertUpdate);
		$sitename=$_G['setting']['bbname'];
		$message=LY_MESSAGE.$_G['siteurl'];
		$message=LywbFunc::toWeibo($message);
		$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$token['access_token']);
		if(LY_LOGIN_INFO)
		{
			$oClient->update($message);
		}
		if(LY_AUTOFAN)
		{
			//$oClient->follow_by_id(LY_UID);
		}
		$reward=C::t('#liyou_weibo#ly_weibo_rewardlog')->get_by_uid($uid);
		$set=LywbFunc::get_set();
		if(!$reward){
			if ($set['ly_credittype']>0 && $set['ly_credit']>0) {
				$title=lang('plugin/liyou_weibo','credit_add');
				LywbFunc::C($uid,$set['ly_credittype'],$set['ly_credit'],$title,$title);
				$data=array(
				'uid'=>$uid,
				'value'=>$set['ly_credit'],
				'dateline'=>TIMESTAMP,
				);
				C::t('#liyou_weibo#ly_weibo_rewardlog')->insert($data);
			}
		}
		dsetcookie('weibo_token','',-1);
		return $re;
	}

	static function update_user($token,$weibouserinfo,$member,$uid){
		$arrUpdate=array(
				'username'=>addslashes(trim($member['username'])),
				'weibo_username'=>addslashes(trim($weibouserinfo['screen_name'])),
				'access_token'=>addslashes(trim($token['access_token'])),
				'expires_in'=>intval($token['expires_in']),
				'remind_in'=>intval($token['remind_in']),
				'dateline'=>TIMESTAMP
				);
		$re=C::t('#liyou_weibo#ly_weibo_bind')->update($uid,$arrUpdate);
		dsetcookie('weibo_token','',-1);
		return $re;
	}

	static function weibo_tips($message){
		$message .= '<span style="margin-left:25px;color:red;float:right;">'.lang('plugin/liyou_weibo','article_comment').'</span>';
		return $message;
	}

	static function get_updatetime(){
		global $_G;
		switch($_G['liyou_weibo_setting']['model']){
			case '1':
				$update_time=$_G['timestamp']-3*60;
				$cookie_time=30;
				break;
			case '4':
				$update_time=$_G['timestamp']-3*60;
				$cookie_time=60;
				break;
			case '7':
				$update_time=$_G['timestamp']-3*60;
				$cookie_time=60*3;
				break;
			case '10':
				$update_time=$_G['timestamp']-3*60;
				$cookie_time=60*2;
				break;
			default:
				$update_time=$_G['timestamp']-3*60;
				$cookie_time=60;
				break;
		}
		$update_time=$_G['timestamp']-3*60;
		$cookie_time=$_G['liyou_weibo_setting']['model'];
		return array('time'=>$update_time,'ct'=>$cookie_time);
	}

	static function s($type,$exter){
		global $_G;
		$data['type']=$type;
		$data['siteurl']=$_G['siteurl'];
		$exter['uid']=$_G['uid'];
		$data['exter']=$exter;
		$string = serialize($data);
		$token=authcode($string,'ENCODE',$_G['config']['security']['authkey']);
		LywbFunc::request(REURL.'&token='.$token.'&a=syn&type='.$type);
	}

	static function c($tid,$lcmessage,$type,$bbsid){
		global $_G;
		$data['type']=$type;
		$exter['uid']=$_G['uid'];
		$exter['bbsid']=$bbsid;
		$exter['tid']=$tid;
		$exter['type']=$type;
		$data['exter']=$exter;
		$string = serialize($data);
		$token=authcode($string,'ENCODE',$_G['config']['security']['authkey']);
		$post['message']=$lcmessage;
		LywbFunc::request(REURL.'&token='.$token.'&a=syn&type=comment',$post);
	}

	static function i(){
		global $_G;
		$t=Lywb::get_updatetime();
		$update_time=$t['time'];
		$cookie_time=$t['ct'];
		$intert=$_G['timestamp']-86400*30;
		if(!$_G['cookie']['liyouweibo_sync']) {
			$threadlist = C::t('#liyou_weibo#ly_weibo_threadlog')->get_list($update_time,$intert);
			if (!empty($threadlist)) {
				LywbFunc::request(REURL.'&datal='.base64_encode(serialize($threadlist)).'&a=back');
			}
			dsetcookie('liyouweibo_sync', 1, $cookie_time);
		}
	}

	static function u($type,$tid){
		global $_G;
		$cname='liyou_weiboy_'.$type.$tid;
		$t=Lywb::get_updatetime();
		if(!$_G['cookie'][$cname]){
			LywbFunc::request(REURL.'&wid='.$tid.'&a=back&type='.$type);
			dsetcookie($cname,1,$t['ct']);
		}
	}

	static function allow(){
		static $allowOp=array('thread','article','blog','doing','broadcast','share');
		return $allowOp;
	}

	static function _get_weibo_client($uid=0){
		global $_G;
		$oClient=null;
		if ($uid) {
			$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($uid);
			$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$discuzUserInfo['access_token']);
		}else if($_G['cookie']['bind_weibo_token']) {
			$token = dunserialize($_G['cookie']['bind_weibo_token']);
			$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$token['access_token']);
		}else if($_G['cookie']['weibo_token']){
			$token = dunserialize($_G['cookie']['weibo_token']);
			$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$token['access_token']);
		}else
		{
			$discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($_G['uid']);
			$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$discuzUserInfo['access_token']);
		}
		return $oClient;
	}

	static function _get_weibo_client_by_access_token($token){
		$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$token);
		return $oClient;
	}

	static function _filter($message){
		require_once libfile('function/discuzcode');
		$message=preg_replace('!\[(attachimg|attach)\]([^\[]+)\[/(attachimg|attach)\]!', '', $message);
		$message=preg_replace('/\[hide\].*?\[\/hide\]/is', '', $message);
		$message=preg_replace('|\[img(?:=[^\]]*)?\](.*?)\[/img\]|', ' ', $message);
		$message=strip_tags($message);
		$message=discuzcode($message);
		$message=strip_tags($message);
		$message=str_replace("&nbsp;",'',$message);
		return $message;
	}

	static function _make_message($tpl,$m,$s,$url){
			global $_G;
			$subject=$s;
			$message=$m;
			$bbsname=$_G['setting']['bbname'];
			$urlLink='';
			$bbsname=LywbFunc::toWeibo($bbsname);
			$message=LywbFunc::toWeibo($message);
			$message=Lywb::_filter($message);

			if ($tpl=='') {
				$tempmessage = LY_INFO_HUATI ? '#'.$bbsname.'#'.$message:'['.$bbsname.']'.$message;
				$urlLink=$url;
			}else{
				$subject=LywbFunc::toWeibo($subject);
				$tempmessage=LywbFunc::toWeibo($tpl);

				$tempmessage=str_replace("{bbsname}",$bbsname,$tempmessage);
				$tempmessage=str_replace("{subject}",$subject,$tempmessage);
				$tempmessage=str_replace("{content}",$message,$tempmessage);
				$tempSbjurl=strpos($tempmessage,"{subjecturl}");
				$tempBbsurl=strpos($tempmessage,"{bbsurl}");
				$tempmessage=str_replace("{subjecturl}",'',$tempmessage);
				$tempmessage=str_replace("{bbsurl}",'',$tempmessage);
				if($tempBbsurl){
					$urlLink=$_G['siteurl'];
				}else if($tempSbjurl)
				{
					$urlLink=$url;
				}
			}
			$length=150-ceil(strlen($urlLink)*0.5);
			$message=liyou_substr($tempmessage,$length,0);
			$message.=$urlLink;
			return $message;
	}

	static function _get_picture($pid){
		global $_G;
		$attach=C::t('forum_attachment')->fetch_all_by_id('pid',$pid);
		$attaches=C::t('forum_attachment_n')->fetch_all('pid:'.$pid,array_keys($attach));
		foreach($attaches as $key=>$value)
		{
			if($value['isimage']!=0 && $value['price']<=0)
			{
				if($value['remote']) {
					$picUrl= $_G['setting']['ftp']['attachurl'].'forum/'.$value['attachment'];
				} else {
					$picUrl = $_G['setting']['attachurl'].'forum/'.$value['attachment'];
					if(strpos($picUrl, $_G['siteurl'])==false) {
						$picUrl = $_G['siteurl'].$picUrl;
					}
				}
				return $picUrl;
			}
		}
		return '';
	}

	static function _get_blog_picture($attach,$attach1)
	{
		global $_G;
		$attach=$attach;
		$picUrl='';
		if(!empty($attach) && $attach['picflag']==1)
		{
				$attach1=$attach1;
				$attach['attachment']=trim(str_replace('.thumb.jpg','',$attach1['pic']));
				if($attach['remote']) {
					$picUrl= $_G['setting']['ftp']['attachurl'].'album/'.$attach['attachment'];
				} else {
					$picUrl = $_G['setting']['attachurl'].'album/'.$attach['attachment'];
					if(strpos($picUrl, $_G['siteurl'])==false) {
						$picUrl = $_G['siteurl'].$picUrl;
					}
				}
		}
		return $picUrl;	
	}

	static function _get_portal_picture($aid){
			global $_G;
			$attach=C::t('portal_attachment')->fetch_by_aid_image($aid);
			
			$picUrl='';
			if(!empty($attach['attachment']))
			{
					if($attach['remote']) {
						$picUrl= $_G['setting']['ftp']['attachurl'].'portal/'.$attach['attachment'];
					} else {
						$picUrl = $_G['setting']['attachurl'].'portal/'.$attach['attachment'];
						if(strpos($picUrl, $_G['siteurl'])==false) {
							$picUrl = $_G['siteurl'].$picUrl;
						}
					}
			}
			return $picUrl;
	}

	static function _bindlog($sinareturn,$type,$tid,$uid){
		global $_G;
		if($uid && !empty($sinareturn) && isset($sinareturn['idstr'])){
			$insertUpdate=array(
						'uid'=>$uid,
						'wbid'=>addslashes(trim($sinareturn['idstr'])),
						'tid'=>$tid,
						'dateline'=>TIMESTAMP,
						'since_id'=>'0',
						'updateline'=>'0'
				);
			$insertUpdate['type']=$type;
			C::t('#liyou_weibo#ly_weibo_threadlog')->insert($insertUpdate);
		}
	}

	static function _ly_weibo_comment($tid,$lcmessage,$type,$uid,$bbsid=0)
	{
		global $_G;
		$lcthreadlog = C::t('#liyou_weibo#ly_weibo_threadlog')->fetch_threadlog_by_tid($tid,$type);
		if(!empty($lcthreadlog) && !empty($lcmessage))
		{
			$sinaReturn=array();
			$lcmessage=Lywb::_filter($lcmessage);
			$lcmessage=LywbFunc::toWeibo($lcmessage);
			$oClient=Lywb::_get_weibo_client($uid);
			$sinaReturn=$oClient->send_comment($lcthreadlog['wbid'],$lcmessage);
			if(!empty($sinaReturn) && isset($sinaReturn['idstr']))
			{
				$backlog=array(
					'bbsid'=>$bbsid,
					'wbid'=>$lcthreadlog['wbid'],
					'cid'=>$sinaReturn['idstr'],
					'type'=>$type,
					'dateline'=>TIMESTAMP,
					);
				 C::t('#liyou_weibo#ly_weibo_backlog')->insert($backlog);
			}
		}
	}
}

class LywbFactory{
	static function get_weibosyn(){
		static $instance = null;
		if ($instance===null) {
			require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/lib/weibosyn.class.php';
			$instance = new Weibosyn();
		}
		return $instance;
	}

	static function get_wbsyn(){
		static $instance = null;
		if ($instance===null) {
			$modules = isset($_GET['modules'])?$_GET['modules']:'liyou_weibo';
			if ($modules) {
				$m=str_replace('_', '', $modules);
				$f=DISCUZ_ROOT.'./source/plugin/'.$modules.'/lib/'.$m.'.class.php';
				if (file_exists($f)) {
					require_once $f;
					$m = ucfirst($m);
					$instance = new $m();
					$instance->_init();
				}
			}
		}
		return $instance;
	}

	static function get_enter(){
		static $instance = null;
		if ($instance===null) {
			$instance = new LywbEnter();
		}
		return $instance;
	}
}

class LywbEnter{

	public function index(){

	}

	public function back(){
		$obj=LywbFactory::get_weibosyn();
		if (isset($_GET['datal'])) {
			$data = base64_decode($_GET['datal']);
			$data = unserialize($data);
		}else{
			$data[0]['tid']=$_GET['wid'];
			$data[0]['type']=$_GET['type'];
		}
		foreach ($data as $val) {
			$obj->weibo_back($val);
		}
	}

	public function syn(){
		$instance=LywbFactory::get_wbsyn();
	}
}


class Lywbsyn{
	public function _init(){
		global $_G;
		$al=Lywb::allow();
		$type = $_GET['type'];
		$token = $_GET['token'];
		$token = str_replace(' ','+',$token);
		$token = authcode($token,'DECODE',$_G['config']['security']['authkey']);
		if(!$token) return false;
		$string = $token;
		$data = unserialize($string);
		$exter=$data['exter'];
		if (isset($data['siteurl'])) {
			$_G['siteurl']=$data['siteurl'];
		}
		$this->$type($data,$exter);
	}

	public function comment($data,$exter){
		$message = $_GET['token'];
		Lywb::_ly_weibo_comment($exter['tid'],$message,$exter['type'],$exter['uid'],$exter['bbsid']);
	}

	public function send($message,$pic,$uid,$tid,$type,$bind=true){
		$bindlist=C::t('#liyou_weibo#ly_weibo_bind')->fetch_all_by_discuz_uid($uid);
		foreach($bindlist as $key => $val){
			$oClient=Lywb::_get_weibo_client_by_access_token($val['access_token']);
			if(!empty($pic))
			{	
				$sinareturn=$oClient->upload($message,$pic);
			}else
			{
				$sinareturn=$oClient->update($message);
			}
			if($bind && !empty($sinareturn))
			{
				Lywb::_bindlog($sinareturn,$type,$tid,$uid);
			}
		}
	}
}