<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$createTableSql=<<<EOF
drop table if exists `pre_ly_weibo_bind`;
drop table if exists `pre_ly_weibo_threadlog`;
drop table if exists `pre_ly_weibo_backlog`;
drop table if exists `pre_ly_weibo_setting`;
drop table if exists `pre_ly_weibo_rewardlog`;
EOF;

runquery($createTableSql);

$finish = TRUE;

?>