<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/config/config.php';
require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/sina_api/saetv2.ex.class.php';
require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/liyou.func.php';

$oOAuth=new SaeTOAuthV2(APP_KEY,APP_SECRET);

if($_REQUEST['code'])
{
	$arrKey=array();
	$arrKey['code']=$_REQUEST['code'];
	$arrKey['redirect_uri']=APP_CALLBACK;
	try{
		if(!function_exists('curl_init'))
		{
			showmessage('liyou_weibo:curl_unavailable');
		}
		$token=$oOAuth->getAccessToken('code',$arrKey);
	}catch(OAuthException $e)
	{

	}
}


if($token)
{
	
	dsetcookie('weibo_token',serialize($token),86400);
	
	$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$token['access_token']);

	$weibouserinfo=$oClient->show_user_by_id($token['uid']);
	if(empty($weibouserinfo))
	{
		showmessage('liyou_weibo:auth_fail');
	}else if(isset($weibouserinfo['screen_name']) && !empty($weibouserinfo['screen_name'])){
		$weibouserinfo = LywbFunc::fromWeibo($weibouserinfo);
	}


	$discuzUserInfo='';

	$token['uid'] && $discuzUserInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_weibo_uid($token['uid']);
	$uid=intval($discuzUserInfo['uid']);
	if($uid>0)
	{
		$member=getuserbyuid($uid);
		if(empty($member))
		{
			$bindweibo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_weibo_uid($token['uid']);
			C::t('#liyou_weibo#ly_weibo_bind')->delete(array('uid'=>$bindweibo['uid']));
			$uid=0;
		}
	}

	if($uid && !$_G['uid'])
	{
		$member=getuserbyuid($uid);
		if(empty($member))
		{
			showmessage('liyou_weibo:user_not_exists');
		}
		require_once libfile('function/member');
		$cookietime = 1296000;
		setloginstatus($member, $cookietime);
		loadcache('usergroups');
		$usergroups = $_G['cache']['usergroups'][$_G['groupid']]['grouptitle'];
		$param = array('username' => $member['username'], 'usergroup' => $_G['cache']['usergroups'][$member['groupid']]['grouptitle']);
		C::t('common_member_status')->update($member['uid'], array('lastip'=>$_G['clientip'], 'lastvisit'=>TIMESTAMP, 'lastactivity' => TIMESTAMP));
		if($_G['setting']['allowsynlogin']) {
			loaducenter();
			$ucsynlogin = uc_user_synlogin($uid);
		}
		Lywb::update_user($token,$weibouserinfo,$member,$uid);
		LywbFunc::sm('liyou_weibo:login_success','weibo_login_s',$member);
	}

	if(!$uid && $_G['uid'])
	{
		$member=getuserbyuid($_G['uid']);
		Lywb::bind_user($token,$weibouserinfo,$_G['uid']);
		LywbFunc::sm('liyou_weibo:bind_success','weibo_bind_s',$member);
	}
	
	if($uid && $_G['uid'])
	{
		if($uid!=$_G['uid'])
		{
			$user=getuserbyuid($uid);
			$usertips=lang('plugin/liyou_weibo','exists_bind',array('username'=>$user['username']));
			showmessage($usertips);
		}
		$member=getuserbyuid($_G['uid']);
		Lywb::update_user($token,$weibouserinfo,$member,$uid);		
		LywbFunc::sm('liyou_weibo:bind_success','weibo_updatebind_s',$member);
	}

	if(defined('IN_MOBILE')){
		$mobilefile = DISCUZ_ROOT.'./source/plugin/liyou_weibo/mobile/callback.php';
		if(file_exists($mobilefile)){
			require_once $mobilefile;
		}
		exit;
	}

	if(!$uid && !$_G['uid'] && !LY_ONEKEY)
	{
		$dreferer = rawurlencode(dreferer());
		showmessage('liyou_weibo:register_or_bind','member.php?mod='.$_G['setting']['regname'].'&referer='.$dreferer);
	}else
	{
		$username='';
		if(empty($weibouserinfo['screen_name'])){
			$dreferer = rawurlencode(dreferer());
			showmessage('liyou_weibo:register_or_bind','member.php?mod='.$_G['setting']['regname'].'&referer='.$dreferer);
		}else
		{
			$usernamelen = dstrlen($weibouserinfo['screen_name']);
			if($usernamelen>2 && $usernamelen<=15)
			{
				$username=$weibouserinfo['screen_name'];
			}else if($usernamelen>15)
			{
				$username=trim(cutstr($weibouserinfo['screen_name'],15,''));
			}
		}
		$checkbind=array();
		$checkbind=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_weibo_uid($token['uid']);
		if(empty($username)) $username=LY_USERPRE.$token['uid'];
		loaducenter();
		$sql = 'SELECT `uid` FROM '.UC_DBTABLEPRE . "members WHERE username='".$username."'";
		$lyuid= DB::fetch_first($sql);
		if(empty($lyuid) && empty($checkbind))
		{
				$randpassword=date("YmdHis"). rand(100,999);
				$password= md5(md5($randpassword));
				$groupid=LY_USERGROUP;
				$email= $token['uid'].'@sina.com';
				$ip= $_SERVER['REMOTE_ADDR'];
				$luid = uc_user_register($username, $password, $email);
				if($luid==-1 || $luid==-2){
					$username=LY_USERPRE.$token['uid'];
					$luid = uc_user_register($username, $password, $email);
				}
				if($luid==-6){
					$email=$token['uid'].rand(0,100).'@sina.com';
					$luid = uc_user_register($username, $password, $email);
				}
				if($luid <= 0){
					showmessage('liyou_weibo:auth_fail');
				}else{
					liyou_addmember($luid, $username, $password, $email, $ip, $groupid, null);
					$lyuid['uid']= $luid;
					Lywb::bind_user($token,$weibouserinfo,$luid,LY_ONEKEY);
				}
		}
		$uid=$lyuid['uid'];
		if(empty($member))
		{
			$member=getuserbyuid($uid);
		}
		if(empty($member))
		{
			showmessage('liyou_weibo:user_not_exists');
		}
		$checkbind=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($uid);
		if(empty($checkbind))
		{
			Lywb::bind_user($token,$weibouserinfo,$uid,LY_ONEKEY);
		}
		require_once libfile('function/member');
		$cookietime = 1296000;
		setloginstatus($member, $cookietime);
		loadcache('usergroups');
		$usergroups = $_G['cache']['usergroups'][$_G['groupid']]['grouptitle'];
		$param = array('username' => $member['username'], 'usergroup' => $_G['cache']['usergroups'][$member['groupid']]['grouptitle']);
		C::t('common_member_status')->update($member['uid'], array('lastip'=>$_G['clientip'], 'lastvisit'=>TIMESTAMP, 'lastactivity' => TIMESTAMP));
		if($_G['setting']['allowsynlogin']) {
			loaducenter();
			$ucsynlogin = uc_user_synlogin($uid);
		}
		Lywb::update_user($token,$weibouserinfo,$member,$uid);
		LywbFunc::sm('liyou_weibo:login_success','weibo_aotulogin_s',$member);
	}
}else
{
	showmessage('liyou_weibo:auth_fail');
}
//From:www_YMG6_COM
?>