<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$fromversion = $_GET['fromversion'];

if($fromversion == '1.0.0'){
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS pre_plugin_k_gaiming_log (
  lid int(11) NOT NULL AUTO_INCREMENT,
  uid int(11) NOT NULL,
  creditunit tinyint(1) NOT NULL,
  creditnum int(11) NOT NULL,
  oldname varchar(255) NOT NULL,
  newname varchar(255) NOT NULL,
  dateline int(11) NOT NULL,
  `ip` char(18) DEFAULT NULL,
  PRIMARY KEY (lid),
  KEY dateline (dateline)
) ENGINE=MyISAM;

EOF;
runquery($sql);	
}
$finish = TRUE;
?>
