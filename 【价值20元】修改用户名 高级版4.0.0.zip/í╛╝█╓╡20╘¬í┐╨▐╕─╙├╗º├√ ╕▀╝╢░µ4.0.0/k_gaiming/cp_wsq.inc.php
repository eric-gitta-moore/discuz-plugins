<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$setting = $_G['cache']['plugin']['k_gaiming'];
require_once libfile('function/core', 'plugin/k_gaiming');
if($extend['wsq']){
	require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
	if(submitcheck('wsqsubmit')) {
		if($_GET['hook_profile_extraInfo_status'] == 1){
			$data[] = array('profile_extraInfo' => array('plugin' => 'k_gaiming', 'include' => 'wsq.class.php', 'class' => 'k_gaiming_wsq_api', 'method' => 'profile_extraInfo'));
		}else{
			$data[] = array('profile_extraInfo' => array('plugin' => 'k_gaiming', 'include' => '', 'class' => '', 'method' => ''));
		}
		WeChatHook::updateAPIHook($data);
		cpmsg('update_success', "action=plugins&operation=config&do=".$do."&identifier=k_gaiming&pmod=cp_wsq", 'succeed');
	}else{
		$apihook = WeChatHook::getAPIHook('k_gaiming');
		showtips(lang('plugin/k_gaiming', 'wsqcp_tips'));
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=k_gaiming&pmod=cp_wsq', 'enctype');
		showtableheader(lang('plugin/k_gaiming', 'wsq_hook_reg_status'));
		showsetting(lang('plugin/k_gaiming', 'profile_extraInfo'), 'hook_profile_extraInfo_status', (($apihook['profile']['extraInfo']['k_gaiming']['allow'] == 1) ? 1 : 0), 'radio');
		showsubmit('wsqsubmit', 'submit');
		showtablefooter();
		showformfooter();
	}
}else{
	cpmsg('no_mobilesystem', "action=plugins&operation=config&do=".$do."&identifier=k_gaiming&pmod=cp_wsq", 'succeed');
}
?>