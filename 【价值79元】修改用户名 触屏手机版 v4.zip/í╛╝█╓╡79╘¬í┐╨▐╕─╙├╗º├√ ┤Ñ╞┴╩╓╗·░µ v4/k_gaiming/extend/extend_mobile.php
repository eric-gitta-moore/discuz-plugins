<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	$oldusername = $_G['username'];
	$olduserid   = $_G['uid'];
	if($_G['charset'] == 'gbk'){
		$newusername = addslashes(dhtmlspecialchars($_GET['newname'],ENT_COMPAT,'GB2312'));
	}else{
		$newusername = addslashes(dhtmlspecialchars($_GET['newname'],ENT_COMPAT,'utf-8'));
	}
	if (empty($newusername)) {
		$re['full'] = 2;
		$re['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',lang('plugin/k_gaiming', 'nonewusername')):lang('plugin/k_gaiming', 'nonewusername');
		echo json_encode($re); 
		exit;
	}
	
	$lastlog = DB::fetch_first("SELECT * FROM ".DB::table("plugin_k_gaiming_log")." WHERE uid='".$_G['uid']."' ORDER BY dateline DESC");
	if($lastlog['dateline'] && ($_G['timestamp'] - $lastlog['dateline'] < 60*60*$setting['jianxie']) ){
		$re['full'] = 2;
		$re['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',lang('plugin/k_gaiming', 'notp2').$setting['jianxie'].lang('plugin/k_gaiming', 'notp2_unit')):lang('plugin/k_gaiming', 'notp2').$setting['jianxie'].lang('plugin/k_gaiming', 'notp2_unit');
		echo json_encode($re); 
		exit;
	}
	if($setting['maxtimes']){
		$times = DB::result_first("SELECT count(*) FROM ".DB::table("plugin_k_gaiming_log")." WHERE uid='".$_G['uid']."'");
		if($times >= $setting['maxtimes']){
			$re['full'] = 2;
			$re['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',lang('plugin/k_gaiming', 'overmaxtimes')):lang('plugin/k_gaiming', 'overmaxtimes');
			echo json_encode($re); 
			exit;
		}
	}
	if(!in_array($_G['member']['groupid'], $setting['usergroups'])){
		$re['full'] = 2;
		$re['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',lang('plugin/k_gaiming', 'notp')):lang('plugin/k_gaiming', 'notp');
		echo json_encode($re); 
		exit;
	}
	loaducenter();
	$error = uc_user_checkname($newusername);
	if($error != 1){
		$re['full'] = 2;
		if($error == -1){
			$re['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',lang('plugin/k_gaiming', 'error_1')):lang('plugin/k_gaiming', 'error_1');
		}elseif($error == -2){
			$re['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',lang('plugin/k_gaiming', 'error_2')):lang('plugin/k_gaiming', 'error_2');
		}elseif($error == -3){
			$re['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',lang('plugin/k_gaiming', 'error_3')):lang('plugin/k_gaiming', 'error_3');
		}
		echo json_encode($re); 
		exit;
	}
	if($setting['creditunit']){
		if($setting['creditnum'] && $c < $setting['creditnum']){
			$re['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',lang('plugin/k_gaiming', 'nocredit')):lang('plugin/k_gaiming', 'nocredit');
			echo json_encode($re); 
			exit;
		}
	}
	changename($oldusername, $newusername);
	changename_for_uc($oldusername, $newusername);
	if($setting['tables']){
		$tables = explode("\n", $setting['tables']);
		foreach($tables as $value){
			$table = explode(",", $value);
			if($table[0]){
				$tablelist[$table[0]] = array('uid' => $table[1], 'username' => $table[2]);
			}
		}
	}
	
	foreach($tablelist as $table => $v) {
		DB::query('UPDATE %t SET '.$v['username'].'=%s WHERE '.$v['uid'].'=%d', array($table, $newusername, $_G['uid']), 'SILENT');
	}
	
	if($setting['creditunit'] && $setting['creditnum']){
		updatemembercount($_G['uid'], array('extcredits'.$setting['creditunit'] => '-'.$setting['creditnum']), true, 'KGM', $_G['uid']);
	}
	$logdata = array(
		'uid' => $_G['uid'],
		'creditunit' => $setting['creditunit'],
		'creditnum' => $setting['creditnum'],
		'oldname' => addslashes($oldusername),
		'newname' => addslashes($newusername),
		'dateline' => $_G['timestamp'],
	);
	DB::insert('plugin_k_gaiming_log', $logdata);
	C::memory()->clear();
	$re['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',lang('plugin/k_gaiming', 'success')):lang('plugin/k_gaiming', 'success');
	$re['full'] = 1;
	echo json_encode($re); 
	exit();
?>