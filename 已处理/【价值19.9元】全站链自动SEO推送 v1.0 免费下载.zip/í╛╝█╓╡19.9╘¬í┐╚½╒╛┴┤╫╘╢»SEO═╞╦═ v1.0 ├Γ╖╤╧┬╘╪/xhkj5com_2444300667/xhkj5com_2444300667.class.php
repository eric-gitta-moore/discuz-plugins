<?php
/*
 *讯幻网：www.xhkj5.com
 *更多商业插件/模版免费下载 就在讯幻网
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_xhkj5com_2444300667 {
	function global_header(){
		global $_G;
		$xhkj5com_2444300667=$_G['cache']['plugin']['xhkj5com_2444300667'];
		if(!$xhkj5com_2444300667['off'])return;
		$section = empty($xhkj5com_2444300667['mod']) ? array() : unserialize($xhkj5com_2444300667['mod']);
		if(!is_array($section)) $section = array();
		if(!($section[0]=='all')){
			if(!(in_array(CURSCRIPT,$section))){
				return;
			}
		}		
		
		$js="<script>
				(function(){
					var bp = document.createElement('script');
					var curProtocol = window.location.protocol.split(':')[0];
					if (curProtocol === 'https') {
						bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
					}
					else {
						bp.src = 'http://push.zhanzhang.baidu.com/push.js';
					}
					var s = document.getElementsByTagName(\"script\")[0];
					s.parentNode.insertBefore(bp, s);
				})();
			</script>";
			
		return $js;
	}	
}

class mobileplugin_xhkj5com_2444300667 extends plugin_xhkj5com_2444300667 {
	function global_header_mobile(){
		return $this->global_header();
	}
}