<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once template('jz52_top:so');
?>