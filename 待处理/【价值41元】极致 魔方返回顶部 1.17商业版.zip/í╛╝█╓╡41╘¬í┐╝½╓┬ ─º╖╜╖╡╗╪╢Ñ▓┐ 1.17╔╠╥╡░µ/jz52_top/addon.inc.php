<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


 
 echo '


  <div class="jz52_plutt">
<iframe width="98%" height="700"  scrolling="yes"  frameborder=no src="http://www.xhkj5.com" ></iframe>
 
 </div>
 ';


?>