<?php die('Permission denied');?>
a:1:{s:71:"http://www.56php.com/plugin.php?id=pick_user:upgrade&myac=get_qq&tpl=no";a:3:{s:4:"data";s:7:"3861570";s:7:"timeout";i:1408196672;s:3:"ttl";i:172800;}}