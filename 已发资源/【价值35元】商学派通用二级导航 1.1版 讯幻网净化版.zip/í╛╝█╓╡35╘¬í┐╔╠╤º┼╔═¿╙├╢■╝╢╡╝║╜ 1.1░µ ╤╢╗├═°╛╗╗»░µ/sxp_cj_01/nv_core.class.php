<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!isset($_G['cache']['plugin'])){
	loadcache('plugin');
}

class plugin_sxp_cj_01{
	public function __construct() {}

	public function global_header() {
		global $_G;
		$nav = $_G['cache']['plugin']['sxp_cj_01'];
		if (!empty($nav)) {
			@extract($nav);
		} 


		include template('sxp_cj_01:subnav');
		return $return;		
	}
}

?>