<?php
/**
 *	[����ѡ�(threed_tab.{modulename})] (C)2014-2015 Powered by Դ���.
 *	Version: ��ҵ��
 *	Date: 2014-11-5 16:37
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class plugin_threed_tab
{
    //TODO - Insert your code here

    public function getattachinfo($pid, $isimg)
    {
        $isimg = dintval($isimg);
        $pid = dintval($pid);
        $tableid = DB::result_first("SELECT tableid FROM " . DB::table('forum_attachment') .
            " WHERE pid='$pid' LIMIT 1");
        $tableid = $tableid >= 0 && $tableid < 10 ? intval($tableid) : 127;
        $table = "forum_attachment_" . $tableid;
        if ($isimg) {
            $sql = "SELECT * FROM " . DB::table($table) . " WHERE pid=" . $pid .
                " and isimage=1  ORDER BY aid asc ";
        } else {
            $sql = "SELECT * FROM " . DB::table($table) . " WHERE pid=" . $pid .
                " and isimage<>1 ORDER BY aid asc ";
        }
        return DB::fetch_all($sql);
    }

    function discuzcode($value)
    {
        global $_G;
        $tab_option = $_G['cache']['plugin']['threed_tab'];
        $tab1_noattach = $tab_option["tab1_noattach"];
        $tab1_noimg = $tab_option["tab1_noimg"];
        $tab_pan = $tab_option["tab_pan"];
        if (!$tab1_noattach && !$tab1_noimg)
            return array();
        $tab_groups = unserialize($tab_option["tab_groups"]);
        $tab_define = $tab_option["tab_define"];
        $tab_define_list = explode("[next]", $tab_define);
        foreach ($tab_define_list as $listk => $listv) {
            $tab_define_forum = explode("[forum]", $listv);
            $tab_define_forumlist = explode(",", $tab_define_forum[0]);
            if (in_array($_G['fid'], $tab_define_forumlist)) {
                if ($value[caller] == "discuzcode") {
                    $pid = $value[param][12];
                    if (!$pid)
                        return array();
                    $tab_msg = $_G['discuzcodemessage'];
                    if ($tab1_noattach && $value[param][15]) { //�����¥��,��ɾ��ԭ����
                        $attachlist = $this->getattachinfo($pid, 0);
                        foreach ($attachlist as $k => $attach) {
                            if (!$tab_pan) {
                                if (preg_match("/\[attach\]" . $attach[aid] . "\[\/attach\]/", $tab_msg)) {
                                    $tab_msg = preg_replace("/\[attach\]" . $attach[aid] . "\[\/attach\]/", "", $tab_msg);
                                }
                            } elseif (preg_match("/\[oneattachatt\]" . $attach[aid] . "\[\/oneattachatt\]/",
                            $tab_msg)) {
                                $tab_msg = preg_replace("/\[oneattachatt\]" . $attach[aid] . "\[\/oneattachatt\]/",
                                    "", $tab_msg);
                            }
                        }
                    }
                    if ($value[param][15]) { //�����¥��
                        $trmp1_arr = explode("[img=", $tab_msg);
                        if (count($trmp1_arr) > 1) { //�����������ͼƬ���Ϳ�ʼ����
                            //echo "��������ͼƬ��������������";
                            $n = 1;
                            $img_srl = array();
                            foreach ($trmp1_arr as $key => $trmp1_arrstr) { //�������ͼƬ����
                                if ($n == 1) {
                                    $n++;
                                    continue;
                                } else { //��ʼ���������
                                    $n++;
                                    $trmp2_arr = explode("[/img]", $trmp1_arrstr);
                                    if (count($trmp2_arr) > 1) { //��ʼ�ָ�2
                                        //echo "��ʼ�ָ�2��";
                                        $trmp3_arr = explode("]", $trmp2_arr[0]);
                                        $img_srl[] = $trmp3_arr[1];
                                        $img_tihua = "[img=" . $trmp2_arr[0] . "[/img]";
                                        if ($tab1_noimg) {
                                            $tab_msg = str_replace($img_tihua, "", $tab_msg);
                                        }
                                    }
                                }
                            }
                            $str = "[allattachimg]";
                            foreach ($img_srl as $key => $img_key) {
                                $str = $str . "||" . $img_key;
                            }
                            $tab_msg = $tab_msg . $str;

                        }
                        if ($tab1_noimg)
                            $attachlist = $this->getattachinfo($pid, 1);
                        foreach ($attachlist as $k => $attach) {
                            //echo "ȡ����ԭλ�õ�ͼƬ,ȡ�������ϢΪ";
                            $tab_msg = preg_replace("/\[attach\]" . $attach[aid] . "\[\/attach\]/", "", $tab_msg);
                        }

                    }
                    $_G['discuzcodemessage'] = $tab_msg;
                }
            }

        }

    }
}
class plugin_threed_tab_forum extends plugin_threed_tab
{
    public $tab_output = "";
    function post_editorctrl_left_output()
    {
        global $_G;
        $tab_option = $_G['cache']['plugin']['threed_tab'];
        $tab_groups = unserialize($tab_option["tab_groups"]);
        $tab_define = $tab_option["tab_define"];
        $tab_define_list = explode("[next]", $tab_define);
        foreach ($tab_define_list as $listk => $listv) {
            $tab_define_forum = explode("[forum]", $listv);
            $tab_define_forumlist = explode(",", $tab_define_forum[0]);
            if (in_array($_G['fid'], $tab_define_forumlist) && in_array($_G['groupid'], $tab_groups)) {
                $tab_define_tablist = explode("[tab]", $tab_define_forum[1]);
                include template('threed_tab:tabedit');
                $alltab = "";
                foreach ($tab_define_tablist as $tabk => $tabv) {
                    $tab_define_tab = explode("[value]", $tabv);
                    $tab_cover = explode(",", $tab_define_tab[2]);
                    if ($_GET['action'] == "newthread" || $_GET['action'] == "edit") {
                        $tabsym = $tabk + 1;
                        $tabsym = "tab" . $tabsym;
                        if (in_array(3, $tab_cover))
                            $alltab .= tabedit("$tabsym");
                    }
                }
                return $alltab;
            }

        }

    }
    function viewthread_posttop_output()
    {
        global $_G, $postlist, $post;
        include template('threed_tab:attach');
        include template('threed_tab:image');
        $tab_option = $_G['cache']['plugin']['threed_tab'];
        $tab_groups = unserialize($tab_option["tab_groups"]);
        $tab_define = $tab_option["tab_define"];
        $tab1_cont = $tab_option["tab1_cont"];
        $tab_location = $tab_option["tab_location"];
        foreach ($postlist as $id => $post) {
            if ($post['first'] == 0 || !in_array($post['groupid'], $tab_groups)) {
                break;
            }

            $tab_define_list = explode("[next]", $tab_define);
            foreach ($tab_define_list as $listk => $listv) {
                $tab_define_forum = explode("[forum]", $listv);
                $tab_define_forumlist = explode(",", $tab_define_forum[0]);

                if (in_array($_G['fid'], $tab_define_forumlist)) {
                    $tab_message = $post['message'];
                    $massage_arr = explode("[allattachimg]||", $tab_message);
                    if (count($massage_arr) > 1) { //��ȡ֮ǰ�����Ľ��������Ƿ��������ͼƬ
                        $tab_message = $massage_arr[0];
                        $attimg_url = explode("||", $massage_arr[1]);
                    }
                    $tab1_message = $tab_message;
                    $tab_first_user = "";
                    $tabother_message = array();
                    $tabother_name = array();
                    $tab_a = array();
                    $tab_define_tablist = explode("[tab]", $tab_define_forum[1]);
                    $tab_c = 0;
                    $tab_n = count($tab_define_tablist);
                    foreach ($tab_define_tablist as $tabk => $tabv) {
                        $tab_define_tab = explode("[value]", $tabv);
                        $tab_name = $tab_define_tab[0];
                        $tab_user = $tab_define_tab[1];
                        $tab_cover = explode(",", $tab_define_tab[2]);
                        if ($tab_c == 0) {
                            $tab_first_user = $tab_define_tab[1];
                            $tab_first_name = $tab_define_tab[0];

                        } else {
                            if (in_array(0, $tab_cover)) {
                                $tab_a[$tab_c] = $tab_define_tab[1];
                                $tabother_name[$tab_c] = $tab_define_tab[0];
                                $tab_c++;
                                continue;
                            }
                            $tabother_message[$tab_c] = $tab_define_tab[1];
                            $tabother_name[$tab_c] = $tab_define_tab[0];
                            if (in_array(1, $tab_cover)) {
                                $haveimg = 0;
                                foreach ($post['attachments'] as $k => $attachimg) {
                                    $haveimg += $attachimg['isimage'];
                                }
                                if ($haveimg||$attimg_url) {
                                    $tabother_message[$tab_c] .= showimgs($post['attachments'],$attimg_url);
                                }
                            }
                            if (in_array(2, $tab_cover)) {
                                $tabother_message[$tab_c] .= show_tab_attach($post['attachments'], $post['groupid']);

                            }
                            if (in_array(3, $tab_cover)) {
                                $tab_sym = $tab_c + 1;
                                $tab_sym = "tab" . $tab_sym;

                                $tabother_message[$tab_c] .= $this->getcatchinfo($tab_message, $tab_sym, 0);
                                $tab1_message = $this->getcatchinfo($tab1_message, $tab_sym, 1);
                                //echo $tab1_message;
                                $tab_message = str_replace("[" . $tab_sym . "]", "", $tab_message);
                                $tab_message = str_replace("[/" . $tab_sym . "]", "", $tab_message);
                            }

                        }
                        $tab_c++;

                    }
                    if ($tab_option["tab1_cont"]) {
                        $tab1_message = $tab_first_user;
                        $tab1_message .= $tab_message;

                    } else {

                        $tab1_message = $tab_first_user . $tab1_message;

                    } //����ǩ��Ϣ�жϽ���

                    $tab_i = 1;
                    $tabwidth = intval(1 / $tab_n * 100);
                    if ($tab_location) {
                        $tab_menu = '<link rel="stylesheet" type="text/css" href="source/plugin/threed_tab/template/tab.css"><script type="text/javascript" src="source/plugin/threed_tab/js/jtab.js"></script><div class="threed_container"><div id="threed_menu"><dl><dd class="threed_current" id="threed_menu' .
                            $tab_i . '"  onclick="setTab(' . "'threed_menu'," . $tab_i . ',' . $tab_n .
                            ')" style="width:' . $tabwidth . '%;"><span>' . $tab_first_name . '</span>';
                        $tab_i = 2;
                        $tab_message = '</dd>';
                        for ($i = 1; $i < $tab_n; $i++) {
                            if ($tab_a[$i]) {
                                $tab_menu = $tab_menu . '<dd id="threed_menu' . $tab_i .
                                    '" onclick="window.open(\'' . $tab_a[$i] . '\')" style="width:' . $tabwidth .
                                    '%;"><span>' . $tabother_name[$i] . '</span></dd>';
                            } else {
                                $tab_menu = $tab_menu . '<dd id="threed_menu' . $tab_i . '" onclick="setTab(' .
                                    "'threed_menu'," . $tab_i . ',' . $tab_n . ')" style="width:' . $tabwidth .
                                    '%;"><span>' . $tabother_name[$i] . '</span></dd>';
                            }
                            $tab_message = $tab_message . '<dd  id="con_threed_menu_' . $tab_i .
                                '" style="display:none">' . $tabother_message[$i] . '</dd>';
                            $tab_i++;
                        } //foreach������
                        $tab_menu = $tab_menu .
                            '</dl></div><div class="threed_content"><dl><dd id="con_threed_menu_1">';
                        $tab_message = $tab_message . '</dl></div></div>';
                        $post["message"] = $tab1_message;
                        $postlist[$id] = $post;
                        $this->tab_output = $tab_message;
                        $postview[0] = $tab_menu;
                        return $postview;

                    } else {
                        $tab_i = 1;
                        $tab_menu = '<link rel="stylesheet" type="text/css" href="source/plugin/threed_tab/template/tab.css"><script type="text/javascript" src="source/plugin/threed_tab/js/jtab.js"></script><div class="threed_container"><div id="threed_menu"><dl><dd class="threed_current" id="threed_menu' .
                            $tab_i . '"  onclick="setTab(' . "'threed_menu'," . $tab_i . ',' . $tab_n .
                            ')" style="width:' . $tabwidth . '%;"><span>' . $tab_first_name . '</span>';
                        $tab_message = '<div class="threed_content"><dl><dd id="con_threed_menu_1">' . $tab1_message .
                            '</dd>';
                        $tab_i = 2;
                        for ($i = 1; $i < $tab_n; $i++) {
                            if ($tab_a[$i]) {
                                $tab_menu = $tab_menu . '<dd id="threed_menu' . $tab_i .
                                    '" onclick="window.open(\'' . $tab_a[$i] . '\')" style="width:' . $tabwidth .
                                    '%;"><span>' . $tabother_name[$i] . '</span></dd>';
                            } else {
                                $tab_menu = $tab_menu . '<dd id="threed_menu' . $tab_i . '" onclick="setTab(' .
                                    "'threed_menu'," . $tab_i . ',' . $tab_n . ')" style="width:' . $tabwidth .
                                    '%;"><span>' . $tabother_name[$i] . '</span></dd>';
                            }
                            $tab_message = $tab_message . '<dd  id="con_threed_menu_' . $tab_i .
                                '" style="display:none">' . $tabother_message[$i] . '</dd>';
                            $tab_i++;
                        }
                        $post["message"] = $tab_menu . '</dl></div>' . $tab_message .
                            '</dl></div></div>';
                        $postlist[$id] = $post;
                        return array();
                    }
                } //�Ƿ��ڵ�ǰ��������
            } //����ÿ���������ý���
        } //post ��Ϣ��������
    } //��������

    function viewthread_postbottom_output()
    {
        $a[0] = $this->tab_output;
        return $a;
    }
    public function getcatchinfo($message, $tabname, $iftab)
    {
        $tab_message = "";
        $tab_arr = explode("[" . $tabname . "]", $message);
        //print_r($left_arr);
        if (count($tab_arr) > 1) {
            $n = 1;
            foreach ($tab_arr as $key => $tab_arrstr) {
                if ($n == 1) {
                    $old_message = $tab_arrstr;
                } else {
                    $tmp_arr = explode("[/" . $tabname . "]", $tab_arrstr);
                    $tab_message .= $tmp_arr[0];
                    $old_message .= $tmp_arr[1];
                }
                $n = $n + 1;
            }
        } else {
            $old_message = $message;
            $tab_message = "";
        }
        if ($iftab) {
            return $old_message;
        } else {
            return $tab_message;
        }
    }
}
?>
