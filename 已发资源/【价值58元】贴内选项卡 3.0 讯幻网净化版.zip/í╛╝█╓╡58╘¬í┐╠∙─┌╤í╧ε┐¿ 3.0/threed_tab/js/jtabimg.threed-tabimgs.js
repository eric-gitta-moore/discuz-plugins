var jq = jQuery.noConflict();
(function(jq) {
    // This is the connector function.
    // It connects one item from the navigation tabimg to one item from the
    // stage tabimg.
    // The default behaviour is, to connect items with the same index from both
    // tabimgs. This might _not_ work with circular tabimgs!
    var connector = function(itemNavigation, tabimgStage) {
        return tabimgStage.jtabimg('items').eq(itemNavigation.index());
    };

    jq(function() {
        // Setup the tabimgs. Adjust the options for both tabimgs here.
        var tabimgStage      = jq('.img-view').jtabimg();
        var tabimgNavigation = jq('.img-nav').jtabimg();

        // We loop through the items of the navigation tabimg and set it up
        // as a control for an item from the stage tabimg.
        tabimgNavigation.jtabimg('items').each(function() {
            var item = jq(this);

            // This is where we actually connect to items.
            var target = connector(item, tabimgStage);

            item
                .on('jtabimgcontrol:active', function() {
                    tabimgNavigation.jtabimg('scrollIntoView', this);
                    item.addClass('active');
                })
                .on('jtabimgcontrol:inactive', function() {
                    item.removeClass('active');
                })
                .jtabimgControl({
                    target: target,
                    tabimg: tabimgStage
                });
        });

        // Setup controls for the stage tabimg
        jq('.prev-stage')
            .on('jtabimgcontrol:inactive', function() {
                jq(this).addClass('inactive');
            })
            .on('jtabimgcontrol:active', function() {
                jq(this).removeClass('inactive');
            })
            .jtabimgControl({
                target: '-=1'
            });

        jq('.next-stage')
            .on('jtabimgcontrol:inactive', function() {
                jq(this).addClass('inactive');
            })
            .on('jtabimgcontrol:active', function() {
                jq(this).removeClass('inactive');
            })
            .jtabimgControl({
                target: '+=1'
            });

        // Setup controls for the navigation tabimg
        jq('.prev-navigation')
            .on('jtabimgcontrol:inactive', function() {
                jq(this).addClass('inactive');
            })
            .on('jtabimgcontrol:active', function() {
                jq(this).removeClass('inactive');
            })
            .jtabimgControl({
                target: '-=1'
            });

        jq('.next-navigation')
            .on('jtabimgcontrol:inactive', function() {
                jq(this).addClass('inactive');
            })
            .on('jtabimgcontrol:active', function() {
                jq(this).removeClass('inactive');
            })
            .jtabimgControl({
                target: '+=1'
            });
    });
})(jQuery);
