<?php

if(!defined('IN_DISCUZ')) {exit('Access Denied');}
loadcache('plugin');
$tuling_plugindomain_config = $_G['cache']['plugin']['tuling_plugindomain'];
$tuling_plugindomain_config['siteurl'] = trim($tuling_plugindomain_config['siteurl']);

$tuling_plugindomain_config['root'] = $tuling_plugindomain_config['siteurl']."plugin.php?id=tuling_plugindomain";
$tuling_plugindomain_config['tuling_plugindomain'] = $tuling_plugindomain_config['siteurl']."source/plugin/tuling_plugindomain/";

$shenlan_pindao = 0;

$tuling_plugindomain_lang = lang('plugin/tuling_plugindomain');
?>