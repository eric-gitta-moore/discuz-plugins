<?php
if(!defined('IN_DISCUZ')) {exit('Access Denied');}

class tuling_plugindomain{
	
}

function geturl($url){
	if(extension_loaded('curl')){
		$result = curl_get($url);
	}else{
		$result = file_get_contents($url); 
	}
	return $result;
}

function curl_get($url){
	$ch = curl_init($url) ;  
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
	$result = curl_exec($ch); 
	curl_close($ch) ; 
	return $result;
}

function curl_post($url,$array){
	$ch = curl_init() ;  
	curl_setopt($ch, CURLOPT_URL,$url) ;  
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, count($array));
	curl_setopt($ch, CURLOPT_POSTFIELDS, $array);  
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION,true);
	$result = curl_exec($ch);  
	curl_close($ch); 
	return $result;  
}

function dump($vars,$level=1,$pre='')  {
	$block = '  ';
	if($level ==1){
		echo "<pre style='font-size:14px;'>\n type:<c style='color:orange'>".gettype($vars)."</c> count:".count($vars)." level:{$level} {\n";
		if(gettype($vars) == 'array'){
			foreach($vars as $k=>$v){
				if(gettype($v)== 'array'){
					echo $block."<b style='color:sienna'>-['{$k}'] Array Level: {$level}</b>\r\n";
					$_level = $level +1;
					dump($v,$_level,"['{$k}']");
				}else{
					echo $block."<span style='color:blue'>-['{$k}']={$v}</span>\r\n";
				}
			}
		}else{
			echo " -".$vars."\r\n";
		}
		echo  " } \n</pre>";
	}
	elseif($level >1){
		$_block="";
		for($i=0;$i<$level;$i++){
			$_block .=$block;
		}
		if(gettype($vars)== 'array'){
			foreach($vars as $_k=>$_v){
				if(gettype($_v)== 'array'){
					echo $_block."<b style='color:sienna'>-{$pre}['{$_k}'] Array Level: {$level}</b>\r\n";
					$_level = $level +1;
					dump($_v,$_level,$pre."['{$_k}']");
				}else{
					echo $_block."<span style='color:blue'>-{$pre}['{$_k}']={$_v}</span>\r\n";
				}
			}
		}else{
			echo $_block."<span style='color:green'> -{$pre}['{$pre}']={$vars}</span>\r\n";
		}
	}
}

function gpc($pre,$tag=0){
	$array = array();
	$pre = str_replace(" ",'',$pre);
	$pre = str_replace("\t",'',$pre);
	if(strpos($pre,'|')!==false){
		$pre_array = explode('|',$pre);
	}

	foreach($_GET as $key=>$g){
		if($pre_array){
			foreach($pre_array as $v){
				if($tag){
					$g=strip_tags($g);
				}
				if(strpos($key,$v) !==false){
					$array[$key] = htmlspecialchars(daddslashes($g));
				}
			}
		}else{
			if($tag){
				$g=strip_tags($g);
			}
			if(strpos($key,$pre) !==false){
				$array[$key] = htmlspecialchars(daddslashes($g));
			}
		}
	}
	return $array;
}

function fetch_all($table,$other='', $_array=''){
	$array = array(
			'filter'=>isset($_array['filter']) ? $_array['filter'] : '*',
			'first'=>isset($_array['first']) ? $_array['first'] : '0',
			'sort'=>isset($_array['sort']) ? $_array['sort'] : false,
			);
	$sql = 'SELECT '.$array['filter'].' FROM '.DB::table($table).' '.$other;
	$query =DB::query($sql);
	$result = array();
	while($tem = DB::fetch($query)){
		if($array['sort']){
			$result[$tem[$array['sort']]] = $tem;
		}else{
			$result[] = $tem;
		}
	}
	if($array['first']){
		$result = $result[0];
	}
	return $result;
}

function tuling_plugindomain_sendSMS($uid,$pwd,$mobile,$content,$time=''){
	global $_G;
	if($_G['charset'] =='gbk'){
		$http = 'http://api.chanyoo.cn/gbk/interface/send_sms.aspx';
	}elseif($_G['charset'] =='utf-8'){
		$http = 'http://api.chanyoo.cn/utf8/interface/send_sms.aspx';
	}elseif($_G['charset'] =='big5'){
		$http = 'http://api.chanyoo.cn/big5/interface/send_sms.aspx';
	}
	
	$data = array(
			'username'=>$uid,
			'password'=>$pwd,
			'receiver'=>$mobile,
			'content'=>$content,
			'sendtime'=>$time,
			);
	$post_url = $http."?username={$uid}&password=".urlencode($pwd)."&receiver=".urlencode($mobile)."&content=".urlencode($content)."&sendtime={$time}";

	$result = file_get_contents($post_url);
	$xml = simplexml_load_string($result);
	if ($xml->result >= 0)	{
		return true;
	}
	else{
		return $xml->message;
	}
}

function tuling_plugindomain_postSMS($url,$data=''){
	$row = parse_url($url);
	$host = $row['host'];
	$port = $row['port'] ? $row['port']:80;
	$file = $row['path'];
	while (list($k,$v) = each($data)){
		$post .= rawurlencode($k)."=".rawurlencode($v)."&";	
	}
	$post = substr( $post , 0 , -1 );
	$len = strlen($post);
	$fp = @fsockopen( $host ,$port, $errno, $errstr, 10);
	if (!$fp) {
		return "$errstr ($errno)\n";
	} else {
		$receive = '';
		$out = "POST $file HTTP/1.1\r\n";
		$out .= "Host: $host\r\n";
		$out .= "Content-type: application/x-www-form-urlencoded\r\n";
		$out .= "Connection: Close\r\n";
		$out .= "Content-Length: $len\r\n\r\n";
		$out .= $post;	
		fwrite($fp, $out);
		while (!feof($fp)) {
			$receive .= fgets($fp, 128);
		}
		fclose($fp);
		$receive = explode("\r\n\r\n",$receive);
		unset($receive[0]);
		return implode("",$receive);
	}
}

function get_cat_array(){
	global $cache_dir,$space_config;
	if(file_exists($cache_dir.'cache_space_cat_array.php')){
		require_once $cache_dir.'cache_space_cat_array.php';
	}else{
		$cat_array['time'] = 0;
	}
	
	if( TIMESTAMP - $cat_array['time'] > $space_config['cat_time'] ){
		$cat_array = fetch_all('space_cat'," WHERE  ORDER BY cat_sort ASC");
		require_once libfile('function/cache');
		$cat_array_field = array();
		$cat_array['time'] = TIMESTAMP;
		$cat_array_field = '$cat_array = '.arrayeval($cat_array).";\n";
		writetocache('space_cat_array', $cat_array_field);
	}
	unset($cat_array['time']);
	return  $cat_array;
}
?>