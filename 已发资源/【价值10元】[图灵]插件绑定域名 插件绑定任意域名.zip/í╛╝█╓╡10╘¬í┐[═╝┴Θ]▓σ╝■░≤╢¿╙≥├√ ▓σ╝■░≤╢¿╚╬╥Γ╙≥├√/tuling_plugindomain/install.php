<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql =<<<EOF
EOF;
$finish = true;
?>