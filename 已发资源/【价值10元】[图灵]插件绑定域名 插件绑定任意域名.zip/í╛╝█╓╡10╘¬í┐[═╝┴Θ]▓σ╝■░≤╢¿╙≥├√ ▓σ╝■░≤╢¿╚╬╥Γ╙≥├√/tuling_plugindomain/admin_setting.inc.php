<?php
if(!defined('IN_ADMINCP')){	exit('Admin Login');}
if(!defined('IN_DISCUZ')) {exit('Access Denied');}

/*
ini_set("display_errors","on");
set_time_limit(0);
error_reporting(E_ALL ^ E_NOTICE);
*/

include_once DISCUZ_ROOT.'./source/plugin/tuling_plugindomain/include/config.inc.php';
include_once DISCUZ_ROOT.'./source/plugin/tuling_plugindomain/include/function.class.php';

$mod = "admin_setting";
$form_url = 'plugins&operation=config&identifier=tuling_plugindomain&pmod='.$mod;
$cp_url ='action='.$form_url;
$now_url = ADMINSCRIPT."?".$cp_url;

$cache_dir = DISCUZ_ROOT.'./data/';

if(file_exists($cache_dir.'cache_tuling_plugindomain_data.php')){
	require_once $cache_dir.'cache_tuling_plugindomain_data.php';
}else{
	$tuling_plugindomain_data = array();
}

$script ='
if(isset($tuling_plugindomain_data[$_SERVER["HTTP_HOST"]]) ){
if(defined("IN_DISCUZ")){
$_GET["id"] = $tuling_plugindomain_data[$_SERVER["HTTP_HOST"]]["plugin_identifier"];
define("APPTYPEID", 127);
define("CURSCRIPT", "plugin");
$discuz = C::app();
$cachelist = array("plugin", "diytemplatename");
$discuz->cachelist = $cachelist;
$discuz->init();
if(!empty($_GET["id"])) {
list($identifier, $module) = explode(":", $_GET["id"]);
$module = $module !== NULL ? $module : $identifier;
} else {
showmessage("plugin_nonexistence");
}
$mnid = "plugin_".$identifier."_".$module;
$pluginmodule = isset($_G["setting"]["pluginlinks"][$identifier][$module]) ? $_G["setting"]["pluginlinks"][$identifier][$module] : (isset($_G["setting"]["plugins"]["script"][$identifier][$module]) ? $_G["setting"]["plugins"]["script"][$identifier][$module] : array("adminid" => 0, "directory" => preg_match("/^[a-z]+[a-z0-9_]*$/i", $identifier) ? $identifier."/" : ""));
if(!preg_match("/^[\w\_]+$/", $identifier)) {
showmessage("plugin_nonexistence");
}
if(empty($identifier) || !preg_match("/^[a-z0-9_\-]+$/i", $module) || !in_array($identifier, $_G["setting"]["plugins"]["available"])) {
showmessage("plugin_nonexistence");
} elseif($pluginmodule["adminid"] && ($_G["adminid"] < 1 || ($_G["adminid"] > 0 && $pluginmodule["adminid"] < $_G["adminid"]))) {
showmessage("plugin_nopermission");
} elseif(@!file_exists(DISCUZ_ROOT.($modfile = "./source/plugin/".$pluginmodule["directory"].$module.".inc.php"))) {
showmessage("plugin_module_nonexistence", "", array("mod" => $modfile));
}
define("CURMODULE", $identifier);
include DISCUZ_ROOT.$modfile;
exit;
}else{
$_ENV["curapp"] = "plugin";
$_GET["id"] = $tuling_plugindomain_data[$_SERVER["HTTP_HOST"]]["plugin_identifier"];
require "./plugin.php";
exit;
}
}';

if(isset($_GET['del'])){
	$domain = urldecode($_GET['del']);
	
	unset($tuling_plugindomain_data[$domain]);
	
	require_once libfile('function/cache');
	$cachedata = '$tuling_plugindomain_data = '.arrayeval($tuling_plugindomain_data).";\n";
	$cachedata .= "\n".$script."\n";
	
	$script = "tuling_plugindomain_data";
	$prefix = 'cache_';
	$dir = DISCUZ_ROOT.'./data/';
	if(!is_dir($dir)) {
		dmkdir($dir, 0777);
	}
	if($fp = @fopen("$dir$prefix$script.php", 'wb')) {
		fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: ".md5($prefix.$script.'.php'.$cachedata.$_G['config']['security']['authkey'])."\n\n$cachedata?>");
		fclose($fp);
	} else {
		exit('Can not write to cache files, please check directory ./data/  .');
	}
}

if(submitcheck('submit')){
	$pluginid= intval(trim(urldecode($_GET['pluginid'])));
	$domain= addslashes(trim(urldecode($_GET['domain'])));
	$url =  addslashes(trim(urldecode($_GET['url'])));
	
	$_plugin = fetch_all("common_plugin"," WHERE pluginid='{$pluginid}' ",array('first'=>"1"));
	
	$tuling_plugindomain_data[$domain] = array(
			'plugin_id'=>$_plugin['pluginid'],
			'plugin_name'=>addslashes($_plugin['name']),
			'plugin_identifier'=>$_plugin['identifier'],
			'domain'=>$domain,
			'url'=>$url,
	);
	
	require_once libfile('function/cache');
	$cachedata = '$tuling_plugindomain_data = '.arrayeval($tuling_plugindomain_data).";\n";
	$cachedata .= "\n".$script."\n";
	
	$script = "tuling_plugindomain_data";
	$prefix = 'cache_';
	$dir = DISCUZ_ROOT.'./data/';
	if(!is_dir($dir)) {
		dmkdir($dir, 0777);
	}
	if($fp = @fopen("$dir$prefix$script.php", 'wb')) {
		fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: ".md5($prefix.$script.'.php'.$cachedata.$_G['config']['security']['authkey'])."\n\n$cachedata?>");
		fclose($fp);
	} else {
		exit('Can not write to cache files, please check directory ./data/  .');
	}
}

$_plugin_array = fetch_all("common_plugin");
$other_plugin_array = array();
$shenlan_plugin_array = array();
foreach($_plugin_array as  $_pa){
	if(strstr($_pa['name'],"{$tuling_plugindomain_lang['admin_setting_inc_php_1']}") || strstr($_pa['name'],"CMS" || strstr($_pa['name'],"521{$tuling_plugindomain_lang['admin_setting_inc_php_2']}") ) ){
		$shenlan_plugin_array[] = $_pa;
	}else{
		$other_plugin_array[] = $_pa;
	}
}
$plugin_array = array_merge($shenlan_plugin_array,$other_plugin_array);

include template("tuling_plugindomain:admin/admin_setting");
?>