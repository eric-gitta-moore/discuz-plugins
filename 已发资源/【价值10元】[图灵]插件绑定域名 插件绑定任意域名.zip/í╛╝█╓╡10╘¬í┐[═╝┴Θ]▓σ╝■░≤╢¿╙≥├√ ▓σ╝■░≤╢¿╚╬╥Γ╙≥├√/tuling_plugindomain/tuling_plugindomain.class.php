<?php
if(!defined('IN_DISCUZ')) { exit('Access Denied'); }

/*
ini_set("display_errors","on");
set_time_limit(0);
error_reporting(E_ALL ^ E_NOTICE);
*/

class plugin_tuling_plugindomain {
	function __construct(){	
		self::jump();
	}
	
	function common(){
		self::jump();
	}
	
	function jump(){
		global $_G;
		$cache_dir = DISCUZ_ROOT.'./data/';
		if( CURSCRIPT =='portal' ||  CURSCRIPT == 'forum' || CURSCRIPT == 'home' ){
			if(file_exists($cache_dir.'cache_tuling_plugindomain_data.php')){
				require_once $cache_dir.'cache_tuling_plugindomain_data.php';
			}
		}
	}
}
?>