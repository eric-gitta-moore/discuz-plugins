<?php
/**
 *  [�����ˡ�����Ԥ��(superman_ppreview.{modulename})] (C)2012-2099 Powered by ʱ���Ƽ�.
 *  Version: 1.1
 *  Date: 2014-10-17 15:28:59
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//error_reporting(E_ALL);

if (submitcheck('settingsubmit')) {
	sc_superman_ppreview_setting::submit();
}
sc_superman_ppreview_setting::show();	
exit;

////////////////////////////////////////////////////////////////////////////
class sc_superman_ppreview_setting
{
	public static function show()
	{
		global $_G, $pluginid;
		$lang = lang('plugin/superman_ppreview');

		loadcache('superman_ppreview');
		$setting = $_G['cache']['superman_ppreview'];

		/*
		 * TODO: variable
		 */
		//$text = $setting['text'];
		//$select = array('name', array(array('opt_val1', 'opt_txt1'), array('opt_val2', 'opt_txt2')));
		//$selected = 'opt_val2';
		//$textarea = $setting['textarea'];
		//$radio = $setting['radio']?1:0;
		
		/*
		 * TODO: forum multiple select 
		 */
		/*
		require_once libfile('function/forumlist');
		$forum_select = '<select name="forums[]" size="10" multiple="multiple">'.forumselect(FALSE, 0, 0, TRUE).'</select>';
		if ($setting['forums']) {
			foreach($setting['forums'] as $v) {
				$forum_select = str_replace('<option value="'.$v.'">', '<option value="'.$v.'" selected>', $forum_select);
			}
		}
		 */

		showformheader("plugins&operation=manage&do=$pluginid&identifier=superman_ppreview&pmod=setting");
		showtableheader($lang['param_setting']);
		/*
		 * TODO: params
		 */
		/*
		showsetting('text_title',       'text_name',         $text,       'text',          '',   0,   'TODO:   comment',   '',   '',   true);
		showsetting('select_title',     $select,        $selected,   'select',        '',   0,   'TODO:   comment',   '',   '',   true);
		showsetting('forums_title',     '',             '',          $forum_select,   '',   0,   'TODO:   comment',   '',   '',   true);
		showsetting('textarea_title',   'textarea_name',     $textarea,   'textarea',      '',   0,   'TODO:   comment',   '',   '',   true);
		showsetting('radio_title',      'radio_name',        $radio,      'radio',         '',   0,   'TODO:   comment',   '',   '',   true);
		 */
		showtablerow(
			'',	//trstryle
			'', //tdstyle
			array(
				'<button class="btn" type="submit" name="settingsubmit" onclick="this.value=1" value="0">'.$lang['btn_save'].'</button>',
			)	//tdtext
		);
		showtablefooter();
		showformfooter();
	}

	public static function submit()
	{
		global $_G, $pluginid;
		$lang = lang('plugin/superman_ppreview');

		loadcache('superman_ppreview');
		$setting           = $_G['cache']['superman_ppreview'];
		/*
		 * TODO: save params
		 */
		//$setting['text']  = trim($_POST['text_name']);
		//$setting['forums'] = $_POST['forums'];
		//$setting['textarea']  = $_POST['textarea_name'];
		//$setting['radio']  = $_POST['radio_name']?1:0;

		save_syscache('superman_ppreview', $setting);
		cpmsg($lang['save_succeed'], 'action=plugins&operation=config&identifier=superman_ppreview&pmod=setting', 'succeed');
	}
}
