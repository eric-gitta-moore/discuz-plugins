<?php
/**
 *  [�����ˡ�����Ԥ��(superman_ppreview.{modulename})] (C)2012-2099 Powered by ʱ���Ƽ�.
 *  Version: 1.1
 *  Date: 2014-10-17 15:28:59
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('SC_DEBUG', false);
if (SC_DEBUG) {
	error_reporting(E_ALL);
}

loadcache('plugin');	
if (!isset($_G['cache']['plugin']['superman_ppreview'])) {
	_sc_exit('loadcache(plugin) null');
}
$config = $_G['cache']['plugin']['superman_ppreview'];
if (!$config['open']) {
	_sc_exit('plugin closed');
}

loadcache('superman_ppreview');
if (!isset($_G['cache']['superman_ppreview'])) {
	_sc_exit('loadcache(superman_ppreview) null');
}
$setting = $_G['cache']['superman_ppreview'];

//TODO
_sc_exit('ok', false);

if (!SC_DEBUG) {
	@header('Content-Length:0');
}
exit;

////////////////////////////////////////////////////////////////////////
function _sc_exit($msg, $exit = true)
{
	if (SC_DEBUG && $_GET['_x'] == 10000) {
		echo '<pre>';
		print_r($msg);
		echo '</pre>';
	}
	if ($exit) exit;
}
