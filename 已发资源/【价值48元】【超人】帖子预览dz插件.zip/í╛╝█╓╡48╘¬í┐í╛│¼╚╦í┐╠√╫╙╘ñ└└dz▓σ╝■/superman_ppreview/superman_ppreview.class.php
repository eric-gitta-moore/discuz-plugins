<?php
/**
 *  [�����ˡ�����Ԥ��(superman_ppreview.{modulename})] (C)2012-2099 Powered by ʱ���Ƽ�.
 *  Version: 1.1
 *  Date: 2014-10-17 15:28:59
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('SC_DEBUG', FALSE);
if (SC_DEBUG) {
    error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING ^ E_DEPRECATED ^E_STRICT);
}

class plugin_superman_ppreview
{
	protected $setting;
	protected $config;

	public function plugin_superman_ppreview()
	{
		global $_G;
		if (!$_G['cache']['plugin']['superman_ppreview']) {
			loadcache('plugin');
		}
		$this->config = $_G['cache']['plugin']['superman_ppreview'];
		if (!$_G['cache']['superman_ppreview']) {
			loadcache('superman_ppreview');
		}
		$this->setting = $_G['cache']['superman_ppreview'];
        $this->mylang = lang('plugin/superman_ppreview');

        $this->open = $this->config['open'];

	}
}

class plugin_superman_ppreview_forum extends plugin_superman_ppreview
{
    public function forumdisplay_postbutton_top_output()
    {
        if($this->open == 0){
            return '';
        }
        $ret =<<<EOF
<style>
.sc_hoverinfobox{position:relative; float:left;z-index: 9999;left:255px;}
.sc_arrow {position:absolute;left:-5px; top:3px; z-index:5}
.sc_arrow em, .sc_arrow span{display:block;width:0;height:0;overflow:hidden; position:relative}
.sc_arrow em{border-color:transparent #0085FF transparent transparent;border-style:dashed solid dashed dashed;border-width:10px}
.sc_arrow span{border-color:transparent #fff transparent transparent;border-style:dashed solid dashed dashed;border-width:10px;top:-20px;left:3px}
.sc_tipsbox{width:500px; position:absolute; top:-15px; left:14px; border:2px solid #0085FF; background:#fff; z-index:4;color:#282828}
.sc_xboxcontent .posCom{height:28px; line-height:28px; color:#fff; background:#ff7700; position:absolute; top:16px; right:0; padding:0 7px 0 14px}
.sc_xboxcontent .posCom span{ font-size:14px}
.sc_xboxcontent h2{ height:38px; line-height:38px; font-size:16px}.xboxcontent{padding:12px 25px 27px 26px}
.sc_xboxcontent li{float:left;display:inline}
.sc_xboxcontent p{line-height:22px; white-space:normal; padding-top:5px; word-wrap:break-word}
.sc_xboxcontent{padding:12px 25px 27px 26px}
.sc_titbar h2{display: inline-block; *display:inline;zoom:1;vertical-align: middle}
.sc_titbar .payIco{display: inline-block; width:16px; height:20px; *margin-left:6px; vertical-align: middle;}
.sc_titbar{width: 387px;word-break: break-all;}
.sc_headbox{border-bottom: 1px dashed #CDCDCD;}
.sc_headboxborder{float:left;border:2px solid #F2F2F2;border-radius:6px;}
.sc_headboxborder a img{border:2px solid;border-color: #CDCDCD;margin: 1px;}
.sc_ck{float: right;border:1px solid;border-width: 3px;border-radius: 6px;background-color: #008fff;padding: 0px 8px;}
.sc_hoverinfobox .showhide{overflow: hidden;border: 1px dashed #FF9A9A;margin: 8px 0;padding: 10px;zoom: 1;width:auto;height:auto;background:none;text-indent:0;cursor:auto;}
.sc_hoverinfobox .showhide h4 {margin-bottom: 10px;color: #F66;font-size: 12px;text-align: center;}
.sc_locked {overflow: hidden;margin: 10px 0;padding: 8px 8px 8px 24px;border: 1px dashed #FF9A9A;font-size: 12px;zoom: 1;}
.sc_hoverinfobox .showhide{overflow:auto;max-height:350px;}
</style>
EOF;
        return $ret;
    }

    public function forumdisplay_thread_subject_output()
    {
        require_once libfile('function/post');
        global $threadlist, $_G;
        $ret = array();
        $staticurl = STATICURL;
        if($this->open == 0){
            return '';
        }
        foreach ($threadlist as $num => $thread) {
            $post = C::t('forum_post')->fetch_all_by_tid_position("tid:{$thread['tid']}", $thread['tid'], 1);
            if ($post) {
                $post = $post[0];
                $msglower = strtolower($post['message']);
                $post = $this->viewthread_procpost($post);
                if ($_G['uid'] == $thread['authorid'] || in_array($_G['adminid'], array(1,2,3))) {
                    if (strpos($msglower, '[hide]') !== FALSE) {
                        $message = $post['message'];
                        if (SC_DEBUG) {
                            $message .= 'AAA';
                        }
                    } else {
                        $message = str_replace(array("\r", "\n"), '', messagecutstr(strip_tags($post['message']), 500));
                        if (SC_DEBUG) {
                            $message .= 'BBB';
                        }
                    }
                } else {
                    if ($_G['group']['readaccess'] >= $thread['readperm']) {
                        if (strpos($msglower, "[hide]") !== FALSE) {
                           $authorreplyexist = FALSE;
                            if (!$_G['forum']['ismoderator']) {
                                if ($_G['uid']) {
                                    $authorreplyexist = C::t('forum_post')->fetch_pid_by_tid_authorid($thread['tid'], $_G['uid']);
                                }
                            } else {
                                $authorreplyexist = TRUE;
                            }
                            if ($authorreplyexist) {
                                $message = $post['message'];
                                if (SC_DEBUG) {
                                    $message .= 'CCC';
                                }
                            } else {
                                if ($_G['uid']) {
                                    $message = sprintf("<div class='locked'>{$_G[username]}{$this->mylang['reply_hidden']}</div>", "forum.php?mod=viewthread&tid={$thread['tid']}");
                                    if (SC_DEBUG) {
                                        $message .= 'DDD';
                                    }
                                } else {
                                    $message = sprintf("<div class='locked'>{$_G[group][grouptitle]}{$this->mylang['reply_hidden']}</div>", "forum.php?mod=viewthread&tid={$thread['tid']}");
                                    if (SC_DEBUG) {
                                        $message .= 'EEE';
                                    }
                                }
                            }
                        } else {
                            $message = str_replace(array("\r", "\n"), '', messagecutstr(strip_tags($post['message']), 500));
                            if (SC_DEBUG) {
                                $message .= 'FFF';
                            }
                        }
                    } else {
                        if ($_G['uid']) {
                            $message = "[{$this->mylang['readperm']} <span class='xw1'>{$thread['readperm']}</span>]";
                            if (SC_DEBUG) {
                                $message .= 'HHH';
                            }
                        } else {
                            $message = "[{$this->mylang['readperm']} <span class='xw1'>{$thread['readperm']}</span>]";
                            if (SC_DEBUG) {
                                $message .= 'III';
                            }
                        }
                    }
                }

                if ($thread['istoday']) {
                    $dateline = '<a><span class="xi1">' . dgmdate($thread['dateline'], 'u') . '</span></a>';
                } else {
                    $dateline = '<span>' . dgmdate($thread['dateline'], 'u') . '</span>';
                }
                $subject = cutstr($post['subject'], 32);

                $dateimg = '';
                if ($thread['icon'] >= 0) {
                    $dateimg = '<img src=' . $staticurl . 'image/stamp/' . $_G[cache][stamps][$thread[icon]][url] . ' alt="' . $_G[cache][stamps][$thread[icon]][text] . '" align="absmiddle" />';
                }
                $avatar = avatar($thread['authorid'], 'small');

                $ret[$num] = <<<EOF
<div class="sc_hoverinfobox" style="display:none">
    <div class="sc_arrow">
        <em></em>
        <span></span>
    </div>

    <div class="sc_tipsbox">
        <div class="sc_xboxcontent">
            <div class="sc_headbox">
                <div class="sc_headboxborder z" style="margin:2px;">
                    <a href="home.php?mod=space&amp;uid={$thread['authorid']}">
                        {$avatar}
                    </a>
                </div>

                <div class="z">
                    <div class="sc_titbar" >
                        <h2 style="overflow: hidden;white-space: normal;text-overflow: ellipsis;">{$subject}{$dateimg}</h2>
                    </div>

                    <div  >
                        <div style="margin-bottom:4px;color:#666;font-size:13px;">
                            <span>
                                <a href="home.php?mod=space&uid={$thread['authorid']}" target="_blank">{$this->mylang['author']}{$thread['author']}</a>
                                <span class="pipe">|</span>
                                {$dateline}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="cl"></div>
            </div>

            <p>{$message}</p>
            <a style="color: #FFFFFF; text-decoration: blink" class="sc_ck" href="forum.php?mod=viewthread&tid={$thread['tid']}">{$this->mylang['see']}</a>
        </div>
    </div>
</div>
EOF;
            }
        }
        return $ret;
    }



    public function forumdisplay_postbutton_bottom_output()
    {
        if($this->open == 0){
            return '';
        }
        $ret =<<<EOF
<script src="http://libs.baidu.com/jquery/1.10.2/jquery.min.js"></script>
<script>
$.noConflict();
(function($){
    $('#moderate table tbody').each(function(){
        if (this.id.indexOf('stickthread_') >= 0 || this.id.indexOf('normalthread_') >= 0) {
            $(this).bind('mouseover', function(){
                $('.sc_hoverinfobox', this).show();
            }).bind('mouseout', function(){
                $('.sc_hoverinfobox', this).hide();
            });
        }
    });
})(jQuery);
</script>
EOF;
        return $ret;
    }

    private  function discuzcode($tid, $message, $smileyoff, $bbcodeoff, $htmlon = 0, $allowsmilies = 1, $allowbbcode = 1, $allowimgcode = 1, $allowhtml = 0, $jammer = 0, $parsetype = '0', $authorid = '0', $allowmediacode = '0', $pid = 0, $lazyload = 0, $pdateline = 0, $first = 0) {
        global $_G;

        static $authorreplyexist;

        if($pid && strpos($message, '[/password]') !== FALSE) {
            if($authorid != $_G['uid'] && !$_G['forum']['ismoderator']) {
                $message = preg_replace("/\s?\[password\](.+?)\[\/password\]\s?/ie", "parsepassword('\\1', \$pid)", $message);
                if($_G['forum_discuzcode']['passwordlock'][$pid]) {
                    return '';
                }
            } else {
                $message = preg_replace("/\s?\[password\](.+?)\[\/password\]\s?/ie", "", $message);
                $_G['forum_discuzcode']['passwordauthor'][$pid] = 1;
            }
        }

        if($parsetype != 1 && !$bbcodeoff && $allowbbcode && (strpos($message, '[/code]') || strpos($message, '[/CODE]')) !== FALSE) {
            $message = preg_replace("/\s?\[code\](.+?)\[\/code\]\s?/ies", "codedisp('\\1')", $message);
        }

        $msglower = strtolower($message);

        $htmlon = $htmlon && $allowhtml ? 1 : 0;

        if(!$htmlon) {
            $message = dhtmlspecialchars($message);
        } else {
            $message = preg_replace("/<script[^\>]*?>(.*?)<\/script>/i", '', $message);
        }

        if($_G['setting']['plugins']['func'][HOOKTYPE]['discuzcode']) {
            $_G['discuzcodemessage'] = & $message;
            $param = func_get_args();
            hookscript('discuzcode', 'global', 'funcs', array('param' => $param, 'caller' => 'discuzcode'), 'discuzcode');
        }

        if(!$smileyoff && $allowsmilies) {
            $message = parsesmiles($message);
        }

        if($_G['setting']['allowattachurl'] && strpos($msglower, 'attach://') !== FALSE) {
            $message = preg_replace("/attach:\/\/(\d+)\.?(\w*)/ie", "parseattachurl('\\1', '\\2', 1)", $message);
        }

        if($allowbbcode) {
            if(strpos($msglower, 'ed2k://') !== FALSE) {
                $message = preg_replace("/ed2k:\/\/(.+?)\//e", "parseed2k('\\1')", $message);
            }
        }

        if(!$bbcodeoff && $allowbbcode) {
            if(strpos($msglower, '[/url]') !== FALSE) {
                $message = preg_replace("/\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.|mailto:)?([^\r\n\[\"']+?))?\](.+?)\[\/url\]/ies", "parseurl('\\1', '\\5', '\\2')", $message);
            }
            if(strpos($msglower, '[/email]') !== FALSE) {
                $message = preg_replace("/\[email(=([a-z0-9\-_.+]+)@([a-z0-9\-_]+[.][a-z0-9\-_.]+))?\](.+?)\[\/email\]/ies", "parseemail('\\1', '\\4')", $message);
            }

            $nest = 0;
            while(strpos($msglower, '[table') !== FALSE && strpos($msglower, '[/table]') !== FALSE){
                $message = preg_replace("/\[table(?:=(\d{1,4}%?)(?:,([\(\)%,#\w ]+))?)?\]\s*(.+?)\s*\[\/table\]/ies", "parsetable('\\1', '\\2', '\\3')", $message);
                if(++$nest > 4) break;
            }

            $message = str_replace(array(
                '[/color]', '[/backcolor]', '[/size]', '[/font]', '[/align]', '[b]', '[/b]', '[s]', '[/s]', '[hr]', '[/p]',
                '[i=s]', '[i]', '[/i]', '[u]', '[/u]', '[list]', '[list=1]', '[list=a]',
                '[list=A]', "\r\n[*]", '[*]', '[/list]', '[indent]', '[/indent]', '[/float]'
            ), array(
                '</font>', '</font>', '</font>', '</font>', '</div>', '<strong>', '</strong>', '<strike>', '</strike>', '<hr class="l" />', '</p>', '<i class="pstatus">', '<i>',
                '</i>', '<u>', '</u>', '<ul>', '<ul type="1" class="litype_1">', '<ul type="a" class="litype_2">',
                '<ul type="A" class="litype_3">', '<li>', '<li>', '</ul>', '<blockquote>', '</blockquote>', '</span>'
            ), preg_replace(array(
                "/\[color=([#\w]+?)\]/i",
                "/\[color=((rgb|rgba)\([\d\s,]+?\))\]/i",
                "/\[backcolor=([#\w]+?)\]/i",
                "/\[backcolor=((rgb|rgba)\([\d\s,]+?\))\]/i",
                "/\[size=(\d{1,2}?)\]/i",
                "/\[size=(\d{1,2}(\.\d{1,2}+)?(px|pt)+?)\]/i",
                "/\[font=([^\[\<]+?)\]/i",
                "/\[align=(left|center|right)\]/i",
                "/\[p=(\d{1,2}|null), (\d{1,2}|null), (left|center|right)\]/i",
                "/\[float=left\]/i",
                "/\[float=right\]/i"

            ), array(
                "<font color=\"\\1\">",
                "<font style=\"color:\\1\">",
                "<font style=\"background-color:\\1\">",
                "<font style=\"background-color:\\1\">",
                "<font size=\"\\1\">",
                "<font style=\"font-size:\\1\">",
                "<font face=\"\\1\">",
                "<div align=\"\\1\">",
                "<p style=\"line-height:\\1px;text-indent:\\2em;text-align:\\3\">",
                "<span style=\"float:left;margin-right:5px\">",
                "<span style=\"float:right;margin-left:5px\">"
            ), $message));

            if($pid && !defined('IN_MOBILE')) {
                $message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/ies", "parsepostbg('\\1', '$pid')", $message);
            } else {
                $message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/is", "", $message);
            }

            if($parsetype != 1) {
                if(strpos($msglower, '[/quote]') !== FALSE) {
                    $message = preg_replace("/\s?\[quote\][\n\r]*(.+?)[\n\r]*\[\/quote\]\s?/is", tpl_quote(), $message);
                }
                if(strpos($msglower, '[/free]') !== FALSE) {
                    $message = preg_replace("/\s*\[free\][\n\r]*(.+?)[\n\r]*\[\/free\]\s*/is", tpl_free(), $message);
                }
            }
            if(!defined('IN_MOBILE')) {
                if(strpos($msglower, '[/media]') !== FALSE) {
                    $message = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/ies", $allowmediacode ? "parsemedia('\\1', '\\2')" : "bbcodeurl('\\2', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
                }
                if(strpos($msglower, '[/audio]') !== FALSE) {
                    $message = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/ies", $allowmediacode ? "parseaudio('\\2', 400)" : "bbcodeurl('\\2', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
                }
                if(strpos($msglower, '[/flash]') !== FALSE) {
                    $message = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/ies", $allowmediacode ? "parseflash('\\2', '\\3', '\\4');" : "bbcodeurl('\\4', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
                }
            } else {
                if(strpos($msglower, '[/media]') !== FALSE) {
                    $message = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", "[media]\\2[/media]", $message);
                }
                if(strpos($msglower, '[/audio]') !== FALSE) {
                    $message = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is", "[media]\\2[/media]", $message);
                }
                if(strpos($msglower, '[/flash]') !== FALSE) {
                    $message = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/is", "[media]\\4[/media]", $message);
                }
            }

            if($parsetype != 1 && $allowbbcode < 0 && isset($_G['cache']['bbcodes'][-$allowbbcode])) {
                $message = preg_replace($_G['cache']['bbcodes'][-$allowbbcode]['searcharray'], $_G['cache']['bbcodes'][-$allowbbcode]['replacearray'], $message);
            }
            if($parsetype != 1 && strpos($msglower, '[/hide]') !== FALSE && $pid) {
                if($_G['setting']['hideexpiration'] && $pdateline && (TIMESTAMP - $pdateline) / 86400 > $_G['setting']['hideexpiration']) {
                    $message = preg_replace("/\[hide[=]?(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/is", "\\3", $message);
                    $msglower = strtolower($message);
                }
                if(strpos($msglower, '[hide=d') !== FALSE) {
                    $message = preg_replace("/\[hide=(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/ies", "expirehide('\\1','\\2','\\3', $pdateline)", $message);
                    $msglower = strtolower($message);
                }
                if(strpos($msglower, '[hide]') !== FALSE) {
                    if($authorreplyexist === null) {
                        if(!$_G['forum']['ismoderator']) {
                            if($_G['uid']) {
                                $authorreplyexist = C::t('forum_post')->fetch_pid_by_tid_authorid($tid, $_G['uid']);
                            }
                        } else {
                            $authorreplyexist = TRUE;
                        }
                    }
                    if($authorreplyexist) {
                        $message = preg_replace("/\[hide\]\s*(.*?)\s*\[\/hide\]/is", tpl_hide_reply(), $message);
                    } else {
                        $message = preg_replace("/\[hide\](.*?)\[\/hide\]/is", tpl_hide_reply_hidden(), $message);
                        $message = '<script type="text/javascript">replyreload += \',\' + '.$pid.';</script>'.$message;
                    }
                }
                if(strpos($msglower, '[hide=') !== FALSE) {
                    $message = preg_replace("/\[hide=(\d+)\]\s*(.*?)\s*\[\/hide\]/ies", "creditshide(\\1,'\\2', $pid, $authorid)", $message);
                }
            }
        }

        if(!$bbcodeoff) {
            if($parsetype != 1 && strpos($msglower, '[swf]') !== FALSE) {
                $message = preg_replace("/\[swf\]\s*([^\[\<\r\n]+?)\s*\[\/swf\]/ies", "bbcodeurl('\\1', ' <img src=\"'.STATICURL.'image/filetype/flash.gif\" align=\"absmiddle\" alt=\"\" /> <a href=\"{url}\" target=\"_blank\">Flash: {url}</a> ')", $message);
            }

            if(defined('IN_MOBILE') && !defined('TPL_DEFAULT') && !defined('IN_MOBILE_API')) {
                $allowimgcode = false;
            }
            $attrsrc = !IS_ROBOT && $lazyload ? 'file' : 'src';
            if(strpos($msglower, '[/img]') !== FALSE) {
                $message = preg_replace(array(
                    "/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies",
                    "/\[img=(\d{1,4})[x|\,](\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies"
                ), $allowimgcode ? array(
                    "parseimg(0, 0, '\\1', ".intval($lazyload).", ".intval($pid).", 'onmouseover=\"img_onmouseoverfunc(this)\" ".($lazyload ? "lazyloadthumb=\"1\"" : "onload=\"thumbImg(this)\"")."')",
                    "parseimg('\\1', '\\2', '\\3', ".intval($lazyload).", ".intval($pid).")"
                ) : ($allowbbcode ? array(
                    (!defined('IN_MOBILE') ? "bbcodeurl('\\1', '<a href=\"{url}\" target=\"_blank\">{url}</a>')" : "bbcodeurl('\\1', '')"),
                    (!defined('IN_MOBILE') ? "bbcodeurl('\\3', '<a href=\"{url}\" target=\"_blank\">{url}</a>')" : "bbcodeurl('\\3', '')"),
                ) : array("bbcodeurl('\\1', '{url}')", "bbcodeurl('\\3', '{url}')")), $message);
            }
        }

        for($i = 0; $i <= $_G['forum_discuzcode']['pcodecount']; $i++) {
            $message = str_replace("[\tDISCUZ_CODE_$i\t]", $_G['forum_discuzcode']['codehtml'][$i], $message);
        }

        unset($msglower);

        if($jammer) {
            $message = preg_replace("/\r\n|\n|\r/e", "jammer()", $message);
        }
        if($first) {
            if(helper_access::check_module('group')) {
                $message = preg_replace("/\[groupid=(\d+)\](.*)\[\/groupid\]/i", lang('forum/template', 'fromgroup').': <a href="forum.php?mod=forumdisplay&fid=\\1" target="_blank">\\2</a>', $message);
            } else {
                $message = preg_replace("/(\[groupid=\d+\].*\[\/groupid\])/i", '', $message);
            }

        }
        return $htmlon ? $message : nl2br(str_replace(array("\t", '   ', '  '), array('&nbsp; &nbsp; &nbsp; &nbsp; ', '&nbsp; &nbsp;', '&nbsp;&nbsp;'), $message));
    }

    private function viewthread_procpost($post, $lastvisit = 0, $ordertype = 1, $maxposition = 0)
    {
        global $_G;

        $rushreply = getstatus($_G['forum_thread']['status'], 3);
        if(!$_G['forum_newpostanchor'] && $post['dateline'] > $lastvisit) {
            $post['newpostanchor'] = '<a name="newpost"></a>';
            $_G['forum_newpostanchor'] = 1;
        } else {
            $post['newpostanchor'] = '';
        }

        $post['lastpostanchor'] = ($ordertype != 1 && $_G['forum_numpost'] == $_G['forum_thread']['replies']) || ($ordertype == 1 && $_G['forum_numpost'] == $_G['forum_thread']['replies'] + 2) ? '<a name="lastpost"></a>' : '';

        if(!$post['hotrecommended']) {
            if($_G['forum_pagebydesc']) {
                if($ordertype != 1) {
                    $post['number'] = $_G['forum_numpost'] + $_G['forum_ppp2']--;
                } else {
                    $post['number'] = $post['first'] == 1 ? 1 : ($_G['forum_numpost'] - 1) - $_G['forum_ppp2']--;
                }
            } else {
                if($ordertype != 1) {
                    $post['number'] = ++$_G['forum_numpost'];
                } else {
                    $post['number'] = $post['first'] == 1 ? 1 : --$_G['forum_numpost'];
                    $post['number'] = $post['number'] - 1;
                }
            }
        }

        if($post['existinfirstpage']) {
            if($_G['forum_pagebydesc']) {
                $_G['forum_ppp2']--;
            } else {
                if($ordertype != 1) {
                    ++$_G['forum_numpost'];
                } else {
                    --$_G['forum_numpost'];
                }
            }
        }

        if($maxposition) {
            $post['number'] = $post['position'];
        }

        if($post['hotrecommended']) {
            $post['number'] = -1;
        }

        if(!$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['threadfilternum'] && getstatus($post['status'], 11)) {
            $post['isWater'] = true;
            if($_G['setting']['hidefilteredpost'] && !$_G['forum']['noforumhidewater']) {
                $post['inblacklist'] = true;
            }
        } else {
            $_G['allblocked'] = false;
        }

        if($post['inblacklist']) {
            $_G['blockedpids'][] = $post['pid'];
        }

        $_G['forum_postcount']++;

        $post['dbdateline'] = $post['dateline'];
        $post['dateline'] = dgmdate($post['dateline'], 'u', '9999', getglobal('setting/dateformat').' H:i:s');
        $post['groupid'] = $_G['cache']['usergroups'][$post['groupid']] ? $post['groupid'] : 7;

        if($post['username']) {

            $_G['forum_onlineauthors'][$post['authorid']] = 0;
            $post['usernameenc'] = rawurlencode($post['username']);
            $post['readaccess'] = $_G['cache']['usergroups'][$post['groupid']]['readaccess'];
            if($_G['cache']['usergroups'][$post['groupid']]['userstatusby'] == 1) {
                $post['authortitle'] = $_G['cache']['usergroups'][$post['groupid']]['grouptitle'];
                $post['stars'] = $_G['cache']['usergroups'][$post['groupid']]['stars'];
            }
            $post['upgradecredit'] = false;
            if($_G['cache']['usergroups'][$post['groupid']]['type'] == 'member' && $_G['cache']['usergroups'][$post['groupid']]['creditslower'] != 999999999) {
                $post['upgradecredit'] = $_G['cache']['usergroups'][$post['groupid']]['creditslower'] - $post['credits'];
                $post['upgradeprogress'] = 100 - ceil($post['upgradecredit'] / ($_G['cache']['usergroups'][$post['groupid']]['creditslower'] - $_G['cache']['usergroups'][$post['groupid']]['creditshigher']) * 100);
                $post['upgradeprogress'] = min(max($post['upgradeprogress'], 2), 100);
            }

            $post['taobaoas'] = addslashes($post['taobao']);
            $post['regdate'] = dgmdate($post['regdate'], 'd');
            $post['lastdate'] = dgmdate($post['lastvisit'], 'd');

            $post['authoras'] = !$post['anonymous'] ? ' '.addslashes($post['author']) : '';

            if($post['medals']) {
                loadcache('medals');
                foreach($post['medals'] = explode("\t", $post['medals']) as $key => $medalid) {
                    list($medalid, $medalexpiration) = explode("|", $medalid);
                    if(isset($_G['cache']['medals'][$medalid]) && (!$medalexpiration || $medalexpiration > TIMESTAMP)) {
                        $post['medals'][$key] = $_G['cache']['medals'][$medalid];
                        $post['medals'][$key]['medalid'] = $medalid;
                        $_G['medal_list'][$medalid] = $_G['cache']['medals'][$medalid];
                    } else {
                        unset($post['medals'][$key]);
                    }
                }
            }

            $post['avatar'] = avatar($post['authorid']);
            $post['groupicon'] = $post['avatar'] ? g_icon($post['groupid'], 1) : '';
            $post['banned'] = $post['status'] & 1;
            $post['warned'] = ($post['status'] & 2) >> 1;

        } else {
            if(!$post['authorid']) {
                $post['useip'] = substr($post['useip'], 0, strrpos($post['useip'], '.')).'.x';
            }
        }
        $post['attachments'] = array();
        $post['imagelist'] = $post['attachlist'] = '';

        if($post['attachment']) {
            if((!empty($_G['setting']['guestviewthumb']['flag']) && !$_G['uid']) || $_G['group']['allowgetattach'] || $_G['group']['allowgetimage']) {
                $_G['forum_attachpids'][] = $post['pid'];
                $post['attachment'] = 0;
                if(preg_match_all("/\[attach\](\d+)\[\/attach\]/i", $post['message'], $matchaids)) {
                    $_G['forum_attachtags'][$post['pid']] = $matchaids[1];
                }
            } else {
                $post['message'] = preg_replace("/\[attach\](\d+)\[\/attach\]/i", '', $post['message']);
            }
        }

        if($_G['setting']['ratelogrecord'] && $post['ratetimes']) {
            $_G['forum_cachepid'][$post['pid']] = $post['pid'];
        }
        if($_G['setting']['commentnumber'] && ($post['first'] && $_G['setting']['commentfirstpost'] || !$post['first']) && $post['comment']) {
            $_G['forum_cachepid'][$post['pid']] = $post['pid'];
        }
        $post['allowcomment'] = $_G['setting']['commentnumber'] && in_array(1, $_G['setting']['allowpostcomment']) && ($_G['setting']['commentpostself'] || $post['authorid'] != $_G['uid']) &&
            ($post['first'] && $_G['setting']['commentfirstpost'] && in_array($_G['group']['allowcommentpost'], array(1, 3)) ||
                (!$post['first'] && in_array($_G['group']['allowcommentpost'], array(2, 3))));
        $forum_allowbbcode = $_G['forum']['allowbbcode'] ? -$post['groupid'] : 0;
        $post['signature'] = $post['usesig'] ? ($_G['setting']['sigviewcond'] ? (strlen($post['message']) > $_G['setting']['sigviewcond'] ? $post['signature'] : '') : $post['signature']) : '';
        $imgcontent = $post['first'] ? getstatus($_G['forum_thread']['status'], 15) : 0;
        if(!defined('IN_ARCHIVER')) {
            if($post['first']) {
                if(!defined('IN_MOBILE')) {
                    $messageindex = false;
                    if(strpos($post['message'], '[/index]') !== FALSE) {
                        $post['message'] = preg_replace("/\s?\[index\](.+?)\[\/index\]\s?/ies", "parseindex('\\1', '$post[pid]')", $post['message']);
                        $messageindex = true;
                        unset($_GET['threadindex']);
                    }
                    if(strpos($post['message'], '[page]') !== FALSE) {
                        if($_GET['cp'] != 'all') {
                            $postbg = '';
                            if(strpos($post['message'], '[/postbg]') !== FALSE) {
                                preg_match("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/is", $post['message'], $r);
                                $postbg = $r[0];
                            }
                            $messagearray = explode('[page]', $post['message']);
                            $cp = max(intval($_GET['cp']), 1);
                            $post['message'] = $messagearray[$cp - 1];
                            if($postbg && strpos($post['message'], '[/postbg]') === FALSE) {
                                $post['message'] = $postbg.$post['message'];
                            }
                            unset($postbg);
                        } else {
                            $cp = 0;
                            $post['message'] = preg_replace("/\s?\[page\]\s?/is", '', $post['message']);
                        }
                        if($_GET['cp'] != 'all' && strpos($post['message'], '[/index]') === FALSE && empty($_GET['threadindex']) && !$messageindex) {
                            $_G['forum_posthtml']['footer'][$post['pid']] .= '<div id="threadpage"></div><script type="text/javascript" reload="1">show_threadpage('.$post['pid'].', '.$cp.', '.count($messagearray).', '.($_GET['from'] == 'preview' ? '1' : '0').');</script>';
                        }
                    }
                }
            }
            if(!empty($_GET['threadindex'])) {
                $_G['forum_posthtml']['header'][$post['pid']] .= '<div id="threadindex"></div><script type="text/javascript" reload="1">show_threadindex(0, '.($_GET['from'] == 'preview' ? '1' : '0').');</script>';
            }
            if(!$imgcontent) {
                require_once libfile('function/discuzcode');
                $post['message'] = $this->discuzcode($post['tid'], $post['message'], $post['smileyoff'], $post['bbcodeoff'], $post['htmlon'] & 1, $_G['forum']['allowsmilies'], $forum_allowbbcode, ($_G['forum']['allowimgcode'] && $_G['setting']['showimages'] ? 1 : 0), $_G['forum']['allowhtml'], ($_G['forum']['jammer'] && $post['authorid'] != $_G['uid'] ? 1 : 0), 0, $post['authorid'], $_G['cache']['usergroups'][$post['groupid']]['allowmediacode'] && $_G['forum']['allowmediacode'], $post['pid'], $_G['setting']['lazyload'], $post['dbdateline'], $post['first']);
                if($post['first']) {
                    $_G['relatedlinks'] = '';
                    $relatedtype = !$_G['forum_thread']['isgroup'] ? 'forum' : 'group';
                    if(!$_G['setting']['relatedlinkstatus']) {
                        $_G['relatedlinks'] = get_related_link($relatedtype);
                    } else {
                        $post['message'] = parse_related_link($post['message'], $relatedtype);
                    }
                    if(strpos($post['message'], '[/begin]') !== FALSE) {
                        $post['message'] = preg_replace("/\[begin(=\s*([^\[\<\r\n]*?)\s*,(\d*),(\d*),(\d*),(\d*))?\]\s*([^\[\<\r\n]+?)\s*\[\/begin\]/ies", $_G['cache']['usergroups'][$post['groupid']]['allowbegincode'] ? "parsebegin('\\2', '\\7', '\\3', '\\4', '\\5', '\\6');" : '', $post['message']);
                    }
                }
            }
        }
        if(defined('IN_ARCHIVER') || defined('IN_MOBILE') || !$post['first']) {
            if(strpos($post['message'], '[page]') !== FALSE) {
                $post['message'] = preg_replace("/\s?\[page\]\s?/is", '', $post['message']);
            }
            if(strpos($post['message'], '[/index]') !== FALSE) {
                $post['message'] = preg_replace("/\s?\[index\](.+?)\[\/index\]\s?/is", '', $post['message']);
            }
            if(strpos($post['message'], '[/begin]') !== FALSE) {
                $post['message'] = preg_replace("/\[begin(=\s*([^\[\<\r\n]*?)\s*,(\d*),(\d*),(\d*),(\d*))?\]\s*([^\[\<\r\n]+?)\s*\[\/begin\]/ies", '', $post['message']);
            }
        }
        if($imgcontent) {
            $post['message'] = '<img id="threadimgcontent" src="./'.stringtopic('', $post['tid']).'">';
        }
        $_G['forum_firstpid'] = intval($_G['forum_firstpid']);
        //$post['numbercard'] = viewthread_numbercard($post);
        $post['mobiletype'] = getstatus($post['status'], 4) ? base_convert(getstatus($post['status'], 10).getstatus($post['status'], 9).getstatus($post['status'], 8), 2, 10) : 0;
        return $post;
    }
}

