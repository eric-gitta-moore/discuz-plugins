<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if($_G['gp_operation'] == 'setstyle') {
	if($_G['gp_formhash'] != FORMHASH) {
		showmessage('undefined_action', NULL);
	}
	$sid = intval($_POST['sid']);
	if($sid){
		dsetcookie('study_stylechange_sid',$sid,'31531314');
	}
	include template('study_stylechange:msg');
}else{
	
	if(in_array($_G[setting][version],array('X1.5','X2'))){
		$data_dir = 'cache';
	}else{
		$data_dir = 'sysdata';
	}
	@include DISCUZ_ROOT.'./data/'.$data_dir.'/cache_study_stylechange_simple.php';
	
	$now_style = in_array(getcookie('study_stylechange_sid'),$pic_array['id']) ? getcookie('study_stylechange_sid') : $_G[setting][styleid];

	include template('study_stylechange:change');

}
?>