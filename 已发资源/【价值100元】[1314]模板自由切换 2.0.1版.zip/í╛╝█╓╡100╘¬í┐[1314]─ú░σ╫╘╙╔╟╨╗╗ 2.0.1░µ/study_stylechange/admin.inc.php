<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      2012-6-29 14:07:01
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!submitcheck('stylesubmit')) {
	if(in_array($_G[setting][version],array('X1.5','X2'))){
		$data_dir = 'cache';
	}else{
		$data_dir = 'sysdata';
	}
	@include_once DISCUZ_ROOT.'./data/'.$data_dir.'/cache_study_stylechange_simple.php';
	
	
	cpheader();
	$query = DB::query("SELECT s.styleid, s.available, s.name, t.name AS tplname, t.directory, t.copyright FROM ".DB::table('common_style')." s LEFT JOIN ".DB::table('common_template')." t ON t.templateid=s.templateid ORDER BY s.available desc, s.styleid");
	$sarray = $tpldirs = array();
	while($row = DB::fetch($query)) {
		$sarray[$row['styleid']] = $row;
		$tpldirs[] = realpath($row['directory']);
	}

	$defaultid = DB::result_first("SELECT svalue FROM ".DB::table('common_setting')." WHERE skey='styleid'");

		$stylelist = '';
		$i = 0;
		foreach($sarray as $id => $style) {
			$style['name'] = dhtmlspecialchars($style['name']);
			$isdefault = $id == $defaultid ? 'checked' : '';
			$available = $style['available'] ? 'checked' : NULL;
			$preview = file_exists($style['directory'].'/preview.jpg') ? $style['directory'].'/preview.jpg' : './static/image/admincp/stylepreview.gif';
			$previewlarge = file_exists($style['directory'].'/preview_large.jpg') ? $style['directory'].'/preview_large.jpg' : '';
			$styleicons = isset($styleicons[$id]) ? $styleicons[$id] : '';
			$checked = in_array($id,$pic_array['id']) ? 'checked' : '';
			$stylelist .= ($i == 0 ? '<tr>' : '').
				'<td width="25%">
				<table cellspacing="0" cellpadding="0" style="margin-left: 10px; width: 170px;"><tr><td style="text-align: center; border-top: none;">'.
				"<p style=\"margin-bottom: 2px;\">&nbsp;</p><img ".($previewlarge ? 'style="cursor:pointer" title="'.$lang['preview_large'].'" onclick="zoom(this, \''.$previewlarge.'\', 1)" ' : '')."src=\"$preview\" alt=\"$lang[preview]\"/></a>
				<p style=\"margin: 2px 0\"><input type=\"text\" class=\"txt\" name=\"namenew[$id]\" value=\"".($pic_array['info'][$id]['name'] ? $pic_array['info'][$id]['name'] : $style[name])."\" size=\"30\" style=\"margin-right:0; width: 80px;\"></p>
				<p class=\"lightfont\">($style[tplname])</p>
				<p style=\"margin: 2px 0\"><label>".lang('plugin/study_stylechange','scriptlang_004')." ".($isdefault ? '<input class="checkbox" type="checkbox" disabled="disabled" checked /><input type="hidden" name="choose[]" value="'.$id.'"/>' : '<input class="checkbox" type="checkbox" name="choose[]" value="'.$id.'" '.$checked.' />')."</label></p>
				</td>
				</tr>
				</table></td>\n".($i == 4 ? '</tr>' : '');
			$i++;
			if($i == 4) {
				$i = 0;
			}
		}
		if($i > 0) {
			$stylelist .= str_repeat('<td></td>', 4 - $i);
		}
		
		
//		shownav('style', 'styles_admin');
//		showsubmenu('styles_admin', array(
//			array('admin', 'styles', '1'),
//			array('import', 'styles&operation=import', '0'),
//			array('cloudaddons_style_link', 'cloudaddons')
//		));
		showtips(lang('plugin/study_stylechange','scriptlang_002'));
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=study_stylechange&pmod=admin',' style="background: #F2F9FD"');
		showtableheader();
		echo $stylelist;
		showtablefooter();
		showtableheader();
		showsubmit('stylesubmit', lang('plugin/study_stylechange','scriptlang_003'));
		showtablefooter();
		showformfooter();
}else{
	$query = DB::query("SELECT s.styleid, t.directory FROM ".DB::table('common_style')." s LEFT JOIN ".DB::table('common_template')." t ON t.templateid=s.templateid ORDER BY s.available desc, s.styleid");
	$styleid_array = array();
	while($row = DB::fetch($query)) {
		$styleid_array[] = $row['styleid'];
		$styles_preview[$row['styleid']]['preview'] = file_exists($row['directory'].'/preview.jpg') ? $row['directory'].'/preview.jpg' : './static/image/admincp/stylepreview.gif';
		$styles_preview[$row['styleid']]['previewlarge'] = file_exists($row['directory'].'/preview_large.jpg') ? $row['directory'].'/preview_large.jpg' : $styles_preview[$row['styleid']]['preview'];
	}

	foreach($_POST[choose] as $key => $value){
		if(in_array($value,$styleid_array)){
			$use_styleid_simple['id'][$value] = $value;
			$use_styleid_simple['preview'][$value] = $styles_preview[$value];
			loadcache('style_'.$value);
			$use_styleid_simple['info'][$value]['name'] = $_POST['namenew'][$value] ? $_POST['namenew'][$value] : $_G['cache']['style_'.$value]['name'];
		}
	}
	$cache_content_simple = '
//This is NOT a freeware, use is subject to license terms
//Powered by www.1314study.com
if(!defined(\'IN_DISCUZ\')) {
	exit(\'Access Denied\');
}
$pic_array = '.var_export($use_styleid_simple,TRUE).";\n";
	writetocache('study_stylechange_simple', $cache_content_simple);
	cpmsg('���óɹ�','action=plugins&operation=config&do='.$pluginid.'&identifier=study_stylechange&pmod=admin', 'succeed');
}
?>