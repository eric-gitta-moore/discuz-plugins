<?php

/**
 *      
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: feedback.inc.php 2012-10-11 14:46:59Z zhugeyun $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

echo "<script>top.location='http://%77%77%77%2E%75%79%75%61%6E%6D%61%2E%63%6F%6D';</script>";
?>
