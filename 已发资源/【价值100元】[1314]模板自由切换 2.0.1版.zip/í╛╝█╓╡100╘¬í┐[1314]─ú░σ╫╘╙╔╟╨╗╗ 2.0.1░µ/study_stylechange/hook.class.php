<?php
/*
	[Discuz!] (C)2001-2009 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: hook.class.php 2012-07-12 10:40:00 zhuge2012112216ilslJQMQ6l $
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//��ǰ����STYLEID����ֹ ��������� ȫ�� common() ��ʹ�� template���µ�STYLEID������
if(!defined('STYLEID')) {
	if(in_array($_G['groupid'],(array)unserialize($_G['cache']['plugin']['study_stylechange']['study_gids']))){
	  $study_styleid = intval(getcookie('study_stylechange_sid'));
		if($study_styleid){
			if(in_array($_G[setting][version],array('X1.5','X2'))){
				$data_dir = 'cache';
			}else{
				$data_dir = 'sysdata';
			}
			@include_once DISCUZ_ROOT.'./data/'.$data_dir.'/cache_study_stylechange_simple.php';
			if(in_array($study_styleid,$pic_array['id'])){
				define('STYLEID', $study_styleid);
				loadcache('style_'.$study_styleid);
	    	$_G[style] = $_G['cache']['style_'.$study_styleid];
	    }
		}
	}
}
class plugin_study_stylechange {
	
	var $isallow;
	var $study_way;
	var $study_place;
	var $lang = array();
	var $return = array();
	function __construct(){
		global $_G;
		$this->isallow = in_array($_G['groupid'],(array)unserialize($_G['cache']['plugin']['study_stylechange']['study_gids']));
		$this->study_way = $_G['cache']['plugin']['study_stylechange']['study_way'];
		$this->study_place = $_G['cache']['plugin']['study_stylechange']['study_place'];
		$this->lang = lang('plugin/study_stylechange');
		if($this->isallow){
			if($this->study_way == '1'){
				if($this->study_place == '3'){
					$this->return[3] = '<span class="pipe">|</span>';
				}
				$this->return[$this->study_place] .= '<a href="#"  onclick="showWindow(\'study_stylechange\', \'plugin.php?id=study_stylechange:change\',\'get\');return false;">'.$this->lang['scriptlang_001'].'</a>';
			}else{
				$this->return[$this->study_place] = '<a href="#"  onclick="showWindow(\'study_stylechange\', \'plugin.php?id=study_stylechange:change\',\'get\');return false;"><img src="source/plugin/study_stylechange/images/change.png" border="0"></a>';
			}
		}
	}
	function common(){
		global $_G;
    if(!defined('STYLEID')) {
			if(in_array($_G['groupid'],(array)unserialize($_G['cache']['plugin']['study_stylechange']['study_gids']))){
			  $study_styleid = intval(getcookie('study_stylechange_sid'));
				if($study_styleid){
					if(in_array($_G[setting][version],array('X1.5','X2'))){
						$data_dir = 'cache';
					}else{
						$data_dir = 'sysdata';
					}
					@include_once DISCUZ_ROOT.'./data/'.$data_dir.'/cache_study_stylechange_simple.php';
					if(in_array($study_styleid,$pic_array['id'])){
						define('STYLEID', $study_styleid);
						loadcache('style_'.$study_styleid);
			    	$_G[style] = $_G['cache']['style_'.$study_styleid];
			    }
				}
			}
		}
	}
	function global_cpnav_extra1(){
		return $this->return[1];
	}
	function global_cpnav_extra2(){
		return $this->return[2];
	}
	function global_usernav_extra1(){
		return $this->return[3];
	}
}


?>