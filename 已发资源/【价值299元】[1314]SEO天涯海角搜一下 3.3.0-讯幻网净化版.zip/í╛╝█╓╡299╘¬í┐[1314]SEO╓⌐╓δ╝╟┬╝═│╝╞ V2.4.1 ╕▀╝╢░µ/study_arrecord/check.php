<?php
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$cachekey = 'scache_'.$pluginarray['plugin']['identifier'];
loadcache($cachekey);
$cachevalue = $_G['cache'][$cachekey];
$cachevalue['check'] = $pluginarray['plugin']['identifier'];
savecache($cachekey, $cachevalue);