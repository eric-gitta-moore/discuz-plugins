<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
exit('0000000000000000000000000000000000000');
}
$op = in_array($_GET['op'], array('all', 'baidu', 'google', '360', 'sougou', 'bing', 'youdao', 'soso', 'yahoo', 'other', 'notitle')) ? $_GET['op'] : 'all';
if($_GET['truncate'] == $_G['formhash']){

cpmsg('&#x64CD;&#x4F5C;&#x6210;&#x529F;', 'action=' . STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=' . $op . '&ac=' . $ac, 'succeed');
}
if (!submitcheck('submit')) {
study_arrecord_admin::subtitle(array(array('&#x5168;&#x90E8;', 'all'), array('&#x767E;&#x5EA6;', 'baidu'), array('&#x8C37;&#x6B4C;', 'google'), array('360&#x641C;&#x7D22;', '360'), array('&#x641C;&#x72D7;', 'sougou'), array('&#x5FC5;&#x5E94;', 'bing'), array('&#x641C;&#x641C;', 'soso'), array('&#x96C5;&#x864E;', 'yahoo'), array('&#x5176;&#x4ED6;', 'other'), array('&#x6CA1;&#x6807;&#x9898;', 'notitle')), $type1314, $op);
s_shownav('sort', 'sorts_admin');
showformheader(STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=' . $op . '&ac=' . $ac);
showtableheader('');
showsubtitle(array('del', '&#x8718;&#x86DB;&#x540D;&#x79F0;', '&#x8718;&#x86DB;IP', '&#x6293;&#x53D6;&#x65F6;&#x95F4;', '&#x8BBF;&#x95EE;&#x7684;&#x9875;&#x9762;', '&#x6765;&#x6E90;&#x7F51;&#x7AD9;'));
$spidername = array(
    	'baidu' => '&#x767E;&#x5EA6;', 
    	'google' => '&#x8C37;&#x6B4C;',
    	'360' => '360&#x641C;&#x7D22;',
    	'sougou'=> '&#x641C;&#x72D7;',
    	'bing' => '&#x5FC5;&#x5E94;',
    	'soso'=> '&#x641C;&#x641C;',
    	'yahoo'=> '&#x96C5;&#x864E;',
    );
$where_array = array();
if($op == 'notitle'){
$where_array = array('title' => '');
}elseif($op != 'all'){
$where_array = array('name' => $op);
}
$perpage = 20;
$maxpages = 1000;
$count = C::t('#study_arrecord#study_arrecord_logs')->count_by_where($where_array);
$page = intval($_GET['page']);
$page = ($page-1 > $count/$perpage || $page > $maxpages) ? 1 : $page;
$start_limit = ($page - 1) * $perpage;
$multipage = multi($count, $perpage, $page, ADMINSCRIPT.'?action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op='.$op, $maxpages);
$loglist = C::t('#study_arrecord#study_arrecord_logs')->fetch_all_by_search($where_array, array('dateline' => 'DESC'), $start_limit, $perpage);
$loglist = dhtmlspecialchars($loglist);
foreach ($loglist as $log) {
			showtablerow('', array('class="td25"', 'class="td28"', ' style="width:100px;"', ' style="width:150px;"', '', ' style="width:200px;"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$log[id]\" $disabled>",
				$spidername[$log['name']] ? $spidername[$log['name']] : $log['name'],
				$log['useip'],
				dgmdate($log['dateline'], 'Y-m-d H:i', $_G['setting']['timeoffset']),
				'<a href="'.$log['url'].'" target="_blank">'.($log['title'] ? $log['title'] : $log['url']).'</a>',
				$log['rurl'],
		    ));
		}
		showsubmit('submit', 'submit', 'del', '&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=' . STUDY_MANAGE_URL . '&type1314=' . $type1314.'&truncate='.$_G['formhash'].'">&#x6E05;&#x7A7A;&#x6240;&#x6709;&#x8BB0;&#x5F55;</a>', $multipage);
		showtablefooter();
		showformfooter();
} else {
		if(is_array($_POST['delete'])) {
			foreach($_POST['delete'] as $key) {
				$key = intval($key);
				C::t('#study_arrecord#study_arrecord_logs')->delete_by_where(array('id' => $key), true);
			}
		}

    cpmsg('&#x64CD;&#x4F5C;&#x6210;&#x529F;', 'action=' . STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=' . $op . '&ac=' . $ac, 'succeed');
}

