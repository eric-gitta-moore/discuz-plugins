<?php
//cronname:&#x6BCF;&#x65E5;&#x6570;&#x636E;&#x6E05;&#x7406;
//hour:2

if(!defined('IN_DISCUZ')) {
    exit('0000000000000000000000000000000000000');
}

require_once libfile('function/cache');

if(empty($_G['cache']['plugin']['study_arrecord'])){
	loadcache('plugin');
}

$day = $_G['cache']['plugin']['study_arrecord']['autoclearday'] > 0 ? $_G['cache']['plugin']['study_arrecord']['autoclearday'] : 30;
if($day != 1314){
		$titme = strtotime(date('Y-m-d', $_G['timestamp'])) - ($day - 1)*86400;
		C::t('#study_arrecord#study_arrecord_logs')->delete_by_where(array('dateline' => array($titme, '<')), 1);
		
		$firstlog = C::t('#study_arrecord#study_arrecord_logs')->fetch_by_search(array(), array('id' => 'ASC'));
		if($firstlog['id'] && $firstlog['id'] > 1){
				$cron_plugin = C::t('common_plugin')->fetch_by_identifier('study_arrecord');
				if($cron_plugin['pluginid']){
					C::t('common_pluginvar')->update_by_variable($cron_plugin['pluginid'], 'plugin_radio', array('value' => 0));
					$minus = $firstlog['id'] - 1;
					DB::query("UPDATE ".DB::table('study_arrecord_logs')." SET `id` = `id` - '$minus' WHERE `id` > 0", 'UNBUFFERED');
					DB::query("ALTER TABLE ".DB::table('study_arrecord_logs')." AUTO_INCREMENT = 1");
					C::t('common_pluginvar')->update_by_variable($cron_plugin['pluginid'], 'plugin_radio', array('value' => 1));
					updatecache(array('plugin', 'setting', 'styles'));
					cleartemplatecache();
				}
		}
}