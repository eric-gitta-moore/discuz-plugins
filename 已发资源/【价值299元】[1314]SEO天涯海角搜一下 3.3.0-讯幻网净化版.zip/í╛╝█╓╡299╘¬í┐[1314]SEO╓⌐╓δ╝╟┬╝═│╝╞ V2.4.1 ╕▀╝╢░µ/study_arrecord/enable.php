<?php
if(!defined('IN_ADMINCP')) {
exit('Access Denied');
}
C::t('common_plugin')->update($_GET['pluginid'], array('available' => 1));
cpmsg('&#25554;&#20214;&#24320;&#21551;&#25104;&#21151;', 'action=plugins'.(!empty($_GET['system']) ? '&system=1' : ''), 'succeed');