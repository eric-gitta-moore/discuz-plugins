<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_study_arrecord{
	function global_footer(){
		global $_G ,$navtitle;
		$splugin_setting = $_G['cache']['plugin']['study_arrecord'];
		if($splugin_setting['plugin_radio']){
			$user_agent = strtolower($_SERVER["HTTP_USER_AGENT"]);
			
			$spiderlist = array(
				'baidu' => 'baiduspider',
				'google' => 'googlebot',
				'soso' => 'sosospider',
				'youdao' => 'youdaobot',
				'bing' => 'bingbot',
				'sougou' => 'sogou',
				'yahoo' => 'yahoo',
				'360' => '360spider',
			);
				
			$spiderkey = '';
			foreach($spiderlist as $key => $value) {
				if(strpos($user_agent, $value) !== false) {
					$spiderkey = $key;
					break;
				}
			}
			
			if(empty($spiderkey) && IS_ROBOT && $splugin_setting['other_arrecord']){
				$spiderkey = 'other';
			}
			
			if($spiderkey){
				$referer = str_replace('&amp;', '&', $_SERVER['HTTP_REFERER']);
					$reurl = parse_url($referer);
					$data = array(
						'name' => $spiderkey,
						'title' => $navtitle,
						'url' => 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'],
						'rurl' => $referer,
						'rsite' => $reurl['host'],
						'useip' => $_G['clientip'],
						'dateline' => $_G['timestamp'],
					);
					C::t('#study_arrecord#study_arrecord_logs')->insert($data);
			}
		}
		return '';
	}
}
