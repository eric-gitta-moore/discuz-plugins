<?php
if(!defined('IN_ADMINCP')) {
exit('Access Denied');
}
C::t('common_plugin')->update($_GET['pluginid'], array('available' => 0));
updatecache(array('plugin', 'setting', 'styles'));
cleartemplatecache();
updatemenu('plugin');
cpmsg('&#25554;&#20214;&#24050;&#20851;&#38381;', 'action=plugins', 'succeed');