<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
define('STUDY_MANAGE_URL', 'plugins&operation=config&do='.$pluginid.'&identifier='.dhtmlspecialchars($_GET['identifier']).'&pmod=admin_manage');
require_once libfile('function/var', 'plugin/study_arrecord/source');
require_once libfile('class/admin', 'plugin/study_arrecord/source');
loadcache('plugin');
$splugin_setting = $_G['cache']['plugin']['study_arrecord'];
$splugin_lang = lang('plugin/study_arrecord');
$type1314 = in_array($_GET['type1314'], array('log')) ? $_GET['type1314'] : 'log';
echo '<link href="./source/plugin/study_arrecord/images/manage.css?'.VERHASH.'" rel="stylesheet" type="text/css" />';
study_arrecord_admin::subtitle(array(
	array('&#x8718;&#x86DB;&#x8BB0;&#x5F55;', 'log'),
),$type1314);

require_once libfile('admin/manage_'.$type1314, 'plugin/study_arrecord/source');
