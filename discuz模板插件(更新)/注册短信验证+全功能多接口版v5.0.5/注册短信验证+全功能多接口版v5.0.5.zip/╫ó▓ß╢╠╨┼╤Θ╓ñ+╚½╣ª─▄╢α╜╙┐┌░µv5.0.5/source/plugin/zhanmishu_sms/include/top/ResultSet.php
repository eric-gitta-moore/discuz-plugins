<?php
/**
 *      [Caogen8.Co!] (C)2014-2018 Cgzz8.Com && plugin by caogen8. && cgzz8.com
 *      小草根(QQ：2575163778) wWw.Caogen8.co
 *
 *      Author: CAOGEN8.CO $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
/**
 * 返回的默认类
 * 
 * @author auto create
 * @since 1.0, 2015-01-20
 */
class ResultSet
{
	
	/** 
	 * 返回的错误码
	 **/
	public $code;
	
	/** 
	 * 返回的错误信息
	 **/
	public $msg;
	
}
