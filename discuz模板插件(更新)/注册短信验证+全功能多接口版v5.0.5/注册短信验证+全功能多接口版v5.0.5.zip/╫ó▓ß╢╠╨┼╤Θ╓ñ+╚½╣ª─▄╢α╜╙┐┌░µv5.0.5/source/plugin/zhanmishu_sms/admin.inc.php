<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
cpheader();
showtips(lang('plugin/zhanmishu_sms', 'servicetips'),'',true,lang('plugin/zhanmishu_sms', 'servicetiptitle'));




?>