<?php
/*
www.wzmiao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//From:www.wzmiao.com
?>
<script type="text/javascript">location.href="http://www.wzmiao.com";</script>