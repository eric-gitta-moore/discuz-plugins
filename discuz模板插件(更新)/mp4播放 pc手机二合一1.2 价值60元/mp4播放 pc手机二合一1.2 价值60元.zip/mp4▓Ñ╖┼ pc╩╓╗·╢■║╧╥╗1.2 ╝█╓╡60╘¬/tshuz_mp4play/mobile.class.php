<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_tshuz_mp4play {
	function discuzcode($value){
		global $_G;
		$pVars = $_G['cache']['plugin']['tshuz_mp4play'];
		$forums = dunserialize($pVars['forums']);
		if(in_array($_G['fid'],$forums)){
			if($value['caller'] == 'discuzcode'){
				preg_match_all("/\[mp4=(.*?)\](.*?)\[\/mp4\]/",$_G['discuzcodemessage'],$match);
				if(count($match[2])){
					foreach($match[2] as $pkey=>$pval){
						$html5media = $this->analyzeMp4($pval,$match[1][$pkey]);
						$_G['discuzcodemessage'] = str_replace($match[0][$pkey],$html5media,$_G['discuzcodemessage']);
					}
				}
			}
		}
	}
	
	function analyzeMp4($url,$value){
		global $_G;
		$pVars = $_G['cache']['plugin']['tshuz_mp4play'];
		$values = explode(",",$value);
		$autoplay = $pVars['autoplay']?' autoplay="autoplay"':'';
		$return = '<video style="background:'.$pVars['bgcolor'].'" controls="controls"'.$autoplay.' width="'.$pVars['mobile_width'].'%" height="'.$pVars['mobile_height'].'%" ><source src="'.$url.'" type="video/mp4" /></video>';
		return $return;
		
	}
}

?>