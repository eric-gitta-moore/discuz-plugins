<?php echo '源码哥商业模板保护！下载获取正版模板请访问源码哥官网：www.fx8.cc';exit;?>
<!--{template common/header}-->
<!-- header start -->
<header class="header">
    <div class="nav">
		<div class="icon_edit y"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_threads}"><span class="none">{lang send_threads}</span></a></div>
		<span class="category">
			<!--{if $subexists && $_G['page'] == 1}-->
			<span class="display name vm" href="#subname_list">
				<h2 class="tit"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></h2>
				<img src="{STATICURL}image/mobile/images/icon_arrow_down.png">
			</span>
			<div id="subname_list" class="subname_list" display="true" style="display:none;">
				<ul>
				<!--{loop $sublist $sub}-->
				<li>
					<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a>
				</li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{else}-->
			<span class="name">
				<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
			</span>
			<!--{/if}-->
		</span>
    </div>
</header>
<!-- header end -->
<!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
<div class="bus_w100">
<!--{if $subexists && $_G['page'] == 1}-->
	<div class="bus_forumbd pb10 bus_radius">
		<div class="subforumshow bus_forum_tt cl">
		<h2><a>{lang forum_subforums}</a></h2>
		</div>
		<div id="sub_forum_$cat[fid]" class="bus_forum bm_c">
		<ul>
	<!--{loop $sublist $sub}-->
			<li>
				<div class="bus_forum_pic">
				<!--{if $sub[icon]}-->
                $sub[icon]
                <!--{else}-->
                <a href="$forumurl"{if $sub[redirect]} {/if}><img src2="$_G['style'][styleimgdir]/forum{if $sub[folder]}_new{/if}.gif" alt="$sub[name]" /></a>
                <!--{/if}-->
				</div>
				<div class="bus_forum_txt">
				<a href="forum.php?mod=forumdisplay&fid={$sub['fid']}">
					<!--{if $sub[todayposts] > 0}--><span class="num">$sub[todayposts]</span><!--{/if}-->
					<div class="bus_name">{$sub[name]}</div>
					<div>
					  {lang forum_threads}：
					  <!--{if empty($sub[redirect])}-->
					  <em>
					  <!--{echo dnumber($sub[threads])}-->
					  </em><em> / </em><em>
					  <!--{echo dnumber($sub[posts])}-->
					  </em>
					  <!--{/if}-->
					  <em> / </em><em>$sub[lastpost][dateline]</em>
					</div>
			    </a>	
				</div>
			</li>
	<!--{/loop}-->
		</ul>
		</div>
	</div>
<!--{/if}-->

<!--{hook/forumdisplay_top_mobile}-->
<!-- Mobanbus threadlist start -->
  <!--{if !$subforumonly}-->
  <div class="mobanbus_list ">
	  <ul id="waterfall">
		<!--{if $_G['forum_threadcount']}-->
		<!--{loop $_G['forum_threadlist'] $key $thread}-->
		<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
		{eval continue;}
		<!--{/if}-->
		{if $thread['attachment'] == 2}
		{eval $table='forum_attachment_'.substr($thread['tid'], -1);}
		{eval $thread['aid'] = DB::result_first("SELECT aid FROM ".DB::table($table)." WHERE tid='$thread[tid]' AND isimage!='0'");}
		{/if}
		
		<li class="bus_wtf_item busload bus_card">
		<div class="auth"><a href="home.php?mod=space&uid={authorid}"><!--{avatar($thread[authorid],small)}--><span><b>$thread[author]</b><br />$thread[dateline]</span></a>
		<cite class="bus_fr"><i class="icon-eye-open"></i> {$thread[views]}   <i class="icon-comments-alt pl10"></i> <a href="forum.php?mod=viewthread&tid=71&extra=page%3D1" title="{lang reply}">{$thread[replies]}</a></cite>
		</div>

		<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
			<span class="icon_top"><img src2="{STATICURL}image/mobile/images/icon_top.png"></span>
		<!--{elseif $thread['digest'] > 0}-->
			<span class="icon_top"><img src2="{STATICURL}image/mobile/images/icon_digest.png"></span>
		<!--{/if}-->
		<!--{hook/forumdisplay_thread_mobile $key}-->
		<div class="bus_box">
			<div class="bus_wtf_pic">
			<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"><img src2="{eval echo(getforumimg($thread['aid'],0,140,140))}"/>
			<p><b>{$thread[subject]}</b>
			<br />
			<!--{echo messagecutstr(DB::result_first('SELECT `message` FROM '.DB::table('forum_post').' WHERE `tid` ='.$thread[tid].' AND `first` =1'),80);}-->
			</p>
			</a></div>
		</div>
		</li>
		<!--{/loop}-->
		<!--{else}-->
		<li><span class="bus_noshow">{lang forum_nothreads}<a href="forum.php?mod=misc&action=nav&mobile=2">{lang send_threads}</a></span></li>
		<!--{/if}-->
		</ul>
  </div>
  $multipage
  <!--{/if}-->
<!-- Mobanbus threadlist start -->
<!--{hook/forumdisplay_bottom_mobile}-->
</div>
<!-- Mobanbus bus_w100 start -->
<!--{template common/footer}-->
