<?php echo '源码哥商业模板保护！下载获取正版模板请访问源码哥官网：www.fx8.cc';exit;?>
<!--{eval $threadsort = $threadsorts = null;}-->
<!--{template common/header}-->
<!-- header start -->
<header class="header">

	<div class="nav">
		<span class="y">
			<button class="btn_pn btn_pn_blue" id="replyid"><span>{lang reply}</span></button>
		</span>
		<span class="name"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></span>
	</div>

</header>
<!-- header end -->
<div class="mobanbus_bd">
<!--{hook/viewthread_top_mobile}-->
<!-- main postlist start -->
<div class="postlist">
<div class="bus_viewtt">
	<h2><!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
	[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
	<!--{/if}-->
	<!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
	[{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]
	<!--{/if}-->
	$_G[forum_thread][subject]
	<!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
	<!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
	<!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
	<!--{/if}-->
	</h2>
	<div class="bus_hf">
	<span>$post[dateline]</span>
	<span class="pl10">
	<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
		<a href="home.php?mod=space&uid=$post[authorid]" class="bus_colora">$post[author]</a>
	<!--{else}-->
		<!--{if !$post['authorid']}-->
		<a href="javascript:;">{lang guest}<em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
		<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
		<!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
		<!--{else}-->
		$post[author] <em>{lang member_deleted}</em>
		<!--{/if}-->
	<!--{/if}-->
	
	</span>
	<span class="pl10">{lang reply}:$_G[forum_thread][allreplies]</span>
	<span class="pl10">{lang show}:$_G[forum_thread][views]</span>
	</div>
</div>
<!-- Mobanbus_cn bus_viewtt end -->
	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
	<!--{hook/viewthread_posttop_mobile $postcount}-->
   <div class="<!--{if $post[first]}-->bus_viewbd<!--{else}-->bus_replybd<!--{/if}--> plc cl" id="pid$post[pid]">
       <div class="display" href="#replybtn_$post[pid]">
		<!--{if $post[first]}-->
		<!--{else}-->
	   <div class="bus_auther pt5">
	   <div class="avatar"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->" /></div>
       <ul class="authi">
				<li class="grey">
					<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
						<b><a href="home.php?mod=space&uid=$post[authorid]" class="bus_colora">$post[author]</a></b>
					<!--{else}-->
						<!--{if !$post['authorid']}-->
						<a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
						<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
						<!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
						<!--{else}-->
						$post[author] <em>{lang member_deleted}</em>
						<!--{/if}-->
					<!--{/if}-->
				</li>
				<li class="grey rela">
					<em class="bus_fr">
						<!--{if isset($post[isstick])}-->
							<img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="vm" /> {lang from} {$post[number]}{$postnostick}
						<!--{elseif $post[number] == -1}-->
							{lang recommend_post}
						<!--{else}-->
							<!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}-->
						<!--{/if}-->
					</em>
					<!--{if $_G['forum']['ismoderator']}-->
					<!-- manage start -->
					<!--{if $post[first]}-->
						<em><a href="#moption_$post[pid]" class="popup bus_colora">{lang manage}</a></em>
						<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
							<!--{if !$_G['forum_thread']['special']}-->
							<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
							<!--{/if}-->
							<input type="button" value="{lang delete}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">
							<input type="button" value="{lang close}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">
							<input type="button" value="{lang admin_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
							<input type="button" value="{lang topicadmin_warn_add}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
						</div>
					<!--{else}-->
						<em><a href="#moption_$post[pid]" class="popup bus_colora">{lang manage}</a></em>
						<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
							<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
							<!--{if $_G['group']['allowdelpost']}--><input type="button" value="{lang modmenu_deletepost}" class="dialog button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
							<!--{if $_G['group']['allowbanpost']}--><input type="button" value="{lang modmenu_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
							<!--{if $_G['group']['allowwarnpost']}--><input type="button" value="{lang modmenu_warn}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
						</div>
					<!--{/if}-->
					<!-- manage end -->
					<!--{/if}-->
					$post[dateline]
				</li>
       </ul>
	   </div>
		<!--{/if}-->
       <div class="message" id="isfirst">
                	<!--{if $post['warned']}-->
                        <span class="grey quote">{lang warn_get}</span>
                    <!--{/if}-->
                    <!--{if !$post['first'] && !empty($post[subject])}-->
                        <h2><strong>$post[subject]</strong></h2>
                    <!--{/if}-->
                    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                        <div class="grey quote">{lang message_banned}</div>
                    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                        <div class="grey quote">{lang message_single_banned}</div>
                    <!--{elseif $needhiddenreply}-->
                        <div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
                    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
						<!--{template forum/viewthread_pay}-->
					<!--{else}-->

                    	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                            <div class="grey quote">{lang admin_message_banned}</div>
                        <!--{elseif $post['status'] & 1}-->
                            <div class="grey quote">{lang admin_message_single_banned}</div>
                        <!--{/if}-->
                        <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                            {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
                        <!--{/if}-->

                        <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                        	<!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                                <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                    {lang has_expired}
                                <!--{else}-->
                                    <div class="box_ex2 viewsort">
                                        <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                                    <!--{loop $threadsortshow['optionlist'] $option}-->
                                        <!--{if $option['type'] != 'info'}-->
                                            $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="grey">--</span><!--{/if}--><br />
                                        <!--{/if}-->
                                    <!--{/loop}-->
                                    </div>
                                <!--{/if}-->
                            <!--{/if}-->
                        <!--{/if}-->
                        <!--{if $post['first']}-->
							<!--{if $threadsortshow['typetemplate']}-->
								$threadsortshow[typetemplate]
								<div class="clear"></div>
								<p>$post[message]</p>
							<!--{elseif $threadsortshow['optionlist']}-->
								<div class="typeoption">
									<!--{if $threadsortshow['optionlist'] == 'expire'}-->
										{lang has_expired}
									<!--{else}-->
										<table summary="{lang threadtype_option}" cellpadding="0" cellspacing="0" class="cgtl mbm">
											<caption>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</caption>
											<tbody>
												<!--{loop $threadsortshow['optionlist'] $option}-->
													<!--{if $option['type'] != 'info'}-->
														<tr>
															<th>$option[title]:</th>
															<td><!--{if $option['value'] !== ''}-->$option[value] $option[unit]<!--{else}-->-<!--{/if}--></td>
														</tr>
													<!--{/if}-->
												<!--{/loop}-->
											</tbody>
										</table>
									<!--{/if}-->
								</div>
								<div class="clear"></div>
 								<p>$post[message]</p>
                           <!--{elseif !$_G[forum_thread][special]}-->
                                $post[message]
                            <!--{elseif $_G[forum_thread][special] == 1}-->
                                <!--{template forum/viewthread_poll}-->
                            <!--{elseif $_G[forum_thread][special] == 2}-->
                                <!--{template forum/viewthread_trade}-->
                            <!--{elseif $_G[forum_thread][special] == 3}-->
                                <!--{template forum/viewthread_reward}-->
                            <!--{elseif $_G[forum_thread][special] == 4}-->
                                <!--{template forum/viewthread_activity}-->
                            <!--{elseif $_G[forum_thread][special] == 5}-->
                                <!--{template forum/viewthread_debate}-->
                            <!--{elseif $threadplughtml}-->
                                $threadplughtml
                                $post[message]
                            <!--{else}-->
                            	$post[message]
                            <!--{/if}-->
                        <!--{else}-->
                            $post[message]
                        <!--{/if}-->
					<!--{/if}-->
					
					<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
					<!--{if $post['attachment']}-->
					   <div class="grey quote">
					   {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
					   </div>
					<!--{elseif $post['imagelist'] || $post['attachlist']}-->
					   <!--{if $post['imagelist']}-->
						<!--{if count($post['imagelist']) == 1}-->
						<ul class="img_one">{echo showattach($post, 1)}</ul>
						<!--{else}-->
						<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
						<!--{/if}-->
						<!--{/if}-->
						<!--{if $post['attachlist']}-->
						<ul>{echo showattach($post)}</ul>
						<!--{/if}-->
					<!--{/if}-->
					<!--{/if}-->
					<!--{if $_G[uid] && $allowpostreply && !$post[first]}-->
					<div id="replybtn_$post[pid]" class="replybtn" display="true" style="display:none;position:absolute;bottom:10px;right:0px; font-size:1em">
						<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" class="bus_colora">{lang reply}</a>
					</div>
					<!--{/if}-->
					
					<!--{if $post[first]}-->
					<div class="bus_box mt20">
						<!--{if $post['relateitem']}-->
							<h3 class="pt10 bbda">{lang related_thread}</h3>
							<ul class="xl xl2 cl">
								<!--{loop $post['relateitem'] $var}-->
								<li>&#8226; <a href="forum.php?mod=viewthread&tid=$var[tid]" title="$var[subject]">$var[subject]</a></li>
								<!--{/loop}-->
							</ul>
						<!--{/if}-->
					</div>
					<!--{/if}-->
			</div>
			<!-- Mobanbus_cn message end -->
       </div>
  </div>
   <!--{if $post[first]}-->
   <div class="bus_next">
   <a href="forum.php?mod=redirect&goto=nextnewset&tid=$_G[tid]" title="{lang next_thread}">{lang next_thread}<i class="icon-angle-right"></i></a>
   <a href="forum.php?mod=redirect&goto=nextoldset&tid=$_G[tid]" title="{lang last_thread}"><i class="icon-angle-left"></i>{lang last_thread}</a>
   </div>
   <div class="bux_box bus_fl pl5">
   <h3 class="bbda">$_G[forum_thread][allreplies] {lang reply}</h3>
   </div>
   <!--{/if}-->
   <!--{hook/viewthread_postbottom_mobile $postcount}-->
   <!--{eval $postcount++;}-->
   <!--{/loop}-->
   <!-- Mobanbus_cn bus_viewbd end -->
   <!--{subtemplate forum/forumdisplay_fastpost}-->
</div>
<!-- Mobanbus_cn postlist end -->

$multipage

<!--{hook/viewthread_bottom_mobile}-->
</div>
<!-- Mobanbus_cn mobanbus_bd end -->
<!--{template common/footer}-->
