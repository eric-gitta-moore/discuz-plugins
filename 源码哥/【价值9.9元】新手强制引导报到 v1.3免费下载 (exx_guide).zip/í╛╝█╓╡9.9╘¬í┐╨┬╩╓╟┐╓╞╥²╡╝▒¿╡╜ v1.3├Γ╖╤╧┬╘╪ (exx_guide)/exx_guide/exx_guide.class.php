<?php
/*
 *源码哥：www.ymg6.com
 *更多商业插件/模版免费下载 就在源码哥
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_exx_guide {
	function common(){
		global $_G;		
		$exx_guide=$_G['cache']['plugin']['exx_guide'];
		$bks=$exx_guide['bk']?$exx_guide['bk']:1;
		$bk=daddslashes($bks);
		$section = empty($exx_guide['yhz']) ? array() : unserialize($exx_guide['yhz']);
		if((empty($section[0]) || in_array($_G['groupid'],$section)) && !($_G['fid']==$bk) && $_G['uid']>0){
			$tiecount=DB::result_first("select count(1) from ".DB::table('forum_thread')." where fid=".$bk." AND authorid=".$_G['uid']);
			if($exx_guide['lj']==1){
				if($exx_guide['wjt'])$url='forum-'.$bk.'-1.html'; else $url='forum.php?mod=forumdisplay&fid='.$bk;
			}else{
				$url='forum.php?mod=post&action=newthread&fid='.$bk;
			}
			if(empty($tiecount) && ($_GET['mod']=="post" || $_GET['mod']=="viewthread" || $_GET['mod']=="forumdisplay")){
				showmessage(dhtmlspecialchars($exx_guide['tis']),$url);
			}
		}
		$info['sn']="000";
		$info['RevisionID']="000";
		$info['RevisionDateline']="000";
		$info['url']="http://www.ymg6.com/";
		$info['ClientUrl']="http://127.0.0.1/";
		$info['SiteID']="000-000--00-000";
		$info['snmd5']="000";
		$info['snmd5a']="000";
		$info['snridmd5']="000";
	}
	
}
