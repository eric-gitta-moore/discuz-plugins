<?php
/*
 * ��ҳ��http://www.fx8.cc
 * Դ�������� ȫ���׷� http://www.fx8.cc
 * ������� ��ϵQQ154606914
 * From www.fx8.cc
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$_G['uid']){//�ο�
	showmessage(lang('plugin/nimba_rename','userlogin'), '', array(), array('login' => true));
}
loadcache('plugin');
$uid=$_G['uid'];
$username=$_G['username'];
$vars=$_G['cache']['plugin']['nimba_rename'];
$open=$vars['open'];
$groups=unserialize($vars['groups']);
if(submitcheck('submit')){
 	if(!$open||!in_array($_G['groupid'],$groups)) showmessage(lang('plugin/nimba_rename','m0'),"forum.php");
	if($uid){
		$count=C::t('#nimba_rename#nimba_rename')->count_by_uid_status($uid,0);
		if($count) showmessage(lang('plugin/nimba_rename','m1'),"forum.php");
	}
	$newname=addslashes($_POST['newname']);
	$reason=addslashes($_POST['reason']);
	if(!$newname) showmessage(lang('plugin/nimba_rename','m2'),"forum.php");
	$same=C::t('common_member')->count_by_like_username($newname);
	if($same) showmessage(lang('plugin/nimba_rename','m4'),"forum.php");
	C::t('#nimba_rename#nimba_rename')->insert(array('uid'=>$uid,'username'=>$_G['username'],'newname'=>$newname,'reason'=>$reason,'dateline'=>$_G['timestamp'],'status'=>0));
	showmessage(lang('plugin/nimba_rename','m3'),"forum.php");
}else{
	$longs=range(1,$max);
	include template('nimba_rename:rename');
}
//From:www_FX8_co
?>