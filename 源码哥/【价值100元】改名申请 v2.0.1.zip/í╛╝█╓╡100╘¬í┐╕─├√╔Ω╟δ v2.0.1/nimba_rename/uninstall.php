<?php
/*
 * 主页：http://www.fx8.cc
 * 源码哥源码论坛 全网首发 http://www.fx8.cc
 * 插件定制 联系QQ154606914
 * From www.fx8.cc
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql = <<<SQL
DROP TABLE IF EXISTS pre_nimba_rename;
SQL;
runquery($sql);
$finish = TRUE;
?>