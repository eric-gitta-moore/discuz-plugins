<?php
/*
 * 主页：http://www.fx8.cc
 * 源码哥源码论坛 全网首发 http://www.fx8.cc
 * 插件定制 联系QQ154606914
 * From www.fx8.cc
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$pagenum=20;
$page=max(1,intval($_GET['page']));
$count=C::t('#nimba_rename#nimba_rename')->count();
showtableheader();
showsubtitle(array(lang('plugin/nimba_rename','username'),lang('plugin/nimba_rename','newname'),lang('plugin/nimba_rename','dateline'),lang('plugin/nimba_rename','reason'),lang('plugin/nimba_rename','status')));
$data=C::t('#nimba_rename#nimba_rename')->fetch_all_by_range(($page - 1)*$pagenum,$pagenum);
foreach($data as $user) {
	switch($user['status']){
		case 2:$status=lang('plugin/nimba_rename','status2');break; 
		case 1:$status=lang('plugin/nimba_rename','status1');break; 
		case 0:$status=lang('plugin/nimba_rename','status0');break;  
	}
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		'<a href="home.php?mod=space&uid='.$user['uid'].'" target="_blank">'.$user['username'].'</a>',
		$user['newname'],	
		date('Y-m-d H:i:s',$user['dateline']),
		$user['reason'],
		$status,
	));
			
}
showtablefooter();
echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_rename&pmod=data");
?>