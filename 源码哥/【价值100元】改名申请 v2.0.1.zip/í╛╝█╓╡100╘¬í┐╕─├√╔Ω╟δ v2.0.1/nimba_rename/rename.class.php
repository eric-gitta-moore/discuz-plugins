<?php
/*
 * 主页：http://www.fx8.cc
 * 源码哥源码论坛 全网首发 http://www.fx8.cc
 * 插件定制 联系QQ154606914
 * From www.fx8.cc
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_nimba_rename {
	public $open=0;
	public $groups=array();
	public $nav=0;
	public $name='';
	
	function  __construct() {
	    loadcache('plugin');
		global $_G;
		$this->vars = $_G['cache']['plugin']['nimba_rename'];
		$this->groups=unserialize($this->vars['groups']);
		$this->nav=$this->vars['nav'];
		$this->name=$this->vars['name'];
		$this->open=$this->vars['open'];
	}	
	
	function global_cpnav_extra1() {
		loadcache('plugin');
		global $_G;
		if($this->open&&in_array($_G['groupid'],$this->groups)&&$this->nav==2) return '<a href="javascript:;" onclick=showWindow(\'nimba_rename\',\'plugin.php?id=nimba_rename:rename&'.FORMHASH.'\')>'.$this->name.'</a>';
	}

	function global_nav_extra(){
		loadcache('plugin');
		global $_G;
		if($this->open&&in_array($_G['groupid'],$this->groups)&&$this->nav==3) return '<ul><li><a href="javascript:;" onclick=showWindow(\'nimba_rename\',\'plugin.php?id=nimba_rename:rename&'.FORMHASH.'\')>'.$this->name.'</a></ul></li>';	
	}
	
	function global_footerlink(){
		loadcache('plugin');
		global $_G;
		if($this->open&&in_array($_G['groupid'],$this->groups)&&$this->nav==4) return '<span class="pipe">|</span><a href="javascript:;" onclick=showWindow(\'nimba_rename\',\'plugin.php?id=nimba_rename:rename&'.FORMHASH.'\')>'.$this->name.'</a>';	
	}
	
	function global_usernav_extra2(){
		loadcache('plugin');
		global $_G;
		if($this->open&&in_array($_G['groupid'],$this->groups)&&$this->nav==5) return '<span class="pipe">|</span><a href="javascript:;" onclick=showWindow(\'nimba_rename\',\'plugin.php?id=nimba_rename:rename&'.FORMHASH.'\')>'.$this->name.'</a>';		
	}
}
//WWW.fx8.cc
?>