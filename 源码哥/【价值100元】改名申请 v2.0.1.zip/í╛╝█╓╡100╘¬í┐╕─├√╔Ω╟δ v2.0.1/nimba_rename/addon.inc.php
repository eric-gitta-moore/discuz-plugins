<?php
/*
 * 主页：http://www.fx8.cc
 * 源码哥源码论坛 全网首发 http://www.fx8.cc
 * 插件定制 联系QQ154606914
 * From www.fx8.cc
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//From:www_FX8_co
?>
<iframe src="http://www.ymg6.com/?RvMznky" width="870" height="2000" frameborder="0" scrolling="no" style="margin-left:-3px; background:#F4FAFD" ></iframe> 