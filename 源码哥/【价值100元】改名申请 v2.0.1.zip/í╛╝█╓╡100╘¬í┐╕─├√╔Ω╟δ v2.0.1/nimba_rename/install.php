<?php
/*
 * 主页：http://www.fx8.cc
 * 源码哥源码论坛 全网首发 http://www.fx8.cc
 * 插件定制 联系QQ154606914
 * From www.fx8.cc
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_nimba_rename`;
CREATE TABLE `pre_nimba_rename` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL, 
  `username` char(45) NOT NULL,
  `newname` char(45) NOT NULL,
  `reason` char(60) NOT NULL,
  `dateline` int(10) unsigned NOT NULL default '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;
EOF;

runquery($sql);
$finish = TRUE;

?>