<?php echo 'Jeavidesign';exit;?>
<div class="flw_hd">
	<!--{if helper_access::check_module('follow')}-->
	<div class="tns">
		<table cellspacing="0" cellpadding="0">
			<tr>
				<th>
					<p><a href="home.php?mod=follow&uid=$uid&do=view" class="xi2 xw1">$spaces['feeds']</a></p>
					<span><a href="home.php?mod=follow&uid=$uid&do=view" class="xi2">{lang follow}</a></span>
				</th>
				<th>
					<p><a href="home.php?mod=follow&do=following&uid=$uid" class="xi2 xw1">$spaces['following']</a></p>
					<span><a href="home.php?mod=follow&do=following&uid=$uid" class="xi2">{lang follow_add}</a></span>
				</th>
				<td>
					<p><a href="home.php?mod=follow&do=follower&uid=$uid" id="followernum_$uid" class="xi2 xw1">$spaces['follower']</a></p>
					<span><a href="home.php?mod=follow&do=follower&uid=$uid" id="followernum_$uid" class="xi2">{lang follow_follower}</a></span>
				</td>
			</tr>
		</table>
	</div>
	<!--{/if}-->
    
    
    	<!--{if !$space[self]}-->
	<div class="mn">
		<ul>
			<!--{if helper_access::check_module('follow')}-->
			<li class="addflw z">
				<!--{if !ckfollow($space['uid'])}-->
					<a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]">{lang follow_add}TA</a>
				<!--{else}-->
					<a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]">{lang follow_del}</a>
				<!--{/if}-->
			</li>
			<!--{/if}-->
			<li class="addf z mll" style="display:none;">
				<!--{if !$isfriend}-->
				<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]&handlekey=addfriendhk_{$space[uid]}" id="a_friend_li_{$space[uid]}" onclick="showWindow(this.id, this.href, 'get', 0);" class="xi2">{lang add_friend}</a>
				<!--{else}-->
				<a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$space[uid]&handlekey=ignorefriendhk_{$space[uid]}" id="a_ignore_{$space[uid]}" onclick="showWindow(this.id, this.href, 'get', 0);" class="xi2">{lang ignore_friend}</a>
				<!--{/if}-->
			</li>
			<li class="pm2 z mll">
				<a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" id="a_sendpm_$space[uid]" onclick="showWindow('showMsgBox', this.href, 'get', 0)" title="{lang send_pm}">{lang send_pm}</a>
			</li>
		</ul>
		<!--{if helper_access::check_module('follow')}-->
		<script type="text/javascript">
		function succeedhandle_followmod(url, msg, values) {
			var fObj = $('followmod');
			if(values['type'] == 'add') {
				fObj.innerHTML = '{lang follow_del}';
				fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
			} else if(values['type'] == 'del') {
				fObj.innerHTML = '{lang follow_add}TA';
				fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
			}
		}
		</script>
		<!--{/if}-->
	</div>
	<!--{/if}-->
    
    
<!--{if !$viewself}-->
	<div class="mtm o cl" style="display:none;">
		<div id="followflag">
			<!--{if helper_access::check_module('follow')}-->
			<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&special={if $flag[$_G['uid']]['status'] == 1}2{else}1{/if}&fuid=$uid&from=head" class="{if $flag[$_G['uid']]['status'] == 1}flw_specialunfo{else}flw_specialfo{/if}" id="specialflag_$uid" onclick="ajaxget(this.href);doane(event);" title="{if $flag[$_G['uid']]['status'] == 1}{lang follow_del_special_following}{else}{lang follow_add_special_following}{/if}"><!--{if $flag[$_G['uid']]['status'] == 1}-->{langfollow_del_special_following}<!--{else}-->{lang follow_add_special_following}<!--{/if}--></a>
			<!--{/if}-->
			<!--{if $flag[$_G['uid']]['mutual']}-->
			<span class="z flw_status_2">{lang follow_follower_mutual}</span>
			<!--{else}-->
			<span class="z flw_status_1">{lang follow_followed},</span>
			<!--{/if}-->
			<a id="a_followmod_{$uid}" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$uid&from=head" onclick="ajaxget(this.href);doane(event);" class="xi2">{lang follow_del}</a>
		</div>
		<div id="unfollowflag" {if isset($flag[$_G['uid']])}style="display: none"{/if}>
			<!--{if isset($flag[$uid])}-->
			<span class="z flw_status_1">{lang follow_user_followed}</span>
			<!--{/if}-->
			<!--{if helper_access::check_module('follow')}-->
			<a id="a_followmod_{$uid}" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$uid&from=head" onclick="ajaxget(this.href);doane(event);" class="flw_btn_fo">{lang follow_add}</a>
			<!--{/if}-->
		</div>
	</div>
<!--{/if}-->
</div>
