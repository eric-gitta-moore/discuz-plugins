<?php echo 'Jeavidesign';exit;?>
<!--{if $_G['forum']['ismoderator']}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->
<div id="pgt" class="bm bw0 mtm pgs cl">

  <ul class="ttb mtn z cl">
    <li{if !$_GET['specialtype']} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">ȫ������</a></li>
    <!--{if $showpoll}-->
    <li{if $_GET['specialtype'] == poll} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_poll}</a></li>
    <!--{/if}--> 
    <!--{if $showtrade}-->
    <li{if $_GET['specialtype'] == trade} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_trade}</a></li>
    <!--{/if}--> 
    <!--{if $showreward}-->
    <li{if $_GET['specialtype'] == reward} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_reward}</a></li>
    <!--{/if}--> 
    <!--{if $showactivity}-->
    <li{if $_GET['specialtype'] == activity} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_activity}</a></li>
    <!--{/if}--> 
    <!--{if $showdebate}-->
    <li{if $_GET['specialtype'] == debate} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_debate}</a></li>
    <!--{/if}-->
  </ul>


	
	<!--{if helper_access::check_module('group')}-->
	<span {if $_G[setting][visitedforums]}id="visitedforums" onmouseover="$('visitedforums').id = 'visitedforumstmp';this.id = 'visitedforums';showMenu({'ctrlid':this.id})"{/if} class="pgb y" style="display:none"><a href="forum.php?mod=group&fid=$_G[fid]">{lang return_index}</a></span>
	
	<a href="javascript:;" id="newspecial" class="y" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})" onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')" title="{lang send_posts}"><img src="{IMGDIR}/pn_post.png" alt="{lang send_posts}" /></a>
	<!--{/if}-->
	<!--{hook/forumdisplay_postbutton_top}-->
</div>
<!--{if $_G['forum']['threadtypes']}-->
	<ul class="pgs ttp bm cl">
		<li id="ttp_all"{if !$_GET['typeid']} class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang forum_viewall}</a></li>
		<!--{if $_G['forum']['threadtypes']}-->
			<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
				<li{if $_GET['typeid'] == $id} class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]{if $_GET['typeid'] != $id}&filter=typeid&typeid=$id$forumdisplayadd[typeid]{/if}">$name</a>
			<!--{/loop}-->
		<!--{/if}-->
		<!--{hook/forumdisplay_filter_extra}-->
	</ul>
<!--{/if}-->
<div id="threadlist" class="tl bm" style="position: relative;">
<div class="th showmenubox">

    ɸѡ��  <span class="showmenu_outer"> <a id="filter_time" href="javascript:;" class="showmenu {if $_GET['specialtype']} a{/if}" onclick="showMenu(this.id)"> 
    <!--{if !$_GET['dateline']}--> 
    ȫ��ʱ�� 
    <!--{elseif $_GET['dateline'] == '86400'}--> 
    һ��
    <!--{elseif $_GET['dateline'] == '172800'}--> 
    ���� 
    <!--{elseif $_GET['dateline'] == '604800'}--> 
    һ��
    <!--{elseif $_GET['dateline'] == '2592000'}--> 
    һ���� 
    <!--{elseif $_GET['dateline'] == '7948800'}--> 
    ������ 
    <!--{else}--> 
    ȫ��ʱ��
    <!--{/if}--> 
    </a> </span><span class="showmenu_outer"> <a id="filter_orderby" href="javascript:;" class="showmenu {if $_GET['specialtype']} a{/if}" onclick="showMenu(this.id)"> 
    <!--{if $_GET['orderby'] == 'dateline'}--> 
    ����ʱ��
    <!--{elseif $_GET['orderby'] == 'replies'}--> 
    �ظ�/�鿴
    <!--{elseif $_GET['orderby'] == 'views'}--> 
    �鿴
    <!--{else}--> 
    Ĭ������
    <!--{/if}--> 
    </a> </span>
    <table cellspacing="0" cellpadding="0" style="display: none">
      <!--hide for dev-->
      <tr>
        <th colspan="{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}3{else}2{/if}"> <!--{if CURMODULE != 'guide'}-->
          
          <div class="tf"> <span id="atarget" {if $_G['cookie']['atarget'] > 0}onclick="setatarget(-1)" class="y atarget_1"{else}onclick="setatarget(1)" class="y"{/if} title="{lang new_window_thread}">{lang new_window}</span> 
            <!--{if $_GET['specialtype'] == 'reward'}--> 
            <a id="filter_reward" href="javascript:;" class="showmenu xi2{if $_GET['rewardtype']} xw1{/if}" onclick="showMenu(this.id)"> 
            <!--{if $_GET['rewardtype'] == ''}--> 
            {lang all_reward} 
            <!--{elseif $_GET['rewardtype'] == '1'}--> 
            {lang rewarding} 
            <!--{elseif $_GET['rewardtype'] == '2'}--> 
            {lang reward_solved} 
            <!--{/if}--> 
            </a>&nbsp; 
            <!--{/if}--> 
            
            <a id="filter_dateline" href="javascript:;" class="showmenu xi2{if $_GET['dateline']} xw1{/if}" onclick="showMenu(this.id)">{lang more}</a>&nbsp; 
            <!--{if empty($_G['forum']['picstyle']) && $_GET['orderby'] == 'lastpost' && (!$_G['setting']['forumseparator'] || !$separatepos) && !$_GET['filter']}--> 
            <a href="javascript:;" onclick="checkForumnew_btn('{$_G['fid']}')" title="{lang showupgrade}" class="forumrefresh"></a> 
            <!--{/if}--> 
            <!--{if $_GET['filter'] == 'hot'}--> 
            <script type="text/javascript" src="{$_G[setting][jspath]}calendar.js?{VERHASH}"></script> 
            <span>$ctime</span> <img src="{IMGDIR}/date_magnify.png" class="cur1" alt="" id="hottime" value="$ctime" fid="$_G[fid]" onclick="showcalendar(event, this, false, false, false, false, function(){viewhot(this);});" align="absmiddle" /> 
            <!--{/if}--> 
            <span id="clearstickthread" style="display: none;"> <span class="pipe">|</span> <a href="javascript:;" onclick="clearStickThread()" class="xi2" title="{lang showdisplayorder}">{lang showdisplayorder}</a> </span> 
            <!--{hook/forumdisplay_filter_extra}--> 
          </div>
          
          <!--{else}--> 
          {lang title} 
          <!--{/if}--> </th>
        
        <!--{if empty($_G['forum']['picstyle'])}--> 
        <!--{if CURMODULE == 'guide'}-->
        <td class="by">{lang forum_group}</td>
        <!--{/if}-->
        <td class="by">{lang author}</td>
        <td class="num">{lang replies}</td>
        <td class="by">{lang lastpost}</td>
        <!--{else}-->
        <td class="by" colspan="3"><a{if empty($_G['cookie']['forumdefstyle'])} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=yes" class="chked"{else} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" class="unchk"{/if} title="{lang view_thread_imagemode}{lang view_thread}">{lang view_thread_imagemode}</a></td>
        <!--{/if}--> 
      </tr>
    </table>
  </div>
	<div class="bm_c">
		<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="listextra" value="$extra" />
			<table cellpadding="0" cellspacing="0" border="0">
				<!--{if $_G['forum_threadcount']}-->
					<tbody class="emptb"><tr><td class="icn"></td><!--{if $_G['forum']['ismoderator']}--><td class="o"></td><!--{/if}--><th></th><td class="by"></td><td class="num"></td><td class="by"></td></tr></tbody>
					<!--{loop $_G['forum_threadlist'] $key $thread}-->
						<!--{ad/threadlist}-->
						<tbody id="$thread[id]">
							<tr>
                            
                            <td class="icn">                            
                            <div class="forumava"> <a href="home.php?mod=space&uid=$thread[authorid]" c="1"> 
                <!--{avatar($thread[authorid],small)}--> 
                </a> </div></td>
                            
                            

								<!--{if $_G['forum']['ismoderator']}-->
								<td class="o">
									<!--{if $thread['fid'] == $_G[fid]}-->
										<!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
											<input onclick="tmodclick(this)" type="checkbox" name="moderate[]" class="pc" value="$thread[tid]" />
										<!--{else}-->
											<input type="checkbox" disabled="disabled" />
										<!--{/if}-->
									<!--{else}-->
										<input type="checkbox" disabled="disabled" />
									<!--{/if}-->
								</td>
								<!--{/if}-->
								<th class="common forumtit">
									<!--{hook/forumdisplay_thread $key}-->
									<!--{if $thread['moved']}-->
										<!--{if $_G['forum']['ismoderator']}-->
											<a href="forum.php?mod=topicadmin&action=moderate&optgroup=3&operation=delete&tid=$thread[moved]" onclick="showWindow('mods', this.href);return false">{lang thread_moved}:</a>
										<!--{else}-->
											{lang thread_moved}:
										<!--{/if}-->
									<!--{/if}-->
									$thread[typehtml]
									<span id="thread_$thread[tid]"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"$thread[highlight] class="xst">$thread[subject]</a></span>
									<!--{if $thread['readperm']}--> - [{lang readperm} <span class="xw1">$thread[readperm]</span>]<!--{/if}-->
									<!--{if $thread['price'] > 0}-->
										<!--{if $thread['special'] == '3'}-->
										- <span style="color: #C60">[{lang thread_reward}<span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span>
										<!--{else}-->
										- [{lang price} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]
										<!--{/if}-->
									<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
										- <span style="color: #269F11">[{lang reward_solved}]</span>
									<!--{/if}-->
									<!--{if $thread['attachment'] == 2}-->
										<img src="{STATICURL}image/filetype/image_s.gif" alt="{lang attach_img}" align="absmiddle" />
									<!--{elseif $thread['attachment'] == 1}-->
										<img src="{STATICURL}image/filetype/common.gif" alt="{lang attachment}" align="absmiddle" />
									<!--{/if}-->
									<!--{if $thread['displayorder'] == 0}-->
										<!--{if $thread[recommendicon]}-->
											<img src="{IMGDIR}/recommend_$thread[recommendicon].gif" align="absmiddle" alt="recommend" title="{lang thread_recommend} $thread[recommends]" />
										<!--{/if}-->
										<!--{if $thread[heatlevel]}-->
											<img src="{IMGDIR}/hot_$thread[heatlevel].gif" align="absmiddle" alt="heatlevel" title="$thread[heatlevel] {lang heats}" />
										<!--{/if}-->
										<!--{if $thread['digest'] > 0}-->
											<img src="{IMGDIR}/digest_$thread[digest].gif" align="absmiddle" alt="digest" title="{lang thread_digest} $thread[digest]" />
										<!--{/if}-->
										<!--{if $thread['rate'] > 0}-->
											<img src="{IMGDIR}/agree.gif" align="absmiddle" alt="agree" title="{lang rate_credit_add}" />
										<!--{/if}-->
									<!--{/if}-->
									
      <a href="forum.php?mod=viewthread&tid=$thread[icontid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" title="{if $thread['displayorder'] == 1}{lang thread_type1} - {/if}
											{if $thread['displayorder'] == 2}{lang thread_type2} - {/if}
											{if $thread['displayorder'] == 3}{lang thread_type3} - {/if}
											{if $thread['displayorder'] == 4}{lang thread_type4} - {/if}
											{if $thread[folder] == 'lock'}{lang closed_thread} - {/if}
											{if $thread['special'] == 1}{lang thread_poll} - {/if}
											{if $thread['special'] == 2}{lang thread_trade} - {/if}
											{if $thread['special'] == 3}{lang thread_reward} - {/if}
											{if $thread['special'] == 4}{lang thread_activity} - {/if}
											{if $thread['special'] == 5}{lang thread_debate} - {/if}
											{if $thread[folder] == "new"}{lang have_newreplies} - {/if}
											{lang target_blank}" target="_blank"> 
      <!--{if $thread[folder] == 'lock'}--> 
      <img src="$_G['style'][styleimgdir]/jeavi_common/folder_lock.gif" /> 
      <!--{elseif $thread['special'] == 1}--> 
      <img src="$_G['style'][styleimgdir]/jeavi_common/pollsmall.gif" alt="{lang thread_poll}" /> 
      <!--{elseif $thread['special'] == 2}--> 
      <img src="$_G['style'][styleimgdir]/jeavi_common/tradesmall.gif" alt="{lang thread_trade}" /> 
      <!--{elseif $thread['special'] == 3}--> 
      <img src="$_G['style'][styleimgdir]/jeavi_common/rewardsmall.gif" alt="{lang thread_reward}" /> 
      <!--{elseif $thread['special'] == 4}--> 
      <img src="$_G['style'][styleimgdir]/jeavi_common/activitysmall.gif" alt="{lang thread_activity}" /> 
      <!--{elseif $thread['special'] == 5}--> 
      <img src="$_G['style'][styleimgdir]/jeavi_common/debatesmall.gif" alt="{lang thread_debate}" /> 
      <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}--> 
      <img src="$_G['style'][styleimgdir]/jeavi_common/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" /> 
      <!--{else}--> 
      <img src="$_G['style'][styleimgdir]/jeavi_common/folder_$thread[folder].gif" style="display:none;" /> 
      <!--{/if}--> 
      </a> 
									<!--{if $thread[multipage]}-->
										<span class="tps">$thread[multipage]</span>
									<!--{/if}-->
                                    
                                    <div class="forumsummary"> 
                <!--{hook/jeavi_summary $key}--> 
              </div>
              <div class="foruminfo"> <i class="z"> 
                <!--{hook/forumdisplay_author $key}--> 
                ¥��:<a href="home.php?mod=space&uid=$thread[authorid]" c="1"> <span>$thread[author]</span></a><span>$thread[dateline]</span><span class="pipe">|</span> {lang lastpost}: <span><!--{if $thread['lastposter']}--><a href="{if $thread[digest] != -2}home.php?mod=space&username=$thread[lastposterenc]{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}" c="1">$thread[lastposter]</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></span> $thread[lastpost] </i><i class="y"> <span class="ico_reply">$thread[allreplies]</span> <span class="ico_see">$thread[views]</span></i> 
              </div>
                                    
                                    
								</th>
								<td class="by">
								
								</td>
								<td class="num">
									
								</td>
								<td class="by">
									
								</td>
							</tr>
						</tbody>
					<!--{/loop}-->
				<!--{else}-->
					<tbody><tr><th colspan="6"><p class="emp">{lang forum_nothreads}</p></th></tr></tbody>
				<!--{/if}-->
			</table>
			<!--{if $_G['forum']['ismoderator'] && $_G['forum_threadcount']}-->
				<!--{template forum/topicadmin_modlayer}-->
			<!--{/if}-->
		</form>
	</div>
</div>
<!--{if helper_access::check_module('group')}-->
<div class="bm bw0 pgs cl">
	$multipage

	<!--{hook/forumdisplay_postbutton_bottom}-->
</div>

<!--{if $_G['setting']['fastpost']}-->
	<!--{template forum/forumdisplay_fastpost}-->
<!--{/if}-->


<!--{if !IS_ROBOT}-->

<div id="filter_reward_menu" class="p_pop showsub" style="display:none" change="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype='+$('filter_reward').value">
  <ul>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all_reward}</a></li>
    <!--{if $showpoll}-->
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1">{lang rewarding}</a></li>
    <!--{/if}--> 
    <!--{if $showtrade}-->
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2">{lang reward_solved}</a></li>
    <!--{/if}-->
  </ul>
</div>
<div id="filter_dateline_menu" class="p_pop showsub" style="display:none">
  <ul class="pop_moremenu">
    <li>{lang orderby}: <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'dateline'}class="xw1"{/if}>{lang list_post_time}</a><span class="pipe">|</span> <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'replies'}class="xw1"{/if}>{lang replies}</a><span class="pipe">|</span> <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'views'}class="xw1"{/if}>{lang views}</a> </li>
    <li>{lang time}: <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['dateline']}class="xw1"{/if}>{lang all}{lang search_any_date}</a><span class="pipe">|</span> <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '86400'}class="xw1"{/if}>{lang last_1_days}</a><span class="pipe">|</span> <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '172800'}class="xw1"{/if}>{lang last_2_days}</a><span class="pipe">|</span> <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '604800'}class="xw1"{/if}>{lang list_one_week}</a><span class="pipe">|</span> <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '2592000'}class="xw1"{/if}>{lang list_one_month}</a><span class="pipe">|</span> <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '7948800'}class="xw1"{/if}>{lang list_three_month}</a> </li>
  </ul>
</div>
<div id="filter_time_menu" class="p_pop showsub" style="display:none">
  <ul>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">ȫ��ʱ��</a></li>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">һ��</a></li>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">����</a></li>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">һ��</a></li>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">һ����</a></li>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">������</a></li>
  </ul>
</div>

<!--{if !$_G['setting']['closeforumorderby']}-->
<div id="filter_orderby_menu" class="p_pop showsub" style="display:none">
  <ul>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">Ĭ������</a></li>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">����ʱ��</a></li>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang replies}</a></li>
    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">�鿴</a></li> 
  </ul>
</div>
<!--{/if}--> 
<!--{/if}--> 


<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
	<ul class="p_pop" id="newspecial_menu" style="display: none">
		<!--{if !$_G['forum']['allowspecialonly']}--><li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" onclick="showWindow('newthread', this.href);doane(event)">{lang post_newthread}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
		<!--{if $_G['setting']['threadplugins']}-->
			<!--{loop $_G['forum']['threadplugin'] $tpid}-->
				<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
					<li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url($_G[setting][threadplugins][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	</ul>
<!--{/if}-->
<!--{/if}-->
