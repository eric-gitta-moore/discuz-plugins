<?php echo 'Jeavidesign';exit;?>
<div id="comment" class="bm">
  <div class="mbm cl"> 
    <em class="y f12">���� $data[commentnum] �˲���</em>
    
    <h2 class="f16 z">��Ա����</h2>
  </div>
  <div id="comment_ul"> 
    
    <!--{if !empty($pricount)}-->
    <p class="mtn mbn y">{lang hide_portal_comment}</p>
    <!--{/if}--> 
    
    <!--{if !$data[htmlmade]}-->
    
    
    
    <form id="cform" name="cform" action="$form_url" method="post" autocomplete="off">
    
    <div class="postrait"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank"><!--{avatar($_G[uid],small)}--></a></div>
    
    
    
				<div class="tedt mbm" id="tedt">
					<div class="area">
                    <b class="comment-arrow"><i></i></b>
						<textarea name="message" rows="3" class="pt" id="message" placeholder="{if !$_G['uid']}��¼����ܷ������ݼ����뻥��{else}����˵����...{/if}" onkeydown="ctrlEnter(event, 'commentsubmit_btn');"></textarea>
					</div>
				</div>
                <div class="mb15 cl">


				<!--{if $secqaacheck || $seccodecheck}-->
					<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
					<div class="mtm z"><!--{subtemplate common/seccheck}--></div>
				<!--{/if}-->
				<!--{if !empty($topicid) }-->
					<input type="hidden" name="referer" value="$topicurl#comment" />
					<input type="hidden" name="topicid" value="$topicid">
				<!--{else}-->
					<input type="hidden" name="portal_referer" value="$viewurl#comment">
					<input type="hidden" name="referer" value="$viewurl#comment" />
					<input type="hidden" name="id" value="$data[id]" />
					<input type="hidden" name="idtype" value="$data[idtype]" />
					<input type="hidden" name="aid" value="$aid">
				<!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}">
				<input type="hidden" name="replysubmit" value="true">
				<input type="hidden" name="commentsubmit" value="true" />
				<p class="pt10 cl y"><button type="submit" name="commentsubmit_btn" id="commentsubmit_btn" value="true" class="pn y"><strong>{lang comment}</strong></button></p>
                </div>
			</form>
    
    
    

   
    
        <script type="text/javascript">
    jQuery(function(){
		jQuery("#tedt .pt").focus(function(){
			  jQuery("#tedt .area").addClass("a");
		}).blur(function(){
			  jQuery("#tedt .area").removeClass("a");
		});
    });
    </script> 

    
    <!--{/if}--> 
    <ul>
    <!--{loop $commentlist $comment}--> 
    <!--{eval $ci++;}-->
    <!--{eval settype($data[commentnum], 'integer');}-->
    <!--{template portal/comment_li}--> 
    <!--{if !empty($aimgs[$comment[cid]])}--> 
    <script type="text/javascript" reload="1">aimgcount[{$comment[cid]}] = [<!--{echo implode(',', $aimgs[$comment[cid]]);}-->];attachimgshow($comment[cid]);</script> 
    <!--{/if}--> 
     <!--{eval if($ci == 6)break;}-->
    <!--{/loop}-->
    </ul>
    <!--{if $ci > 5}-->
    <p class="ptn cl" style=" text-align:center">
       <a href="$common_url" class="xi2">�鿴ȫ������>></a>
      </p>
    <!--{/if}-->  
  </div>
</div>

