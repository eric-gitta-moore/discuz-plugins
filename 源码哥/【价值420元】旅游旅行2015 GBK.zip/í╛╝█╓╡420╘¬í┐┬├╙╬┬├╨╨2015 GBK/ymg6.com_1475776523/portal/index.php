<?php echo 'Jeavidesign';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jeavi.slide.js"></script>

<div class="wp"> 
  <!--[diy=diy1]-->
  <div id="diy1" class="area"></div>
  <!--[/diy]--> 
</div>
</div>
<div class="fullSlide cl"> 
  <!--[diy=jeavi-fullSlide]-->
  <div id="jeavi-fullSlide" class="area"></div>
  <!--[/diy]--> 
  
</div>
<div class="ban-menu animated-area cl">
  <div class="wp"> 
    <!--[diy=ban-menu]-->
    <div id="ban-menu" class="area"></div>
    <!--[/diy]--> 
  </div>
</div>

<!-- ������ͼ -->
<div class="wonderful_bg cl">
  <div class="wp cl">
    <div class="index_t">
      <h3>��;����</h3>
      <p>���� ÿһ�ε����ж���һ���ɱ䣬��¼����������û��� ����</p>
    </div>
    <div class="wonderful"> 
      
      <!--[diy=wonderful-c]-->
      <div id="wonderful-c" class="area"></div>
      <!--[/diy]--> 
      
    </div>
  </div>
</div>




<div class="tranking">
  <div class="wp cl"> 
    
    <!--[diy=jeavi-tranking]-->
    <div id="jeavi-tranking" class="area"></div>
    <!--[/diy]--> 
    
  </div>
</div>

<div class="statistics">
  <div class="wp cl"> 
    
    <!--[diy=jeavi-statistics]-->
    <div id="jeavi-statistics" class="area"></div>
    <!--[/diy]--> 
  </div>
</div>
<div class="selected">
  <div class="wp cl">
    <div class="index_t">
      <h3>����������ߵ���</h3>
      <p>���� Follow your mind. Travel your life ����</p>
    </div>
    <!--[diy=selected-l]-->
    <div id="selected-l" class="area"></div>
    <!--[/diy]--> 
  </div>
</div>
<div id="maincontent">
  <div class="index_t cl">
    <h3>��;֮��</h3>
    <p>���� ̤������г̣�ֻ����;���������ķ羰 ����</p>
  </div>
  <div class="loading"></div>
  <div class="element pict">
    <div class="small-element"> 
      <!--[diy=slides1-r]-->
      <div id="slides1-r" class="area"></div>
      <!--[/diy]--> 
    </div>
  </div>
  <div class="element pict">
    <div class="small-element"> 
      <!--[diy=slides2-r]-->
      <div id="slides2-r" class="area"></div>
      <!--[/diy]--> 
    </div>
  </div>
  <div class="element pict">
    <div class="small-element"> 
      <!--[diy=slides3-r]-->
      <div id="slides3-r" class="area"></div>
      <!--[/diy]--> 
    </div>
  </div>
  <div class="element pict">
    <div class="small-element"> 
      <!--[diy=slides4-r]-->
      <div id="slides4-r" class="area"></div>
      <!--[/diy]--> 
    </div>
  </div>
  <a href="javascript:void(0)" class="element navi left"><img src="$_G['style'][styleimgdir]/img/left.png" alt="left"></a> <a href="javascript:void(0)" class="element navi right"><img src="$_G['style'][styleimgdir]/img/right.png" alt="right"></a> </div>
<div class="talk_con cl">
  <div class="talk_box"> 
    
    <!--[diy=quoteright]-->
    <div id="quoteright" class="area"></div>
    <!--[/diy]--> 
    
  </div>
</div>



<script type="text/javascript">
jQuery(".fullSlide").slide({titCell:".hd ul",  mainCell:".bd ul", effect:"fold",  autoPlay:true, mouseOverStop:false, autoPage:true });
jQuery(".wonderfula").slide({ mainCell:".bd ul", effect:"leftLoop",easing:"easeInOutQuint",delayTime:500, vis:4, scroll:1,autoPlay:true });
jQuery(".talk_box").slide({ mainCell:".bd ul", titCell:".hd ul",autoPlay:true,autoPage:true, easing:"easeInCubic"});
</script> 

<!--{template common/footer}--> 


