<?php echo 'Jeavidesign';exit;?>
<!--{if $_G['uid']}-->
<div id="um" class="user_box">
  <div class="user_name y" id="m" onMouseOver="showMenu({'ctrlid':'m','pos':'34!','ctrlclass':'hover','duration':2});"> <strong class="vwmy{if $_G['setting']['connect']['allow'] && $_G[member][conisbind]} qq{/if}"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">{$_G[member][username]}</a></strong> 
    <!--{if $_G['group']['allowinvisible']}--> 
    <em id="loginstatus" style="display:none;"> <a id="loginstatusid" href="member.php?mod=switchstatus" title="{lang login_switch_invisible_mode}" onclick="ajaxget(this.href, 'loginstatus');return false;" class="xi2"></a> </em>
    <!--{/if}--> 
  </div>
  <p class="user_info y"> 
    <!--{hook/global_usernav_extra1}--><!--{hook/global_usernav_extra2}--><!--{hook/global_usernav_extra3}--><!--{hook/global_usernav_extra4}--> 
    <a href="home.php?mod=space&do=notice" id="myprompt" class="a showmenu{if $_G[member][newprompt]} new{/if}" onmouseover="showMenu({'ctrlid':'myprompt','pos':'34!','ctrlclass':'hover','duration':2});" title="{lang remind}">
    <!--{if $_G[member][newprompt] || $_G[member][newpm]}-->
    <!--{eval settype($_G[member][newprompt], 'integer');}-->
    <!--{eval settype($_G[member][newpm], 'integer');}-->
    <!--{eval $noticenum = $_G[member][newprompt] + $_G[member][newpm];}-->
    <i class="animated bounce">$noticenum</i>
    <!--{/if}--></a><span id="myprompt_check"></span>    
    </p>
</div>

<!--{elseif !empty($_G['cookie']['loginuser'])}-->
<div id="um" class="user_box"> <a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a> <a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a> <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a> </div>
<!--{elseif !$_G[connectguest]}--> 
<div style=" display:none;"><!--{template member/login_simple}--></div>
<div class="login_info y">
<ul>
<li><a href="connect.php?mod=login&amp;op=init&amp;referer=forum.php&amp;statfrom=login" title="QQ��½" class="app_l i_qq"></a></li>
<li><a href="plugin.php?id=wechat:login" title="΢�ŵ�¼" class="app_l i_wx"></a></li>
<li><a href="javascript:;" onClick="javascript:lsSubmit();">{lang login}</a></li>
<li><a href="member.php?mod={$_G[setting][regname]}" class="signup">$_G['setting']['reglinkname']</a></li>
</ul>
</div>
<!--{else}-->
<div id="um" class="user_box">
  <div class="user_name y"> <em class="vwmy qq">{$_G[member][username]}</em> </div>
  <p class="user_info y"> 
    <!--{hook/global_usernav_extra1}--> 
    <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a> <a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}: 0</a> <em>{lang usergroup}: $_G[group][grouptitle]</em> </p>
</div>
<!--{/if}--> 

