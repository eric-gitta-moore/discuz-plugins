<?php echo 'Jeavidesign';exit;?>
<div id="user_m">
	<div class="hd">
        <a href="javascript:void(0)" class="next"><em></em><span></span></a>
		<a href="javascript:void(0)" class="prev"><em></em><span></span></a>
        <ul>
        </ul>
    </div>
    <div class="bd">
		<ul>
			<!--{loop $_G['setting']['mynavs'] $nav}-->
            <!--{eval $i++;}-->
				<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->
					<li>$nav[code]</li>
				<!--{/if}-->
			<!--{/loop}-->
		</ul>
        </div>
<div style="display:none;">
    <!--{hook/global_qmenu_top}-->
	<!--{hook/global_qmenu_bottom}-->
</div>
</div>

<!--{if $i > 6}-->
<script type="text/javascript">jQuery("#user_m").slide({ mainCell:".bd ul",titCell:".hd ul", effect:"left", delayTime:800,vis:6,scroll:6,pnLoop:false,autoPage:true,trigger:"click",easing:"easeOutCubic" });
</script>
<!--{/if}-->




