<?php echo 'Jeavidesign';exit;?>
<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
<dl class="bbda cl">
  <!--{if !$post['first']}-->
  <div class="preview_avt"> 
    <!--{if $post[author] && !$post['anonymous']}--> 
    <a href="home.php?mod=space&uid=$post[authorid]"><!--{avatar($post[authorid], small)}--></a> 
    <!--{else}--> 
    <img src="{STATICURL}image/magic/hidden.gif" alt="hidden" /> 
    <!--{/if}--> 
  </div>
  <!--{/if}-->
  
  <div class="preview_body" {if $post['first']}style="margin:0"{/if}>
  
  <!--{if empty($post['deleted'])}-->
  
  <dt> <span class="y xw0"> 
    <!--{if $allowpostreply && $post['invisible'] == 0}--> 
    <!--{if !$needhiddenreply}--> 
    <!--{if $post['first']}--> 
    <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&extra=$_GET[extra]&page=$page{if $_GET[from]}&from=$_GET[from]{/if}" onclick="changecontentdivid($_G[tid]);showWindow('reply', this.href)">{lang reply}</a> 
    <!--{else}--> 
    <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page{if $_GET[from]}&from=$_GET[from]{/if}" onclick="changecontentdivid($_G[tid]);showWindow('reply', this.href)">{lang reply}</a> 
    <!--{/if}--> 
    <!--{/if}--> 
    <!--{/if}--> 
    <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}--> 
    <a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page{if $_GET[from]}&from=$_GET[from]{/if}"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}</a><!--{/if}--> 
    <!--{/if}--> 
    
    </span> 
    
    <!--{if !$post['first']}--> 
    
    <!--{if $post['authorid'] && !$post['anonymous']}--> 
    <a href="home.php?mod=space&uid=$post[authorid]" target="_blank" class="xi2">$post[author]</a>$authorverifys 
    <!--{hook/viewthread_postheader $postcount}--> 
    <em id="author_$post[pid]"> {lang poston}</em> 
    <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}--> 
    {lang anonymous} 
    <!--{hook/viewthread_postheader $postcount}--> 
    <em id="author_$post[pid]"> {lang poston}</em> 
    <!--{elseif !$post['authorid'] && !$post['username']}--> 
    {lang guest} 
    <!--{hook/viewthread_postheader $postcount}--> 
    <em id="author_$post[pid]"> {lang poston}</em> 
    <!--{/if}--> 
    <span class="xg1 xw0">$post[dateline]</span> 
    
    <!--{/if}--> 
    
  </dt>
  <dd class="previewPost"> 
    <!--{subtemplate forum/viewthread_node_body}--> 
  </dd>
  <!--{else}-->
  <dd>{lang post_deleted}</dd>
  <!--{/if}-->
  </dvi>
  
  <!--{if $post['first'] && $_G['setting']['fastpost'] && $allowpostreply && !$_G['forum_thread']['archiveid'] && !$secqaacheck && !$seccodecheck}-->
  <div class="previewvfastpost" id="vfastpost">
    <form method="post" autocomplete="off" id="vfastpostform_{$_G['tid']}" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&fromvf=1&extra=$_G[gp_extra]&replysubmit=yes{if $_G['gp_ordertype'] != 1}&infloat=yes&handlekey=vfastpost_{$_G['tid']}{/if}{if $_G[gp_from]}&from=$_G[gp_from]{/if}" onsubmit="this.message.value = parseurl(this.message.value);changecontentdivid({$_G['tid']});ajaxpost('vfastpostform_{$_G['tid']}', 'return_reply', 'return_reply', 'onerror');return false;">
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <table cellspacing="0" cellpadding="0" id="vfastposttb">
        <tr>
          <td id="vf_l"></td>
          <td id="vf_m"><input type="text" name="message" id="vmessage_{$_G['tid']}" onKeyDown="seditor_ctlent(event, '$(\'vreplysubmit_{$_G['tid']}\').click()');"/></td>
          <td id="vf_r"></td>
          <td id="vf_b"><button type="submit" class="pn pnc" name="replysubmit" id="vreplysubmit_{$_G['tid']}" value="true" style="">post_newreply</button></td>
        </tr>
      </table>
    </form>
  </div>
  <script type="text/javascript">
				//$('note_{$tid}').focus();
				function succeedhandle_vfastpost_{$_G['tid']}(url, message, param) {
					$('vmessage_{$_G['tid']}').value = '';
					succeedhandle_fastpost(url, message, param);
					showCreditPrompt();
				}
			</script> 
  <!--{/if}-->
  
</dl>

<!--{if !empty($aimgs[$post[pid]])}--> 
<script type="text/javascript" reload="1">
	aimgcount[{$post[pid]}] = [<!--{echo dimplode($aimgs[$post[pid]]);}-->];
	attachimggroup($post['pid']);
	<!--{if empty($_G['setting']['lazyload'])}-->
		<!--{if !$post['imagelistthumb']}-->
			attachimgshow($post[pid]);
		<!--{else}-->
			attachimgshow($post[pid], 1);
		<!--{/if}-->
	<!--{/if}-->
	<!--{if $post['imagelistthumb']}-->
		attachimglstshow($post['pid'], <!--{echo intval($_G['setting']['lazyload'])}-->, 0, '{$_G[setting][showexif]}');
	<!--{/if}-->
</script> 
<!--{/if}--> 
<!--{hook/viewthread_endline $postcount}--> 


