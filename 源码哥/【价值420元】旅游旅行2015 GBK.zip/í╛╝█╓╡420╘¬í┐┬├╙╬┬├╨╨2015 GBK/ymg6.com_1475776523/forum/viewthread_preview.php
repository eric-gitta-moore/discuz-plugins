<?php echo 'Jeavidesign';exit;?>
{eval
	$specialarr = array(0 => array('thread', '{lang index_posts}'), 1 => array('poll', '{lang thread_poll}'), 2 => array('trade', '{lang thread_trade}'), 3 => array('reward', '{lang thread_reward}'), 4 => array('activity', '{lang thread_activity}'), 5 => array('debate', '{lang thread_debate}'));
	$specialtype = $specialarr[$_G['forum_thread']['special']];
	$previewspecial = $_G['forum_thread']['special'];
	$_G[home_tpl_titles][] = $navsubject;
	$_G[home_tpl_titles][] = $specialtype[1];
	$_G[home_tpl_titles][] = '{lang portal}';
}

<!--{template common/header}-->

<script type="text/javascript">var fid = parseInt('$_G[fid]'), tid = parseInt('$_G[tid]');</script>

<form method="post" autocomplete="off" name="modactions" id="modactions">
<input type="hidden" name="formhash" value="{FORMHASH}" />
<input type="hidden" name="optgroup" />
<input type="hidden" name="operation" />
<input type="hidden" name="listextra" value="$_GET[extra]" />
</form>

<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']);var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}';var aimgcount = new Array();</script>

<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
	<!--{eval $thread['id'] = 'stickthread_'.$thread['tid'];}-->
<!--{else}-->
	<!--{eval $thread['id'] = 'normalthread_'.$thread['tid'];}-->
<!--{/if}-->
<div class="fastpreview"><span class="icon_preview"></span><a class="showhide y" href="javascript:void(0);" onclick="previewThread('$thread[tid]', '$thread[id]');" title="{lang hide_preview}">{lang hide_preview}</a>
	<div>
		<div>
			<div class="bm_c">
			<!--{eval $postcount = 0;}-->
			<!--{loop $postlist $postid $post}-->
				<!--{if $postid}-->
					<!--{eval $_G[forum_thread][special] = 0;}-->
					<div id="post_$post[pid]" class="xld xlda mbm">
						<!--{subtemplate forum/viewthread_preview_node}-->
					</div>
				<!--{/if}-->
				<!--{eval $postcount++;}-->
			<!--{/loop}-->
			<div id="postlistreply_{$_G['tid']}" name="postlistreply" tid="{$_G['tid']}" class="xld xlda mbm"><div id="post_new_{$_G['tid']}" class="viewthread_table" style="display: none"></div></div>
			<!--{if $multipage}-->
			<div class="pgs cl">$multipage</div>
			<!--{/if}-->
			</div>


		</div>
	</div>
</div>



<script type="text/javascript">
var rnd='{TIMESTAMP}';{if $_G['page'] > 1}window.scrollTo('0',getElementOffset($('threadPreviewTR_{$_G['tid']}')).top);{/if}
<!--{if !IS_ROBOT && !empty($_G[setting][lazyload])}-->
new lazyload();
<!--{/if}-->
</script>

<!--{template common/footer}-->

