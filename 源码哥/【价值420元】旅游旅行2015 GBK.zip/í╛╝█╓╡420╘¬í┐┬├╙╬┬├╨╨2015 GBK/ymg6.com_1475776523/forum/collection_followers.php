<?php echo 'Jeavidesign';exit;?>
<!--{template common/header}-->
<div id="pt" class="bm cl">
	<div class="z">
		<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
		<a href="forum.php?mod=collection">{lang collection}</a> <em>&rsaquo;</em>
		<a href="forum.php?mod=collection&action=view&ctid=$ctid">{$_G['collection']['name']}</a> <em>&rsaquo;</em>
		{lang collection_followlist}
	</div>
</div>
<script type="text/javascript" src="{$_G[setting][jspath]}home_friendselector.js?{VERHASH}"></script>
<script type="text/javascript">
	var fs;
	var clearlist = 0;
</script>

<div id="ct" class="ct2 wp cl">
<div class="mn">
	<div class="bm mb0 pbn">
		<div class="bm_h cl">
			<a href="forum.php?mod=collection&action=view&ctid={$_G['collection']['ctid']}" class="y pn"><span class="cw0">&laquo; {lang collection_backcollection}</span></a>
			<h1>
				<a href="forum.php?mod=collection&action=view&ctid={$_G['collection']['ctid']}">{$_G['collection']['name']}</a>
			</h1>
		</div>
		<div class="bm_c">
        <div class="cl">
          
          <div title="$avgrate" class="ptn pbn xg1 cl"> 
            <!--{if $_G['collection']['ratenum'] > 0}--> 
            <span class="clct_ratestar"><span class="star star$star">&nbsp;</span></span> &nbsp;{lang collection_totalrates} 
            <!--{else}--> 
            {lang collection_norate} 
            <!--{/if}--> 
          </div>
        </div>
        <div class="mbn cl"> 
          <!--{if $_G['collection']['arraykeyword']}-->
          <p class="mbn"> {lang collection_keywords} 
            <!--{loop $_G['collection']['arraykeyword'] $unique_keyword}--> 
            <a href="search.php?mod={if $_G['setting']['search']['collection']['status']}collection{else}forum{/if}&srchtxt={echo rawurlencode($unique_keyword)}&formhash={FORMHASH}&searchsubmit=true&source=collectionsearch" target="_blank" class="xi2">$unique_keyword</a>&nbsp; 
            <!--{/loop}--> 
          </p>
          <!--{/if}-->
          <p> {lang collection_creator}<a href="home.php?mod=space&uid={$_G['collection']['uid']}" class="xi2" c="1">{$_G['collection']['username']}</a> 
            <!--{if $collectionteamworker}--> 
            <span class="pipe">|</span> {lang collection_teamworkers} 
            <!--{loop $collectionteamworker $collectionworker}--> 
            <span id="k_worker_uid_{$collectionworker['uid']}"> <a href="home.php?mod=space&uid={$collectionworker['uid']}" c="1" class="xi2">{$collectionworker['username']}</a>&nbsp; 
            <!--{if $permission}--> 
            <a href="forum.php?mod=collection&action=edit&op=removeworker&ctid={$_G['collection']['ctid']}&uid={$collectionworker['uid']}&formhash={FORMHASH}"  onclick="showDialog('{lang collection_delete_confirm}','confirm','','ajaxget(\''+this.href+'\',\'k_worker_uid_{$collectionworker['uid']}\')');return false;" class="xi2">[{lang delete}]</a>&nbsp; 
            <!--{/if}--> 
            </span> 
            <!--{/loop}--> 
            <!--{/if}--> 
          </p>
        </div>
        <div>{$_G['collection']['desc']}</div>
      </div>
	</div>
	
	<div class="bm">
		<div class="tb mlr cl">
			<ul>
				<li><a href="forum.php?mod=collection&action=view&op=comment&ctid={$_G['collection']['ctid']}">{lang collection_commentlist}</a></li>
				<li class="a"><a href="forum.php?mod=collection&action=view&op=followers&ctid={$_G['collection']['ctid']}">{lang collection_followlist}</a></li>
			</ul>
		</div>
		<!--{if $followers}-->
			<div class="bm_c">
				<ul class="ml mls cl">
				<!--{loop $followers $follower}-->
					<li>
						<a href="home.php?mod=space&uid=$follower[uid]" class="avt"><!--{avatar($follower[uid],small)}--></a>
						<p><a href="home.php?mod=space&uid=$follower[uid]">$follower[username]</a></p>
					</li>
				<!--{/loop}-->
				</ul>
			</div>
		<!--{else}-->
			<p class="emp">{lang no_content}</p>
		<!--{/if}-->
		<!--{if $multipage}--><div class="bm_c cl">$multipage</div><!--{/if}-->
	</div>
    </div>
    <div class="sd">
    <div class="bm bml tns">
      <table cellspacing="0" cellpadding="4">
        <tr>
          <th> <p>{$_G['collection']['threadnum']}</p>
            {lang collection_threadnum} </th>
          <th> <p>{$_G['collection']['commentnum']}</p>
            {lang collection_commentnum} </th>
          <td><p><span id="rightcolfollownum">{$_G['collection']['follownum']}</span></p>
            {lang collection_follow} </td>
        </tr>
      </table>
    </div>
    
    <!--{if $followers}-->
    <div class="bm nframe">
      <div class="bm_h"> 
        <h2>{lang collection_newfollowers}</h2>
      </div>
      <div class="bm_c">
        <ul class="ml mls cl">
          <!--{loop $followers $follower}-->
          <li> <a href="home.php?mod=space&uid=$follower[uid]" class="avt"><!--{avatar($follower[uid],small)}--></a>
            <p><a href="home.php?mod=space&uid=$follower[uid]" c="1">$follower[username]</a></p>
          </li>
          <!--{/loop}-->
        </ul>
      </div>
    </div>
    <!--{/if}--> 
    
    <!--{if $userCollections}-->
    <div class="bm nframe">
      <div class="bm_h">
        <h2>{lang collection_creators}</h2>
      </div>
      <div class="bm_c"> 
        <!--{loop $userCollections $ucollection}-->
        <div class="pbn"> <a href="forum.php?mod=collection&action=view&ctid={$ucollection['ctid']}" class="xi2 xw1">$ucollection[name]</a> </div>
        <div class="pbm"> {lang collection_threadnum} $ucollection[threadnum], {lang collection_follow} $ucollection[follownum], {lang collection_commentnum} $ucollection[commentnum] </div>
        <!--{/loop}--> 
      </div>
    </div>
    <!--{/if}--> 
    <!--{hook/collection_side_bottom}--> 
  </div>
    
</div>
<!--{template common/footer}-->
