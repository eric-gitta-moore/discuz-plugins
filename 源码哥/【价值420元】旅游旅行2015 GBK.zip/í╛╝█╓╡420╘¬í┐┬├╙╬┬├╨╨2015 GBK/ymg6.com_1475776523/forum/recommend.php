<?php echo 'Jeavidesign';exit;?>
<!--{if $_G['forum']['recommendlist']['images'] && $_G['forum']['modrecommend']['imagenum']}-->
<div class="nframe cl">
  <div class="bm_h cl">
    <h2 class="xb2">�Ƽ�ͼ��</h2>
  </div>
  <ul class="coverlist cl">
    <!--{loop $_G['forum']['recommendlist']['images'] $k $imginfo}-->
    <li>
      <div class="m"><a href="forum.php?mod=viewthread&tid=$imginfo[tid]" title="$imginfo[subject]" target="_blank"><img src="$imginfo[filename]" alt="$imginfo[subject]" width="100" height="65"></a></div>
      <h2><a href="forum.php?mod=viewthread&tid=$imginfo[tid]" title="$imginfo[subject]" target="_blank"><!--{echo cutstr($imginfo[subject], 30)}--></a></h2>
      <p><a href="home.php?mod=space&uid=$imginfo[authorid]" class="f12 xb4">$imginfo[author]</a></p>
    </li>
    <!--{/loop}-->
  </ul>
</div>
<!--{/if}-->
<div class="nframe mbl">
  <div class="bm_h cl">
    <h2 class="xb2">{lang forum_recommend}</h2>
  </div>
  <!--{eval unset($_G['forum']['recommendlist']['images']);}-->
  <ul class="nlist">
    <!--{loop $_G['forum']['recommendlist'] $rtid $recommend}-->
    <li><em class="y f12 xb4 mln"><a href="home.php?mod=space&uid=$recommend[authorid]">$recommend[author]</a></em><a href="forum.php?mod=viewthread&tid=$rtid" $recommend[subjectstyles] target="_blank">$recommend[subject]</a></li>
    <!--{/loop}-->
  </ul>
</div>

