<?php echo 'Jeavidesign';exit;?>
<div class="bm mbl nframe">
  <div class="bm_h">
    <h2>{lang forum_subforums}</h2>
  </div>
  <div class="subforum">
    <ul class="xl xl2 cl">
      <!--{loop $sublist $sub}--> 
      <!--{eval $forumurl = !empty($sub['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$sub['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$sub['fid'];}-->
      <li> 
        <!--{if $sub[icon]}--> 
        $sub[icon] 
        <!--{else}--> 
        <a href="$forumurl"{if $sub[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $sub[folder]}_new{/if}.gif" alt="$sub[name]" /></a> 
        <!--{/if}--> 
        <a href="$forumurl" {if !empty($sub[redirect])}target="_blank"{/if} style="{if !empty($sub[extra][namecolor])}color: {$sub[extra][namecolor]};{/if}">$sub[name]</a><!--{if $sub[todayposts] && !$sub['redirect']}--><span class="xw0 xi1" title="{lang forum_todayposts}"> ($sub[todayposts])</span><!--{/if}--> 
      </li>
      <!--{/loop}-->
    </ul>
  </div>
</div>



