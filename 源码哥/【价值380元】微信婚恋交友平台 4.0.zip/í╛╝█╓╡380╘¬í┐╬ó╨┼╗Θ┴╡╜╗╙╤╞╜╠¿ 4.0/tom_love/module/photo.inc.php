<?php
/*
 * CopyRight  : [fx8.cc!] (C)2014-2016
 * Document   : Դ��磺www.fx8.cc��www.ymg6.com
 * Created on : 2015-10-14,08:44:22
 * Author     : Դ���(QQ��154606914) wWw.fx8.cc $
 * Description: This is NOT a freeware, use is subject to license terms.
 *              Դ����Ʒ ������Ʒ��
 *              Դ�������� ȫ���׷� http://www.fx8.cc��
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$act = isset($_GET['act'])? trim($_GET['act']):'';

if($act == 'del' && $_GET['formhash'] == FORMHASH){
    $picid = intval($_GET['picid']);
    C::t('#tom_love#tom_love_pic')->delete($picid);
    
    $pic_num = C::t('#tom_love#tom_love_pic')->fetch_all_count(" AND user_id ={$__UserInfo['id']} ");
    $updateData = array();
    $updateData['pic_num'] = $pic_num;
    C::t('#tom_love#tom_love')->update($__UserInfo['id'],$updateData);
}

$picList = C::t('#tom_love#tom_love_pic')->fetch_all_list(" AND user_id ={$__UserInfo['id']} ","ORDER BY id DESC",0,100);

$delUrl = "plugin.php?id=tom_love&mod=photo&act=del&formhash=".FORMHASH."&picid=";

$uploadUrl = "plugin.php?id=tom_love&mod=upload&act=photo&formhash=".FORMHASH;

$allow_upload_num = $jyConfig['pic_num'] - $__UserInfo['pic_num'];
if($allow_upload_num < 1){
    $allow_upload_num = 0;
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_love:photo");
?>
