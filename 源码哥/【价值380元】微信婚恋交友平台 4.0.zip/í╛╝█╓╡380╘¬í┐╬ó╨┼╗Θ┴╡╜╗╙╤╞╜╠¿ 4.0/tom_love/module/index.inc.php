<?php
/*
 * CopyRight  : [fx8.cc!] (C)2014-2016
 * Document   : Դ��磺www.fx8.cc��www.ymg6.com
 * Created on : 2015-10-14,08:44:22
 * Author     : Դ���(QQ��154606914) wWw.fx8.cc $
 * Description: This is NOT a freeware, use is subject to license terms.
 *              Դ����Ʒ ������Ʒ��
 *              Դ�������� ȫ���׷� http://www.fx8.cc��
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page     = isset($_GET['page'])? intval($_GET['page']):1;

$pagesize = 8;
$start = ($page-1)*$pagesize;

if($jyConfig['must_info'] == 1){
    $where = " AND recommend = 1 AND status = 1 AND year>0 ";
}else{
    $where = " AND recommend = 1 AND status = 1 ";
}

$userData = C::t('#tom_love#tom_love')->fetch_all_list($where,"ORDER BY add_time DESC",$start,$pagesize);
$userDataCount = C::t('#tom_love#tom_love')->fetch_all_count($where);

$userList = array();
if(is_array($userData) && !empty($userData)){
    foreach ($userData as $key => $value){
        $userList[$key] = $value;
        $userList[$key]['describe'] = dhtmlspecialchars($value['describe']);
        if($jyConfig['age_type_id'] == 1){
            $userList[$key]['age'] = $nowYear - $value['year'];
        }else{
            $userList[$key]['age'] = $nowYear - $value['year'] + 1;
        }
        
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $userDataCount){
    $showNextPage = 0;
}

$allPageNum = ceil($userDataCount/$pagesize);

$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_love&mod=index&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_love&mod=index&page={$nextPage}";
$infoUrl = "plugin.php?id=tom_love&mod=info&uid=";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_love:index");
?>
