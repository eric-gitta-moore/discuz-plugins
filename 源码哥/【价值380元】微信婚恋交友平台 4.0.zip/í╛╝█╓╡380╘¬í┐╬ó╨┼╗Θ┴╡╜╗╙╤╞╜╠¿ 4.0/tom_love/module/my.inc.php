<?php
/**
 * 
 * Դ������ѣ�Ϊ��֤Դ�����Դ�ĸ���ά�����ϣ���ֹԴ����׷���Դ�����ⷺ�ģ�
 *             ϣ����������Դ�����Դ�Ļ�Ա��Ҫ�����Դ����׷���Դ�ṩ��������;
 *             �类���֣���ȡ��Դ���VIP��Ա�ʸ�ֹͣһ�к��ڸ���֧���Լ����в���BUG����������
 *          
 * Դ����Ʒ ������Ʒ
 * Դ�������� ȫ���׷� http://Www.fx8.cc
 * ������www.ymg6.com (���ղر���!)
 * ����֧��/����ά����QQ 154606914
 * лл֧�֣���л���Դ�������ɵĹ�ע������������   
 * 
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$act = isset($_GET['act'])? trim($_GET['act']):'';

if($jyConfig['age_type_id'] == 1){
    $age = $nowYear - $__UserInfo['year'];
}else{
    $age = $nowYear - $__UserInfo['year'] + 1;
}

$infoBox = 0;
$myBox = 0;
if($act == 'info'){
    $infoBox = 1;
    
    $provinceList = C::t('#tom_love#tom_common_district')->fetch_all_by_level(1);
    $cityList = C::t('#tom_love#tom_common_district')->fetch_all_by_upid($__UserInfo['province_id']);
    $areaList = C::t('#tom_love#tom_common_district')->fetch_all_by_upid($__UserInfo['city_id']);
    $yearArray = array();
    $startYear = $nowYear - 60;
    $endYear = $nowYear - 15;
    for($i=$startYear;$i<=$endYear;$i++){
        $yearArray[] = $i;
    }
    
}else if($act == 'saveInfo' && $_GET['formhash'] == FORMHASH){
    
    $friend = isset($_GET['friend'])? intval($_GET['friend']):0;
    $marriage = isset($_GET['marriage'])? intval($_GET['marriage']):0;
    $nickname = isset($_GET['nickname'])? daddslashes(diconv(urldecode($_GET['nickname']),'utf-8')):'';
    $sex = isset($_GET['sex'])? intval($_GET['sex']):0;
    $year = isset($_GET['year'])? intval($_GET['year']):0;
    $country = isset($_GET['country'])? intval($_GET['country']):0;
    $province = isset($_GET['province'])? intval($_GET['province']):0;
    $city = isset($_GET['city'])? intval($_GET['city']):0;
    $area = isset($_GET['area'])? intval($_GET['area']):0;
    $job = isset($_GET['job'])? intval($_GET['job']):0;
    $height = isset($_GET['height'])? intval($_GET['height']):0;
    $weight = isset($_GET['weight'])? intval($_GET['weight']):0;
    $edu = isset($_GET['edu'])? intval($_GET['edu']):0;
    $pay = isset($_GET['pay'])? intval($_GET['pay']):0;
    $marital = isset($_GET['marital'])? intval($_GET['marital']):0;
    $wx = isset($_GET['wx'])? daddslashes(diconv(urldecode($_GET['wx']),'utf-8')):0;
    $qq = isset($_GET['qq'])? daddslashes($_GET['qq']):0;
    $tel = isset($_GET['tel'])? daddslashes($_GET['tel']):'';
    $describe = isset($_GET['describe'])? daddslashes(diconv(urldecode($_GET['describe']),'utf-8')):'';
    
    if(C::t('#tom_love#tom_love')->check_nickname($__UserInfo['id'],$nickname)){
        echo '201';exit;
    }
    
    $provinceStr = "";
    $cityStr = "";
    $areaStr = "";
    $provinceInfo = C::t('#tom_love#tom_common_district')->fetch_by_id($province);
    $cityInfo = C::t('#tom_love#tom_common_district')->fetch_by_id($city);
    $areaInfo = C::t('#tom_love#tom_common_district')->fetch_by_id($area);
    if($provinceInfo){
        $provinceStr = $provinceInfo['name'];
    }
    if($cityInfo){
        $cityStr = $cityInfo['name'];
    }
    if($areaInfo){
        $areaStr = $areaInfo['name'];
    }
    
    $updateData = array();
    $updateData['friend'] = $friend;
    $updateData['marriage'] = $marriage;
    $updateData['nickname'] = $nickname;
    $updateData['sex'] = $sex;
    $updateData['year'] = $year;
    $updateData['country_id'] = $country;
    $updateData['province_id'] = $province;
    $updateData['city_id'] = $city;
    $updateData['area_id'] = $area;
    $updateData['work_id'] = $job;
    $updateData['height'] = $height;
    $updateData['weight'] = $weight;
    $updateData['edu_id'] = $edu;
    $updateData['pay_id'] = $pay;
    $updateData['marital_id'] = $marital;
    $updateData['describe'] = $describe;
    $updateData['wx'] = $wx;
    $updateData['qq'] = $qq;
    $updateData['tel'] = $tel;
    $updateData['area'] = $provinceStr." ".$cityStr." ".$areaStr;
    C::t('#tom_love#tom_love')->update($__UserInfo['id'],$updateData);
    echo '1';exit;
}else if($act == 'close' && $_GET['formhash'] == FORMHASH){
    $close = isset($_GET['close'])? intval($_GET['close']):0;
    $updateData = array();
    $updateData['closed'] = $close;
    C::t('#tom_love#tom_love')->update($__UserInfo['id'],$updateData);
    echo '1';exit;
}else if($act == 'rec' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 200,
    );
    if(!empty($jyConfig['rec_score']) && $jyConfig['rec_score'] > $__UserInfo['score']){
        $outArr['status'] = 101;
        echo json_encode($outArr); exit;
    }
    $insertData = array();
    $insertData['user_id'] = $__UserInfo['id'];
    $insertData['rec_status'] = 1;
    $insertData['rec_time'] = TIMESTAMP;
    C::t('#tom_love#tom_love_rec')->insert($insertData);
    
    $updateData = array();
    $updateData['score'] = $__UserInfo['score']-$jyConfig['rec_score'];
    C::t('#tom_love#tom_love')->update($__UserInfo['id'],$updateData);
    
    echo json_encode($outArr); exit;
}else{
    $myBox = 1;
    
    $recStatus = 0;
    $recInfo = C::t('#tom_love#tom_love_rec')->fetch_by_uid($__UserInfo['id']);
    if($__UserInfo['recommend'] == 1){
        $recStatus = 1;
    }else if($recInfo && $recInfo['rec_status'] == 1 && $__UserInfo['recommend'] == 0){
        $recStatus = 2;
    }
    
    $renzhengStatus = 0;
    $renzhengInfo = C::t('#tom_love#tom_love_renzheng')->fetch_by_uid($__UserInfo['id']);
    if($__UserInfo['renzheng'] == 1){
        $renzhengStatus = 1;
    }else if($renzhengInfo && $renzhengInfo['renzheng_status'] == 1 && $__UserInfo['renzheng'] == 0){
        $renzhengStatus = 2;
    }
    
    $meanlianCount = C::t('#tom_love#tom_love_guanxi')->fetch_all_count(" AND type_id=2 AND user_id={$__UserInfo['id']} ");
    $anlianmeCount = C::t('#tom_love#tom_love_guanxi')->fetch_all_count(" AND type_id=2 AND gx_user_id={$__UserInfo['id']} ");
    
}

$recUrl = "plugin.php?id=tom_love&mod=my&uid={$__UserInfo['id']}&act=rec&formhash=".FORMHASH;
$closeUrl = "plugin.php?id=tom_love&mod=my&uid={$__UserInfo['id']}&act=close&formhash=".FORMHASH;
$saveUrl = "plugin.php?id=tom_love&mod=my";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_love:my");
?>
