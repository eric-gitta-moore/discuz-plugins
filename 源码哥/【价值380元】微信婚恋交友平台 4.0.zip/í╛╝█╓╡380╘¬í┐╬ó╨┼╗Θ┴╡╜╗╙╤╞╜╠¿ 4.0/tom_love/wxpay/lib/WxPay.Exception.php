<?php
/**
 * 
 * 源码哥提醒：为保证源码哥资源的更新维护保障，防止源码哥首发资源被恶意泛滥，
 *             希望所有下载源码哥资源的会员不要随意把源码哥首发资源提供给其他人;
 *             如被发现，将取消源码哥VIP会员资格，停止一切后期更新支持以及所有补丁BUG等修正服务；
 *          
 * 源码哥出品 必属精品
 * 源码哥源码论坛 全网首发 http://Www.fx8.cc
 * 官网：www.ymg6.com (请收藏备用!)
 * 技术支持/更新维护：QQ 154606914
 * 谢谢支持，感谢你对草根吧分享吧的关注和信赖！！！   
 * 
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/**
 * 
 * 微信支付API异常类
 * @author widyhu
 *
 */
class WxPayException extends Exception {
	public function errorMessage()
	{
		return $this->getMessage();
	}
}
