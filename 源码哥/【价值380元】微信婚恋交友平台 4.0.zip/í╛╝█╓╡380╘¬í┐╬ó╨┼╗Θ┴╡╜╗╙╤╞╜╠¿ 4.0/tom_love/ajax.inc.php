<?php
/*
 * CopyRight  : [fx8.cc!] (C)2014-2016
 * Document   : Դ��磺www.fx8.cc��www.ymg6.com
 * Created on : 2015-10-14,08:44:22
 * Author     : Դ���(QQ��154606914) wWw.fx8.cc $
 * Description: This is NOT a freeware, use is subject to license terms.
 *              Դ����Ʒ ������Ʒ��
 *              Դ�������� ȫ���׷� http://www.fx8.cc��
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loaducenter();
$jyConfig = $_G['cache']['plugin']['tom_love'];
$pluginScriptLang = $scriptlang['tom_love'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

if($_GET['act'] == 'pic'){
    $callback = $_GET['callback'];
    $uid = isset($_GET['uid'])? intval($_GET['uid']):0;
    $outArr = array();
    $picList = C::t('#tom_love#tom_love_pic')->fetch_all_list(" AND user_id ={$uid} ","ORDER BY id DESC",0,100);
    $i = 1;
    if(is_array($picList) && !empty($picList)){
        foreach ($picList as $key => $value) {
            $outArr[$i] = $value['pic_url'];
            $i++;
        }
    }
    $outStr = '';
    $outStr = json_encode($outArr);
    if($callback){
        $outStr = $callback . "(" . $outStr. ")";
    }
    echo $outStr;
    die();
}else if($_GET['act'] == 'city'){
    $callback = $_GET['callback'];
    $pid = isset($_GET['pid'])? intval($_GET['pid']):0;
    $outArr = array();
    $cityList = C::t('#tom_love#tom_common_district')->fetch_all_by_upid($pid);
    if(is_array($cityList) && !empty($cityList)){
        foreach ($cityList as $key => $value) {
            $outArr[$key]['id'] = $value['id'];
            $outArr[$key]['name'] = diconv($value['name'],CHARSET,'utf-8');
        }
    }
    $outStr = '';
    $outStr = json_encode($outArr);
    if($callback){
        $outStr = $callback . "(" . $outStr. ")";
    }
    echo $outStr;
    die();
}else if($_GET['act'] == 'area'){
    $callback = $_GET['callback'];
    $pid = isset($_GET['pid'])? intval($_GET['pid']):0;
    $outArr = array();
    $areaList = C::t('#tom_love#tom_common_district')->fetch_all_by_upid($pid);
    if(is_array($areaList) && !empty($areaList)){
        foreach ($areaList as $key => $value) {
            $outArr[$key]['id'] = $value['id'];
            $outArr[$key]['name'] = diconv($value['name'],CHARSET,'utf-8');
        }
    }
    $outStr = '';
    $outStr = json_encode($outArr);
    if($callback){
        $outStr = $callback . "(" . $outStr. ")";
    }
    echo $outStr;
    die();
    
}else if($_GET['act'] == 'contact' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 200,
    );
    
    $uid = isset($_GET['uid'])? intval($_GET['uid']):0;
    $gid = isset($_GET['gid'])? intval($_GET['gid']):0;
    
    $__UserInfo = C::t('#tom_love#tom_love')->fetch_by_id($uid);
    
    if(!empty($jyConfig['contact_score']) && $jyConfig['contact_score'] > $__UserInfo['score']){
        $outArr['status'] = 101;
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['user_id'] = $uid;
    $insertData['gx_user_id'] = $gid;
    $insertData['type_id'] = 1;
    C::t('#tom_love#tom_love_guanxi')->insert($insertData);
    
    $updateData = array();
    $updateData['score'] = $__UserInfo['score']-$jyConfig['contact_score'];
    C::t('#tom_love#tom_love')->update($uid,$updateData);
    
    echo json_encode($outArr); exit;
    
}else if($_GET['act'] == 'anlian' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 200,
    );
    
    $uid = isset($_GET['uid'])? intval($_GET['uid']):0;
    $gid = isset($_GET['gid'])? intval($_GET['gid']):0;
    
    $__UserInfo = C::t('#tom_love#tom_love')->fetch_by_id($uid);
    
    if(!empty($jyConfig['anlian_score']) && $jyConfig['anlian_score'] > $__UserInfo['score']){
        $outArr['status'] = 101;
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['user_id'] = $uid;
    $insertData['gx_user_id'] = $gid;
    $insertData['type_id'] = 2;
    C::t('#tom_love#tom_love_guanxi')->insert($insertData);
    
    DB::query("UPDATE ".DB::table('tom_love')." SET anlians=anlians+1 WHERE id='$gid'", 'UNBUFFERED');
    
    $updateData = array();
    $updateData['score'] = $__UserInfo['score']-$jyConfig['anlian_score'];
    C::t('#tom_love#tom_love')->update($uid,$updateData);
    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'hello' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 200,
    );
    
    $uid = isset($_GET['uid'])? intval($_GET['uid']):0;
    $tid = isset($_GET['tid'])? intval($_GET['tid']):0;
    
    $__UserInfo = C::t('#tom_love#tom_love')->fetch_by_id($uid);
    $toUser = C::t('#tom_love#tom_love')->fetch_by_id($tid);
    
    if(!empty($jyConfig['hello_score']) && $jyConfig['hello_score'] > $__UserInfo['score']){
        $outArr['status'] = 101;
        echo json_encode($outArr); exit;
    }
    
    if(!empty($__UserInfo['bbs_uid']) && !empty($toUser['bbs_uid'])){
        $helloTmpArr = explode("\n", $jyConfig['hello_txt']);
        $helloArr = array();
        if(is_array($helloTmpArr) && !empty($helloTmpArr)){
            foreach ($helloTmpArr as $key => $value){
                $value = trim($value);
                if(!empty($value)){
                    $helloArr[] = $value;
                }
            }
        }
        
        $randKey = array_rand($helloArr, 1);
        $sms_object = lang('plugin/tom_love','sms_object');
        
        sendpm($toUser['bbs_uid'], $sms_object, $helloArr[$randKey], $__UserInfo['bbs_uid']);
        
        $updateData = array();
        $updateData['score'] = $__UserInfo['score']-$jyConfig['hello_score'];
        C::t('#tom_love#tom_love')->update($uid,$updateData);
    }
    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'delanlian' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 200,
    );
    $id = isset($_GET['aid'])? intval($_GET['aid']):0;
    
    $guanxi = C::t('#tom_love#tom_love_guanxi')->fetch_by_id($id);
    if($guanxi){
       DB::query("UPDATE ".DB::table('tom_love')." SET anlians=anlians-1 WHERE id='{$guanxi['gx_user_id']}'", 'UNBUFFERED'); 
    }
    C::t('#tom_love#tom_love_guanxi')->delete($id);
    
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'share' && $_GET['formhash'] == FORMHASH){
    
    if($jyConfig['share_score_s'] == 0){
        echo '1';exit;
    }
    
    $uid = isset($_GET['uid'])? intval($_GET['uid']):0;
    
    $__UserInfo = C::t('#tom_love#tom_love')->fetch_by_id($uid);
    
    $todayShareTimes = C::t('#tom_love#tom_love_share')->fetch_all_count(" AND user_id = {$uid}  AND share_time > {$nowTime} ");
    if($__UserInfo && $todayShareTimes < $jyConfig['share_time']){
        
        $updateData = array();
        $updateData['score'] = $__UserInfo['score'] + $jyConfig['share_score_num'];
        C::t('#tom_love#tom_love')->update($__UserInfo['id'],$updateData);
        
        $insertData = array();
        $insertData['user_id'] = $uid;
        $insertData['share_time'] = TIMESTAMP;
        C::t('#tom_love#tom_love_share')->insert($insertData);
    }
    
    echo '1';exit;
}

?>
