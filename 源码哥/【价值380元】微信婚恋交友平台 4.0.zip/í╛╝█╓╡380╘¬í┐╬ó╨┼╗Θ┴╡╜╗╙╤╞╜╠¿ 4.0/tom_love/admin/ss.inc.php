<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=ss'; 
$modListUrl = $adminListUrl.'&tmod=ss';
$modFromUrl = $adminFromUrl.'&tmod=ss';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
if($formhash == FORMHASH && $act == 'del'){
    C::t('#tom_love#tom_love_shuoshuo')->delete($_GET['id']);
    cpmsg($pluginScriptLang['act_success'], $modListUrl, 'succeed');
}else{
    $pagesize = 10;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_love#tom_love_shuoshuo')->fetch_all_count("");
    $gbList = C::t('#tom_love#tom_love_shuoshuo')->fetch_all_list("","ORDER BY ss_time DESC",$start,$pagesize);
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' . $pluginScriptLang['gaibai_list'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $pluginScriptLang['nickname'] . '</th>';
    echo '<th>' . $pluginScriptLang['ss_content'] . '</th>';
    echo '<th>' . $pluginScriptLang['ss_time'] . '</th>';
    echo '<th>' . $pluginScriptLang['handle'] . '</th>';
    echo '</tr>';
    foreach ($gbList as $key => $value){
        $ssTime = dgmdate($value['ss_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $__UserInfo = C::t('#tom_love#tom_love')->fetch_by_id($value['user_id']);
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a target="_blank" href="'.$adminBaseUrl.'&tmod=user&act=show&id='.$value['user_id'].'&formhash='.FORMHASH.'">' . $__UserInfo['nickname'] . '</a></td>';
        echo '<td>' . $value['content'] . '</td>';
        echo '<td>' . $ssTime . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'">' . $pluginScriptLang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter();
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
}
//From:www_FX8_co
?>
