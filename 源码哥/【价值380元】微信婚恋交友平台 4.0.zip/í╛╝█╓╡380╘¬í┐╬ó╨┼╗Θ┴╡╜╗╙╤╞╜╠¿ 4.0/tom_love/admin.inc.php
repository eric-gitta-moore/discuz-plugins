<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$pluginScriptLang = $scriptlang['tom_love'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowYear = dgmdate($_G['timestamp'], 'Y',$tomSysOffset);
$pluginVarList = C::t('common_pluginvar')->fetch_all_by_pluginid($pluginid);
$jyConfig = array();
foreach ($pluginVarList as $vark => $varv){
    $jyConfig[$varv['variable']] = $varv['value'];
}

$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_love&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_love&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_love&pmod=admin';

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_love/config/works.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_love/config/works.utf.php';
}

include DISCUZ_ROOT.'./source/plugin/tom_love/tom.func.php';
if($_GET['tmod'] == 'user'){
    include DISCUZ_ROOT.'./source/plugin/tom_love/admin/user.inc.php';
    
}else if($_GET['tmod'] == 'rec'){
    include DISCUZ_ROOT.'./source/plugin/tom_love/admin/rec.inc.php';
    
}else if($_GET['tmod'] == 'rz'){
    include DISCUZ_ROOT.'./source/plugin/tom_love/admin/rz.inc.php';
    
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_love/admin/addon.inc.php';
    
}else if($_GET['tmod'] == 'ss'){
    include DISCUZ_ROOT.'./source/plugin/tom_love/admin/ss.inc.php';
    
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_love/admin/user.inc.php';
}
//From:www_FX8_co
?>
