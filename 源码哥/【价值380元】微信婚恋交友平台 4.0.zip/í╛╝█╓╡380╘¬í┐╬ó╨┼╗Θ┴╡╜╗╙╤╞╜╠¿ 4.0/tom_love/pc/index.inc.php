<?php
/*
 * CopyRight  : [fx8.cc!] (C)2014-2016
 * Document   : Դ��磺www.fx8.cc��www.ymg6.com
 * Created on : 2015-10-14,08:44:22
 * Author     : Դ���(QQ��154606914) wWw.fx8.cc $
 * Description: This is NOT a freeware, use is subject to license terms.
 *              Դ����Ʒ ������Ʒ��
 *              Դ�������� ȫ���׷� http://www.fx8.cc��
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$_G['setting']['switchwidthauto']=0;
$_G['setting']['allowwidthauto']=1;


$page     = isset($_GET['page'])? intval($_GET['page']):1;
$recid     = isset($_GET['recid'])? intval($_GET['recid']):0;

$pagesize = 15;
$start = ($page-1)*$pagesize;

$where = " AND status = 1 AND avatar !='' AND avatar != 'source/plugin/tom_weixin_jy/images/avatar_default.jpg' AND nickname !='' ";

if($recid == 1){
    $where.= " AND recommend = 1 ";
}

if($jyConfig['must_info'] == 1){
    $where.=" AND year>0 ";
}

$userData = C::t('#tom_love#tom_love')->fetch_all_list($where,"ORDER BY add_time DESC",$start,$pagesize);
$userDataCount = C::t('#tom_love#tom_love')->fetch_all_count($where);

$userList = array();
if(is_array($userData) && !empty($userData)){
    foreach ($userData as $key => $value){
        $userList[$key] = $value;
        $userList[$key]['describe'] = dhtmlspecialchars($value['describe']);
        if($jyConfig['age_type_id'] == 1){
            $userList[$key]['age'] = $nowYear - $value['year'];
        }else{
            $userList[$key]['age'] = $nowYear - $value['year'] + 1;
        }
        $userList[$key]['time'] = dgmdate($value['add_time'], 'Y-m-d',$tomSysOffset);
        $userList[$key]['first_pic'] = $value['avatar'];
    }
}

$paging = helper_page :: multi($userDataCount, $pagesize, $page, "plugin.php?id=tom_love:pc&mod=index&recid={$recid}", 0, 11, false, false);

$navtitle = $jyConfig['seo_title'];
$metakeywords =  $jyConfig['seo_keywords'];
$metadescription = $jyConfig['seo_description'];

include template("tom_love:pc/index");
?>
