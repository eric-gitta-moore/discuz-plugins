jq(function() {
	jq(".searchBt").toggle(
	  function () {
		  jq(".searchInput").slideDown("fast");
		jq(this).addClass("searchOn");
                    jq('body').one('click', function() {    //��BODY��һ���Ե���¼�   
		        if(jq(".searchBt").hasClass("searchOn"))jq(".searchBt").trigger("click");
                    });
	  },
	  function () {
		 jq(".searchInput").slideUp("fast");
		jq(this).removeClass("searchOn");
	  }
	);
        jq(".searchInput input").click(function() {     //�����ʾ���ֲ�����   
                return false;   
       });
});
