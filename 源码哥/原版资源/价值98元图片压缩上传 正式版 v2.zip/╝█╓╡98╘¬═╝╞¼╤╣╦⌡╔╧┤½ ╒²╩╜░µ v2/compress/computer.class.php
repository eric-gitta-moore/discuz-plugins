<?php 
// +----------------------------------------------------------------------
// | Copyright:    (c) 2014-2015 http://www.fx8.cc All rights reserved.
// +----------------------------------------------------------------------
// | Developer:    源码哥分享吧 (www.ymg6.com 请收藏备用!)
// +----------------------------------------------------------------------
// | Author:       by 源码哥. 技术支持/更新维护：QQ 154606914
// +----------------------------------------------------------------------
// | Action:       嵌入点
// +----------------------------------------------------------------------

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_compress {
	
	function global_footer() {
		global $_G;
		$setup = $_G['cache']['plugin']['compress'];
		if(!$setup){
		    loadcache('plugin');
			$setup = $_G['cache']['plugin']['compress'];
		}
		$setup['width'] = $setup['width'] ? $setup['width'] : 1024 ;
		$setup['height'] = $setup['height'] ? $setup['height'] : 768 ;
		$setup['quality'] = $setup['quality'] ? $setup['quality'] : 80 ;
		
		$return = '<script>
if (SWFUpload != undefined) {
	var SWFobj = SWFUpload;
    var NEWobj = SWFobj.instances;
	var movie = new Array();
	for (var key in NEWobj) {
		movie[key] = NEWobj[key];
	}
    for (var key in movie) {
	    try {	
            uploadType = movie[key].customSettings.uploadType;
            if (uploadType == "album" || uploadType == "image" || uploadType == "portal") {
                Configure = movie[key].settings;
                obj = document.getElementById(key);
                newSpan = document.createElement("span");
                newSpan.id = Configure.button_placeholder_id;
                obj.parentNode.appendChild(newSpan);
                movie[key].destroy();
             
                var SosvUpload = new SWFobj({
                    upload_url: Configure.upload_url,
                    post_params: Configure.post_params,
                    file_size_limit: Configure.file_size_limit,
                    file_types: Configure.file_types,
                    file_types_description: Configure.file_types_description,
                    file_upload_limit: Configure.file_upload_limit,
                    file_queue_limit: Configure.file_queue_limit,
                    swfupload_preload_handler: preLoad,
                    swfupload_load_failed_handler: loadFailed,
                    file_dialog_start_handler: fileDialogStart,
                    file_queued_handler: fileQueued,
                    file_queue_error_handler: fileQueueError,
                    file_dialog_complete_handler: fileDialogComplete,
                    upload_start_handler: uploadStart,
                    upload_progress_handler: uploadProgress,
                    upload_error_handler: uploadError,
                    upload_success_handler: uploadSuccess,
                    upload_complete_handler: uploadComplete,
                    button_image_url: Configure.button_image_url,
                    button_placeholder_id: Configure.button_placeholder_id,
                    button_width: Configure.button_width,
                    button_height: Configure.button_height,
                    button_cursor: Configure.button_cursor,
                    button_window_mode: Configure.button_window_mode,
                    flash_url: "source/plugin/compress/static/images/swfupload.swf",
                    flash9_url: "source/plugin/compress/static/images/swfupload.swf",
                    custom_settings: Configure.custom_settings,
                    debug: false
                });
                
                SWFobj.prototype.startUpload = function(fileID) {
					Type = this.customSettings.uploadType;
					if (Type == "album" || Type == "image" || Type == "portal") {
					    this.startResizedUpload(this.getFile(0).ID, '.$setup['width'].', '.$setup['height'].', SWFobj.RESIZE_ENCODING.JPEG, '.$setup['quality'].', false);
					}else{
						this.callFlash("StartUpload", [fileID]);
					}
                };

                IsReady = document.createElement("span");
                IsReady.innerHTML = "'.lang('plugin/compress','IsReady').'";
                SosvUpload.customSettings.imgBoxObj.appendChild(IsReady);
            }
        } catch (ex) {
		    IsReady = document.createElement("span");
            IsReady.innerHTML = "'.lang('plugin/compress','does_not').'";
            movie[key].customSettings.imgBoxObj.appendChild(IsReady);
	    }	
    }
}
</script>';
		
		return $return;
	}

//From:www_FX8_co
}