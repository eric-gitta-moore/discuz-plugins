<?php
error_reporting(0);
define('VERSION','1.83');
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
class plugin_niuc_runcode{
	function __construct(){
		$this->codewidth = $_G['cache']['plugin']['niuc_runcode']['codewidth'] > 0 ? $_G['cache']['plugin']['niuc_runcode']['codewidth'] : 600;
		$this->codeheight = $_G['cache']['plugin']['niuc_runcode']['codeheight'] > 0 ? $_G['cache']['plugin']['niuc_runcode']['codeheight'] : 500;
	}
	function _permission(){
		global $_G;
		$usergroups = (array)unserialize($_G['cache']['plugin']['niuc_runcode']['usergroups']);
		$forums  = (array)unserialize($_G['cache']['plugin']['niuc_runcode']['forums']);
		if(in_array('', $usergroups))
			$usergroups = array();
		if((in_array($_G['groupid'],$usergroups) and in_array($_G['fid'],$forums)))
			return TRUE;
		else
			return FALSE;
	}
	function code_to_pre($brush, $code, $type = 0) {
		global $_G, $post;
		$code = str_replace(array('<br />', '<br>', '<BR>'), '', $code);
		if($type == 0){
			$_G['high_code'][$post['pid']][] = $code;
			return '<div class="hightitle">'.$brush.lang('plugin/niuc_runcode', 'highcodetip').'</div><div class="niuc_specode"><pre class="brush:'.strtolower($brush).'">'.$code.'</pre></div>';
		} else {
			$_G['run_code'][$post['pid']][] = $code;
			isset($_SESSION['i'])?($_SESSION['i']++):($_SESSION['i']=0);
			$i=$_SESSION['i'];
			return '<div style="width:'.$this->codewidth.'px"><textarea name="runcode" id="runcode'.$i.'" rows="16" class="codearea" style="width:'.$this->codewidth.'px">'.$code.'</textarea><br /><div style="text-align:right;margin-top:10px">'.lang('plugin/niuc_runcode', 'tip').' <input type="button" value=" '.lang('plugin/niuc_runcode', 'run').' " onClick="runcode($(\'runcode'.$i.'\'))" class="pn pnc vm"> <input type="button" value=" '.lang('plugin/niuc_runcode', 'saveas').' " onClick="savecode($(\'runcode'.$i.'\'))" class="pn pnc vm"> <input type="button" value=" '.lang('plugin/niuc_runcode', 'copy').' " onClick="copycode($(\'runcode'.$i.'\'))" class="pn pnc vm"></div></div>';
		}
	}
	function discuzcode($param){
		global $_G;
		if($param['caller'] == 'messagecutstr') {
			$_G['discuzcodemessage'] = preg_replace("/\[code=([a-zA-Z0-9]+?)\s?(width=)?([0-9a-zA-Z]+)?\]/iUse", '', $_G['discuzcodemessage']);
			$_G['discuzcodemessage'] = preg_replace("/\[runcode\s?(width=)?([0-9a-zA-Z]+)?\]/iUse", '', $_G['discuzcodemessage']);
		} elseif($param['caller'] == 'discuzcode'){
			$n=substr_count($_G['discuzcodemessage'],'[runcode');
			$_G['discuzcodemessage'] = preg_replace('/\[code=([a-zA-Z0-9]+)?\s?(width=)?([0-9a-zA-Z]+)?\](.+?)\[\/code\]/ies', "\$this->code_to_pre('\\1', '\\4')", $_G['discuzcodemessage']);
			$_G['discuzcodemessage'] = preg_replace('/\[runcode\s?(width=)?([0-9a-zA-Z]+)?\](.+?)\[\/runcode\]/ies', "\$this->code_to_pre('\\1', '\\3', 1)", $_G['discuzcodemessage']);
		}
	}
}
class plugin_niuc_runcode_forum extends plugin_niuc_runcode{
	function viewthread_bottom(){
		global $_G;
		return '<script type="text/javascript" src="source/plugin/niuc_runcode/js/runcode.js"></script><link type="text/css" rel="stylesheet" href="source/plugin/niuc_runcode/highcode/styles/shCore.css"/><link type="text/css" rel="stylesheet" href="source/plugin/niuc_runcode/highcode/styles/shThemeDefault.css"/><link type="text/css" rel="stylesheet" href="source/plugin/niuc_runcode/css/main.css"/><script type="text/javascript" src="source/plugin/niuc_runcode/highcode/scripts/shCore.js"></script><script type="text/javascript" src="source/plugin/niuc_runcode/js/highcode.js"></script>';
	}
	function post_top(){
		return '<link type="text/css" rel="stylesheet" href="source/plugin/niuc_runcode/css/main.css"/>';
	}
	function viewthread_bottom_output(){
		global $postlist;
		foreach($postlist as $pid => $post) {
			$post['message'] = preg_replace('/<pre[^>](.*?)>(.*?)<\/pre>/ies', "\$this->_replace('\\1', '\\2', $pid)", $post['message']);
			$post['message'] = preg_replace('/<textarea[^>](.*?)>(.*?)<\/textarea>/ies', "\$this->_replace('\\1', '\\2', $pid, 1)", $post['message']);
			$postlist[$pid] = $post;
		}
		return '';
	}
	function _replace($param, $codecontent, $pid, $type = 0) {
		global $_G;
		if($type == 0){
			return '<pre '.stripslashes($param).'>'.str_replace(array('<br>', '<br />'), '', array_shift($_G['high_code'][$pid])).'</pre>';
		} else {
			return '<textarea '.stripslashes($param).'>'.str_replace(array('<br>', '<br />'), '', array_shift($_G['run_code'][$pid])).'</textarea>';
		}
		
	}
	function post_editorctrl_left(){
		global $_G;
		$usedfunc = (array)unserialize($_G['cache']['plugin']['niuc_runcode']['usedfunc']);
		$strr += "var usedfunc = new Array();";
		$strr += count($usedfunc) == 1 ? intval($usedfunc[0]) : 3;
		if($this->_permission() && $usedfunc[0] > 0) {
			return '<script src="/source/plugin/niuc_runcode/js/main.js"></script><a href="javascript:;" id="runcode" title="'.lang('plugin/niuc_runcode', 'insert_code').'" onclick="niuc_showmenu()">Code</a><script>var code_title="'.lang('plugin/niuc_runcode', 'insert_code').'",shut="'.lang('plugin/niuc_runcode', 'shut').'",submit="'.lang('plugin/niuc_runcode', 'submit').'",run_code="'.lang('plugin/niuc_runcode', 'run_code').'",usedfunc="'.$strr.'",v_codewidth="'.$_G['cache']['plugin']['niuc_runcode']['codewidth'].'";</script>';
		}
	}
}
?>