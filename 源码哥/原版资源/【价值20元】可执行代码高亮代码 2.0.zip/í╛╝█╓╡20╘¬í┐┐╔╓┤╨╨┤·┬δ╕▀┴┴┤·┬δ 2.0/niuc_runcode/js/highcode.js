function loadjs(jsfile){
    var oHead = document.getElementsByTagName('HEAD').item(0);
    var oScript= document.createElement("script");
    oScript.type = "text/javascript";
    oScript.src = jsfile;
    oHead.appendChild(oScript);
}
var x = (document.compatMode.toLowerCase() == "css1compat" ) ? document.documentElement : document.body;
var s = x.innerHTML;
var reg = /<pre class=\"?brush:([a-zA-Z0-9]+)\"?/ig;
var r = s.match(reg);
if(r != null){
	var brush={"AppleScript":"0", "as3":"0", "bash":"0", "coldfusion":"0", "cpp":"0", "csharp":"0", "css":"0", "delphi":"0", "diff":"0", "erlang":"0", "groovy":"0", "java":"0", "javafx":"0", "javascript":"0", "objc":"0", "perl":"0", "php":"0", "plain":"0", "powershell":"0", "python":"0", "ruby":"0", "sass":"0", "scala":"0", "sql":"0", "vb":"0", "xml":"0"};
	for(var i=0; i<r.length; i++){
		var k = r[i].split(":");
		brush[k[1].replace('"', '')] = "1";
	}
	var pname;
	for (y in brush){
		if(brush[y] == "1"){
			loadjs('/source/plugin/niuc_runcode/highcode/scripts/shbrush' + y.toLowerCase() + '.js');
		}
	}
	SyntaxHighlighter.config.clipboardSwf = '/source/plugin/niuc_runcode/highcode/scripts/clipboard.swf';
	SyntaxHighlighter.config.strings.expandSource = 'expand Source';
	SyntaxHighlighter.config.strings.viewSource = 'view source';
	SyntaxHighlighter.config.strings.copyToClipboard = 'copy to clipboard';
	SyntaxHighlighter.config.strings.copyToClipboardConfirmation = ' The code is in your clipboard now';
	SyntaxHighlighter.config.strings.print = 'print';
	SyntaxHighlighter.config.strings.help = '?';
	SyntaxHighlighter.config.strings.alert = '';
	SyntaxHighlighter.defaults['auto-links'] = false;
	SyntaxHighlighter.config.strings.noBrush = "Can\'t find brush for: ";
	SyntaxHighlighter.config.strings.brushNotHtmlScript = "Brush wasn\'t configured for html-script option: ";
	SyntaxHighlighter.all();
}