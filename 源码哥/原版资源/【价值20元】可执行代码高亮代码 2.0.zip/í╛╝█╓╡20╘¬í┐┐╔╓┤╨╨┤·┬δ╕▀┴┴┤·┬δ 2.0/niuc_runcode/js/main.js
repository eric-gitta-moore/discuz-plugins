var isIE = !(!document.all);
var browser = navigator.appName;
var b_version = navigator.appVersion;
var version = b_version.split(";"); 
if(version[1] != null){
	var trim_Version = version[1].replace(/[ ]/g, "");
}
else{
	trim_Version = version;
}
	
isIE9 = browser == "Microsoft Internet Explorer" && trim_Version == "MSIE9.0";
function movecursor(oPos, id, tag){
	var oTextarea = document.getElementById(id);
	if(isIE){
		var oTextRange = oTextarea.createTextRange();
		var selStart = oPos[0];
		var selEnd = oPos[2] + tag[1].length + tag[0].length;
		var br_start = 0;
		var br_end = 0;
		var value = oTextarea.value;
		if(!isIE9){
			var s = value.substr(0, selStart);
			k = s.split('\n');
			br_start += k.length>1 ? k.length-1 : 0;
	
			s = value.substr(selEnd);
			k = s.split('\n');
			br_end += k.length>1 ? k.length - 1 : 0;
		}
		oTextRange.moveStart('character', oPos[0]+tag[0].length - br_start);
		oTextRange.moveEnd('character', oPos[1]-tag[1].length + br_end);
		oTextRange.select();
		oTextarea.focus();
	}else {   
		oTextarea.select();   
		oTextarea.selectionStart = oPos[0] + tag[0].length;
		oTextarea.selectionEnd = oPos[1] + tag[0].length;;
	}   
}

function getPos(id){
	if(typeof(id.selectionStart) == "number"){
		start = id.selectionStart;
		end = id.selectionEnd;
	}
	else if(document.selection){
    	var start = 0, end = 0;
		var range = document.selection.createRange();
		if(range.parentElement().id == id){
			var range_all = document.body.createTextRange();
			range_all.moveToElementText($(id));
			for (start=0; range_all.compareEndPoints("StartToStart", range) < 0; start++)
				range_all.moveStart('character', 1);
			if(!isIE9){
				for (var i = 0; i <= start; i ++){
					if ($(id).value.charAt(i) == '\n'){
						start++;
					}	
				}
			}
			var range_all = document.body.createTextRange();
			range_all.moveToElementText($(id));
			
			for (end = 0; range_all.compareEndPoints('StartToEnd', range) < 0; end++)
				range_all.moveStart('character', 1);
			if(!isIE9) {
				for (var i = 0; i <= end; i++){
					if ($(id).value.charAt(i) == '\n'){
						end++;
					}
				}
			}
		}
	}
	var arr = [start, end];
	return arr;
}
function insert_textarea(id, tag){
	var niuc_obj;
	niuc_obj = document.getElementById(id);
	var pos = new Array();
	if (document.selection){
		niuc_obj.focus();
		sel = document.selection.createRange();
		pos = getPos('niuc_text');
		pos[2] = pos[1];
		pos[1] = pos[1] - $(id).value.length;
		sel.text = tag[0] + sel.text + tag[1];
		niuc_obj.focus();
	}
	else if (niuc_obj.selectionStart || niuc_obj.selectionStart == '0') {
		var startPos = niuc_obj.selectionStart;
		var endPos = niuc_obj.selectionEnd;
		var cursorPos = endPos;
		pos[0] = startPos;
		pos[1] = endPos;
		if(niuc_obj.selectionStart != niuc_obj.selectionEnd) {
			niuc_obj.value = niuc_obj.value.substring(0, startPos) + tag[0] + niuc_obj.value.substr(startPos, endPos - startPos) + tag[1] + niuc_obj.value.substring(endPos, niuc_obj.value.length); 
		} else {
			niuc_obj.value = niuc_obj.value.substring(0, startPos) + tag[0] + tag[1] + niuc_obj.value.substring(startPos);
		}
	} else {
		niuc_obj.value += tag[0] + tag[1];
	}
	movecursor(pos, 'niuc_text', tag);
}
function niuc_showmenu(params){
	checkFocus();
	var sel, selection;
	var str = '', strdialog = 0,tag = "codes";
	var ctrlid = editorid + (params ? '_cst' + params + '_' : '_') + tag;
	var menu = $(ctrlid + '_menu');
	var pos = [0, 0];
	var menuwidth = 550;
	var menupos = '43!';
	var menutype = 'menu';

	if(BROWSER.ie) {
		checkFocus();
		sel = wysiwyg ? editdoc.selection.createRange() : document.selection.createRange();
		//pos = getCaret();
	}

	selection = sel ? (wysiwyg ? sel.htmlText : sel.text) : getSel();
	str+='<select id="niuc_select">';
	var textarea_str = '<textarea id="niuc_text" style="width:510px; height:200px"></textarea>';
	var highcode = '<option value="AppleScript">AppleScript</option><option value="AS3">AS3</option><option value="Bash">Bash</option><option value="ColdFusion">ColdFusion</option><option value="Cpp">Cpp</option><option value="CSharp">CSharp</option><option value="Css">Css</option><option value="Delphi">Delphi</option><option value="Diff">Diff</option><option value="Erlang">Erlang</option><option value="Groovy">Groovy</option><option value="Java">Java</option><option value="JavaFX">JavaFX</option><option value="JavaScript">JavaScript</option><option value="ObjC">ObjC</option><option value="Perl">Perl</option><option value="Php">Php</option><option value="Plain">Plain</option><option value="PowerShell">PowerShell</option><option value="Python">Python</option><option value="Ruby">Ruby</option><option value="Sass">Sass</option><option value="Scala">Scala</option><option value="Sql">Sql</option><option value="Vb">Vb</option><option value="Xml">Xml</option>';
	if(usedfunc == 0) {
		str += '<option value="0" selected="selected">-</option></select>';
	} else if(usedfunc == 1) {
		str += '<option value="-1" selected="selected">' + run_code + '</option><option value="0" selected="selected">-</option></select><br />' + textarea_str;
	} else if(usedfunc == 2) {
		str += '<option value="0" selected="selected">-</option>' + highcode + '</select><br />' + textarea_str;
	} else if(usedfunc == 3) {
	str += '<option value="-1" selected="selected">' + run_code + '</option><option value="0" selected="selected">-</option>' + highcode + '</select><br />' + textarea_str;
	}
	menupos = '00';
	menutype = 'win';
	var menu = document.createElement('div');
	menu.id = ctrlid + '_menu';
	menu.style.display = 'none';
	menu.className = 'p_pof upf';
	menu.style.width = menuwidth + 'px';
	if(menupos == '00') {
			menu.className = 'fwinmask';
			s = '<table width="100%" cellpadding="0" cellspacing="0" class="fwin"><tr><td class="t_l"></td><td class="t_c"></td><td class="t_r"></td></tr><tr><td class="m_l">&nbsp;&nbsp;</td><td class="m_c">'
				+ '<h3 class="flb"><em>' + code_title + '</em><span><a onclick="hideMenu(\'\', \'win\');return false;" class="flbc" href="javascript:;">' + shut + '</a></span></h3><div class="c">' + str + '</div>'
				+ '<p class="o pns"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>' + submit + '</strong></button></p>'
				+ '</td><td class="m_r"></td></tr><tr><td class="b_l"></td><td class="b_c"></td><td class="b_r"></td></tr></table>';
		}
	menu.innerHTML = s;
	$(editorid + '_editortoolbar').appendChild(menu);
	showMenu({'ctrlid':ctrlid, 'mtype':menutype, 'evt':'click', 'duration':3, 'cache':0, 'drag':1, 'pos':menupos});
	$("niuc_text").focus();
	var objs = menu.getElementsByTagName('*');
	for(var i = 0; i < objs.length; i++) {
		_attachEvent(objs[i], 'keydown', function(e) {
			e = e ? e : event;
			obj = BROWSER.ie ? event.srcElement : e.target;
			if((obj.type == 'text' && e.keyCode == 13) || (obj.type == 'textarea' && e.ctrlKey && e.keyCode == 13)) {
				if($(ctrlid + '_submit') && tag != 'image') $(ctrlid + '_submit').click();
				doane(e);
			} else if(e.keyCode == 27) {
				hideMenu('', 'win');
				hideMenu();
				doane(e);
			}
		});
	}
	if($('niuc_select')) $('niuc_select').onchange = function(){
		var niuc_tag = new Array();
		if($('niuc_select').value == 0) {
			return;
		} else if ($('niuc_select').value < 0) {
			niuc_tag[0] = "[runcode]";
			niuc_tag[1] = "[/runcode]";
		} else {
			niuc_tag[0] = "[code=" + $('niuc_select').value + ']';
			niuc_tag[1] = "[/code]";
		}
		insert_textarea("niuc_text", niuc_tag);
		
		var sele;
		usedfunc == 2 ? sele=0 : sele = 1;
		$('niuc_select').options[sele].selected = true;
	}
	if($(ctrlid + '_submit')) $(ctrlid + '_submit').onclick = function() {
		checkFocus();
		if(BROWSER.ie && wysiwyg) {
			//setCaret(pos[0]);
		}
		if(wysiwyg){
			$("niuc_text").value = $("niuc_text").value.replace(/</g, '&lt;').replace(/\r?\n/g, '<br />');
		}
		insertText($("niuc_text").value, 0, 0, false, sel);
		hideMenu('', 'win');
		hideMenu();
	}
}