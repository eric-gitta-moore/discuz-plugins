function runcode(obj) {
	var winname = window.open('', "_blank", '');
	winname.document.open('text/html', 'replace');
	winname.opener = null;
	winname.document.write(obj.value.replace(/[\xA0]/g, ' '));
	winname.document.close();
}
function savecode(obj) {
        var winname = window.open('', '_blank', 'top=10000');
        winname.document.open('text/html', 'replace');
        winname.document.write(obj.value);
        winname.document.execCommand('saveas', '', 'code.htm');
        winname.close();
}
function br2rn(id){
	//$(id).value=$(id).value.replace(/<br \/>/ig,"");
}