<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once ('pluginvar.func.php');
splugin_thinks(CURMODULE);
?>