<?php
/*
 * 出处：草根吧
 * 官网: Www.fx8.cc
 * 备用网址: www.ymg6.com (请收藏备用!)
 * 技术支持/更新维护：QQ 154606914
 * 
 */
!defined('IN_DISCUZ') && exit('Access Denied');

//辅助系统
if(file_exists(DISCUZ_ROOT.'./source/plugin/k_gaiming/extend/extend_mobile.php')){
	$extend['wsq'] = 1; 
}


?>