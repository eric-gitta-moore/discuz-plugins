<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_ADMINCP')) exit('Access Denied');
$sql = <<<EOF

DROP TABLE IF EXISTS pre_plugin_k_gaiming_log;
CREATE TABLE IF NOT EXISTS pre_plugin_k_gaiming_log (
  lid int(11) NOT NULL AUTO_INCREMENT,
  uid int(11) NOT NULL,
  creditunit tinyint(1) NOT NULL,
  creditnum int(11) NOT NULL,
  oldname varchar(255) NOT NULL,
  newname varchar(255) NOT NULL,
  dateline int(11) NOT NULL,
  `ip` char(18) DEFAULT NULL,
  PRIMARY KEY (lid),
  KEY dateline (dateline)
) ENGINE=MyISAM;

EOF;
runquery($sql);

$finish = TRUE;

?>