<?php 
!defined('IN_DISCUZ') && exit('Access Denied');

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_plugin_xm_issuetrack`;

EOF;

runquery($sql);
$finish = TRUE;
?>