<?php 

!defined('IN_DISCUZ') && exit('Access Denied');

class plugin_xm_issuetrack {

    protected $cvars = array();
    private $isUnserialized = false;
    private $cssLoaded = false;
    private $forum_set = array();

    public function __construct() {
        global $_G;
        $this->cvars = $_G['cache']['plugin']['xm_issuetrack'];
        $this->_unserializeAll();
    }
    
    private function _get_forum_set($fid) {
        $this->forum_set = array(
            'enable' => $this->cvars['forum_enable'][$fid],
            'unsolve' => $this->cvars['forum_id_unsolve'][$fid],
            'answer' => $this->cvars['forum_id_answer'][$fid],
            'solve' => $this->cvars['forum_id_solve'][$fid],
            'force' => $this->cvars['forum_force'][$fid],
        );
    }

    protected function _unserializeAll() {
        if (!$this->isUnserialized) {
            $this->cvars['forum_enable'] = $this->cvars['forum_enable'] ? unserialize($this->cvars['forum_enable']) : array();
            $this->cvars['forum_id_unsolve'] = $this->cvars['forum_id_unsolve'] ? unserialize($this->cvars['forum_id_unsolve']) : array();
            $this->cvars['forum_id_answer'] = $this->cvars['forum_id_answer'] ? unserialize($this->cvars['forum_id_answer']) : array();
            $this->cvars['forum_id_solve'] = $this->cvars['forum_id_solve'] ? unserialize($this->cvars['forum_id_solve']) : array();
            $this->cvars['forum_force'] = $this->cvars['forum_force'] ? unserialize($this->cvars['forum_force']) : array();
            $this->cvars['gids'] = $this->cvars['gids'] ? unserialize($this->cvars['gids']) : array();
            $this->cvars['gids'] = in_array('', $this->cvars['gids']) ? array() : $this->cvars['gids'];
            $this->isUnserialized = true;
        }
    }

    protected function _load_css() {
        if (!$this->cssLoaded) {
            $this->cssLoaded = true;
            return '<link rel="stylesheet" type="text/css" href="source/plugin/xm_issuetrack/template/main.css" />';
        }
        return '';
    }

    protected function _global_header_output() {
        global $_G;
       
        $query = DB::query("SELECT i.*, t.subject FROM " . DB::table('plugin_xm_issuetrack') . " i, " . DB::table('forum_thread') . " t WHERE i.authorid='$_G[uid]' and i.new=2 and i.tid=t.tid");
        $issueList = array();
        $i = 0;
        while ($issue = DB::fetch($query)) {
            $issue['id'] = ++$i;
            $issueList[] = $issue;
        }
        if ($issueList) {
            $allowIgore = $this->cvars['allowIgnore'];
            include template('xm_issuetrack:index_top');
        }
        $return = $this->_load_css() . $return;
        return $return;
    }
    
    public function _add_issue($arg){
    	global $_G;
        $tid = $arg['param'][2]['tid'];
        $fid = $arg['param'][2]['fid'];
        $this->_get_forum_set($fid);
        if ($this->forum_set['enable'] && 
        	($arg['param'][0] == 'post_newthread_succeed' || $arg['param'][0] == 'post_newthread_mod_succeed') && 
        	$tid && ($this->forum_set['force'] || intval(getgpc('typeid')) == $this->forum_set['unsolve'])) {
            $data = array(
                'tid' => $tid,
                'authorid' => $_G['uid'],
            );
            DB::insert('plugin_xm_issuetrack', $data);
            if ($this->forum_set['force'] && intval(getgpc('typeid')) != $this->forum_set['unsolve']) {
                DB::update('forum_thread', array('typeid' => $this->forum_set['unsolve']), array('tid' => $tid), true);
            }
        } elseif ($this->forum_set['enable'] && $arg['param'][0] == 'post_reply_succeed' && $tid && (empty($this->cvars['gids']) || in_array($_G['groupid'], $this->cvars['gids']))) {
            $issue = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xm_issuetrack') . " WHERE tid='$tid'");
            if ($issue && $_G['uid'] != $issue['authorid'] && $issue['new'] == 1) {
                DB::update('plugin_xm_issuetrack', array('new' => 2), array('tid' => $tid), true);
                if ($this->forum_set['answer']) {
                    DB::update('forum_thread', array('typeid' => $this->forum_set['answer']), array('tid' => $tid), true);
                }
                if($_G['setting']['ifttt']){
                	ifttt::run('xm_issuetrack_newreply', array('touid' => $issue['authorid'], 'tid' => $tid));
                }
            }
        }
    }
}

class plugin_xm_issuetrack_forum extends plugin_xm_issuetrack {

    public function __construct() {
        global $_G;
        parent::__construct();
    }

    public function post_issue_message($arg) {
        return $this->_add_issue($arg);
    }
    
    
    public function index_top_output() {
        return $this->_global_header_output();
    }

    public function forumdisplay_top_output() {
        return $this->_global_header_output();
    }

    public function viewthread_posttop_output() {
        global $_G, $postlist;
        $returnArr = array();
        $tid=$_G['tid'];
        if ($_G['forum_thread']['authorid'] == $_G['uid'] && !empty($postlist) && is_array($postlist)) {
            $issue = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xm_issuetrack') . " WHERE tid='$tid'");
            if($issue['new'] > 0){
                $i = 0;
                foreach ($postlist as $pid => $post) {
                    $return = '';
                    if ($post['authorid'] != $_G['forum_thread']['authorid'])
                        include template('xm_issuetrack:post_top');
                    elseif($post['first'])
                        include template('xm_issuetrack:post_top_first');
                    $returnArr[$i++] = $return;
                }
            }
        }
        if(!empty($returnArr)){
            $returnArr[0] = $this->_load_css() . $returnArr[0];
        }
        return $returnArr;
    }


}

class mobileplugin_xm_issuetrack_forum extends plugin_xm_issuetrack {
	public function post_issue_message($arg) {
        return $this->_add_issue($arg);
    }
}
