<?php 
!defined('IN_DISCUZ') && exit('Access Denied');

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_plugin_xm_issuetrack`;
CREATE TABLE `pre_plugin_xm_issuetrack` (
  `tid` mediumint(8) unsigned NOT NULL,
  `authorid` mediumint(8) unsigned NOT NULL,
  `pid` int(10) NOT NULL DEFAULT '0',
  `new` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`tid`),
  KEY `user` (`authorid`,`new`)
) ENGINE=MyISAM;

EOF;

runquery($sql);
$finish = TRUE;
?>