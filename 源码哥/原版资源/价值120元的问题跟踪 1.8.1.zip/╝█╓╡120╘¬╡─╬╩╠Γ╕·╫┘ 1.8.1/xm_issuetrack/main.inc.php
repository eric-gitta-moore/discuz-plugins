<?php
/*
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
!defined('IN_DISCUZ') && exit('Access Denied');

$cvars = $_G['cache']['plugin']['xm_issuetrack'];
$cvars['forum_enable'] = $cvars['forum_enable'] ? unserialize($cvars['forum_enable']) : array();
$cvars['forum_id_unsolve'] = $cvars['forum_id_unsolve'] ? unserialize($cvars['forum_id_unsolve']) : array();
$cvars['forum_id_answer'] = $cvars['forum_id_answer'] ? unserialize($cvars['forum_id_answer']) : array();
$cvars['forum_id_solve'] = $cvars['forum_id_solve'] ? unserialize($cvars['forum_id_solve']) : array();
$cvars['forum_force'] = $cvars['forum_force'] ? unserialize($cvars['forum_force']) : array();

$tid = intval(getgpc('tid'));
$pid = intval(getgpc('pid'));
$issue = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xm_issuetrack') . " WHERE tid='$tid'");
if ($issue && $issue['new'] > 0 && getgpc('action') == 'accept' && $_G['uid'] == $issue['authorid']) {
    $thread = DB::fetch_first("SELECT fid, special, price, dateline, subject FROM " . DB::table('forum_thread') . " WHERE tid='$tid'");
    $post = DB::fetch_first("SELECT authorid FROM " . DB::table(getposttablebytid($tid)) . " WHERE pid = $pid");
    $fid = $thread['fid'];
    _get_forum_set($fid);
    if ($cvars['forum_set']['solve']) { //&#22914;&#26524;&#35774;&#32622;&#20102;&#20998;&#31867;ID
        DB::update('forum_thread', array('typeid' => $cvars['forum_set']['solve']), array('tid' => $tid), true);
    }
    if ($pid > 0) {
        if ($thread['special'] == 3) { //&#22914;&#26524;&#26159;&#24748;&#36175;&#24086;
            updatemembercount($post['authorid'], array($_G['setting']['creditstransextra'][2] => $thread['price']), 1, 'RAC', $tid);
            DB::update('forum_thread', array('price' => -$thread['price']), array('tid' => $tid));
            $cvars['bestAnswerShow'] = 2;
        }
        if ($cvars['bestAnswerShow'] & 2) { //&#31227;&#21160;&#33267;&#27801;&#21457;
            DB::query("UPDATE " . DB::table(getposttablebytid($tid)) . " SET dateline=$thread[dateline]+1 WHERE pid='$pid'");
        }
        if ($cvars['bestAnswerShow'] & 1) { //&#22238;&#24086;&#25512;&#33616;
        	if($cvars['bestAnswerShow'] & 2){
        		$postnum = 2;
        	}else{
	            $postnum = DB::result_first("SELECT COUNT(*) FROM " . DB::table(getposttablebytid($tid)) . " WHERE tid='$tid' AND pid < $pid");
	            $postnum++;
	        }
            DB::query("REPLACE INTO " . DB::table('forum_poststick') . " SET tid='$tid', pid='$pid', position='$postnum', dateline='$_G[timestamp]'");
            DB::query("UPDATE " . DB::table('forum_thread') . " SET moderated='1', stickreply='1' WHERE tid='$tid'");
        }
        if ($cvars['pmAfterAccept']) { //&#23545;&#27491;&#30830;&#22238;&#31572;&#32773;&#36827;&#34892;&#25552;&#37266;
            $msg = "&#24744;&#23545;<a href='forum.php?mod=viewthread&tid={$tid}' target='_blank'>{$thread[subject]}</a>&#30340;&#22238;&#31572;&#24471;&#21040;&#20102;&#25552;&#38382;&#32773;&#30340;&#35748;&#21487;&#12290;";
            notification_add($post['authorid'], 'xm_issuetrack', $msg);
        }
    }
    if($_G['setting']['ifttt']){
    	ifttt::run('xm_issuetrack_accept');
    }
    DB::update('plugin_xm_issuetrack', array('new' => 0), array('tid' => $tid));
    showmessage('&#35748;&#21487;&#25104;&#21151;&#65281;', "forum.php?mod=viewthread&tid=$tid", array(), array('alert' => 'right', 'showdialog' => true, 'locationtime' => true));
} elseif ($issue && getgpc('action') == 'ignore' && $_G['uid'] == $issue['authorid'] && $issue['new'] > 0) {
    DB::update('plugin_xm_issuetrack', array('new' => 1), array('tid' => $tid));
    showmessage('&#24573;&#30053;&#25104;&#21151;&#65281;', dreferer());
} else {
    showmessage('undefined_action');
    $v = '2012081418PV1us00VSS/1115/1345095246';
}

function _get_forum_set($fid) {
    global $cvars;
    $cvars['forum_set'] = array(
        'enable' => $cvars['forum_enable'][$fid],
        'unsolve' => $cvars['forum_id_unsolve'][$fid],
        'answer' => $cvars['forum_id_answer'][$fid],
        'solve' => $cvars['forum_id_solve'][$fid],
        'force' => $cvars['forum_force'][$fid],
    );
    return $cvars['forum_set'];
}

?>
