<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
echo lang("plugin/nciaer_musicplayer", "logy_m_g");