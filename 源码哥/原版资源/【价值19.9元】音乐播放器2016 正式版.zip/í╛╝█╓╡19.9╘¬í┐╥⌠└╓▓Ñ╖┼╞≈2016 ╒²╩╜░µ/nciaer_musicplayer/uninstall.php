<?php
/*
 * qq: 1069971363
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied!');
}

//delete the mp3 file
function _delDir($dir) {
	$d = opendir($dir);
	while ($file = readdir($d)) {
		if ($file != "." && $file != "..") {
			$musicUrl = $dir . "/" . $file;
			unlink($musicUrl);
		}
	}
	closedir($d);
}

_delDir("source/plugin/nciaer_musicplayer/mp3");
if (file_exists(DISCUZ_ROOT . "./data/sysdata/cache_nciaer_musicplayer.php")) {
	unlink(DISCUZ_ROOT . "./data/sysdata/cache_nciaer_musicplayer.php");
} 
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_nciaer_musicplayer`;
EOF;
runquery($sql);

$finish = TRUE;