<?php
/*
 * qq: 1069971363
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$appurl = $_G['siteurl'] . "admin.php?action=plugins&operation=config&do=$_GET[do]&identifier=nciaer_musicplayer&pmod=upload_music";
$p = $_GET['p'];
$p = $p ? $p : 'index';
if ($p == 'index') {
	$page = $_G['page'];
	$begin = ($page - 1) * 10;
	$musicList = array();
	$rs = DB::query("select * from " . DB::table('nciaer_musicplayer') . " order by id desc limit $begin , 10");
	while ($row = DB::fetch($rs)) {
		$musicList[] = $row;
	}
	$allnum = DB::result_first("select count(*) from " . DB::table('nciaer_musicplayer'));
	$pagenav = multi($allnum, 10, $page, $appurl . "&p=$p");
} elseif ($p == 'add') {
	if (submitcheck('musicSubmit') && $_POST["formhash"] == FORMHASH) {
		$title = addslashes($_POST['title']);
		if($_FILES["music_url"]["name"] == "" || $title == "") {
			cpmsg(lang('plugin/nciaer_musicplayer', 'miss_msg'), $appurl);
		} else if($_FILES['music_url']['error'] != 0) {
			cpmsg(lang('plugin/nciaer_musicplayer', 'up_err'), $appurl);
		}else{
			if (pathinfo($_FILES["music_url"]["name"], PATHINFO_EXTENSION) != "mp3") {
				cpmsg(lang('plugin/nciaer_musicplayer', 'type_err'));
			}
			$musicUrl = "source/plugin/nciaer_musicplayer/mp3/" . time() . ".mp3";
			@move_uploaded_file($_FILES['music_url']['tmp_name'], $musicUrl);
			DB::insert('nciaer_musicplayer', array(
				'id' => '',
				'title' => $title,
				'music_url' => $musicUrl,
				'dateline' => time(),
			));
			_updateCache();
			cpmsg(lang('plugin/nciaer_musicplayer', 'add_success'), $appurl);
		}

	}
} elseif ($p == 'del') {
	if ($_GET['formhash'] == FORMHASH) {
		$music = DB::fetch_first("select * from " . DB::table('nciaer_musicplayer') . " where id = " . intval($_GET["id"]));
		//delete mp3 file
		unlink(DISCUZ_ROOT . $music["music_url"]);
		DB::query("delete from " . DB::table('nciaer_musicplayer') . " where id = " . intval($_GET["id"]));
		_updateCache();
		cpmsg(lang('plugin/nciaer_musicplayer', 'delete_success'), $appurl);
	}
}
include template("nciaer_musicplayer:music_$p");

//更新缓存函数
function _updateCache() {
	$mp3_urls = DB::fetch_all("select * from " . DB::table("nciaer_musicplayer"));
	$cacheArr = "\$mp3_urls = " . arrayeval($mp3_urls) . ";\n";
	writetocache("nciaer_musicplayer", $cacheArr);
}