<?php
/*
 * qq: 1069971363
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied!');
}

$sql = <<<EOF
create table if not exists `pre_nciaer_musicplayer` (
  `id` int not null auto_increment primary key,
  `title` varchar(200) not null,
  `music_url` varchar(200) not null,
  `dateline` tinyint not null
)engine=myisam
EOF;
runquery($sql);
$finish = TRUE;