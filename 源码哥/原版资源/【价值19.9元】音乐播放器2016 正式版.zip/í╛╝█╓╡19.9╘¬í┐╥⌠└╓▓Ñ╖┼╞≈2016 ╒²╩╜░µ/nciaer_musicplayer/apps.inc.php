<?php
/*
	qq: 1069971363
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
?>
<iframe src="http://addon.discuz.com/?@56030.developer" width="870" height="2000" frameborder="0" scrolling="no" style="margin-left:-3px; background:#F4FAFD" ></iframe> 