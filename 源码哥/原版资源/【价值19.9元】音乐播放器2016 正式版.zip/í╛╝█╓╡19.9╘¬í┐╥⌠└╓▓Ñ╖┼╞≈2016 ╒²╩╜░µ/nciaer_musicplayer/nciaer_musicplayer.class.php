<?php
/*
 * qq: 1069971363
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile("function/cache");

class plugin_nciaer_musicplayer {

	function global_cpnav_extra1() {

		global $_G;
		extract($_G["cache"]["plugin"]["nciaer_musicplayer"]);
		//判断是否存在缓存文件，后台上传、删除操作都会更新缓存
		if (file_exists(DISCUZ_ROOT . "./data/sysdata/cache_nciaer_musicplayer.php")) {
			require_once DISCUZ_ROOT . "./data/sysdata/cache_nciaer_musicplayer.php";
		} else {
			$mp3_urls = DB::fetch_all("select * from " . DB::table("nciaer_musicplayer"));
			$cacheArr = "\$mp3_urls = " . arrayeval($mp3_urls) . ";\n";
			writetocache("nciaer_musicplayer", $cacheArr);
			require_once DISCUZ_ROOT . "./data/sysdata/cache_nciaer_musicplayer.php";
		}
		$randIndex = array_rand($mp3_urls);
		$mp3_url = $mp3_urls[$randIndex];

		$musicVal = "source/plugin/nciaer_musicplayer/player/player{$playerStyle}.swf?mp3={$mp3_url['music_url']}&autostart={$is_autostart}&autoreplay={$is_replay}&volume={$vol}";
		include template("nciaer_musicplayer:index");
		switch (intval($playPosition)) {
		case 1: //全站显示
			return $return;
			break;
		case 2: //首页显示
			return CURMODULE == "index" ? $return : "";
			break;
		case 3: //帖子页显示
			return CURMODULE == "viewthread" ? $return : "";
			break;
		}
	}
}