<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */if (!defined('IN_DISCUZ')) {
	exit('Access Deined');
} 
function g2u($a) {
	return is_array($a) ? array_map('g2u', $a) : iconv('GBK', 'UTF-8', $a);
} 
function u2g($a) {
	return is_array($a) ? array_map('u2g', $a) : iconv('UTF-8', 'GBK', $a);
} 
$op = $_GET['op'];
if (!$op) {
	$op = 'seo';
} 
include template('seo:nav');
if ($op == 'ping') {
	$web_root = $_G ['siteurl'];
	if (substr($web_root, -1) != '/') {
		$web_root = $web_root . '/';
	}
	$web_root='"'.$web_root.'"';
	include_once 'source/plugin/seo/precord.inc.php';
} else if($op=='link'){
	$the_host = $_SERVER ['HTTP_HOST'];
	$b = "http://" . $the_host;
	$web_root = $_G ['siteurl'];
	if (substr($web_root, -1) == '/') {
		$web_root = rtrim($web_root,'/');
	}
	$query=DB::query("select *  from ".DB::table('common_friendlink')." order by displayorder asc");
	while($link=DB::fetch($query)){
		$links[]=$link;
	}
	include template('seo:link');
}else if ($op == 'seo') {
	$the_host = $_SERVER ['HTTP_HOST'];
	$b = "http://" . $the_host;
	$web_root = $_G ['siteurl'];
	if (substr($web_root, -1) != '/') {
		$web_root = $web_root . '/';
	} 
	

	$time = $_GET['time'];
	if (!$time) {
		$timestamp = $_G['timestamp'];
		$time = date('Y-m-d', $timestamp);
	} 
	$query = DB :: query('select spider,count(*) num,max(spidertime) spidertime from ' . DB :: table('plugin_seo_spider') . " where FROM_UNIXTIME(spidertime,'%Y-%m-%d')='" . $time . "' group by spider ");
	while ($field = DB :: fetch($query)) {
		$seo[] = $field;
	} 
	foreach($seo as $k => $v) {
		$seo[$k]['spiderurl'] = DB :: result_first("select spiderurl from " . DB :: table('plugin_seo_spider') . " where spidertime=" . $v['spidertime']);
	} 
	include template('seo:seoeye');
} else if ($op == 'zhizhu') {
	$yemian = daddslashes(trim($_GET['yemian']));
	$ip = daddslashes(trim($_GET['ip']));
	$yinqing = daddslashes($_GET['yinqing']);
	$time1 = daddslashes($_GET['time1']);
	$con = " where 1";
	$conn = '';
	if ($yemian) {
		$con .= " and spiderurl='$yemian'";
		$conn .= "&yemian=" . $yemian;
	} 
	if ($ip) {
		$con .= " and spiderip='$ip'";
		$conn .= "&ip=" . $ip;
	} 
	if ($yinqing) {
		$con .= " and spider='$yinqing'";
		$conn .= "&yinqing=" . $yinqing;
	} 
	if ($time1) {
		$con .= " and FROM_UNIXTIME(spidertime,'%Y-%m-%d')='" . $time1 . "'";
		$conn .= "&time1=" . $time1;
	} 
	$con .= " order by spidertime desc";
	$curpage = daddslashes($_GET['page']);
	$perpage = 15;
	if (!$curpage) {
		$curpage = 1;
	} 
	$curnum = ($curpage-1) * $perpage;
	$sign = 1;
	$num = DB :: result_first("SELECT count(*) FROM " . DB :: table('plugin_seo_spider') . " $con");
	$query = DB :: query(' select * from ' . DB :: table('plugin_seo_spider') . " $con limit $curnum,$perpage ");
	while ($field = DB :: fetch($query)) {
		$zhizhuarr[] = $field;
	} 
	// debug($zhizhuarr);
	include template('seo:zhizhu');
} else {
	include_once 'source/plugin/seo/cleardata.inc.php';
} 

?> 