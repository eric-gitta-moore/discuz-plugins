<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!isset($_G['cache']['plugin']['seo'])){
	loadcache('plugin');
}
$config=$_G['cache']['plugin']['seo'];

$allowaction = array('list', 'detail', 'add');
$op = in_array($_G['gp_op'], $allowaction) ? $_G['gp_op'] : 'list';

$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';

if(file_exists($settingfile)){
	include $settingfile;
}
if(file_exists(DISCUZ_ROOT . './data/cache/cache_seo_setting.php')){
	$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
	include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
}
if(empty($seo_setting)){
	include DISCUZ_ROOT . './source/plugin/seo/seo_setting.php';
}
switch ($op){
	case 'list':
		showformheader("plugins&operation=config&do=$do&identifier=seo&pmod=domain&op=add");
		showtableheader(lang('plugin/seo', 'a1'));
		showsetting(lang('plugin/seo','b1'), 'b1', $seo_setting['b1'], 'radio', 0, 1,lang('plugin/seo','b1_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','a3'), 'a3', $seo_setting['a3'], 'radio', 0, 1,lang('plugin/seo','a3_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','b5'), 'b5', $seo_setting['b5'], 'radio', 0, 1,lang('plugin/seo','b5_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','b6'), 'b6', $seo_setting['b6'], 'radio', 0, 1,lang('plugin/seo','b6_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','b3'), 'b3', $seo_setting['b3'], 'radio', 0, 1,lang('plugin/seo','b3_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','b4'), 'b4', $seo_setting['b4'], 'radio', 0, 1,lang('plugin/seo','b4_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','b2'), 'b2', $seo_setting['b2'], 'radio', 0, 1,lang('plugin/seo','b2_comment'));
		showtagfooter('tbody');
		showtagfooter('tbody');
		showsubmit('editsubmit','submit');
		showtablefooter();
		showformfooter();
		break;
	case 'add':		
		if(submitcheck('editsubmit')){
			//�洢��վ��ͼ��������������
			$seo_setting['a3']=$_GET['a3'];
			$seo_setting['b1']=$_GET['b1'];
			$seo_setting['b2']=$_GET['b2'];
			$seo_setting['b3']=$_GET['b3'];
			$seo_setting['b4']=$_GET['b4'];
			$seo_setting['b5']=$_GET['b5'];
			$seo_setting['b6']=$_GET['b6'];
			require_once libfile('function/cache');
			writetocache('seo_setting', getcachevars(array('seo_setting' => $seo_setting)));//����������������д�뻺��
			
		}
		
		
		cpmsg(lang('plugin/seo', 'a2'), 'action=plugins&operation=config&do=$do&identifier=seo&pmod=domain', 'succeed');
		break;
	
}
?>