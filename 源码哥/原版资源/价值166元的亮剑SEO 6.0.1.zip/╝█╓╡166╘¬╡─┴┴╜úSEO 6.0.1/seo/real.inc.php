<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT.'/source/plugin/seo/function_inc.php';
if(!isset($_G['cache']['plugin']['seo'])){
	loadcache('plugin');
}
$config=$_G['cache']['plugin']['seo'];

$allowaction = array('list', 'detail', 'add');
$op = in_array($_G['gp_op'], $allowaction) ? $_G['gp_op'] : 'list';

$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';

if(file_exists($settingfile)){
	include $settingfile;
}
if(file_exists(DISCUZ_ROOT . './data/cache/cache_seo_setting.php')){
	$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
	include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
}
if(empty($seo_setting)){
	include DISCUZ_ROOT . './source/plugin/seo/seo_setting.php';
	if($_G['charset']!='gbk'){
		$seo_setting['thesaurus_setting']=iconv('gbk','utf-8',$seo_setting['thesaurus_setting']);
		$seo_setting['post_cloud']=iconv('gbk','utf-8',$seo_setting['post_cloud']);
		$seo_setting['allow_tips']=iconv('gbk','utf-8',$seo_setting['allow_tips']);
		
	}
}
if($_GET['op']=='sc'){
	$sql="delete from ".DB::table('plugin_seo_thread');

	DB::query($sql);

	cpmsg(lang('plugin/seo','xx2'),'action=plugins&operation=config&do=$do&identifier=seo&pmod=real', 'succeed');

}
switch ($op){
	case 'list':
		
		showformheader("plugins&operation=config&do=$do&identifier=seo&pmod=real&op=add",'enctype');
		showtableheader(lang('plugin/seo', 'thesaurus_setting'));
		showsetting(lang('plugin/seo','tips_thesaurus'), 'thesaurus_setting', $seo_setting['thesaurus_setting'], 'textarea', 0, 1,lang('plugin/seo','thesaurus_setting_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','c1'), 'logonew', $nav['pic'], 'filetext', '', 0,lang('plugin/seo','c2'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','issuper'), 'issuper', $seo_setting['issuper'], 'radio', 0, 1,lang('plugin/seo','super_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','isuid'), 'isuid', $seo_setting['isuid'], 'radio', 0, 1,lang('plugin/seo','isuid_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','tips_post'), 'allow_thesaurus', $seo_setting['allow_thesaurus'], 'radio', 0, 1,lang('plugin/seo','allow_thesaurus_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','tips_title'), 'allow_title', $seo_setting['allow_title'], 'radio', 0, 1,lang('plugin/seo','allow_title_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','title_portal'), 'title_portal', $seo_setting['title_portal'], 'radio', 0, 1,lang('plugin/seo','title_portal_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','content_portal'), 'content_portal', $seo_setting['content_portal'], 'radio', 0, 1,lang('plugin/seo','content_portal_comment'));
		showtagfooter('tbody');
		
		showsubmit('editsubmit',lang('plugin/seo','cloud_update'));
		showtablefooter();
		showformfooter();
		break;
	case 'add':		
		if(submitcheck('editsubmit')){
			//αԭ����������������
			$seo_setting['thesaurus_setting']=$_GET['thesaurus_setting'];
			$seo_setting['allow_thesaurus']=$_GET['allow_thesaurus'];
			$seo_setting['allow_title']=$_GET['allow_title'];
			$seo_setting['title_portal']=$_GET['title_portal'];
			$seo_setting['content_portal']=$_GET['content_portal'];
			$seo_setting['edit_thread']=$_GET['edit_thread'];
			$seo_setting['batch']=$_GET['batch'];
			$seo_setting['batch_title']=$_GET['batch_title'];
			$seo_setting['issuper']=$_GET['issuper'];
			$seo_setting['isuid']=$_GET['isuid'];
			if($_FILES['logonew']['tmp_name']) {
				$upload = new discuz_upload();
				$upload->init($_FILES['logonew']);
				if($upload->init($_FILES['logonew']) && $upload->save()) {
					$logonew = $upload->attach['attachment'];
				}
				$tmpaddr=$_G['setting']['attachurl'].'temp/'.$logonew;
				$str=file_get_contents($tmpaddr);
				$seo_setting['thesaurus_setting']=$str;
				if($_G['charset']!='gbk'){
					$seo_setting['thesaurus_setting']=iconv('gbk','utf-8',$str);
				}
				
			}else if($_GET['logonew']){
				$str=file_get_contents($_GET['logonew']);
				$seo_setting['thesaurus_setting']=$str;
				if($_G['charset']!='gbk'){
					$seo_setting['thesaurus_setting']=iconv('gbk','utf-8',$str);
				}
			}
			global $_G;
			$config = $_G ['cache'] ['plugin'] ['seo'];
			$wwforums = $config ['wwforums'];
			$wwforums = unserialize ( $wwforums );
			$wwforums = implode(',',$wwforums);
			if($seo_setting['batch']&&$seo_setting['thesaurus_setting']){
				$query=DB::query("SELECT tid,fid,subject,message FROM ".DB::table('forum_post')." where first=1 and invisible=0 and fid in(".$wwforums.')');
				while($thr=DB::fetch($query)){
					$threads[]=$thr;
				}
				if ($seo_setting ['allow_thesaurus']) {
						$words = array ();
						$str = str_replace ( "\r", "", $seo_setting ['thesaurus_setting'] );
						$arr = explode ( "\n", $str);
						foreach ( $arr as $k => $v ) {
							if($v){
								$str_data = explode ( "=", $v );
								$words += array ("$str_data[0]" => "$str_data[1]" );
							}
						}
						$words=array_unique($words);
						//$_GET ['message'] = strtr ( $_GET ['message'], $words ); 
						
					}
				foreach($threads as $value){
					if(!$seo_setting['batch_title']){
						$sql = "UPDATE ".DB::table('forum_post')."  set message='".strtr ($value['message'], $words )."' where tid='".$value['tid']."'";
					}else{
						$sql = "UPDATE ".DB::table('forum_post')."  set message='".strtr ($value['message'], $words )."' , " ."  subject='".strtr ($value['subject'], $words )."' where tid='".$value['tid']."'";

						$sql2 = "UPDATE ".DB::table('forum_thread')."  set subject='".strtr ($value['subject'], $words )."' where tid='".$value['tid']."'";
					}
					DB::query($sql);
					if($sql2){
						DB::query($sql2);
					}
				}
				
			
		
				$seo_setting['batch']=0;
			}
			require_once libfile('function/cache');
			writetocache('seo_setting', getcachevars(array('seo_setting' => $seo_setting)));//����������������д�뻺��
		cpmsg(lang('plugin/seo', 'thesaurus_post'), 'action=plugins&operation=config&do=$do&identifier=seo&pmod=real', 'succeed');
		break;
	}
	
}
?>