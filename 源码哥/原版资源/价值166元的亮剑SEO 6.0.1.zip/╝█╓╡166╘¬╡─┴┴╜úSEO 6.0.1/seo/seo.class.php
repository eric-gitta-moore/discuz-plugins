<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
} 
require_once DISCUZ_ROOT.'source/plugin/seo/lj_seo.class.php';
class plugin_seo {
	function __construct() {
	} 
	function is_ie() {
		$str = preg_match('/MSIE ([0-9]\.[0-9])/', $_SERVER['HTTP_USER_AGENT'], $matches);
		if ($str == 0) {
			return 0;
		} else {
			return floatval($matches[1]);
		} 
	} 
	function is_ff() {
		$str = preg_match('/Firefox/', $_SERVER['HTTP_USER_AGENT'], $matches);
		if ($str == 0) {
			return false;
		} else {
			return true;
		} 
	} 
	function global_footerlink() {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$share1 = $config ['share1'];
		$isnot = $config ['isnot'];
		$sharecode1 = $config ['sharecode1'];
		if ($isnot) {
			if ($share1) {
				return $sharecode1;
			} 
		} 
	} 
	function common() {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';
		if (file_exists ($settingfile)) {
			include $settingfile;
		} 
		if (file_exists (DISCUZ_ROOT . './data/cache/cache_seo_setting.php')) {
			$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
			include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
		} 
		$the_host = $_SERVER ['HTTP_HOST'];
		//debug($_SERVER);
		$serversoft = $_SERVER['SERVER_SOFTWARE'];
		if(strpos($serversoft,'Apache')!==false){
			$the_uri = isset ($_SERVER ['REQUEST_URI']) ? $_SERVER ['REQUEST_URI'] : '';
		}else{
			$the_uri = isset ($_SERVER ['HTTP_X_REWRITE_URL']) ? $_SERVER ['HTTP_X_REWRITE_URL'] : '';
		}
		if ($the_uri == '/') {
			$the_uri = '';
		} 

		$the_url = $the_host . $the_uri;
		$rewrite = $seo_setting['rewrite'];
		if ($rewrite) {
			$rulearray = explode("\n", $rewrite);
			foreach($rulearray as $value) {
				$value = explode("->", trim($value));
				if (trim($value[0]) == $the_url) {
					header ('HTTP/1.1 301 Moved Permanently');
					header ("Location: http://" . trim($value[1]));
				} 
			} 
		} 
		$tid = addslashes($_GET['tid']);
		$aid = addslashes($_GET['aid']);
		if ($tid) {
			$type = 0;
		} else if ($aid) {
			$tid = $aid;
			$type = 1;
		} else {
			$type = 2;
		} 
		$spiderarray = array(0 => 'baiduspider', 1 => 'googlebot', 15 => 'sogou web spider', 25 => '360spider', 30 => 'sosospider');
		$spidername = array(0 => lang('plugin/seo', 'c20'), 1 => lang('plugin/seo', 'g1'), 15 => 'sogou web spider', 25 => '360spider', 30 => 'sosospider');
		$serverport = $_SERVER["SERVER_PORT"];
		$string = $_SERVER["QUERY_STRING"];
		$serverip = $_SERVER["REMOTE_ADDR"];
		$url = "http://" . $_SERVER["SERVER_NAME"];
		if ($serverport !== "80") {
			$url .= ":" . $ServerPort;
		} 
		$url .= $the_uri?$the_uri:($_SERVER['PHP_SELF']?$_SERVER['PHP_SELF']:$_SERVER['SCRIPT_NAME']);

		$agent = strtolower($_SERVER["HTTP_USER_AGENT"]);
		foreach ($spiderarray as $key => $value) {
			if (strpos($agent, $value) !== false) {
				$spider = $spidername[$key];
			} 
		} 

		if (!empty($spider)) {
			$spiderdata = array('tid' => $tid,
				'type' => $type,
				'spider' => $spider,
				'spidertime' => $_G['timestamp'],
				'spiderurl' => $url,
				'spiderip' => $serverip,
				);
			DB :: insert('plugin_seo_spider', $spiderdata);
		} 
		if ($seo_setting['jiankong'] && $seo_setting['x4'] && $seo_setting['cleartime'] != date('Ymd')) {
			$time = $_G['timestamp'] - $seo_setting['jiankong'] * 86400;
			$sql = "delete from " . DB :: table("plugin_seo_ping") . " where dateline<'" . $time . "'";
			DB :: query($sql);
			$sql = "delete from " . DB :: table("plugin_seo_spider") . " where spidertime<'" . $time . "'";
			DB :: query($sql);
			$seo_setting['cleartime'] = date('Ymd');
			require_once libfile('function/cache');
			writetocache('seo_setting', getcachevars(array('seo_setting' => $seo_setting))); //����������������д�뻺��
		} 

		$domain = $_G['setting']['domain'];
		$defaultdomain = $_G['setting']['domain']['app']['default'];
		$defaultindex = $_G['setting']['domain']['defaultindex'];

		$isnot = $config ['isnot'];
		$domains = $config ['domains'];
		$isindex = $config ['index'];
		$simple = $config ['simple'];
		if ($isnot) {
			$url = $config ['url'];
			if ($url) {
				if (!$defaultdomain) {
					$defaultdomain = $url;
				} 
				$select = $config ['select'];
				$the_host = $_SERVER ['HTTP_HOST'];
				$request_uri = isset ($the_uri) ? $the_uri : '';
				//debug($request_uri);
				$rewriterule = $_G ['setting'] ['rewriterule'];
				$status = $_G ['setting'] ['rewritestatus'];

				$b1 = $seo_setting['b1'];
				if (!$simple && $b1) {
					$a3 = $seo_setting['a3'];
					$b2 = $seo_setting['b2'];
					$b3 = $seo_setting['b3'];
					$b4 = $seo_setting['b4'];
					$b5 = $seo_setting['b5'];
					$b6 = $seo_setting['b6'];
					if (in_array ('forum_viewthread', $status)) {
						$viewthreadmod = $rewriterule ['forum_viewthread'];
						$viewthreadmod = preg_replace ("/{page}/", "([0-9]+)", $viewthreadmod);
						$viewthreadmod = preg_replace ("/{prevpage}/", "([0-9]+)", $viewthreadmod);
						$viewthreadmod = str_replace ("{id}", '([0-9]+)', $viewthreadmod);
						$viewthreadmod = str_replace ("{fid}", '([0-9]+)', $viewthreadmod);
						$viewthreadmod = str_replace ("{tid}", '([0-9]+)', $viewthreadmod);
						$viewthreadmod = str_replace ("{blogid}", '([0-9]+)', $viewthreadmod);
						$viewthreadmod = '\/' . str_replace (".", '\.', $viewthreadmod);
						$page = $_GET['page']?$_GET['page']:'1';
						$prevpage = $_GET['prevpage']?$_GET['prevpage']:'1';
						$viewthreadmod1 = $rewriterule ['forum_viewthread'];
						$viewthreadmod1 = str_replace ("{tid}", $_GET['tid'], $viewthreadmod1);
						$viewthreadmod1 = str_replace ("{page}", $page, $viewthreadmod1);
						$viewthreadmod1 = preg_replace ("/{prevpage}/", $prevpage, $viewthreadmod1);
						$viewthreadmod1 = '/' . $viewthreadmod1;

						$viewthreadmod2 = "\/forum.php\?mod=viewthread\&tid=([0-9]+).*?";
					} 
					if (in_array ('forum_forumdisplay', $status)) {
						$forumdisplaymod = $rewriterule ['forum_forumdisplay'];
						$forumdisplaymod = preg_replace ("/{page}/", "([0-9]+)", $forumdisplaymod);
						$forumdisplaymod = preg_replace ("/{prevpage}/", "([0-9]+)", $forumdisplaymod);
						$forumdisplaymod = str_replace ("{id}", '([0-9]+)', $forumdisplaymod);
						$forumdisplaymod = str_replace ("{fid}", '([0-9]+)', $forumdisplaymod);
						$forumdisplaymod = str_replace ("{tid}", '([0-9]+)', $forumdisplaymod);
						$forumdisplaymod = str_replace ("{blogid}", '([0-9]+)', $forumdisplaymod);
						$forumdisplaymod = '\/' . str_replace (".", '\.', $forumdisplaymod);

						$page = $_GET['page']?$_GET['page']:'1';
						$forumdisplaymod1 = $rewriterule ['forum_forumdisplay'];
						$forumdisplaymod1 = str_replace ("{fid}", $_GET['fid'], $forumdisplaymod1);
						$forumdisplaymod1 = str_replace ("{page}", $page, $forumdisplaymod1);
						$forumdisplaymod1 = '/' . $forumdisplaymod1;

						$forumdisplaymod2 = "\/forum.php\?mod=forumdisplay\&fid=([0-9]+)\&page=([0-9]+).*?";
					} 
					if (in_array ('group_group', $status)) {
						$groupmod = $rewriterule ['group_group'];
						$groupmod = preg_replace ("/{page}/", "([0-9]+)", $groupmod);
						$groupmod = preg_replace ("/{prevpage}/", "([0-9]+)", $groupmod);
						$groupmod = str_replace ("{id}", '([0-9]+)', $groupmod);
						$groupmod = str_replace ("{fid}", '([0-9]+)', $groupmod);
						$groupmod = str_replace ("{tid}", '([0-9]+)', $groupmod);
						$groupmod = str_replace ("{blogid}", '([0-9]+)', $groupmod);
						$groupmod = '\/' . str_replace (".", '\.', $groupmod);

						$groupmod1 = $rewriterule ['group_group'];
						$groupmod1 = str_replace ("{fid}", $_GET['fid'], $groupmod1);
						$groupmod1 = str_replace ("{page}", $_GET['page'], $groupmod1);
						$groupmod1 = '/' . $groupmod1;

						$groupmod2 = "\/forum.php\?mod=group\&fid=([0-9]+)\&page=([0-9]+).*?";
					} 
					if (in_array ('home_space', $status)) {
						$spacemod = $rewriterule ['home_space'];
						$spacemod = preg_replace ("/{page}/", "([0-9]+)", $spacemod);
						$spacemod = preg_replace ("/{prevpage}/", "([0-9]+)", $spacemod);
						$spacemod = str_replace ("{id}", '([0-9]+)', $spacemod);
						$spacemod = str_replace ("{fid}", '([0-9]+)', $spacemod);
						$spacemod = str_replace ("{tid}", '([0-9]+)', $spacemod);
						$spacemod = str_replace ("{value}", '([0-9]+)', $spacemod);
						$spacemod = str_replace ("{user}", 'uid', $spacemod);
						$spacemod = str_replace ("{blogid}", '([0-9]+)', $spacemod);
						$spacemod = '\/' . str_replace (".", '\.', $spacemod);

						$spacemod1 = $rewriterule ['home_space'];
						$spacemod1 = str_replace ("{user}", 'uid', $spacemod1);
						$spacemod1 = str_replace ("{value}", $_GET['uid'], $spacemod1);
						$spacemod1 = '/' . $spacemod1;

						$spacemod2 = "\/home.php\?mod=space\&uid=([0-9]+).*?";
					} 
					if (in_array ('home_blog', $status)) {
						$blogmod = $rewriterule ['home_blog'];
						$blogmod = preg_replace ("/{page}/", "([0-9]+)", $blogmod);
						$blogmod = preg_replace ("/{prevpage}/", "([0-9]+)", $blogmod);
						$blogmod = str_replace ("{id}", '([0-9]+)', $blogmod);
						$blogmod = str_replace ("{uid}", '([0-9]+)', $blogmod);
						$blogmod = str_replace ("{fid}", '([0-9]+)', $blogmod);
						$blogmod = str_replace ("{tid}", '([0-9]+)', $blogmod);
						$blogmod = str_replace ("{value}", '([0-9]+)', $blogmod);
						$blogmod = str_replace ("{user}", 'uid', $blogmod);
						$blogmod = str_replace ("{blogid}", '([0-9]+)', $blogmod);
						$blogmod = '\/' . str_replace (".", '\.', $blogmod);

						$blogmod1 = $rewriterule ['home_blog'];
						$blogmod1 = str_replace ("{blogid}", $_GET['id'], $blogmod1);
						$blogmod1 = str_replace ("{uid}", $_GET['uid'], $blogmod1);
						$blogmod1 = '/' . $blogmod1;
						$blogmod2 = "\/home.php\?mod=space\&uid=([0-9]+)\&do=blog&id=([0-9]+).*?";
					} 

					if ($b6 || !$domain['app']['forum']) {
						$url6 = $url;
					} else {
						$url6 = $domain['app']['forum'];
					} 
					if ($a3) {
						if ($the_host != $url6 || preg_match('/' . $viewthreadmod2 . '/', $request_uri)) {
							if (preg_match('/' . $viewthreadmod . '/', $request_uri) || preg_match('/' . $viewthreadmod2 . '/', $request_uri)) {
								header ('HTTP/1.1 301 Moved Permanently');
								header ("Location: http://" . $url6 . $viewthreadmod1);
							} 
						} 
					} else {
						if ($the_host != $url6) {
							if (preg_match('/' . $viewthreadmod . '/', $request_uri) || preg_match('/' . $viewthreadmod2 . '/', $request_uri)) {
								header ('HTTP/1.1 301 Moved Permanently');
								header ("Location: http://" . $url6 . $request_uri);
							} 
						} 
					} 

					if ($b5 || !$domain['app']['forum']) {
						$url5 = $url;
					} else {
						$url5 = $domain['app']['forum'];
					} 
					if ($a3) {
						if ($the_host != $url5 || preg_match('/' . $forumdisplaymod2 . '/', $request_uri)) {
							if (preg_match('/' . $forumdisplaymod . '/', $request_uri) || preg_match('/' . $forumdisplaymod2 . '/', $request_uri)) {
								header ('HTTP/1.1 301 Moved Permanently');
								header ("Location: http://" . $url5 . $forumdisplaymod1);
							} 
						} 
					} else {
						if ($the_host != $url5 || preg_match('/' . $forumdisplaymod2 . '/', $request_uri)) {
							if (preg_match('/' . $forumdisplaymod . '/', $request_uri)) {
								header ('HTTP/1.1 301 Moved Permanently');
								header ("Location: http://" . $url5 . $request_uri);
							} 
						} 
					} 
					if ($b3 || !$domain['app']['group']) {
						$url3 = $url;
					} else {
						$url3 = $domain['app']['group'];
					} 
					if ($a3) {
						if ($the_host != $url3 || preg_match('/' . $groupmod2 . '/', $request_uri)) {
							if (preg_match('/' . $groupmod . '/', $request_uri) || preg_match('/' . $groupmod2 . '/', $request_uri)) {
								header ('HTTP/1.1 301 Moved Permanently');
								header ("Location: http://" . $url3 . $groupmod1);
							} 
						} 
					} else {
						if ($the_host != $url3) {
							if (preg_match('/' . $groupmod . '/', $request_uri)) {
								header ('HTTP/1.1 301 Moved Permanently');
								header ("Location: http://" . $url3 . $request_uri);
							} 
						} 
					} 
					if ($b4 || !$domain['app']['home']) {
						$url4 = $url;
					} else {
						$url4 = $domain['app']['home'];
					} 
					if ($a3) {
						if ($the_host != $url4 || preg_match('/' . $spacemod2 . '/', $request_uri)) {
							if (preg_match('/' . $spacemod . '/', $request_uri) || preg_match('/' . $spacemod2 . '/', $request_uri)) {
								header ('HTTP/1.1 301 Moved Permanently');
								header ("Location: http://" . $url4 . $spacemod1);
							} 
						} 
					} else {
						if ($the_host != $url4) {
							if (preg_match('/' . $spacemod . '/', $request_uri) || preg_match('/' . $spacemod2 . '/', $request_uri)) {
								header ('HTTP/1.1 301 Moved Permanently');
								header ("Location: http://" . $url4 . $request_uri);
							} 
						} 
					} 
					if ($b2 || !$domain['app']['home']) {
						$url2 = $url;
					} else {
						$url2 = $domain['app']['home'];
					} 
					if ($a3) {
						if ($the_host != $url2 || preg_match('/' . $blogmod2 . '/', $request_uri)) {
							if (preg_match('/' . $blogmod . '/', $request_uri) || preg_match('/' . $blogmod2 . '/', $request_uri)) {
								header ('HTTP/1.1 301 Moved Permanently');
								header ("Location: http://" . $url2 . $blogmod1);
							} 
						} 
					} else {
						if ($the_host != $url2) {
							if (preg_match('/' . $blogmod . '/', $request_uri) || preg_match('/' . $blogmod2 . '/', $request_uri)) {
								header ('HTTP/1.1 301 Moved Permanently');
								header ("Location: http://" . $url2 . $blogmod1);
							} 
						} 
					} 
					if ($select && $domain['app']) {
						if ((strtolower ($request_uri) == "/forum.php" && $defaultindex == 'forum.php') || (strtolower ($request_uri) == "/forum.php" && $domain['app']['forum'])) {
							header ('HTTP/1.1 301 Moved Permanently');
							$request_uri = "/";
							if (!$domain['app']['forum']) {
								$urlx = $url;
							} else {
								$urlx = $domain['app']['forum'];
							} 
							header ("Location: http://" . $urlx . $request_uri);
						} 
					} 
					if ($isindex && $domain['app']) {
						if (strtolower ($request_uri) == "/portal.php" && $defaultindex == 'portal.php') {
							header ('HTTP/1.1 301 Moved Permanently');
							$request_uri = "/";
							header ("Location: http://" . $url . $request_uri);
						} 
					} 
				} else if ($simple) {
					$urlarray = explode("\r\n", $domains);
					if ($the_host != $url && !in_array($the_host, $urlarray)&&CURMODULE!='platform'&&CURMODULE!='super_outer_chain'&&CURMODULE!='ljexam') {
						
						header ('HTTP/1.1 301 Moved Permanently');
						header ("Location: http://" . $url . $request_uri);
					} 
				} 

				if ($select) {
					if (strtolower ($request_uri) == "/forum.php" && $defaultindex == 'forum.php') {
						header ('HTTP/1.1 301 Moved Permanently');
						$request_uri = "/";
						header ("Location: http://" . $url . $request_uri);
					}
				} else if ($isindex) {
					if (strtolower ($request_uri) == "/portal.php" && $defaultindex == 'portal.php') {
						header ('HTTP/1.1 301 Moved Permanently');
						$request_uri = "/";
						header ("Location: http://" . $url . $request_uri);
					} 
				} 
			} 
		} 
	} 
} 
class plugin_seo_forum extends plugin_seo {
	function post_checkreply() {
		$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';
		if (file_exists ($settingfile)) {
			include $settingfile;
		} 
		if (file_exists (DISCUZ_ROOT . './data/cache/cache_seo_setting.php')) {
			$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
			include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
		} 
		$edit_thread = $seo_setting ['edit_thread'];
		if ($_GET ['topicsubmit'] || ($_GET['editsubmit'] && $edit_thread)) {
			// if ($_GET ['topicsubmit']) {
			global $_G;
			$config = $_G ['cache'] ['plugin'] ['seo'];
			$wwforums = $config ['wwforums'];
			$wuser = $config ['wuser'];
			$wuser = unserialize ($wuser);
			$groupid = $_G ['groupid'];
			$wwforums = unserialize ($wwforums);
			$fid = addslashes($_GET ['fid']);
			$issuper = $seo_setting['issuper'];
			if (!$issuper) {
				if (in_array ($groupid, $wuser)) {
					if (in_array ($fid, $wwforums)) {
						if ($seo_setting ['allow_thesaurus']) {
							$words = array ();
							$str = str_replace ("\r", "", $seo_setting ['thesaurus_setting']);
							$arr = explode ("\n", $str);
							foreach ($arr as $k => $v) {
								if ($v) {
									$str_data = explode ("=", $v);
									$words += array ("$str_data[0]" => "$str_data[1]");
								} 
							} 
							$words = array_unique($words);
							$_GET ['message'] = strtr (addslashes($_GET ['message']), $words);
						} 
						if ($seo_setting ['allow_title']) {
							$words = array ();
							$str = str_replace ("\r", "", $seo_setting ['thesaurus_setting']);
							$arr = explode ("\n", $str);
							foreach ($arr as $k => $v) {
								if ($v) {
									$str_data = explode ("=", $v);
									$words += array ("$str_data[0]" => "$str_data[1]");
								} 
							} 
							$words = array_unique($words);
							$_GET ['subject'] = strtr (addslashes($_GET ['subject']), $words);
						} 
					} 
				} 
			} 
		} 
	} 
	function post_top() {
		global $_G;
		$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';
		if (file_exists ($settingfile)) {
			include $settingfile;
		} 
		if (file_exists (DISCUZ_ROOT . './data/cache/cache_seo_setting.php')) {
			$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
			include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
		} 
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$yforums = $config ['yforums'];
		$yuser = $config ['yuser'];
		$yuser = unserialize ($yuser);
		$groupid = $_G ['groupid'];
		$yforums = unserialize ($yforums);
		$fid = addslashes($_GET ['fid']);
		$allow_cloud = $seo_setting['allow_cloud'];
		if ($allow_cloud) {
			if (in_array ($groupid, $yuser)) {
				if (in_array ($fid, $yforums)) {
					$seocloudname = lang ('plugin/seo', 'seocloudname');
					$tips = $seo_setting['allow_tips'];
					if ($seo_setting['ftype'] == 'f1') {
						$ftype = 'www.yuxinqi.info';
					} else {
						$ftype = 'www.seoeye.cn';
					} 
					include template ('seo:seocloud');
				} 
			} 
		} 
		return $return;
	} 
	function viewthread_seo_output($param, $param1) {
		global $_G;
	} 
	function viewthread_useraction() {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$share = $config ['share'];
		$weizhi = $config ['weizhi'];
		if ($weizhi == 3 && $share) {
			$sharecode = $config ['sharecode'];
		} 
		return $sharecode;
	} 
	function viewthread_postfooter() {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$share = $config ['share'];
		$weizhi = $config ['weizhi'];
		if ($weizhi == 4 && $share) {
			$sharecode = $config ['sharecode'];
			if ($sharecode) {
				$v = $this -> is_ie();
				if ($v <= 6 && $v != 0) {
					$sharecode = '<div style="float:right;position:relative;top:-16px;">' . $sharecode . '</div>';
				} else if ($v == 7) {
					$sharecode = '<div style="float:right;position:relative;top:-20px;">' . $sharecode . '</div>';
				} else if ($this -> is_ff()) {
					$sharecode = '<div style="float:right;">' . $sharecode . '</div>';
				} else {
					$sharecode = '<div style="float:right;position:relative;top:-6px;">' . $sharecode . '</div>';
				} 
			} 
		} 
		return array($sharecode);
	} 
	function viewthread_title_extra() {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$weizhi = $config ['weizhi'];
		$share = $config ['share'];
		if ($weizhi == 1 && $share) {
			$sharecode = $config ['sharecode'];
			if ($sharecode) {
				$v = $this -> is_ie();
				if ($v <= 6 && $v != 0) {
					$sharecode = '<div style="float:right;position:relative;top:-16px;">' . $sharecode . '</div>';
				} else if ($v == 7) {
					$sharecode = '<div style="float:right;position:relative;top:-20px;">' . $sharecode . '</div>';
				} else if ($this -> is_ff()) {
					$sharecode = '<div style="float:right;">' . $sharecode . '</div>';
				} else {
					$sharecode = '<div style="float:right;position:relative;top:-6px;">' . $sharecode . '</div>';
				} 
			} 
			// debug($weizhi);
		} 
		return $sharecode;
	} 
	function viewthread_postheader() {
		if(empty($_GET['inajax'])){
		global $_G;
		$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';
		if (file_exists ($settingfile)) {
			include $settingfile;
		} 
		if (file_exists (DISCUZ_ROOT . './data/cache/cache_seo_setting.php')) {
			$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
			include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
		} 
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$share = $config ['share'];
		$isnot = $config ['isnot'];
		$weizhi = $config ['weizhi'];
		$sharecode = $config ['sharecode'];
		$issuper = $seo_setting['issuper'];
		$wwforums = $config ['wwforums'];
		$groupid = $_G ['groupid'];
		$wwforums = unserialize ($wwforums);
		$wuser = $config ['wuser'];
		$wuser = unserialize ($wuser);
		$tid = addslashes($_GET['tid']);
		if ($tid) {
			$thread = DB :: fetch_first("select * from " . DB :: table('forum_thread') . " where tid=$tid");
			$fid = $thread['fid'];
			$authorid = $thread['authorid'];
			if ($authorid) {
				$authorgroupid = DB :: result_first("select groupid from " . DB :: table('common_member') . " where uid=$authorid");
				if ($issuper && $groupid == 1 && in_array ($fid, $wwforums) && in_array ($authorgroupid, $wuser)) {
					$super = $_GET['super'];
					if ($super) {
						$str = '|&nbsp;&nbsp;<a href="forum.php?mod=viewthread&tid=' . $tid . '">' . lang('plugin/seo', 'x11') . '</a>';
					} else {
						$str = '|&nbsp;&nbsp;<a href="forum.php?mod=viewthread&tid=' . $tid . '&super=1">' . lang('plugin/seo', 'x22') . '</a>';
					} 
				} 
			} 
		} 
		if ($sharecode) {
			$v = $this -> is_ie();
			if ($v <= 6 && $v != 0) {
				$sharecode = '<div style="float:right;position:relative;top:-16px;">' . $sharecode . '</div>';
			} else if ($v == 7) {
				$sharecode = '<div style="float:right;position:relative;top:-20px;">' . $sharecode . '</div>';
			} else if ($this -> is_ff()) {
				$sharecode = '<div style="float:right;">' . $sharecode . '</div>';
			} else {
				$sharecode = '<div style="float:right;position:relative;top:-6px;">' . $sharecode . '</div>';
			} 
		} 
		$yun = $config['yun'];
		$myarray = array();
		$tid = addslashes($_GET['tid']);
		if ($tid) {
			if ($isnot) {
				if ($yun) {
					$the_host = $_SERVER ['HTTP_HOST'];
					$b = "http://" . $the_host;
					$web_root = $_G ['siteurl'];
					if (substr($web_root, -1) != '/') {
						$web_root = $web_root . '/';
					} 
					$rewriterule = $_G ['setting'] ['rewriterule'];
					$status = $_G ['setting'] ['rewritestatus'];

					$fid = DB :: result_first("SELECT fid FROM " . DB :: table('forum_thread') . " where tid=$tid");
					$displayorder = DB :: result_first("SELECT displayorder FROM " . DB :: table('forum_thread') . " where tid=$tid");
					$subject = DB :: result_first("SELECT subject FROM " . DB :: table('forum_thread') . " where tid=$tid");
					$pforums = $config ['pforums'];
					$puser = $config ['puser'];
					$puser = unserialize ($puser);
					$groupid = $_G ['groupid'];
					$pforums = unserialize ($pforums);
					if (in_array ($groupid, $puser)) {
						if (in_array ($fid, $pforums)) {
							if (in_array ('forum_viewthread', $status)) {
								$mod = $rewriterule ['forum_viewthread'];
								$mod = preg_replace ("/{page}/", "1", $mod);
								$mod = preg_replace ("/{prevpage}/", "1", $mod);
								$mod = str_replace ("{id}", $tid, $mod);
								$mod = str_replace ("{fid}", $tid, $mod);
								$mod = str_replace ("{tid}", $tid, $mod);
								$mod = str_replace ("{blogid}", $tid, $mod);
								$turl = $web_root . $mod;
							} else {
								$turl = $web_root . "forum.php?mod=viewthread&amp;tid=" . $tid;
							} 
							$e = $_G ['setting'] ['bbname'];
							$type = 0;
							$check = DB :: result_first("select count(*) from " . DB :: table("plugin_seo_ping") . " where tid=" . $tid);
							if (!$check) {
								if ($_G['charset'] == 'utf-8') {
									$subject = iconv('gbk', 'utf-8', $subject);
								} 
								$myarray[0] = '<script src="source/plugin/seo/js/jquery.min.js"></script><script>var jq = jQuery.noConflict();jq.getJSON("http://www.seoeye.cn/mycloud.php?callback=?",{turl:"' . $turl . '",b: "' . $web_root . '",e:"' . $e . '",displayorder:"' . $displayorder . '",host:"' . $the_host . '",charset:"' . $charset . '"},function(data) {jq.get("plugin.php?id=seo:precord&op=add",{result:data.result,gsign:data.gsign,tid:"' . $tid . '",type:"' . $type . '",subject:"' . $subject . '",b:"' . $turl . '"});})</script>';
							} 
						} 
					} 
				} 
			} 
			if ($share && $weizhi == 2) {
				$myarray[0] .= $sharecode;
			} 
			if ($str) {
				$myarray[0] .= $str;
			} 
		} 
	}
		return $myarray;
		
	} 
	function viewthread_newthread_output() {
		global $_G, $postlist, $skipaids, $post;
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';
		if (file_exists ($settingfile)) {
			include $settingfile;
		} 
		if (file_exists (DISCUZ_ROOT . './data/cache/cache_seo_setting.php')) {
			$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
			include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
		} 
		$super = addslashes($_GET['super']);
		$tid = addslashes($_GET['tid']);
		if ($tid&&eregi("^[0-9]+$",$tid)) {
			$uid = $_G['uid'];
			
			$issuper = $seo_setting['issuper'];
			$isuid = $seo_setting['isuid'];
			$warr = DB :: result_first("select count(*) from " . DB :: table('plugin_seo_thread') . " where tid=$tid ");
			$pid = DB :: result_first("select pid from " . DB :: table('forum_post') . " where tid=$tid and first=1");
			$parr = DB :: fetch_first(' select * from ' . DB :: table('forum_post') . " where tid=$tid and first=1");
			$subject = $parr['subject'];
			$message = $parr['message'];
			$dateline = $parr['dateline'];
			$thread = DB :: fetch_first("select * from " . DB :: table('forum_thread') . " where tid=$tid");
			$fid = $thread['fid'];
			$authorid = $thread['authorid'];
			if ($authorid) {
				$authorgroupid = DB :: result_first("select groupid from " . DB :: table('common_member') . " where uid=$authorid"); 
				//Զ��
				$isremote = $config ['isremote'];
				$remotebk = $config ['remotebk'];
				$remotebk = unserialize ($remotebk);
				$remoteuser = $config ['remoteuser'];
				$remoteuser = unserialize ($remoteuser);
				if($isremote){
					if (in_array ($authorgroupid, $remoteuser)) {
						if (in_array ($fid, $remotebk)) {
							
								$tid=addslashes($_GET['tid']);
								$thepost=DB::fetch_first("select pid,authorid from ".DB::table('forum_post')." where tid=$tid and first=1");
								$lj_ljremote=new lj_seo();//���Բ��Բ��Բ��Բ��Բ��Բ��Բ���
								$lj_ljremote->updatemessage($thepost['pid'],$thepost['authorid']);
							}
						}
				}
				//Զ��
				$iswailian = $config ['iswailian'];
				$replacenum = $config ['replacenum'];
				$wlsj = $config ['wlsj'];
				$times = ($dateline + $wlsj * 24 * 60 * 60) < $_G[timestamp];
				if ($iswailian && $times&&$postlist[$pid][message]) {
					$users = $config ['users'];
					$fids = $config ['fids'];
					$users = unserialize ($users);
					
					$fids = unserialize ($fids);
					if (!in_array ($authorgroupid, $users)) {
						if (!in_array ($fid, $fids)) {
							// $pid = DB :: result_first("select pid from " . DB :: table('forum_post') . " where tid=$tid and first=1"); 
							// �����б�
							$siteurl = $_G['siteurl'];
							$siteurl = str_replace('http://', '', $siteurl);
							if (substr($siteurl, -1) == '/') {
								$siteurl = str_replace('/', '', $siteurl);
							} 
							$siteurl = $siteurl . '|'; 
							// $urls=array('http://www.seoeye.cn/','www.163.com/');
							$urllist = $config ['urllist'];
							$urllist = explode("\r\n", $urllist); 
							// debug($urllist);
							foreach($urllist as $k => $v) {
								$v = str_replace('http://', '', $v);
								if (substr($v, -1) == '/') {
									$v = str_replace('/', '', $v);
								} 
								$siteurl .= $v . '|';
							} 
							$siteurl = trim($siteurl, '|');
							//$postlist[$pid][message] = preg_replace('/<[^>]*href=[\'\"]http:\/\/(?!'.'www.seoeye.cn'.')[^\'^\"]*[\'\"][^>]*>(.+?)<\/a>/is', "$1", ); 
							//$me=$postlist[$pid][message];
							$postlist[$pid][message] = preg_replace('/<[^>]*href=[\'\"]http:\/\/(?!'.$siteurl.')[^\'^\"]*[\'\"][^>]*>(.*?)<\/a>/is', "$1", $postlist[$pid][message]); 
							// debug($postlist[$pid][message]);
							// $pattern='/<[^>]*href=[\'\"]http?:\/\/(?!www\.seoeye\.cn|seoeye\.cn|[\w\_]+\.www\.163\.com)[^\'^\"]*[\'\"][^>]*>(.+?)<\/a>/is';
						} 
					} 
				} 
				//
				$aac=DB::result_first("select count(*) from ".DB::table('plugin_seo_gjz'));
				if($postlist[$pid][message]&&$aac){
					$query=DB::query("select * from ".DB::table('plugin_seo_gjz'));

					while($data=DB::fetch($query)){
						$mydata[]=$data;	
					}
					foreach($mydata as $kk=>$vv){
							$a=$vv[newname];
							if($vv[b]){
								$a='<b>'.$vv[newname].'</b>';
							}
							if($vv[i]){
								$a='<i>'.$a.'</i>';
							}
							if($vv[u]){
								$a='<u>'.$a.'</u>';
							}
							$gjz[$vv[newname]]='<a href="'.$vv[newurl].'" style="color:'.$vv[c].'" >'.$a.'</a>';
						}
					if($replacenum){
						foreach($gjz as $k=>$v){
							if(!preg_match('/<img.*?'.$k.'.*?>/is',$postlist[$pid][message])){
								//debug(3432);
								$postlist[$pid][message] = preg_replace("/$k/",$v,$postlist[$pid][message],$replacenum);
							}
							
						}
					
					}else{
						
						$postlist[$pid][message] = strtr ($postlist[$pid][message], $gjz); //���ؽ�� 
					}
				
				}
				//
				$groupid = $_G ['groupid'];
				$config = $_G ['cache'] ['plugin'] ['seo'];
				$wwforums = $config ['wwforums'];
				$wuser = $config ['wuser'];
				$wuser = unserialize ($wuser);
				$wwforums = unserialize ($wwforums);
				if (!$warr) {
					
					if (in_array ($authorgroupid, $wuser)) {
						if (in_array ($fid, $wwforums)) {
							if ($seo_setting ['allow_thesaurus']) {
								// ͬ����滻�ؼ�����
								$words = array ();
								$str = str_replace ("\r", "", $seo_setting ['thesaurus_setting']);
								$arr = explode ("\n", $str);
								foreach ($arr as $k => $v) {
									if ($v) {
										$str_data = explode ("=", $v);
										$words += array ("$str_data[0]" => "$str_data[1]");
									} 
								} //debug($_GET ['message']);
								$words = array_unique($words);
								$message = strtr ($message, $words); //���ؽ�� 
								
							} 

							if ($seo_setting ['allow_title']) {
								// ͬ����滻�ؼ�����
								$words = array ();
								$str = str_replace ("\r", "", $seo_setting ['thesaurus_setting']);
								$arr = explode ("\n", $str);
								foreach ($arr as $k => $v) {
									if ($v) {
										$str_data = explode ("=", $v);
										$words += array ("$str_data[0]" => "$str_data[1]");
									} 
								} 
								$words = array_unique($words);
								$subject = strtr ($subject, $words); //���ؽ��
							} 
							// debug($postlist);
							// $_GET ['message']=$_GET ['message'].'123';
							// debug($_GET ['message']);
							$insertarray = array('uid' => $authorid, 'fid' => $fid, 'tid' => $tid, 'title' => $subject, 'message' => $message);

							DB :: insert('plugin_seo_thread', $insertarray);
						} 
					} 
				} 
				
				// �ѵ����ӱ�����ʱ�Ƿ�αԭ����������ͨ�û����ʻ���������ֿ�ò����ж����ֿ�
				if (($super == 1 || IS_ROBOT || empty($isuid) && !$uid ) && $issuper && in_array ($authorgroupid, $wuser) && in_array ($fid, $wwforums)&&$postlist[$pid][message]) {
					$arr = DB :: fetch_first(' select title,message from ' . DB :: table('plugin_seo_thread') . " where tid=$tid");
					if ($arr['title'] && $arr['message']) {
						$title = $arr['title'];
						$message = $arr['message'];
						$subject = $title;
						$postlist[$pid][message] = $message; 
						$postlist[$pid][dateline] = $dateline; 
						// $postlist[$pid][dateline] = dgmdate($dateline, 'u', '9999', getglobal('setting/dateformat').' H:i:s');
						// debug($postlist[$pid][dateline]);
						$check = $postlist[$pid]['attachments'];
						$postlist[$pid] = viewthread_procpost($postlist[$pid], $_G['member']['lastvisit'], $ordertype, $maxposition);

						if ($check) {
							parseattach($_G['forum_attachpids'], $_G['forum_attachtags'], $postlist, $skipaids);
						} 
						$_G[forum_thread][short_subject] = $title;
						$_G[forum_thread][subject] = $title;
						
						$iswailian = $config ['iswailian'];
				$wlsj = $config ['wlsj'];
				$times = ($dateline + $wlsj * 24 * 60 * 60) < $_G[timestamp];
				if ($iswailian && $times&&$postlist[$pid][message]) {
					$users = $config ['users'];
					$fids = $config ['fids'];
					$users = unserialize ($users);
					$fids = unserialize ($fids);
					if (!in_array ($authorgroupid, $users)) {
						if (!in_array ($fid, $fids)) {
							// $pid = DB :: result_first("select pid from " . DB :: table('forum_post') . " where tid=$tid and first=1"); 
							// �����б�
							$siteurl = $_G['siteurl'];
							$siteurl = str_replace('http://', '', $siteurl);
							if (substr($siteurl, -1) == '/') {
								$siteurl = str_replace('/', '', $siteurl);
							} 
							$siteurl = $siteurl . '|'; 
							// $urls=array('http://www.seoeye.cn/','www.163.com/');
							$urllist = $config ['urllist'];
							$urllist = explode("\r\n", $urllist); 
							// debug($urllist);
							foreach($urllist as $k => $v) {
								$v = str_replace('http://', '', $v);
								if (substr($v, -1) == '/') {
									$v = str_replace('/', '', $v);
								} 
								$siteurl .= $v . '|';
							} 
							$siteurl = trim($siteurl, '|');
							$postlist[$pid][message] = preg_replace('/<[^>]*href=[\'\"]http:\/\/(?!'.$siteurl.')[^\'^\"]*[\'\"][^>]*>(.*?)<\/a>/is', "$1", $postlist[$pid][message]); 
							
						}
					}
				}
				//
				$aac=DB::result_first("select count(*) from ".DB::table('plugin_seo_gjz'));
				if($postlist[$pid][message]&&$aac){
					$query=DB::query("select * from ".DB::table('plugin_seo_gjz'));

					while($data=DB::fetch($query)){
						$mydata[]=$data;	
					}
					foreach($mydata as $kk=>$vv){
							$a=$vv[newname];
							if($vv[b]){
								$a='<b>'.$vv[newname].'</b>';
							}
							if($vv[i]){
								$a='<i>'.$a.'</i>';
							}
							if($vv[u]){
								$a='<u>'.$a.'</u>';
							}
							$gjz[$vv[newname]]='<a href="'.$vv[newurl].'" style="color:'.$vv[c].'" >'.$a.'</a>';
						}
					if($replacenum){
						foreach($gjz as $k=>$v){
							if(!preg_match('/<img.*?'.$k.'.*?>/is',$postlist[$pid][message])){
								//debug(3432);
								$postlist[$pid][message] = preg_replace("/$k/",$v,$postlist[$pid][message],$replacenum);
							}
							
						}
					
					}else{
						
						$postlist[$pid][message] = strtr ($postlist[$pid][message], $gjz); //���ؽ�� 
					}
				
				}
				//
					} 
				} 
			} 
		} 
		// [subject]subjectenc
	} 
	 
	function post_seo_message($param) {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$ping = $config ['ping'];
		$yun = $config['yun'];
		$isnot = $config ['isnot'];

		if ($isnot) {
			if ($param ['param'] [0] == "post_newthread_succeed") {
				$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';
				if (file_exists ($settingfile)) {
					include $settingfile;
				} 
				if (file_exists (DISCUZ_ROOT . './data/cache/cache_seo_setting.php')) {
					$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
					include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
				} 
				$allow_publish = $seo_setting ['allow_publish'];
				$allow_num = $seo_setting ['allow_num'];
				$charset = $_G ['charset'];
				$currentnum = DB :: result_first("select count(*) from " . DB :: table("forum_thread") . " where dateline>" . strtotime(date('Ymd000000')));
				if (!($currentnum % $allow_publish)) {
					
					$config = $_G ['cache'] ['plugin'] ['seo'];
					$csforums = $config ['csforums'];
					$csforums = unserialize($csforums);
					$csforums = implode(',', $csforums);
					$csforums = trim(trim($csforums), ',');
					if ($seo_setting['create_txt']) {
						$filename = 'sitemap.txt';
						$web_root = $_G['siteurl'];
						$rewriterule = $_G['setting']['rewriterule'];
						$charset = $_G['charset'];
						$status = $_G['setting']['rewritestatus']; //�û�url��̬��
						$sitemap = '';
						if ($_GET['allow_num']) {
							$conn = " LIMIT 0,1000";
						} 
						// �Ż�����
						$query = DB :: query('SELECT aid,dateline FROM ' . DB :: TABLE('portal_article_content') . $conn);
						while ($row = DB :: fetch($query)) {
							if (in_array('portal_article', $status)) {
								$mod = $rewriterule['portal_article'];
								$mod = str_replace('{page}/', '', $mod);
								$mod = preg_replace("/{page}/", "1", $mod);
								$mod = preg_replace("/{prevpage}/", "1", $mod);
								$mod = str_replace("{id}", $row['aid'], $mod);
								$mod = str_replace("{fid}", $row['aid'], $mod);
								$mod = str_replace("{tid}", $row['aid'], $mod);
								$mod = str_replace("{blogid}", $row['aid'], $mod);
								$turl = $web_root . $mod;
							} else {
								$turl = $web_root . "portal.php?mod=view&amp;aid=" . $row['aid'];
							} 
							$link = $turl;
							$sitemap .= "$link\n";
						} 
						if ($_GET['cs1']) {
							// ��־
							$query = DB :: query('SELECT blogid,uid,dateline FROM ' . DB :: table('home_blog') . ' order by blogid desc' . $conn);
							while ($row = DB :: fetch($query)) {
								if (in_array('home_blog', $status)) {
									$mod = $rewriterule['home_blog'];
									$mod = str_replace('{page}/', '', $mod);
									$mod = preg_replace("/{page}/", "1", $mod);
									$mod = preg_replace("/{prevpage}/", "1", $mod);
									$mod = str_replace("{id}", $row['blogid'], $mod);
									$mod = str_replace("{fid}", $row['blogid'], $mod);
									$mod = str_replace("{tid}", $row['blogid'], $mod);
									$mod = str_replace("{uid}", $row['uid'], $mod);
									$mod = str_replace("{blogid}", $row['blogid'], $mod);
									$turl = $web_root . $mod;
								} else {
									$turl = $web_root . "home.php?mod=space&amp;do=blog&amp;id=" . $row['blogid'];
								} 
								$link = $turl;
								$sitemap .= "$link\n";
							} 
						} 
						// ���
						if ($csforums) {
							$query = DB :: query("SELECT fid,type,status FROM " . DB :: table('forum_forum') . " WHERE status='1' and fid in ($csforums) And type='forum' order by fid ");
						} else {
							$query = DB :: query("SELECT fid,type,status FROM " . DB :: table('forum_forum') . " WHERE status='1' And type='forum' order by fid ");
						} while ($row = DB :: fetch($query)) {
							if (in_array('forum_forumdisplay', $status)) {
								if ($forumkeys[$row['fid']]) {
									$row['fid'] = $forumkeys[$row['fid']];
								} 
								$mod = $rewriterule['forum_forumdisplay'];
								$mod = str_replace('{page}/', '', $mod);
								$mod = preg_replace("/{page}/", "1", $mod);
								$mod = preg_replace("/{prevpage}/", "1", $mod);
								$mod = str_replace("{id}", $row['fid'], $mod);
								$mod = str_replace("{fid}", $row['fid'], $mod);
								$mod = str_replace("{tid}", $row['fid'], $mod);
								$mod = str_replace("{blogid}", $row['fid'], $mod);
								$turl = $web_root . $mod;
							} else {
								$turl = $web_root . "forum.php?mod=forumdisplay&amp;fid=" . $row['fid'];
							} 
							$link = $turl;
							$sitemap .= "$link\n";
						} 
						if ($_GET['allow_num']) {
							$connx = " LIMIT 0,1000";
						} 
						if ($_GET['cs2']) {
							$csnum = $_GET['cs2'];
							$connx = " LIMIT 0,$csnum";
						} 
						// ����
						if ($csforums) {
							$querys = DB :: query('SELECT tid,lastpost FROM ' . DB :: table('forum_thread') . " where fid in ($csforums) and displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4'   order by tid desc $connx");
						} else {
							$querys = DB :: query('SELECT tid,lastpost FROM ' . DB :: table('forum_thread') . " where displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4'  order by tid desc $connx");
						} while ($row = DB :: fetch($querys)) {
							if (in_array('forum_viewthread', $status)) {
								$mod = $rewriterule['forum_viewthread'];
								$mod = str_replace('{page}/', '', $mod);
								$mod = preg_replace("/{page}/", "1", $mod);
								$mod = preg_replace("/{prevpage}/", "1", $mod);
								$mod = str_replace("{id}", $row['tid'], $mod);
								$mod = str_replace("{fid}", $row['tid'], $mod);
								$mod = str_replace("{tid}", $row['tid'], $mod);
								$mod = str_replace("{blogid}", $row['tid'], $mod);
								$turl = $web_root . $mod;
							} else {
								$turl = $web_root . "forum.php?mod=viewthread&amp;tid=" . $row['tid'];
							} 
							$link = $turl;
							$sitemap .= "$link\n";
						} 

						$fp = fopen(DISCUZ_ROOT . '/' . $filename, 'w');
						fwrite($fp, $sitemap);
						fclose($fp);
					} 

					

					$filename = 'sitemap.xml';
					$web_root = $_G ['siteurl'];
					if (substr($web_root, -1) != '/') {
						$web_root = $web_root . '/';
					} 
					$rewriterule = $_G ['setting'] ['rewriterule'];
					$status = $_G ['setting'] ['rewritestatus'];
					$sitemap = "<?xml version=\"1.0\" encoding=\"$charset\"?>\n";
					$sitemap .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">' . "\n";
					if ($allow_num) {
						$conn = " LIMIT 0,1000";
					} 
					$query = DB :: query ('SELECT aid,dateline FROM ' . DB :: TABLE ('portal_article_content') . " order by aid desc " . $conn);
					while ($row = DB :: fetch ($query)) {
						if (in_array ('portal_article', $status)) {
							$mod = $rewriterule ['portal_article'];
							$mod = str_replace('{page}/', '', $mod);
							$mod = preg_replace ("/{page}/", "1", $mod);
							$mod = preg_replace ("/{prevpage}/", "1", $mod);
							$mod = str_replace ("{id}", $row ['aid'], $mod);
							$mod = str_replace ("{fid}", $row ['aid'], $mod);
							$mod = str_replace ("{tid}", $row ['aid'], $mod);
							$mod = str_replace ("{blogid}", $row ['aid'], $mod);
							$turl = $web_root . $mod;
						} else {
							$turl = $web_root . "portal.php?mod=view&amp;aid=" . $row ['aid'];
						} 
						$link = $turl;
						$lastpost = date ('Y-m-d', $row ['dateline']);
						$priority = rand (1, 10) / 10;
						$sitemap .= "<url>\n";
						$sitemap .= "<loc>$link</loc>\n";
						$sitemap .= "<priority>$priority</priority>\n";
						$sitemap .= "<lastmod>$lastpost</lastmod>\n";
						$sitemap .= "<changefreq>daily</changefreq>\n";
						$sitemap .= "</url>\n";
					} 
					$query = DB :: query ('SELECT blogid,uid,dateline FROM ' . DB :: table ('home_blog') . ' order by blogid desc' . $conn);
					while ($row = DB :: fetch ($query)) {
						if (in_array ('home_blog', $status)) {
							$mod = $rewriterule ['home_blog'];
							$mod = str_replace('{page}/', '', $mod);
							$mod = preg_replace ("/{page}/", "1", $mod);
							$mod = preg_replace ("/{prevpage}/", "1", $mod);
							$mod = str_replace ("{id}", $row ['blogid'], $mod);
							$mod = str_replace ("{fid}", $row ['blogid'], $mod);
							$mod = str_replace ("{tid}", $row ['blogid'], $mod);
							$mod = str_replace ("{uid}", $row ['uid'], $mod);
							$mod = str_replace ("{blogid}", $row ['blogid'], $mod);
							$turl = $web_root . $mod;
						} else {
							$turl = $web_root . "home.php?mod=space&amp;do=blog&amp;id=" . $row ['blogid'];
						} 
						$link = $turl;
						$lastpost = date ('Y-m-d', $row ['dateline']);
						$priority = rand (1, 10) / 10;
						$sitemap .= "<url>\n";
						$sitemap .= "<loc>$link</loc>\n";
						$sitemap .= "<priority>$priority</priority>\n";
						$sitemap .= "<lastmod>$lastpost</lastmod>\n";
						$sitemap .= "<changefreq>daily</changefreq>\n";
						$sitemap .= "</url>\n";
					} 
					$query = DB :: query ("SELECT fid,type,status FROM " . DB :: table ('forum_forum') . " WHERE status='1' And type='forum' order by fid ");
					$forumkeys = $_G['setting']['forumkeys'];
					while ($row = DB :: fetch ($query)) {
						if (in_array ('forum_forumdisplay', $status)) {
							if ($forumkeys[$row['fid']]) {
								$row['fid'] = $forumkeys[$row['fid']];
							} 
							$mod = $rewriterule ['forum_forumdisplay'];
							$mod = str_replace('{page}/', '', $mod);
							$mod = preg_replace ("/{page}/", "1", $mod);
							$mod = preg_replace ("/{prevpage}/", "1", $mod);
							$mod = str_replace ("{id}", $row ['fid'], $mod);
							$mod = str_replace ("{fid}", $row ['fid'], $mod);
							$mod = str_replace ("{tid}", $row ['fid'], $mod);
							$mod = str_replace ("{blogid}", $row ['fid'], $mod);
							$turl = $web_root . $mod;
						} else {
							$turl = $web_root . "forum.php?mod=forumdisplay&amp;fid=" . $row ['fid'];
						} 
						$link = $turl;
						$lastpost = date ('Y-m-d');
						$priority = rand (1, 10) / 10;
						$sitemap .= "<url>\n";
						$sitemap .= "<loc>$link</loc>\n";
						$sitemap .= "<priority>$priority</priority>\n";
						$sitemap .= "<lastmod>$lastpost</lastmod>\n";
						$sitemap .= "<changefreq>always</changefreq>\n";
						$sitemap .= "</url>\n";
					} 
					$querys = DB :: query ('SELECT tid,lastpost FROM ' . DB :: table ('forum_thread') . " order by tid desc $conn");
					while ($row = DB :: fetch ($querys)) {
						if (in_array ('forum_viewthread', $status)) {
							$mod = $rewriterule ['forum_viewthread'];
							$mod = str_replace('{page}/', '', $mod);
							$mod = preg_replace ("/{page}/", "1", $mod);
							$mod = preg_replace ("/{prevpage}/", "1", $mod);
							$mod = str_replace ("{id}", $row ['tid'], $mod);
							$mod = str_replace ("{fid}", $row ['tid'], $mod);
							$mod = str_replace ("{tid}", $row ['tid'], $mod);
							$mod = str_replace ("{blogid}", $row ['tid'], $mod);
							$turl = $web_root . $mod;
						} else {
							$turl = $web_root . "forum.php?mod=viewthread&amp;tid=" . $row ['tid'];
						} 
						$link = $turl;
						$lastpost = $row ['lastpost'];
						$lastpost = date ("Y-m-d", $lastpost);
						$priority = rand (1, 10) / 10;
						$sitemap .= "<url>\n";
						$sitemap .= "<loc>$link</loc>\n";
						$sitemap .= "<priority>$priority</priority>\n";
						$sitemap .= "<lastmod>$lastpost</lastmod>\n";
						$sitemap .= "<changefreq>daily</changefreq>\n";
						$sitemap .= "</url>\n";
					} 
					$link = $web_root;
					$lastpost = date ("Y-m-d", time ());
					$sitemap .= "<url>\n";
					$sitemap .= "<loc>$link</loc>\n";
					$sitemap .= "<priority>1.0</priority>\n";
					$sitemap .= "<lastmod>$lastpost</lastmod>\n";
					$sitemap .= "<changefreq>daily</changefreq>\n";
					$sitemap .= "</url>\n";
					$sitemap .= "</urlset>\n";
					$fp = fopen (DISCUZ_ROOT . '/' . $filename, 'w');
					fwrite ($fp, $sitemap);
					fclose ($fp);
				} 
				if (!$yun) {
					if ($ping) {
						if (function_exists(curl_setopt)) {
							$pforums = $config ['pforums'];
							$puser = $config ['puser'];
							$google = $config ['google'];
							$puser = unserialize ($puser);
							$groupid = $_G ['groupid'];
							$pforums = unserialize ($pforums);
							$fid = addslashes($_GET ['fid']);
							if (in_array ($groupid, $puser)) {
								if (in_array ($fid, $pforums)) {
									$the_host = $_SERVER ['HTTP_HOST']; 
									// $the_host = $_G ['siteurl'];
									
									function postUrl($url, $postvar, $charset) {
										$ch = curl_init ();
										$headers = array ("POST " . $url . " HTTP/1.0", "Content-type: text/xml; charset=\"$charset\"", "Accept: text/xml", "Content-length: " . strlen ($postvar));
										curl_setopt ($ch, CURLOPT_URL, $url);
										curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
										curl_setopt ($ch, CURLOPT_POST, 1);
										curl_setopt ($ch, CURLOPT_HTTPHEADER, $headers);
										curl_setopt ($ch, CURLOPT_POSTFIELDS, $postvar);
										$res = curl_exec ($ch);
										curl_close ($ch);
										return $res;
									} 
									$a = $param ['param'] [0];
									$b = $web_root . $param ['param'] [1];
									$c = $param ['param'] [2];
									$d = $param ['param'] [3];
									$e = $_G ['setting'] ['bbname'];
									$baiduXML = "<?xml version=\"1.0\" encoding=\"$charset\"?> 
					<methodCall> 
					<methodName>weblogUpdates.extendedPing</methodName> 
					<params> 
					<param><value><string>$e</string></value></param> 
					<param><value><string>$web_root</string></value></param> 
					<param><value><string>$b</string></value></param> 
					<param><value><string>" . $web_root . "forum.php?mod=rss</string></value></param> 
					</params> 
					</methodCall>";
									$tid = $param ['param'] [2]['tid'];
									if ($tid) {
										$displayorder = DB :: result_first("SELECT displayorder FROM " . DB :: table('forum_thread') . " where tid=$tid");
										if ($displayorder >= 0 || $displayorder == '-188') {
											$res = postUrl ('http://ping.baidu.com/ping/RPC2', $baiduXML, $charset); 
											// ��¼ping
											$str = strpos ($res, "<int>0</int>");
											if ($str) {
												$result = 1;
											} else {
												$result = 0;
											} 
											$spidertype = '0';
											$spidertypearray = array(0 => '�ٶ�');
											$url = $b;
											$dateline = time();
											$title = DB :: result_first("select subject from " . DB :: table("forum_thread") . " where tid=$tid");
											$pingarray = array("status" => $result, "title" => $title, "spidertype" => $spidertype, "type" => 0, "tid" => $tid, "url" => $url, "dateline" => $dateline);
											$check = DB :: result_first("select count(*) from " . DB :: table("plugin_seo_ping") . " where tid=" . $tid);
											if (!$check) {
												DB :: insert("plugin_seo_ping", $pingarray);
											} 
										} 
										// ��¼ping
										// �ȸ�ping
										if ($google) {
											$googleXML = "
											<?xml version=\"1.0\"?>
											<methodCall>
											  <methodName>weblogUpdates.extendedPing</methodName>
											  <params>
												<param>
												  <value>$e</value>
												</param>
												<param>
												  <value>$web_root</value>
												</param>
												<param>
												  <value>$b</value>
												</param>
												<param>
												  <value>" . $web_root . "forum.php?mod=rss</value>
												</param>
											  </params>
											</methodCall>";
											$res = postUrl('http://blogsearch.google.com/ping/RPC2', $googleXML); 
											// debug($res);
											// �����Ƿ��سɹ������жϣ����ݹȸ�ping�Ľӿ�˵����
											if (strpos($res, "<boolean>0</boolean>")) {
												$result = 1;
											} else {
												$result = 0;
											} 
											$spidertype = '1';
											$pingarray = array("status" => $result, "title" => $title, "spidertype" => $spidertype, "type" => 0, "tid" => $tid, "url" => $url, "dateline" => $dateline);
											if (!$check) {
												DB :: insert("plugin_seo_ping", $pingarray);
											} 
										} 
										// �ȸ�ping
										//showmessage ($a, $b, $c, $d);
									} 
								} 
							} 
						} 
					} 
				} 
			} 
		} 
	} 
} 

class plugin_seo_portal extends plugin_seo {
	
	function view_article_output($param) {
		global $_G, $content, $article;
		$puid = $_G['uid']; 
		// debug($article);
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$wuser = $config ['wuser'];
		$wuser = unserialize ($wuser);
		$isuid = $config ['isuid'];
		$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';

		if (file_exists ($settingfile)) {
			include $settingfile;
		} 
		if (file_exists (DISCUZ_ROOT . './data/cache/cache_seo_setting.php')) {
			$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
			include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
		} 
		$issuper = $seo_setting['issuper'];
		if ($issuper) {
			$aid = $_GET['aid'];
			$article1 = DB :: fetch_first("select a.*,b.content from " . DB :: table('portal_article_title') . " a left join " . DB :: table('portal_article_content') . " b on a.aid=b.aid where a.aid=$aid");
			$title = $article1['title'];
			$contents = $article1['content'];
			$uid = $article1['uid'];
			$catid = $article1['catid'];
			$super = $_GET['super'];
			$authorid = DB :: result_first("select groupid from " . DB :: table('common_member') . " where uid=$uid");
			if ($seo_setting ['content_portal']) {
				$words = array ();
				$str = str_replace ("\r", "", $seo_setting ['thesaurus_setting']);
				$arr = explode ("\n", $str);
				foreach ($arr as $k => $v) {
					if ($v) {
						$str_data = explode ("=", $v);
						$words += array ("$str_data[0]" => "$str_data[1]");
					} 
				} 
				$words = array_unique($words);
				$contents = strtr ($contents, $words);
			} 
			if ($seo_setting ['title_portal']) {
				$words = array ();
				$str = str_replace ("\r", "", $seo_setting ['thesaurus_setting']);
				$arr = explode ("\n", $str);
				foreach ($arr as $k => $v) {
					if ($v) {
						$str_data = explode ("=", $v);
						$words += array ("$str_data[0]" => "$str_data[1]");
					} 
				} 
				$words = array_unique($words);
				$title = strtr ($title, $words);
			} 
			$insertarray = array('uid' => $uid, 'catid' => $catid, 'aid' => $aid, 'title' => $title, 'content' => $contents);

			DB :: insert('plugin_seo_portal', $insertarray); 
			// �ѵ����ӱ�����ʱ�Ƿ�αԭ����������ͨ�û����ʻ���������ֿ�ò����ж����ֿ�
			if (($super == 1 || IS_ROBOT || empty($isuid) && !$puid) && $issuper && in_array ($authorid, $wuser)) {
				$arr = DB :: fetch_first(' select title,content from ' . DB :: table('plugin_seo_portal') . " where aid=$aid");

				if ($arr['title'] && $arr['content']) {
					if($seo_setting ['title_portal']){
						$title = $arr['title'];
						$article[title] = $title;
					}
					if ($seo_setting ['content_portal']) {
						$message = $arr['content'];
						$content['content'] = $message;
					}
				} 
			} 
		} 
	} 
	function view_article_subtitle($param) {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$wuser = $config ['wuser'];
		$wuser = unserialize ($wuser);
		$groupid = $_G ['groupid'];
		$aid = addslashes($_GET['aid']);
		$thread = DB :: fetch_first("select * from " . DB :: table('portal_article_title') . " where aid=$aid");
		$uid = $thread['uid'];
		$authorid = DB :: result_first("select groupid from " . DB :: table('common_member') . " where uid=$uid");
		$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';

		if (file_exists ($settingfile)) {
			include $settingfile;
		} 
		if (file_exists (DISCUZ_ROOT . './data/cache/cache_seo_setting.php')) {
			$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
			include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
		} 
		$issuper = $seo_setting['issuper'];
		$returnstr = '';
		if ($issuper && $groupid == 1 && in_array ($authorid, $wuser)) {
			$super = $_GET['super'];
			if ($super) {
				$returnstr .= '|&nbsp;&nbsp;<a href="portal.php?mod=view&aid=' . $aid . '">' . lang('plugin/seo', 'x11') . '</a>';
			} else {
				$returnstr .= '|&nbsp;&nbsp;<a href="portal.php?mod=view&aid=' . $aid . '&super=1">' . lang('plugin/seo', 'x22') . '</a>';
			} 
		} 

		$yun = $config['yun'];
		$rewriterule = $_G ['setting'] ['rewriterule'];
		$status = $_G ['setting'] ['rewritestatus'];
		$isnot = $config ['isnot'];

		if ($isnot) {
			if ($yun) {
				$the_host = $_SERVER ['HTTP_HOST'];
				$b = "http://" . $the_host;
				$web_root = $_G ['siteurl'];
				if (substr($web_root, -1) != '/') {
					$web_root = $web_root . '/';
				} 
				$aid = addslashes($_GET['aid']);
				$tid = $aid;
				$displayorder = "-188";
				$subject = DB :: result_first("select title from " . DB :: table("portal_article_title") . " where aid=$aid");
				if (in_array ('portal_article', $status)) {
					$mod = $rewriterule ['portal_article'];
					$mod = preg_replace ("/{page}/", "1", $mod);
					$mod = preg_replace ("/{prevpage}/", "1", $mod);
					$mod = str_replace ("{id}", $aid, $mod);
					$mod = str_replace ("{fid}", $aid, $mod);
					$mod = str_replace ("{tid}", $aid, $mod);
					$mod = str_replace ("{blogid}", $aid, $mod);
					$turl = $web_root . $mod;
				} else {
					$turl = $web_root . "portal.php?mod=view&amp;aid=" . $aid;
				} 
				$e = $_G ['setting'] ['bbname'];
				$type = 1;
				$check = DB :: result_first("select count(*) from " . DB :: table("plugin_seo_ping") . " where tid=" . $tid);
				if (!$check) {
					$returnstr .= '<script src="source/plugin/seo/js/jquery.min.js"></script><script>var jq = jQuery.noConflict();jq.getJSON("http://www.seoeye.cn/mycloud.php?callback=?",{turl:"' . $turl . '",b: "' . $web_root . '",e:"' . $e . '",displayorder:"' . $displayorder . '",host:"' . $the_host . '",charset:"' . $charset . '"},function(data) {jq.get("plugin.php?id=seo:precord&op=add",{result:data.result,gsign:data.gsign,tid:"' . $tid . '",type:"' . $type . '",subject:"' . $subject . '",b:"' . $turl . '"});})</script>';
				} 
			} 
		} 

		return $returnstr;
	} 
	function portalcp_seo_output($param) {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$rewriterule = $_G ['setting'] ['rewriterule'];
		$charset = $_G ['charset'];
		$web_root = $_G ['siteurl'];
		if (substr($web_root, -1) != '/') {
			$web_root = $web_root . '/';
		} 
		$config = $_G ['cache'] ['plugin'] ['seo'];
		$ping = $config ['pingportal'];
		$isnot = $config ['isnot'];
		$yun = $config['yun'];
		if ($isnot) {
			if ($_GET['articlesubmit']) {
				$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';

				if (file_exists ($settingfile)) {
					include $settingfile;
				} 
				if (file_exists (DISCUZ_ROOT . './data/cache/cache_seo_setting.php')) {
					$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
					include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
				} 
				$allow_portal = $seo_setting ['allow_portal'];
				$allow_num = $seo_setting ['allow_num'];
				if ($allow_portal) {
					$filename = 'sitemap.xml';
					$status = $_G ['setting'] ['rewritestatus'];
					$sitemap = "<?xml version=\"1.0\" encoding=\"$charset\"?>\n";
					$sitemap .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">' . "\n";
					if ($allow_num) {
						$conn = " LIMIT 0,1000";
					} 
					$query = DB :: query ('SELECT aid,dateline FROM ' . DB :: TABLE ('portal_article_content') . $conn);
					while ($row = DB :: fetch ($query)) {
						if (in_array ('portal_article', $status)) {
							$mod = $rewriterule ['portal_article'];
							$mod = preg_replace ("/{page}/", "1", $mod);
							$mod = preg_replace ("/{prevpage}/", "1", $mod);
							$mod = str_replace ("{id}", $row ['aid'], $mod);
							$mod = str_replace ("{fid}", $row ['aid'], $mod);
							$mod = str_replace ("{tid}", $row ['aid'], $mod);
							$mod = str_replace ("{blogid}", $row ['aid'], $mod);
							$turl = $web_root . $mod;
						} else {
							$turl = $web_root . "portal.php?mod=view&amp;aid=" . $row ['aid'];
						} 
						$link = $turl;
						$lastpost = date ('Y-m-d', $row ['dateline']);
						$priority = rand (1, 10) / 10;
						$sitemap .= "<url>\n";
						$sitemap .= "<loc>$link</loc>\n";
						$sitemap .= "<priority>$priority</priority>\n";
						$sitemap .= "<lastmod>$lastpost</lastmod>\n";
						$sitemap .= "<changefreq>daily</changefreq>\n";
						$sitemap .= "</url>\n";
					} 
					$query = DB :: query ('SELECT blogid,uid,dateline FROM ' . DB :: table ('home_blog') . ' order by blogid desc' . $conn);
					while ($row = DB :: fetch ($query)) {
						if (in_array ('home_blog', $status)) {
							$mod = $rewriterule ['home_blog'];
							$mod = preg_replace ("/{page}/", "1", $mod);
							$mod = preg_replace ("/{prevpage}/", "1", $mod);
							$mod = str_replace ("{id}", $row ['blogid'], $mod);
							$mod = str_replace ("{fid}", $row ['blogid'], $mod);
							$mod = str_replace ("{tid}", $row ['blogid'], $mod);
							$mod = str_replace ("{uid}", $row ['uid'], $mod);
							$mod = str_replace ("{blogid}", $row ['blogid'], $mod);
							$turl = $web_root . $mod;
						} else {
							$turl = $web_root . "home.php?mod=space&amp;do=blog&amp;id=" . $row ['blogid'];
						} 
						$link = $turl;
						$lastpost = date ('Y-m-d', $row ['dateline']);
						$priority = rand (1, 10) / 10;
						$sitemap .= "<url>\n";
						$sitemap .= "<loc>$link</loc>\n";
						$sitemap .= "<priority>$priority</priority>\n";
						$sitemap .= "<lastmod>$lastpost</lastmod>\n";
						$sitemap .= "<changefreq>daily</changefreq>\n";
						$sitemap .= "</url>\n";
					} 
					$query = DB :: query ("SELECT fid,type,status FROM " . DB :: table ('forum_forum') . " WHERE status='1' And type='forum' order by fid ");
					while ($row = DB :: fetch ($query)) {
						if (in_array ('forum_forumdisplay', $status)) {
							$mod = $rewriterule ['forum_forumdisplay'];
							$mod = preg_replace ("/{page}/", "1", $mod);
							$mod = preg_replace ("/{prevpage}/", "1", $mod);
							$mod = str_replace ("{id}", $row ['fid'], $mod);
							$mod = str_replace ("{fid}", $row ['fid'], $mod);
							$mod = str_replace ("{tid}", $row ['fid'], $mod);
							$mod = str_replace ("{blogid}", $row ['fid'], $mod);
							$turl = $web_root . $mod;
						} else {
							$turl = $web_root . "forum.php?mod=forumdisplay&amp;fid=" . $row ['fid'];
						} 
						$link = $turl;
						$lastpost = date ('Y-m-d');
						$priority = rand (1, 10) / 10;
						$sitemap .= "<url>\n";
						$sitemap .= "<loc>$link</loc>\n";
						$sitemap .= "<priority>$priority</priority>\n";
						$sitemap .= "<lastmod>$lastpost</lastmod>\n";
						$sitemap .= "<changefreq>always</changefreq>\n";
						$sitemap .= "</url>\n";
					} 
					$querys = DB :: query ('SELECT tid,lastpost FROM ' . DB :: table ('forum_thread') . " order by tid desc $conn");
					while ($row = DB :: fetch ($querys)) {
						if (in_array ('forum_viewthread', $status)) {
							$mod = $rewriterule ['forum_viewthread'];
							$mod = preg_replace ("/{page}/", "1", $mod);
							$mod = preg_replace ("/{prevpage}/", "1", $mod);
							$mod = str_replace ("{id}", $row ['tid'], $mod);
							$mod = str_replace ("{fid}", $row ['tid'], $mod);
							$mod = str_replace ("{tid}", $row ['tid'], $mod);
							$mod = str_replace ("{blogid}", $row ['tid'], $mod);
							$turl = $web_root . $mod;
						} else {
							$turl = $web_root . "forum.php?mod=viewthread&amp;tid=" . $row ['tid'];
						} 
						$link = $turl;
						$lastpost = $row ['lastpost'];
						$lastpost = date ("Y-m-d", $lastpost);
						$priority = rand (1, 10) / 10;
						$sitemap .= "<url>\n";
						$sitemap .= "<loc>$link</loc>\n";
						$sitemap .= "<priority>$priority</priority>\n";
						$sitemap .= "<lastmod>$lastpost</lastmod>\n";
						$sitemap .= "<changefreq>daily</changefreq>\n";
						$sitemap .= "</url>\n";
					} 
					$link = $web_root;
					$lastpost = date ("Y-m-d", time ());
					$sitemap .= "<url>\n";
					$sitemap .= "<loc>$link</loc>\n";
					$sitemap .= "<priority>1.0</priority>\n";
					$sitemap .= "<lastmod>$lastpost</lastmod>\n";
					$sitemap .= "<changefreq>daily</changefreq>\n";
					$sitemap .= "</url>\n";
					$sitemap .= "</urlset>\n";
					$fp = fopen (DISCUZ_ROOT . '/' . $filename, 'w');
					fwrite ($fp, $sitemap);
					fclose ($fp);
				} 
				if ($ping) {
					if (function_exists(curl_setopt)) {
						$the_host = $_SERVER ['HTTP_HOST'];
						$b = "http://" . $the_host;
						$web_root = $_G ['siteurl'];
						if (substr($web_root, -1) != '/') {
							$web_root = $web_root . '/';
						} 
						$aid = DB :: result_first("SELECT aid FROM " . DB :: table('portal_article_title') . " order by aid desc");
						$the_host = $_SERVER ['HTTP_HOST'];
						function postUrl($url, $postvar, $charset) {
							$ch = curl_init ();
							$headers = array ("POST " . $url . " HTTP/1.0", "Content-type: text/xml; charset=\"" . $charset . "\"", "Accept: text/xml", "Content-length: " . strlen ($postvar));
							curl_setopt ($ch, CURLOPT_URL, $url);
							curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
							curl_setopt ($ch, CURLOPT_POST, 1);
							curl_setopt ($ch, CURLOPT_HTTPHEADER, $headers);
							curl_setopt ($ch, CURLOPT_POSTFIELDS, $postvar);
							$res = curl_exec ($ch);
							curl_close ($ch);
							return $res;
						} 
						if (in_array ('portal_article', $status)) {
							$mod = $rewriterule ['portal_article'];
							$mod = preg_replace ("/{page}/", "1", $mod);
							$mod = preg_replace ("/{prevpage}/", "1", $mod);
							$mod = str_replace ("{id}", $aid, $mod);
							$mod = str_replace ("{fid}", $aid, $mod);
							$mod = str_replace ("{tid}", $aid, $mod);
							$mod = str_replace ("{blogid}", $aid, $mod);
							$turl = $web_root . $mod;
						} else {
							$turl = $web_root . "portal.php?mod=view&amp;aid=" . $aid;
						} 

						$e = $_G ['setting'] ['bbname'];
						$baiduXML = "<?xml version=\"1.0\" encoding=\"$charset\"?> 
					<methodCall> 
					<methodName>weblogUpdates.extendedPing</methodName> 
					<params> 
					<param><value><string>$e</string></value></param> 
					<param><value><string>$web_root</string></value></param> 
					<param><value><string>$turl</string></value></param> 
					<param><value><string>" . $web_root . "portal.php?mod=rss</string></value></param> 
					</params> 
					</methodCall>";
						if (!$yun) {
							$res = postUrl ('http://ping.baidu.com/ping/RPC2', $baiduXML, $charset);
							$str = strpos ($res, "<int>0</int>");
							if ($str) {
								$result = 1;
							} else {
								$result = 0;
							} 
							$spidertype = '0';
							$spidertypearray = array(0 => lang('plugin/seo', 'c20'));
							$url = $turl;
							$tid = $aid;
							$dateline = time();
							$title = DB :: result_first("select title from " . DB :: table("portal_article_title") . " where aid=$tid");
							$pingarray = array("status" => $result, "title" => $title, "spidertype" => $spidertype, "type" => 1, "tid" => $tid, "url" => $url, "dateline" => $dateline);
							$check = DB :: result_first("select count(*) from " . DB :: table("plugin_seo_ping") . " where tid=" . $tid);
							if (!$check) {
								DB :: insert("plugin_seo_ping", $pingarray);
							} 
							// �ȸ�ping
							if ($google) {
								$googleXML = "
											<?xml version=\"1.0\"?>
											<methodCall>
											  <methodName>weblogUpdates.extendedPing</methodName>
											  <params>
												<param>
												  <value>$e</value>
												</param>
												<param>
												  <value>$web_root</value>
												</param>
												<param>
												  <value>$turl</value>
												</param>
												<param>
												  <value>" . $web_root . "forum.php?mod=rss</value>
												</param>
											  </params>
											</methodCall>";
								$res = postUrl('http://blogsearch.google.com/ping/RPC2', $googleXML, $charset); 
								// debug($res);
								// �����Ƿ��سɹ������жϣ����ݹȸ�ping�Ľӿ�˵����
								if (strpos($res, "<boolean>0</boolean>")) {
									$result = 1;
								} else {
									$result = 0;
								} 
								$spidertype = '1';
								$pingarray = array("status" => $result, "title" => $title, "spidertype" => $spidertype, "type" => 0, "tid" => $tid, "url" => $url, "dateline" => $dateline);
								$check = DB :: result_first("select count(*) from " . DB :: table("plugin_seo_ping") . " where tid=" . $tid);
								if (!$check) {
									DB :: insert("plugin_seo_ping", $pingarray);
								} 
							} 
							// �ȸ�ping
						} 
					} 
				} 
			} 
		} 
	} 
} 

?>