<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT.'/source/plugin/seo/function_inc.php';
if(!isset($_G['cache']['plugin']['seo'])){
	loadcache('plugin');
}
$config=$_G['cache']['plugin']['seo'];

$allowaction = array('list', 'detail', 'add');
$op = in_array($_G['gp_op'], $allowaction) ? $_G['gp_op'] : 'list';

$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';

if(file_exists($settingfile)){
	include $settingfile;
}
if(file_exists(DISCUZ_ROOT . './data/cache/cache_seo_setting.php')){
	$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
	include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
}
if(empty($seo_setting)){
	include DISCUZ_ROOT . './source/plugin/seo/seo_setting.php';
	if($_G['charset']!='gbk'){
		$seo_setting['thesaurus_setting']=iconv('gbk','utf-8',$seo_setting['thesaurus_setting']);
		$seo_setting['post_cloud']=iconv('gbk','utf-8',$seo_setting['post_cloud']);
		$seo_setting['allow_tips']=iconv('gbk','utf-8',$seo_setting['allow_tips']);
		
	}
}
//showtips(lang('plugin/seo', 'tips_setting'));
switch ($op){
	case 'list':
		showformheader("plugins&operation=config&do=$do&identifier=seo&pmod=baidu_sitemap&op=add");
		showtableheader(lang('plugin/seo', 'vars_setting'));
		showsetting(lang('plugin/seo','tips_publish'), array('allow_publish', array(
				array(1, 1),
				array(5, 5),
				array(10, 10),
				array(20, 20),
				array(50, 50),
				array(100, 100)
			)), $seo_setting['allow_publish'], 'mradio','','',lang('plugin/seo','allow_publish_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','tips_portal'), 'allow_portal', $seo_setting['allow_portal'], 'radio', 0, 1,lang('plugin/seo','allow_portal_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','cs1'), 'cs1', $seo_setting['cs1'], 'radio', 0, 1,lang('plugin/seo','cs1_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','tips_num'), 'allow_num', $seo_setting['allow_num'], 'radio', 0, 1,lang('plugin/seo','allow_num_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','cs2'), 'cs2', $seo_setting['cs2'], 'text', 0, 1,lang('plugin/seo','cs2_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','create_xml'), 'create_xml', $seo_setting['create_xml'], 'radio', 0, 1,lang('plugin/seo','create_xml_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','create_txt'), 'create_txt', $seo_setting['create_txt'], 'radio', 0, 1,lang('plugin/seo','create_txt_comment'));
		//showtagfooter('tbody');
		//showsetting(lang('plugin/seo','create_index'), 'create_index', 1, 'radio', 0, 1,lang('plugin/seo','create_index_comment'));
		showtagfooter('tbody');
		showtagfooter('tbody');
		showsubmit('editsubmit',lang('plugin/seo','updatexml'));
		showtablefooter();
		showformfooter();
		break;
	case 'add':		
		if(submitcheck('editsubmit')){
			$forumkeys=$_G['setting']['forumkeys'];
			//�洢��վ��ͼ��������������
			$seo_setting['allow_publish']=$_GET['allow_publish'];
			$seo_setting['allow_portal']=$_GET['allow_portal'];
			$seo_setting['allow_num']=$_GET['allow_num'];
			$seo_setting['cs1']=$_GET['cs1'];
			$seo_setting['cs2']=$_GET['cs2'];
			$seo_setting['create_xml']=$_GET['create_xml'];
			//$seo_setting['create_index']=$_GET['create_index'];
			$seo_setting['create_txt']=$_GET['create_txt'];
			require_once libfile('function/cache');
			writetocache('seo_setting', getcachevars(array('seo_setting' => $seo_setting)));//����������������д�뻺��
			
			$config = $_G ['cache'] ['plugin'] ['seo'];
			$csforums = $config ['csforums'];
			$csforums=unserialize($csforums);
			$csforums=implode(',',$csforums);
			$csforums=trim(trim($csforums),',');
			if($seo_setting['create_txt']){
			$filename='sitemap.txt';
			$web_root=$_G['siteurl'];
			$rewriterule = $_G['setting']['rewriterule'];
			$charset=$_G['charset'];
			$status = $_G['setting']['rewritestatus'];//�û�url��̬��
			$sitemap='';
			if($_GET['allow_num'])
			{
				$conn=" LIMIT 0,1000";
			}
			
			//�Ż�����
			$query =DB::query('SELECT aid,dateline FROM '.DB::TABLE('portal_article_content').$conn);
			while($row=DB::fetch($query)){
				  if(in_array('portal_article',$status)){
					  $mod=$rewriterule['portal_article'];
					  $mod=str_replace('{page}/','',$mod);
					  $mod=preg_replace("/{page}/","1",$mod);
					  $mod=preg_replace("/{prevpage}/","1",$mod);	 
					  $mod=str_replace("{id}",$row['aid'],$mod);
					  $mod=str_replace("{fid}",$row['aid'],$mod);	
					  $mod=str_replace("{tid}",$row['aid'],$mod);
					  $mod=str_replace("{blogid}",$row['aid'],$mod);
					$turl=$web_root.$mod;
				}else{
					$turl=$web_root."portal.php?mod=view&amp;aid=".$row['aid'];
				}
				 $link = $turl;
				 $sitemap.="$link\n";
			}
			if($_GET['cs1']){
			//��־
			$query=DB::query('SELECT blogid,uid,dateline FROM '.DB::table('home_blog').' order by blogid desc'.$conn);
			while($row=DB::fetch($query)){
				  if(in_array('home_blog',$status)){
					  $mod=$rewriterule['home_blog'];
					  $mod=str_replace('{page}/','',$mod);
					  $mod=preg_replace("/{page}/","1",$mod);
					  $mod=preg_replace("/{prevpage}/","1",$mod);	 
					  $mod=str_replace("{id}",$row['blogid'],$mod);
					  $mod=str_replace("{fid}",$row['blogid'],$mod);	
					  $mod=str_replace("{tid}",$row['blogid'],$mod);
					   $mod=str_replace("{uid}",$row['uid'],$mod);
					  $mod=str_replace("{blogid}",$row['blogid'],$mod);
					$turl=$web_root.$mod;
				}else{
					$turl=$web_root."home.php?mod=space&amp;do=blog&amp;id=".$row['blogid'];
				}
				 $link = $turl;
				 $sitemap.="$link\n";
			}
			}
			//���
			if($csforums){
				$query=DB::query("SELECT fid,type,status FROM ".DB::table('forum_forum')." WHERE status='1' and fid in ($csforums) And type='forum' order by fid ");
			}else{
				$query=DB::query("SELECT fid,type,status FROM ".DB::table('forum_forum')." WHERE status='1' And type='forum' order by fid ");
			}
			while($row=DB::fetch($query)){
				  if(in_array('forum_forumdisplay',$status)){
					  if($forumkeys[$row['fid']]){
						$row['fid']=$forumkeys[$row['fid']];
					  }
					  $mod=$rewriterule['forum_forumdisplay'];
					  $mod=str_replace('{page}/','',$mod);
					  $mod=preg_replace("/{page}/","1",$mod);
					  $mod=preg_replace("/{prevpage}/","1",$mod);	 
					  $mod=str_replace("{id}",$row['fid'],$mod);
					  $mod=str_replace("{fid}",$row['fid'],$mod);	
					  $mod=str_replace("{tid}",$row['fid'],$mod);
					  $mod=str_replace("{blogid}",$row['fid'],$mod);
					$turl=$web_root.$mod;
				}else{
					$turl=$web_root."forum.php?mod=forumdisplay&amp;fid=".$row['fid'];
				}
				  $link = $turl;
				  $sitemap.="$link\n";
			}
			if($_GET['allow_num'])
			{
				$connx=" LIMIT 0,1000";
			}
			if($_GET['cs2'])
			{
				$csnum=$_GET['cs2'];
				$connx=" LIMIT 0,$csnum";
			}
			//����
			if($csforums){
				$querys = DB::query('SELECT tid,lastpost FROM '.DB::table('forum_thread')." where fid in ($csforums) and displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4'   order by tid desc $connx");
			}else{
				$querys = DB::query('SELECT tid,lastpost FROM '.DB::table('forum_thread')." where displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4'  order by tid desc $connx");
			}
			
			while($row = DB::fetch($querys))
			{
				 if(in_array('forum_viewthread',$status)){
					  $mod=$rewriterule['forum_viewthread'];
					  $mod=str_replace('{page}/','',$mod);
					  $mod=preg_replace("/{page}/","1",$mod);
					  $mod=preg_replace("/{prevpage}/","1",$mod);	 
					  $mod=str_replace("{id}",$row['tid'],$mod);
					  $mod=str_replace("{fid}",$row['tid'],$mod);	
					  $mod=str_replace("{tid}",$row['tid'],$mod);
					  $mod=str_replace("{blogid}",$row['tid'],$mod);
					$turl=$web_root.$mod;
				}else{
					$turl=$web_root."forum.php?mod=viewthread&amp;tid=".$row['tid'];
				}
				  $link = $turl;
				  $sitemap.="$link\n";
			}
			
			 $fp = fopen(DISCUZ_ROOT.'/'.$filename,'w');
			fwrite($fp,$sitemap);
			fclose($fp);
			}


			
			if($seo_setting['create_xml']){
			$filename='sitemap.xml';
			$web_root=$_G['siteurl'];
			$rewriterule = $_G['setting']['rewriterule'];
			$charset=$_G['charset'];
			$status = $_G['setting']['rewritestatus'];//�û�url��̬��
			$sitemap="<?xml version=\"1.0\" encoding=\"$charset\"?>\n";
			$sitemap .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">'."\n";
			if($_GET['allow_num'])
			{
				$conn=" LIMIT 0,1000";
			}
			//�Ż�����
			$query =DB::query('SELECT aid,dateline FROM '.DB::TABLE('portal_article_content').$conn);
			while($row=DB::fetch($query)){
				  if(in_array('portal_article',$status)){
					  $mod=$rewriterule['portal_article'];
					  $mod=str_replace('{page}/','',$mod);
					  $mod=preg_replace("/{page}/","1",$mod);
					  $mod=preg_replace("/{prevpage}/","1",$mod);	 
					  $mod=str_replace("{id}",$row['aid'],$mod);
					  $mod=str_replace("{fid}",$row['aid'],$mod);	
					  $mod=str_replace("{tid}",$row['aid'],$mod);
					  $mod=str_replace("{blogid}",$row['aid'],$mod);
					$turl=$web_root.$mod;
				}else{
					$turl=$web_root."portal.php?mod=view&amp;aid=".$row['aid'];
				}
				 $link = $turl;
				 $lastpost = date('Y-m-d',$row['dateline']);
				 $priority=rand(1,10)/10;
				 $sitemap.="<url>\n";
				 $sitemap.="<loc>$link</loc>\n";
				 $sitemap.="<priority>$priority</priority>\n";
				 $sitemap.="<lastmod>$lastpost</lastmod>\n";
				 $sitemap.="<changefreq>daily</changefreq>\n";
				 $sitemap.="</url>\n";
			}
			//��־
			if($_GET['cs1']){
			$query=DB::query('SELECT blogid,uid,dateline FROM '.DB::table('home_blog').' order by blogid desc'.$conn);
			while($row=DB::fetch($query)){
				  if(in_array('home_blog',$status)){
					  $mod=$rewriterule['home_blog'];
					  $mod=str_replace('{page}/','',$mod);
					  $mod=preg_replace("/{page}/","1",$mod);
					  $mod=preg_replace("/{prevpage}/","1",$mod);	 
					  $mod=str_replace("{id}",$row['blogid'],$mod);
					  $mod=str_replace("{fid}",$row['blogid'],$mod);	
					  $mod=str_replace("{tid}",$row['blogid'],$mod);
					  $mod=str_replace("{uid}",$row['uid'],$mod);
					  $mod=str_replace("{blogid}",$row['blogid'],$mod);
					$turl=$web_root.$mod;
				}else{
					$turl=$web_root."home.php?mod=space&amp;do=blog&amp;id=".$row['blogid'];
				}
				 $link = $turl;
				 $lastpost = date('Y-m-d',$row['dateline']);
				 $priority=rand(1,10)/10;
				 $sitemap.="<url>\n";
				 $sitemap.="<loc>$link</loc>\n";
				 $sitemap.="<priority>$priority</priority>\n";
				 $sitemap.="<lastmod>$lastpost</lastmod>\n";
				 $sitemap.="<changefreq>daily</changefreq>\n";
				 $sitemap.="</url>\n";
			}
			}
			//���
			if($csforums){
				$query=DB::query("SELECT fid,type,status FROM ".DB::table('forum_forum')." WHERE status='1' and fid in ($csforums) And type='forum' order by fid ");
			}else{
				$query=DB::query("SELECT fid,type,status FROM ".DB::table('forum_forum')." WHERE status='1' And type='forum' order by fid ");
			}
			while($row=DB::fetch($query)){
				  if(in_array('forum_forumdisplay',$status)){
					  if($forumkeys[$row['fid']]){
						$row['fid']=$forumkeys[$row['fid']];
					  }
					  $mod=$rewriterule['forum_forumdisplay'];
					  $mod=str_replace('{page}/','',$mod);
					  $mod=preg_replace("/{page}/","1",$mod);
					  $mod=preg_replace("/{prevpage}/","1",$mod);	 
					  $mod=str_replace("{id}",$row['fid'],$mod);
					  $mod=str_replace("{fid}",$row['fid'],$mod);	
					  $mod=str_replace("{tid}",$row['fid'],$mod);
					  $mod=str_replace("{blogid}",$row['fid'],$mod);
					$turl=$web_root.$mod;
				}else{
					$turl=$web_root."forum.php?mod=forumdisplay&amp;fid=".$row['fid'];
				}
				 $link = $turl;
				 $lastpost = date('Y-m-d');
				 $priority=rand(1,10)/10;
				 $sitemap.="<url>\n";
				 $sitemap.="<loc>$link</loc>\n";
				 $sitemap.="<priority>$priority</priority>\n";
				 $sitemap.="<lastmod>$lastpost</lastmod>\n";
				 $sitemap.="<changefreq>always</changefreq>\n";
				 $sitemap.="</url>\n";
			}
			//����
			if($_GET['allow_num'])
			{
				$connx=" LIMIT 0,1000";
			}
			if($_GET['cs2'])
			{
				$csnum=$_GET['cs2'];
				$connx=" LIMIT 0,$csnum";
			}
			//����
			if($csforums){
				$querys = DB::query('SELECT tid,lastpost FROM '.DB::table('forum_thread')." where fid in ($csforums) and displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4'   order by tid desc $connx");
			}else{
				$querys = DB::query('SELECT tid,lastpost FROM '.DB::table('forum_thread')." where displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4'  order by tid desc $connx");
			}
			while($row = DB::fetch($querys))
			{
				 if(in_array('forum_viewthread',$status)){
					  $mod=$rewriterule['forum_viewthread'];
					  $mod=str_replace('{page}/','',$mod);
					  $mod=preg_replace("/{page}/","1",$mod);
					  $mod=preg_replace("/{prevpage}/","1",$mod);	 
					  $mod=str_replace("{id}",$row['tid'],$mod);
					  $mod=str_replace("{fid}",$row['tid'],$mod);	
					  $mod=str_replace("{tid}",$row['tid'],$mod);
					  $mod=str_replace("{blogid}",$row['tid'],$mod);
					$turl=$web_root.$mod;
				}else{
					$turl=$web_root."forum.php?mod=viewthread&amp;tid=".$row['tid'];
				}
				 $link = $turl;
				 $lastpost = $row['lastpost'];
				 $lastpost = date("Y-m-d",$lastpost);
				 $priority=rand(1,10)/10;
				 $sitemap.="<url>\n";
				 $sitemap.="<loc>$link</loc>\n";
				 $sitemap.="<priority>$priority</priority>\n";
				 $sitemap.="<lastmod>$lastpost</lastmod>\n";
				 $sitemap.="<changefreq>daily</changefreq>\n";
				 $sitemap.="</url>\n";
			}
			 $sitemap .= "</urlset>\n";
			 $fp = fopen(DISCUZ_ROOT.'/'.$filename,'w');
			fwrite($fp,$sitemap);
			fclose($fp);
			}
		}
		cpmsg(lang('plugin/seo', 'tips_succeed'), 'action=plugins&operation=config&do=$do&identifier=seo&pmod=baidu_sitemap', 'succeed');
		break;
	
}
?>