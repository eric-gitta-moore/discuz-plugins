<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT.'/source/plugin/seo/function_inc.php';
if(!isset($_G['cache']['plugin']['seo'])){
	loadcache('plugin');
}
$config=$_G['cache']['plugin']['seo'];
$allowaction = array('list', 'detail', 'add');
$op = in_array($_G['gp_op'], $allowaction) ? $_G['gp_op'] : 'list';

$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';

if(file_exists($settingfile)){
	include $settingfile;
}
if(file_exists(DISCUZ_ROOT . './data/cache/cache_seo_setting.php')){
	$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
	include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
}
if(empty($seo_setting)){
	include DISCUZ_ROOT . './source/plugin/seo/seo_setting.php';
	if($_G['charset']!='gbk'){
		$seo_setting['thesaurus_setting']=iconv('gbk','utf-8',$seo_setting['thesaurus_setting']);
		$seo_setting['post_cloud']=iconv('gbk','utf-8',$seo_setting['post_cloud']);
		$seo_setting['allow_tips']=iconv('gbk','utf-8',$seo_setting['allow_tips']);
		
	}
}
switch ($op){
	case 'list':
		$farray=array('f1'=>lang ( 'plugin/seo', 'f1' ),'f2'=>lang ( 'plugin/seo', 'f2' ));
		$typeselect = '<select name="ftype" onchange="if(this.value.indexOf(\'select\') != -1 || this.value.indexOf(\'radio\') != -1) $(\'extra\').style.display=\'\'; else $(\'extra\').style.display=\'none\';">';
		foreach($farray as $k=>$v){
			$typeselect .= '<option value="'.$k.'" '.($seo_setting['ftype'] == $k ? 'selected' : '').'>'.lang ( 'plugin/seo', $k).'</option>';
		}
		$typeselect .= '</select>';
		showformheader("plugins&operation=config&do=$do&identifier=seo&pmod=cloud&op=add");
		showtableheader(lang('plugin/seo', 'tips_cloud'));
		showsetting(lang('plugin/seo','allow_cloud'), 'allow_cloud', $seo_setting['allow_cloud'], 'radio', 0, 1,lang('plugin/seo','allow_cloud_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','post_cloud'), 'post_cloud', $seo_setting['post_cloud'], 'textarea', 0, 1,lang('plugin/seo','post_cloud_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','allow_tips'), 'allow_tips', $seo_setting['allow_tips'], 'text', 0, 1,lang('plugin/seo','allow_tips_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/seo','f_tips'), '','',$typeselect,'','',lang('plugin/seo','f_tips_comment'));
		showtagfooter('tbody');
		showsubmit('editsubmit',lang('plugin/seo','cloud_update'));
		showtablefooter();
		showformfooter();
		break;
	case 'add':		
		if(submitcheck('editsubmit')){
			//�Ʋɼ���������������
			$seo_setting['allow_cloud']=$_GET['allow_cloud'];
			$seo_setting['post_cloud']=$_GET['post_cloud'];
			$seo_setting['allow_tips']=$_GET['allow_tips'];
			$seo_setting['ftype']=$_GET['ftype'];
			require_once libfile('function/cache');
			writetocache('seo_setting', getcachevars(array('seo_setting' => $seo_setting)));//����������������д�뻺��
		cpmsg(lang('plugin/seo', 'cloud_post'), 'action=plugins&operation=config&do=$do&identifier=seo&pmod=cloud', 'succeed');
		break;
	}
	
}
?>