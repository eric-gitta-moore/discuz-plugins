<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_plugin_seo_gjz` (
  `id` int(10) NOT NULL auto_increment,
  `px` int(11) NOT NULL,
  `newname` varchar(255) NOT NULL,
  `newurl` varchar(255) NOT NULL,
  `b` int(11) NOT NULL,
  `i` int(11) NOT NULL,
  `u` int(11) NOT NULL,
  `c` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
)
EOF;
runquery($sql);
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_plugin_seo_portal` (
  `id` int(10) NOT NULL auto_increment,
  `aid` int(10) NOT NULL,
  `catid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY  (`id`)
)
EOF;
runquery($sql);
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_plugin_seo_thread` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `fid` int(10) NOT NULL,
  `tid` int(10) NOT NULL,
  `title` char(100)  NOT NULL,
  `message` mediumtext  NOT NULL,
  PRIMARY KEY  (`id`)
)
EOF;
runquery($sql);
//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_plugin_seo_ping` (
  `id` int(10) NOT NULL auto_increment,
  `tid` int(10) NOT NULL,
  `spidertype` tinyint(3) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `title` char(100) NOT NULL,
  `status` tinyint(10) NOT NULL,
  `url` char(100) NOT NULL,
  `dateline` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
);
EOF;
runquery($sql);
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_plugin_seo_spider` (
  `id` int(10) unsigned NOT NULL default '0',
  `tid` int(10) unsigned NOT NULL default '0',
  `type` tinyint(3) NOT NULL,
  `spider` varchar(10) NOT NULL,
  `spidertime` int(10) unsigned NOT NULL default '0',
  `spiderurl` varchar(100) NOT NULL,
  `spiderip` varchar(15) NOT NULL
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>