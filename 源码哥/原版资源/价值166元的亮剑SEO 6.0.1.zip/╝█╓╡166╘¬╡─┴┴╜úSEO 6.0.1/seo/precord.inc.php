<?php
/*
 *源码哥出品，必属精品
 *源码哥分享吧www.ymg6.com
 *备用域名www.fx8.cc
 *更多精品资源请访问源码哥官方网站免费获取
 *源码哥99%的资源都是回复后直接免费下载的，不像某网站需要这个VIP，那个VIP
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
date_default_timezone_set(PRC);
function toInt($string)
{
    return preg_replace('#[^0-9]#si', '', $string);
}

if(!isset($_G['cache']['plugin']['seo'])){
	loadcache('plugin');
}
$config=$_G['cache']['plugin']['seo'];
$allowaction = array('list', 'detail', 'add');
$op = in_array($_G['gp_op'], $allowaction) ? $_G['gp_op'] : 'list';

$settingfile = DISCUZ_ROOT . './data/sysdata/cache_seo_setting.php';

if(file_exists($settingfile)){
	include $settingfile;
}
if(file_exists(DISCUZ_ROOT . './data/cache/cache_seo_setting.php')){
	$settingfile = DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
	include DISCUZ_ROOT . './data/cache/cache_seo_setting.php';
}
switch ($op){
	case 'list':
		$spidertypearray=array(0=>lang('plugin/seo', 'c5'),1=>lang('plugin/seo', 'g1'));
		$perpage=10;
		$page=$_GET['page']?$_GET['page']:1;
		$start = ($page - 1) * $perpage;

		$count=DB::result_first("select count(*) from ".DB::table("plugin_seo_ping")." order by id desc");//先获取到数组，然后对两个数组进行拼接，这样，先获取到当前页tid的拼接字符串，使用//in($tidarray的方式)然后从蜘蛛记录表中获取相应tid的记录。然后对两个数组进行合并
		$pingrecord=DB::query("select * from ".DB::table("plugin_seo_ping")." order by id desc limit $start,$perpage");
		while($x_thr=DB::fetch($pingrecord)){
			$record[]=$x_thr;
		}
		
		$i=1;
		if($record){
		foreach($record as $v){
			if(count($record)==$i){
				$tidstring.=$v['tid'];
			}else{
				$tidstring.=$v['tid'].',';
			}
			$i++;
		}
		}
		$spidername = array(0=>lang('plugin/seo','c20'),1=>lang('plugin/seo','g1'));
		if($tidstring){
		$myspider=DB::query("select tid,type,spider,max(spidertime) spidertime from ".DB::table("plugin_seo_spider")." where tid in($tidstring) group by tid,type,spider");
		while($x_thr=DB::fetch($myspider)){
			$spider[]=$x_thr;
		}
		if($spider){
			foreach($record as $key=>$value){
				foreach($spider as $spidervalue){
					if($value['tid']==$spidervalue['tid']&&$value['type']==$spidervalue['type']&&$spidername[$value['spidertype']]===$spidervalue['spider']){
						
						$record[$key]['spidertime']=$spidervalue['spidertime'];
						
					}
				}
			}
		}
		}
		
		showtableheader(lang('plugin/seo', 'ping_setting'));
			showsubtitle(array('',lang('plugin/seo', 'c6'),lang('plugin/seo', 'c7'),lang('plugin/seo', 'c8'),'url',lang('plugin/seo', 'c9'),lang('plugin/seo', 'c10'),lang('plugin/seo', 'c11'),lang('plugin/seo', 'c12')));
			$i=1;
			foreach($record as $k=>$v){
				if($v['status']){
					$v['status']=lang('plugin/seo', 'c13');
				}else{
					$v['status']=lang('plugin/seo', 'c14');
				}
				if($v['type']){
					$v['type']=lang('plugin/seo', 'c15');
				}else{
					$v['type']=lang('plugin/seo', 'c16');
				}
				if($v['spidertime']){
					$v['spidertime']=date('Y-m-d H:i:s',$v['spidertime']);
				}else{
					$v['spidertime']=lang('plugin/seo', 'c17');
				}
				showtablerow('', array('class="td25"'), array(
					$i,
					$v['title'],
					$spidertypearray[$v['spidertype']],
					$v['type'],
					$v['url'],
					$v['status'],
					date('Y-m-d H:i:s',$v['dateline']),
					$v['spidertime'],
					"<span id='sl_$v[id]'><img src='static/image/common/loading.gif' onload='load(\"$v[url]\",$v[id],$v[spidertype])'><span>"
				));
				$i++;
			}
		$multi = multi($count,$perpage, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$do&identifier=seo&pmod=new&op=ping");
		showsubmit('', '', '', '', $multi);
		include template('seo:precord');
		break;
	case 'add':
		$result=addslashes($_GET['result']);
		$gsign=addslashes($_GET['gsign']);
		$spidertype='0';
		$spidertypearray=array(0=>lang('plugin/seo', 'c20'));
		$title=addslashes($_GET['subject']);
		$type=addslashes($_GET['type']);
		//$title=iconv('utf-8','gbk',$title);
		$url=addslashes($_GET['b']);
		$tid=addslashes($_GET['tid']);
		if($type){
			$title= DB::result_first("SELECT title FROM ".DB::table('portal_article_title')." where aid=".$tid);
		}else{
			$title= DB::result_first("SELECT subject FROM ".DB::table('forum_thread')." where tid=".$tid);
		}
		$dateline=$_G['timestamp'];
		$pingarray=array("status"=>$result,"title"=>$title,"type"=>$type,"spidertype"=>$spidertype,"tid"=>$tid,"url"=>$url,"dateline"=>$dateline);
		$check=DB::result_first("select count(*) from ".DB::table("plugin_seo_ping")." where tid=".$tid);
		if(!$check){
			DB::insert("plugin_seo_ping",$pingarray);
		}
		if(isset($gsign)){
			$spidertype='1';
			$pingarray=array("status"=>$gsign,"title"=>$title,"type"=>$type,"spidertype"=>$spidertype,"tid"=>$tid,"url"=>$url,"dateline"=>$dateline);
			if(!$check){
				DB::insert("plugin_seo_ping",$pingarray);
			}
		}
		break;
}
?>