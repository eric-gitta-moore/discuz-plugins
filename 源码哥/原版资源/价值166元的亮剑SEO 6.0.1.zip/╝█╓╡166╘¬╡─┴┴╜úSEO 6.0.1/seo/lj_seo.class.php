<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */
class lj_seo{

function downremoteimg($message, $uid)
{
	global $_G;
    //$message = str_replace(array("\r", "\n"),  "\\n", $message);
    preg_match_all("/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]|\[img=\d{1,4}[x|\,]\d{1,4}\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is",
        $message, $image1, PREG_SET_ORDER);
    preg_match_all("/\<img.+src=('|\"|)?(.*)(\\1)([\s].*)?\>/ismUe", $message, $image2,
        PREG_SET_ORDER);
    $temp = $aids = $existentimg = array();
    $rem = array();
    if (is_array($image1) && !empty($image1))
    {
        foreach ($image1 as $value)
        {
            $temp[] = array('0' => $value[0], '1' => trim(!empty($value[1]) ? $value[1] : $value[2]));
            $suf = explode(".", substr(strrev($temp['0']['1']), 0, 7));
            if (!isset($suf[1]))
            {
                $temp['0']['1'] .= ".gif";
            }
        }
    }
    if (is_array($image2) && !empty($image2))
    {
        foreach ($image2 as $value)
        {
            $temp[] = array('0' => $value[0], '1' => trim($value[2]));
        }
    }
    //if (empty($temp)) { $rem['err']=1;}
	@include_once libfile('class/upload');
    require_once libfile('class/image');
    if (is_array($temp) && !empty($temp))
    {
        $upload = new discuz_upload();
        $attachaids = array();

        foreach ($temp as $value)
        {
            $imageurl = $value[1];
            $hash = md5($imageurl);
            if (strlen($imageurl))
            {
                $imagereplace['oldimageurl'][] = $value[0];
                if (!isset($existentimg[$hash]))
                {
                    $existentimg[$hash] = $imageurl;
                    $attach['ext'] = $upload->fileext($imageurl);
                    if (!$upload->is_image_ext($attach['ext']))
                    {
                        continue;
                    }
                    $content = '';
                    if (preg_match('/^(http:\/\/|\.)/i', $imageurl))
                    {
                        $content = dfsockopen($imageurl);
                    } elseif (preg_match('/^(' . preg_quote(getglobal('setting/attachurl'), '/') .
                    ')/i', $imageurl))
                    {
                        $imagereplace['newimageurl'][] = $value[0];
                    }
                    if (empty($content))
                        continue;
                    $patharr = explode('/', $imageurl);
                    $attach['name'] = trim($patharr[count($patharr) - 1]);
                    $attach['thumb'] = '';

                    $attach['isimage'] = $upload->is_image_ext($attach['ext']);
                    $attach['extension'] = $upload->get_target_extension($attach['ext']);
                    $attach['attachdir'] = $upload->get_target_dir('forum');
                    $attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('forum') .
                        '.' . $attach['extension'];
                    $attach['target'] = getglobal('setting/attachdir') . './forum/' . $attach['attachment'];

                    if (!@$fp = fopen($attach['target'], 'wb'))
                    {
                        continue;
                    } else
                    {
                        flock($fp, 2);
                        fwrite($fp, $content);
                        fclose($fp);
                    }
                    if (!$upload->get_image_info($attach['target']))
                    {
                        @unlink($attach['target']);
                        continue;
                    }
                    $attach['size'] = filesize($attach['target']);
                    $upload->attach = $attach;
                    $thumb = $width = 0;
                    if ($upload->attach['isimage'])
                    {
                        if ($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight'])
                        {
                            $image = new image();
                            $thumb = $image->Thumb($upload->attach['target'], '', $_G['setting']['sourcewidth'],
                                $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
                            $width = $image->imginfo['width'];
                            $upload->attach['size'] = $image->imginfo['size'];
                        }
                        if ($_G['setting']['thumbstatus'])
                        {
                            $image = new image();
                            $thumb = $image->Thumb($upload->attach['target'], '', $_G['setting']['thumbwidth'],
                                $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
                            $width = $image->imginfo['width'];
                        }
                        if ($_G['setting']['thumbsource'] || !$_G['setting']['thumbstatus'])
                        {
                            list($width) = @getimagesize($upload->attach['target']);
                        }
                        if ($_G['setting']['watermarkstatus'] && empty($_G['forum']['disablewatermark']))
                        {
                            $image = new image();
                            $image->Watermark($attach['target'], '', 'forum');
                            $upload->attach['size'] = $image->imginfo['size'];
                        }
                    }

                    $aids[] = $aid = getattachnewaid($uid);
                    $setarr = array(
                        'aid' => $aid,
                        'dateline' => $_G['timestamp'],
                        'filename' => $upload->attach['name'],
                        'filesize' => $upload->attach['size'],
                        'attachment' => $upload->attach['attachment'],
                        'isimage' => $upload->attach['isimage'],
                        'uid' => $uid,
                        'thumb' => $thumb,
                        'remote' => '0',
                        'width' => $width);
                    //C::t("forum_attachment_unused")->insert($setarr);
					$setarrs[$setarr['aid']]=$setarr;
                    $attachaids[$hash] = $imagereplace['newimageurl'][] = '[attach]' . $aid .
                        '[/attach]';

                } else
                {
                    $imagereplace['newimageurl'][] = $attachaids[$hash];
                }
            }
        }
        if (!empty($aids))
        {
            require_once libfile('function/post');
        }
        $message = str_replace($imagereplace['oldimageurl'], $imagereplace['newimageurl'],
            $message);
        //$message = addcslashes($message, '/"');

    }
    $mess['aid'] = $aids;
    $mess['message'] = $message;
    $mess['setarr'] = $setarrs;
    return $mess;
}
	
function updatemessage($pid)
{
    
    $arr_mes = DB::fetch_first("SELECT tid,first,authorid,message FROM " . DB::
        table("forum_post") . " WHERE pid=$pid");
    $atableid = $arr_mes['tid'] % 10;
    $uid = $arr_mes['authorid'];
    $re_mes = $this->downremoteimg($arr_mes['message'], $uid);
	foreach($re_mes['aid'] as $aid){
    if (empty($aid))
    {
        return 0;
    } else
    {
        
        DB::update('forum_attachment', array(
            'pid' => $pid,
            'tid' => $arr_mes['tid'],
            'tableid' => $atableid,
            'uid' => $uid), "aid = " . $aid);
        DB::insert("forum_attachment_" . $atableid, array(
            'aid' => $aid,
            'pid' => $pid,
            'tid' => $arr_mes['tid'],
            'dateline' => time(),
            'uid' => $uid,
            'filename' => $re_mes['setarr'][$aid]['filename'],
            'filesize' => $re_mes['setarr'][$aid]['filesize'],
            'attachment' => $re_mes['setarr'][$aid]['attachment'],
            'isimage' => 1,
            'width' => $re_mes['setarr'][$aid]['width']));
        DB::insert("forum_threadimage", array('tid' => $arr_mes['tid'], 'attachment' =>
                $re_mes['setarr'][$aid]['attachment']));

        if (1 == $arr_mes['first'])
        {
            global $_G;
            loadcache('plugin');
            $iscover = $_G['cache']['plugin']['localization_picture'];
            if (1 == $iscover['iscover'])
            {
                $g = setcover($pid, $arr_mes['tid'], $aid);
                if($g) echo 'ghj';

            }
            DB::update("forum_thread", array('attachment' => '2'), "tid = " . $arr_mes['tid']);
        } else
        {
            DB::update("forum_thread", array('attachment' => '2'), "tid = " . $arr_mes['tid']);
        }

        DB::update("forum_post", array('attachment' => '2', 'message' => $re_mes['message']),
            "pid=$pid");
    }
	}
    return 1;
}
}
?>