<?php
/*
 *源码哥分享吧www.ymg6.com
 *备用域名www.fx8.cc
 *更多精品资源请访问源码哥官方网站免费获取
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');

//cronname:cron_daily
//week:-1
//day:-1
//hour:00
//minute:0

$psetting = $_G['cache']['plugin']['k_diyupdatecache'];
include_once libfile('function/block');

if($psetting['bids']){
	$psetting['bidsarray'] = explode(",", $psetting['bids']);
	
	foreach($psetting['bidsarray'] as $bid){
		block_get_batch($bid);
		block_updatecache($bid, true);
	}
}else{
	if($psetting['blocktypes'] == 1){//仅DIY模块
		$bids = C::t("common_block")->fetch_all_bid_by_blocktype(0, 9999);
		foreach($bids as $bid){
			block_get_batch($bid);
			block_updatecache($bid, true);
		}
	}elseif($psetting['blocktypes'] == 2){//仅调用数据
		$bids = C::t("common_block")->fetch_all_bid_by_blocktype(1, 9999);
		foreach($bids as $bid){
			block_updatecache($bid, true);
		}
	}elseif($psetting['blocktypes'] == 3){//全部模块
		$bids = DB::fetch_all('SELECT bid FROM '.DB::table('common_block').' ORDER BY bid DESC', null, 'bid');
		$bids = array_keys($bids);
		foreach($bids as $bid){
			block_get_batch($bid);
			block_updatecache($bid, true);
		}
	}
}