<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
function is_utf8($word) 
{ 
	if (preg_match("/^([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}/",$word) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}$/",$word) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){2,}/",$word) == true) 
	{ 
		return true; 
	} 
	else
	{ 
		return false; 
	} 

} // function is_utf8
$str=file_get_contents('http://www.ymg6.com/gg/addon.php?/?@liangjian');
if($_G['charset']=='utf-8'){
	if(!is_utf8($str)){
	$str=iconv('gbk','utf-8',$str);
}
}

echo str_replace('resource/template/','http://www.ymg6.com/gg/addon.php?/resource/template/',str_replace('resource/developer/','http://www.ymg6.com/gg/addon.php?/resource/developer/',str_replace('resource/plugin/','http://www.ymg6.com/gg/addon.php?/resource/plugin/',$str)));
?>