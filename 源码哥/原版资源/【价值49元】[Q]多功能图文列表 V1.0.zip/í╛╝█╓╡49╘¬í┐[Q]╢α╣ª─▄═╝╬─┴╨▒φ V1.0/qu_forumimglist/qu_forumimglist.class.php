<?php

/**
 *      [FX8!] (C)2013-2016 Www.fx8.cc.
 *      Դ�������� ȫ���׷� http://www.fx8.cc��
 *
 *      $Id: 179667784 2015-11-08 20:57:29Z mpage $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_qu_forumimglist {
	
}


class plugin_qu_forumimglist_forum extends plugin_qu_forumimglist {
	
	function forumdisplay_thread_subject_output() {
		global $_G,$threadtids;
		$q_var = $_G['cache']['plugin']['qu_forumimglist'];
		$q_fids = (array)unserialize($q_var['q_fids']);
		$qpicheight = $q_var['qpicheight'];
		$qpicwidth = $q_var['qpicwidth'];
		$qlimitheight = $q_var['qlimitheight'];
		$q_num = intval($q_var['q_num']);
		$q_ybj = $q_var['q_ybj'];
		$q_sbj = $q_var['q_sbj'];
		$q_xbj = $q_var['q_xbj'];
		$q_zbj = $q_var['q_zbj'];
		$q_yj = $q_var['q_yj'];
		$q_title = $q_var['q_title'];
		$q_dj = intval($q_var['q_dj']);
		$q_zd = intval($q_var['q_zd']);
		$q_dx = intval($q_var['q_dx']);
		$q_zhaiyao = intval($q_var['q_zhaiyao']);
		$enable = $q_var['enable'];
		if($q_dx){$q_dxnr = 'DESC';}else{$q_dxnr = 'ASC';};
		if(!in_array($_G['fid'], $q_fids)) return;
		foreach($_G['forum_threadlist'] as $thread){
			$qimglist = '<style>.threadlist_imglist img{margin:'.$q_sbj.' '.$q_ybj.' '.$q_xbj.' '.$q_zbj.';-moz-border-radius:'.$q_yj.';-webkit-border-radius: '.$q_yj.';border-radius:'.$q_yj.';}</style>';
			include_once libfile('function/post');
			if($q_zhaiyao){
				$zhaiyao = messagecutstr(DB::result_first("SELECT message FROM ".DB::table('forum_post')." WHERE tid =".$thread[tid]." AND first =1"),$q_zhaiyao);
				$qimglist .= '<div class="qing_listsummary cl">'.$zhaiyao.'</div>';
			}
			if($thread['attachment']) {
				$tid = intval($thread['tid']);
				$tableid = getattachtableid($tid);
				$qnum = $q_num ? $q_num : '5';
				$query = DB::query("SELECT * FROM ". DB::table('forum_attachment_'.$tableid)." WHERE tid ='$tid' ORDER BY aid ".$q_dxnr." LIMIT $qnum");
				if ($_G['cookie']['qinghideimg'] > 0){
					$qimglist .='<div class="threadlist_imglist qnone_1">';
				}else{
					$qimglist .='<div class="threadlist_imglist qnone_-1">';
				}
				while ($attach = DB::fetch($query)) {
					$attachurl = $attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'];
					$zoomfile = $attachurl.'forum/'.$attach['attachment'];
					$arrimg = getimagesize($attachurl);
					if($qlimitheight){
						$qwidth = $qpicheight/$arrimg[1] * $arrimg[0];
					}else{
						$qwidth = $qpicwidth;
					}
					$this->height = $qpicheight;
					$this->width = $qwidth;
					$thumb = getforumimg($attach['aid'], 0, $this->width, $this->height);
					if($q_zd){
						if($thread['displayorder'] > 0){
							$qimglist .='';
						}else{
							if($q_dj == 1){
								if($thread['forumstick']){
									$qimglist .= '<img class="qing_imgcursor" src="'.$thumb.'" height="'.$qpicheight.'" onclick="zoom(this, this.src, 0, 0, 0)" />';
								}else{
									$qimglist .= '<img class="qing_imgcursor" src="'.$thumb.'" height="'.$qpicheight.'" onclick="zoom(this, this.src, 0, 0, 0)" />';
								}
							}else{
								if($thread['forumstick']){
									$qimglist .= '<a href="forum.php?mod=viewthread&tid='.$thread['tid'].'" target="_blank"><img src="'.$thumb.'" height="'.$qpicheight.'" /></a>';
								}else{
									$qimglist .= '<a href="forum.php?mod=viewthread&tid='.$thread['tid'].'" onclick="atarget(this)"><img src="'.$thumb.'" height="'.$qpicheight.'" /></a>';
								}
							}
						}
					}else{
						if($q_dj == 1){
								if($thread['forumstick']){
									$qimglist .= '<img class="qing_imgcursor" src="'.$thumb.'" height="'.$qpicheight.'" onclick="zoom(this, this.src, 0, 0, 0)" />';
								}else{
									$qimglist .= '<img class="qing_imgcursor" src="'.$thumb.'" height="'.$qpicheight.'" onclick="zoom(this, this.src, 0, 0, 0)" />';
								}
							}else{
								if($thread['forumstick']){
									$qimglist .= '<a href="forum.php?mod=viewthread&tid='.$thread['tid'].'" target="_blank"><img src="'.$thumb.'" height="'.$qpicheight.'" /></a>';
								}else{
									$qimglist .= '<a href="forum.php?mod=viewthread&tid='.$thread['tid'].'" onclick="atarget(this)"><img src="'.$thumb.'" height="'.$qpicheight.'" /></a>';
								}
							}
					}
				}
				$qimglist .= '</div>';
			}
			$return[] = $qimglist;
		}
		return $return;
	}
	
	
	function forumdisplay_filter_extra() {
		global $_G;
		return '<link rel="stylesheet" type="text/css" href="source/plugin/qu_forumimglist/images/style.css" />';
	}
}

?>