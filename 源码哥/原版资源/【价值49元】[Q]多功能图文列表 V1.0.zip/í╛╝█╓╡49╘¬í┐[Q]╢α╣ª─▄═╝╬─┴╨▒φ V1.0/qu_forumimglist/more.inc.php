<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
?>
<iframe src="http://www.fx8.cc" width="820" height="3200" frameborder="0" scrolling="no" style="margin-top:-55px"></iframe> 
