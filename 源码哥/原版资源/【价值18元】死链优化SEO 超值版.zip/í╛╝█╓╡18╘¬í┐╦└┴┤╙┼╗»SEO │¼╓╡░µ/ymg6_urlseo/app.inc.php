<?php
/**
 * 有任何问题请联系Mickey！
 * QQ：484488314
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied!');
}
?>

<iframe src="http://www.ymg6.com/gg/addon.php?/?@57310.developer" width="1010" height="2300" frameborder="0" scrolling="no"></iframe>