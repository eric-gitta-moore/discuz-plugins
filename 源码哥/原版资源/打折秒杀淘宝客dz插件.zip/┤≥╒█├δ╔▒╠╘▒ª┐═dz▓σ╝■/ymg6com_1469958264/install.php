<?php
/**
 * [安装]
 */
if(!defined('IN_DISCUZ')) {  
    exit('Access Denied');  
}  
// 载入配置项
include 'config/config_global.php';
// 定义表前缀
$_pr = $_config['db']['1']['tablepre'];  
//各种安装操作  
$sql = "SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for " . $_pr . "cctbk_goods
-- ----------------------------
DROP TABLE IF EXISTS `" . $_pr . "cctbk_goods`;
CREATE TABLE `" . $_pr . "cctbk_goods` (
  `gid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gtitle` char(50) NOT NULL DEFAULT '',
  `gprice` decimal(7,2) unsigned NOT NULL DEFAULT '0.00',
  `gnewprice` decimal(7,2) unsigned NOT NULL DEFAULT '0.00',
  `gpic` varchar(200) NOT NULL DEFAULT '',
  `gtbpic` varchar(200) NOT NULL DEFAULT '',
  `gsort` int(10) unsigned NOT NULL DEFAULT '0',
  `gbuynum` int(10) unsigned NOT NULL DEFAULT '0',
  `gurl` varchar(200) NOT NULL DEFAULT '',
  `gcowrieid` char(20) NOT NULL DEFAULT '0',
  `gcoupon` set('".$installlang['coupon_1']."','".$installlang['coupon_2']."','".$installlang['coupon_3']."','".$installlang['coupon_4']."') NOT NULL DEFAULT '".$installlang['coupon_1']."',
  `gtheirweb` set('tmall','taobao') NOT NULL DEFAULT '',
  `gtag` char(30) NOT NULL DEFAULT '',
  `gbegintime` varchar(20) NOT NULL DEFAULT '',
  `govertime` varchar(20) NOT NULL DEFAULT '',
  `gaddtime` int(10) unsigned NOT NULL DEFAULT '0',
  `gwangwang` char(20) NOT NULL DEFAULT '',
  `seller_id` char(20) NOT NULL DEFAULT '',
  `discount` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `gremark` varchar(300) NOT NULL DEFAULT '',
  `category_cid` int(10) unsigned NOT NULL DEFAULT '0',
  `category_cname` char(20) NOT NULL DEFAULT '',
  `channel_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`)
) ENGINE=MyISAM;";  
runquery($sql);  
  
$finish = TRUE;  