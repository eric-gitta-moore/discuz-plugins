<?php
/**
 * [商品管理]
 */
// 判断常量 安全处理
if(!defined('IN_DISCUZ')) exit('Access Denied');
// 定义css js img 路径常量
define('P_ROOT', 'source/plugin/ymg6com_1469958264');
// 定义当前路径
define('THIS_URL', 'admin.php?action=plugins&operation=config&do=43&identifier=ymg6com_1469958264&pmod=goods');
// 定义当前域名
define('THIS_WEB', $_SERVER['HTTP_HOST']);
// 载入函数库
include 'source/plugin/ymg6com_1469958264/function.func.php';
// 载入公共菜单模板
include template('ymg6com_1469958264:adminCommon');
include 'config/config_global.php';

//----------------------------执行控制器中的方法-----------------------------
// 实例化商品管理控制器
$control = new GoodsControl($_config);
// 判断方法名
if(!$_GET['method']){
	// 执行商品列表方法
	$control -> index();
}
if($_GET['method'] == 'add'){
	// 执行添加方法
	$control -> add();
}
if($_GET['method'] == 'del'){
	// 执行删除方法 
	$control -> del();
}
if($_GET['method'] == 'modify'){
	// 执行修改方法
	$control -> modify();
}

//----------------------------商品管理控制器-----------------------------
class GoodsControl{
	private $_category;	// 分类
	private $_channel;	// 频道
	private $_pr;		// 表前缀

	/**
	 * [__construct 构造函数]
	 */
	public function __construct($_config){
		$this -> _category = include 'source/plugin/ymg6com_1469958264/data/category.inc.php';	// 获取分类数据
		$this -> _channel = include 'source/plugin/ymg6com_1469958264/data/channel.inc.php';		// 获取频道数据
		$this -> _pr = $_config['db']['1']['tablepre'];
	}

	/**
	 * [index 商品列表]
	 */
	public function index(){
		// 获取分页信息
		$page = $_GET['page'] ? $_GET['page'] : 1;
		$pageSize = 10;
		// 判断分页数据是否合法
		if (!is_numeric($page) || !is_numeric($pageSize)) {
			die(lang('plugin/ymg6com_1469958264', 'page_error'));
		}
		// 定义分页起始数据
		$offset = ($page - 1) * $pageSize;
		// 组合SQL
		$goodsSql = "SELECT * FROM " . $this -> _pr . "cctbk_goods ORDER BY gaddtime DESC LIMIT " . $offset . "," . $pageSize;
		// 查询数据
		$goods = DB::fetch_all($goodsSql);

		// ---------------------分页---------------------
		// 获取商品总数
		$allGoods = DB::fetch_all("SELECT COUNT(*) FROM " . $this -> _pr . "cctbk_goods");
		// 计算总页数
		$allPage = ceil($allGoods['0']['COUNT(*)'] / $pageSize);
		// 分页
		$multipage = multi($allGoods['0']['COUNT(*)'], $pageSize, $page, THIS_URL, $allPage);
		// 载入商品列表模板
		include template('ymg6com_1469958264:goods');
	}

	/**
	 * [add 商品添加]
	 */
	public function add(){
		// 判断POST提交是否有数据
		if (submitcheck('submitgoods')) {
			// 获取POST数据
			$data = $_POST;
			unset($data['formhash']);
			unset($data['submitgoods']);
			// 商品标签处理
			$data['gtag'] = implode(',', $data['gtag']);
			// 商品图片处理
			$data['gpic'] = $this -> _up();
			// 商品生成时间
			$data['gaddtime'] = time();
			// 标题处理
			$data['gtitle'] = htmlspecialchars($data['gtitle']);
			$data['gremark'] = htmlspecialchars($data['gremark']);
			// 处理所属分类
			$data['category_cname'] = $this -> _category[$data['category_cid']]['cname'];
			// 插入数据库
			if(DB::insert('cctbk_goods', $data, true)){
				$this -> _success(lang('plugin/ymg6com_1469958264', 'add_success'), THIS_URL);
			}else{
				$this -> _error(lang('plugin/ymg6com_1469958264', 'add_failed'), THIS_URL);
			}
		}
		// 定义活动开始时间
		$beginDay = date('Y-m-d');
		// 定义活动结束时间
		$endDay = date('Y-m-d', time() + 60 * 60 * 24 * 7);
		// 获取分类
		$category = $this -> _category;
		// 获取频道信息
		$channel = $this -> _channel;

		// 载入商品列表模板
		include template('ymg6com_1469958264:goods_add');
	}

	/**
	 * [modify 修改商品]
	 * @return [type] [description]
	 */
	public function modify(){
		// 获得要修改的商品GID
		$gid = $_GET['gid'] ? $_GET['gid'] : 0;
		// 判断gid是否合法
		if (!is_numeric($gid)) {
			$this -> _error(lang('plugin/ymg6com_1469958264', 'edit_goods_not_found'));
		}
		// 判断POST提交
		if(submitcheck('submitgoods')){
			// 获取POST数据
			$data = $_POST;
			unset($data['formhash']);
			unset($data['submitgoods']);
			// 商品标签处理
			$data['gtag'] = implode(',', $data['gtag']);
			// 商品图片处理
			$data['gpic'] = $this -> _up();
			// 商品生成时间
			$data['gaddtime'] = time();
			// 标题处理
			$data['gtitle'] = htmlspecialchars($data['gtitle']);
			$data['gremark'] = htmlspecialchars($data['gremark']);
			// 处理所属分类
			$data['category_cname'] = $this -> _category[$data['category_cid']]['cname'];
			// 插入数据库
			if(DB::update('cctbk_goods', $data, array('gid' => $gid))){
				$this -> _success(lang('plugin/ymg6com_1469958264', 'edit_success'), THIS_URL);
			}else{
				$this -> _error(lang('plugin/ymg6com_1469958264', 'edit_failed'), THIS_URL);
			}
		}
		//获取所有分类
		$category = $this -> _category;
		// 获取频道信息
		$channel = $this -> _channel;
		// 获得商品旧数据
		$oldData = DB::fetch_first("SELECT * FROM " . $this -> _pr . "cctbk_goods WHERE gid=" . $gid);		
		// 处理标签
		$oldData['gtag'] = explode(',', $oldData['gtag']);
		// 载入修改商品模板
		include template('ymg6com_1469958264:goods_modify');
	}

	/**
	 * [del 删除商品]
	 */
	public function del(){
		// 获取要删除的商品ID
		$gid = $_GET['gid'] ? $_GET['gid'] : 0;
		// 判断商品ID是否合法
		if (!is_numeric($gid)) {
			$this -> _error(lang('plugin/ymg6com_1469958264', 'delete_goods_not_found'));
		}
		// 执行删除方法 判断是否成功
		if (DB::delete('cctbk_goods', array('gid' => $gid))){
			// 删除成功
			$this -> _success(lang('plugin/ymg6com_1469958264', 'delete_success'),THIS_URL);
		}else{
			// 删除失败 
			$this -> _error(lang('plugin/ymg6com_1469958264', 'delete_failed'));
		}
	}

	/**
	 * [_up 图片上传]
	 * @return [type] [description]
	 */
	private function _up(){
		// 载入上传类
		include 'source/plugin/ymg6com_1469958264/Upload.class.php';
		//判断是否有上传图片
		if(!empty($_FILES['gpic']['name'])){
			// 实例化上传类
			$upload = new UploadFile();
			// 设置附件上传大小
			$upload -> maxSize  = 3145728 ;
			// 设置附件上传类型
			$upload -> allowExts  = array('jpg', 'gif', 'png', 'jpeg');
			// 设置附件上传目录
			$path = 'data/attachment/common/' . date('Ymd') . '/';
			// 创建目录
			is_dir($path) || mkdir($path,0777,true);
			// 上传目录
			$upload -> savePath = $path;
			if(!$upload -> upload()) {
				// 上传错误提示错误信息
				$this -> error($upload->getErrorMsg());
			}else{
				// 上传成功 获取上传文件信息
				$info =  $upload -> getUploadFileInfo();
				$info = current($info);
				$imgpath = $info['savepath'] . $info['savename'];
				$imgpath = ltrim($imgpath,'.');
				return $imgpath;
			}
		}
	}

	/**
	 * [_success 操作成功]
	 * @param  [type] $msg [提示信息]
	 * @param  [type] $url [跳转地址]
	 */
	private function _success($msg,$url){
		echo "<script>alert('$msg');location.href='$url';</script>";
		die();
	}
	
	/**
	 * [_error 操作失败]
	 * @param  [type] $msg [提示信息]
	 * @return [type]      [description]
	 */
	private function _error($msg){
		echo "<script>alert('$msg');history.back();</script>";
		die();
	}
}