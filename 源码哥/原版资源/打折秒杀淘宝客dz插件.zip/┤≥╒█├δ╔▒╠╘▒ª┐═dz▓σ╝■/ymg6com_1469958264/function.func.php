<?php
/**
 * [函数库]
 */
/**
 * [S 缓存控制函数]
 * @param string  		 $key   [缓存文件名]
 * @param array,string   $value [缓存值]
 * @param integer 		 $time  [缓存时间(0:永久缓存)]
 */
function S($key = '', $value = '', $time = 0){
	// 定义缓存目录
	$cacheDir = 'data/cache/';
	// 定义缓存文件名
	$fileName = $cacheDir . $key . '.txt';

	// 如果$value === NULL 删除缓存
	if ($value === NULL) return @unlink($fileName);

	// 如果$value不为空 写入缓存
	if ($value) {
		// 创建缓存目录
		is_dir($cacheDir) || mkdir($cacheDir);
		// 生成缓存时间
		$time = sprintf('%011d', $time);
		// 生成缓存文件
		return file_put_contents($fileName, $time . json_encode($value));
	}

	// 如果$value == '' 读取缓存
	if ($value == '') {
		// 判断缓存文件是否存在
		if (!is_file($fileName)) return false;
		// 获取缓存数据
		$data = file_get_contents($fileName);
		// 获取缓存时间
		$time = (int)substr($data, 0,11);
		// 判断缓存时间是否失效 (文件生成时间 + 缓存时间) 是否小于当前时间
		if ($time !=0 && (fileatime($fileName) + $time) < time()) {
			// 缓存失效 删除缓存文件
			@unlink($fileName);
			return false;
		}
		// 获取缓存真实数据
		$cacheData = json_decode(substr($data, 11), true);
		return $cacheData;
	}
}

/**
 * [M 实例化模型]
 * @param  [string] $table [表名]
 * @return [object]        [反出模型对象]
 */
function M($table,$_config){
	// 实例化模型
	$model = new Model($table,$_config);
	// 反出模型对象
	return $model;
}

/**
 * [utf82gbk 转字符集]
 * @param  [type] $data [description]
 * @return [type]       [description]
 */
function utf82gbk($data){
    if(is_array($data)){
        return array_map('utf82gbk', $data);
    }
    return iconv('utf-8','gbk',$data);
}

/**
 * [p 打印函数]
 * @param  [type] $var [变量]
 * @return [type]      [description]
 */
function p($var) {
	if (is_bool($var)) {
		var_dump($var);
	} else if (is_null($var)) {
		var_dump(NULL);
	} else {
		echo "<pre style='padding:10px;border-radius:5px;background:#F5F5F5;border:1px solid #aaa;font-size:14px;line-height:18px;'>" . print_r($var, true) . "</pre>";
	}
}