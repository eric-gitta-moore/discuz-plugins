<?php
/**
 * [异步采集商品]
 */
// 判断常量 安全处理
if(!defined('IN_DISCUZ')) exit('Access Denied');
// $a = substr($str, 0, strpos($str, '-'));
// 载入函数库
include 'source/plugin/ymg6com_1469958264/function.func.php';
// 载入配置项
include 'config/config_global.php';
// 定义表前缀
$_pr = $_config['db']['1']['tablepre'];
// --------------------------定义AJAX提交常量--------------------------
if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	define('IS_AJAX', TRUE);
}else{
	define('IS_AJAX', FALSE);
}
// 不是AJAX请求 输出错误信息
if(IS_AJAX){
	// 是否推荐
	if($_POST['data']['isrec'] == 1){
		$isrec = lang('plugin/ymg6com_1469958264', 'goods_tag_2');
	}
	if($_POST['data']['ispost'] == 1){
		$ispost = lang('plugin/ymg6com_1469958264', 'goods_tag_1');
	}
	// 获取分类数据
	$category = include 'source/plugin/ymg6com_1469958264/data/category.inc.php';	
	// 重组数据
	$addData = array(
		'gtitle'		=> $_POST['data']['title'],						// 标题 
		'gprice'		=> $_POST['data']['price'],						// 价格
		'gnewprice'		=> $_POST['data']['promotion_price'],			// 促销价
		'gpic'			=> $_POST['data']['pic'],						// 图片
		'gtbpic'		=> $_POST['data']['taobao_pic'], 				// 淘宝图片
		'gsort'			=> $_POST['data']['sort'],						// 排序
		'gbuynum'		=> $_POST['data']['volume'],					// 销量
		'gurl'			=> $_POST['data']['url'],						// 链接地址
		'gcowrieid'		=> $_POST['data']['num_iid'],					// 宝贝ID
		'gtheirweb'		=> $_POST['data']['site'],						// 所属商城
		'gbegintime'	=> date('Y-m-d', $_POST['data']['start']),		// 开始时间
		'govertime'		=> date('Y-m-d',$_POST['data']['end']),			// 结束时间
		'gaddtime'		=> $_POST['data']['dateline'], 					// 添加时间
		'seller_id'		=> $_POST['data']['seller_id'],					// 商家ID
		'gwangwang'		=> $_POST['data']['nick'],						// 商家旺旺
		'category_cid'	=> $_POST['data']['cat'],						// 所属分类ID
		'discount'		=> $_POST['data']['discount'],					// 折扣
		'channel_id'	=> $_POST['data']['channel'],					// 所属频道
	);
	
	if(defined('CHARSET') && CHARSET != 'utf-8') {
		$addData = utf82gbk($addData);
	}
	$addData['gtag'] = $ispost . ',' . $isrec;					// 标签
	// 所属分类名
	$addData['category_cname'] = $category[$_POST['data']['cat']]['cname'];

	// 判断是否添加过
	if(DB::fetch_first("SELECT gtitle FROM " . $_pr . "cctbk_goods WHERE gtitle=" .  "'" . $addData['gtitle'] . "'")){
		echo 3;die();
	}else{
		// 数据入库  
		if(DB::insert('cctbk_goods', $addData, true)){
			echo 1;die();
		}else{
			echo 0;die();
		}
	}
	
}
