<?php
/**
 * [卸载]
 */
if(!defined('IN_DISCUZ')) {  
    exit('Access Denied');  
}    
// 载入配置项
include 'config/config_global.php';
// 定义表前缀
$_pr = $_config['db']['1']['tablepre'];  
//各种反安装操作，恢复安装时的修改  
$sql = "DROP table " . $_pr . "cctbk_goods;";
runquery($sql);   
    
$finish = TRUE;  