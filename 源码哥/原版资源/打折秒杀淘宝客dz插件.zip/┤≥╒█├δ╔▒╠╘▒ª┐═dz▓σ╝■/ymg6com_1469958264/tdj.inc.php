<?php
/**
 * [淘点金跳转页面]
 */
define('P_ROOT', 'source/plugin/ymg6com_1469958264');
// 定义商品ID
$iid = $_GET['iid'];
// 获取淘点金代码
loadcache();
$tdjCode = $_G['cache']['plugin']['ymg6com_1469958264']['tdjcode'];

// 正则匹配淘点金pid
preg_match_all('/pid:.*?"(.*?)",/', $tdjCode, $pregPid);
$pid = $pregPid[1][0];

// 载入跳转页
include template('ymg6com_1469958264:tdj');