<?php
/**
 * [LOGO管理]
 */
// 判断常量 安全处理
if(!defined('IN_DISCUZ')) exit('Access Denied');
// 定义css js img 路径常量
define('P_ROOT', 'source/plugin/ymg6com_1469958264');
// 载入函数库
include 'source/plugin/ymg6com_1469958264/function.func.php';
// 载入公共菜单模板
include template('ymg6com_1469958264:adminCommon');
// 定义当前URL
define('THIS_URL', $_SERVER['HTTP_REFERER']);

if(submitcheck('submitlogo')){
	// 判断LOGO方式
	if(($_POST['pic'] && $_FILES['gpic']['name']) || (!$_POST['pic'] && !$_FILES['gpic']['name'])){
		echo "<script>alert('".lang('plugin/ymg6com_1469958264', 'logo_error')."');location.href='" . THIS_URL . "'</script>";
		die();
	}

	// 判断POST提交
	if($_POST['pic']){
		// 判断格式是否正确
		$url = $_POST['pic'];
		if(!preg_match('/^(http:\/\/)(.*?)/', $url)){
			echo "<script>alert('".lang('plugin/ymg6com_1469958264', 'logo_url_error')."');location.href='" . THIS_URL . "'</script>";
		}else{
			// 保存图片
			S('logo', NULL);
			S('logo', $url, 0);
			echo "<script>alert('".lang('plugin/ymg6com_1469958264', 'logo_save_ok')."');</script>";
		}
	// 判断是否文件上传
	}else if($_FILES['gpic']['name']){
		// 载入上传类
		include 'source/plugin/ymg6com_1469958264/Upload.class.php';
		// 实例化上传类
		$upload = new UploadFile();
		// 设置附件上传大小
		$upload -> maxSize  = 3145728 ;
		// 设置附件上传类型
		$upload -> allowExts  = array('jpg', 'gif', 'png', 'jpeg');
		// 设置附件上传目录
		$path = 'data/attachment/common/logo/';
		// 创建目录
		is_dir($path) || mkdir($path,0777,true);
		// 上传目录
		$upload -> savePath = $path;
		if(!$upload -> upload()) {
			// 上传错误提示错误信息
			$this -> error($upload->getErrorMsg());
		}else{
			// 上传成功 获取上传文件信息
			$info =  $upload -> getUploadFileInfo();
			$info = current($info);
			$imgpath = $info['savepath'] . $info['savename'];
			$imgpath = ltrim($imgpath,'.');
			// 保存图片
			S('logo', NULL);
			S('logo', $imgpath, 0);
			echo "<script>alert('".lang('plugin/ymg6com_1469958264', 'logo_save_ok')."');</script>";
		}
	}
}
// 获取LOGO 
$logo = S('logo');

// 载入LOGO设置页面
include template('ymg6com_1469958264:logo');