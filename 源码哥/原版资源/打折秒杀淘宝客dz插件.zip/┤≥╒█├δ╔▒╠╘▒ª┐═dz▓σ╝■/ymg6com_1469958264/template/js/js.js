/**
 * [列表页JS效果]
 */
jQuery(document).ready(function(){
	/**
	 * [商品列表页效果]
	 */
    

    /**
     * [分页处理]
     */
    jQuery('.mypage .pg .prev').text(cctbk_lang.prepage);

    /**
     * [backTime 倒计时]
     */
   // 倒计时定时器
    setInterval(backTime, 1000);
    setInterval(backTime2, 1000);

	/**
     * [backTime 倒计时]
     */
    function backTime(){
      // 循环时间容器
      jQuery.each(jQuery('.settime'), function() {
        if(this.getAttribute("endTime") == ''){
          jQuery(this).html(cctbk_lang.tobegin);
          return;
        }
        // 获取结束时间
        var endTime = this.getAttribute("endTime");
        // 获取当前时间
        var _time = Date.parse(new Date()) / 1000;
        // 计算当前和结束的时间差
        var lag = endTime - _time;
        // 判断时间差是否大于0
        if (lag > 0) {
           // 计算天
           var day = Math.floor((lag / 3600) / 24);
           // 计算时
           var hour = Math.floor((lag / 3600) % 24);
           // 计算分
           var minite = Math.floor((lag / 60) % 60);
           // 计算秒
           var second = Math.floor(lag % 60);  
           // 输出时间
           jQuery(this).html(day + cctbk_lang.day + (hour < 10 ? '0' + hour + "" : ''+hour+'') + cctbk_lang.hour + (minite < 10 ? '0' + minite + "" : ''+minite+'') + cctbk_lang.minute + (second < 10 ? '0' + second + "" : ''+second+'') + cctbk_lang.second);
        }else{
          // 输出结束
          jQuery(this).html('00' + cctbk_lang.day + '00' + cctbk_lang.hour + '00' + cctbk_lang.minute + '00' + cctbk_lang.second);
        }
      });
    }


    function backTime2(){
      // 循环时间容器
      jQuery.each(jQuery('..shop_list .settime'), function() {
        if(this.getAttribute("endTime") == ''){
          jQuery(this).html(cctbk_lang.tobegin);
          return;
        }
        // 获取结束时间
        var endTime = this.getAttribute("endTime");
        // 获取当前时间
        var _time = Date.parse(new Date()) / 1000;
        // 计算当前和结束的时间差
        var lag = endTime - _time;
        // 判断时间差是否大于0
        if (lag > 0) {
           // 计算天
           var day = Math.floor((lag / 3600) / 24);
           // 计算时
           var hour = Math.floor((lag / 3600) % 24);
           // 计算分
           var minite = Math.floor((lag / 60) % 60);
           // 计算秒
           var second = Math.floor(lag % 60);  
           // 输出时间
           jQuery(this).html(day + cctbk_lang.day + (hour < 10 ? '0' + hour + "" : ''+hour+'') + cctbk_lang.hour + (minite < 10 ? '0' + minite + "" : ''+minite+'') + cctbk_lang.minute + (second < 10 ? '0' + second + "" : ''+second+'') + cctbk_lang.second);
        }else{
          // 输出结束
          jQuery(this).html('00' + cctbk_lang.day + '00' + cctbk_lang.hour + '00' + cctbk_lang.minute + '00' + cctbk_lang.second);
        }
      });
    }
    /**
     * [fixedTop 距离顶部固定元素]
     * @param  {[string]}  id      [元素ID]
     * @param  {[integer]} topdis  [距离顶部距离]
     * @param  {[integer]} oldleft [原左边偏移]
     */
    function fixedTop(id, topdis, oldleft){
      // 获取元素顶部的偏移
      var mainTop = jQuery('#' + id).offset().top;
      // 绑定滚动条滚动事件
      jQuery(window).bind('scroll', function() {
        // 判断文档顶部偏移是否大于元素顶部偏移
        if(jQuery(window).scrollTop() >= mainTop){
          // 获取元素距离左边的偏移
          var idLeft = Math.round(jQuery('#' + id).offset().left);
          // 增加元素固定属性
          jQuery('#' + id).css({'position' : 'fixed' , 'top' : topdis + 'px', 'left' : idLeft + 'px'});
        }else{
          // 去除元素固定属性
          jQuery('#' + id).css({'position' : 'absolute', 'left': oldleft + 'px'});
        }
      });
    }
    fixedTop('category', 0, -160);

    // 异步加载图片
      /*jQuery('img.lazy').lazyload({
        thershold : 200,      // 距离图片200px时加载
        effect : "fadeIn",    // 加载完成后淡入
      });*/

    // 页面加载完后执行
    
	window.onload = function(){
      // 获取图片对象
      var imgobj = jQuery('.shop_list ul li a img');
      // 循环图片对象
      jQuery.each(imgobj, function(k, v) {
        // 获取对象的url地址
         var src = jQuery(this).attr('data-original');
         // 实例化图片加载对象
         var img = new Image();
         // 传人图片src
         img.src = src;
         // 图片加载完成后
         img.onload = function(){
             // 赋值到图片对象中
             v.src = src;
         }
      });
    }
	

});
