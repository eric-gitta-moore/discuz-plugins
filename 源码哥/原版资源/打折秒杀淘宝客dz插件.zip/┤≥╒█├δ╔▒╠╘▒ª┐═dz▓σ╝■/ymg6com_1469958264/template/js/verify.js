/**
 * [数据验证,异步处理]
 */
jQuery(function(){
    // 验证分类
    jQuery('.add_window input').blur(function() {
        // 验证分类名
        if(jQuery(this).is('.cname')){
             var obj = jQuery(this);
             //清除添加的span标签
            jQuery(this).parent().find(".sp").remove();
            // 验证分类名长度
            if(this.value.length > 20 || this.value == ''){
                //定义错误提示
                var str = jQuery(cctbk_verify_lang.category_error_1);   
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }else{
                //定义正确提示
                var str = jQuery(cctbk_verify_lang.ok);   
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }
        }
        // 验证排序
        if(jQuery(this).is('.csort')){
             var obj = jQuery(this);
             //清除添加的span标签
            jQuery(this).parent().find(".sp").remove();
            // 验证分类名长度
            if(!this.value.match(/[0-9]/) || this.value.length > 3 || this.value > 255){
                //定义错误提示
                var str = jQuery(cctbk_verify_lang.order_error);  
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }else{
                //定义正确提示
                var str = jQuery(cctbk_verify_lang.ok);   
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }
        }
    });

    // 验证商品
    jQuery('.goods_add input').blur(function() {
        // 验证分类名
        if(jQuery(this).is('.gtitle')){
             var obj = jQuery(this);
             //清除添加的span标签
            jQuery(this).parent().find(".sp").remove();
            // 验证分类名长度
            if(this.value.length > 50 || this.value == ''){
                //定义错误提示
                var str = jQuery(cctbk_verify_lang.category_error_2);   
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }else{
                //定义正确提示
                var str = jQuery(cctbk_verify_lang.ok);   
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }
        }
        // 验证新旧价格
        if(jQuery(this).is('.gprice,.gnewprice')){
             var obj = jQuery(this);
             //清除添加的span标签
            jQuery(this).parent().find(".sp").remove();
            // 验证分类名长度
            if(!this.value.match(/[0-9\.]+?/) || this.value.length > 7){
                //定义错误提示
                var str = jQuery(cctbk_verify_lang.price_error);  
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }else{
                //定义正确提示
                var str = jQuery(cctbk_verify_lang.ok);   
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }
        }
        // 验证宝贝ID
        if(jQuery(this).is('.gcowrieid')){
             var obj = jQuery(this);
             //清除添加的span标签
            jQuery(this).parent().find(".sp").remove();
            // 验证分类名长度
            if(this.value == '' || this.value.length > 20){
                //定义错误提示
                var str = jQuery(cctbk_verify_lang.goods_id_error);  
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }else{
                //定义正确提示
                var str = jQuery(cctbk_verify_lang.ok);   
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }
        }
        // 验证购买量
        if(jQuery(this).is('.gbuynum')){
             var obj = jQuery(this);
             //清除添加的span标签
            jQuery(this).parent().find(".sp").remove();
            // 验证分类名长度
            if(!this.value.match(/\d+?/) || this.value.length > 10){
                //定义错误提示
                var str = jQuery(cctbk_verify_lang.buynum_error);  
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }else{
                //定义正确提示
                var str = jQuery(cctbk_verify_lang.ok);   
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }
        }
        // 验证排序
        if(jQuery(this).is('.gsort')){
             var obj = jQuery(this);
             //清除添加的span标签
            jQuery(this).parent().find(".sp").remove();
            // 验证分类名长度
            if(!this.value.match(/\d+?/) || this.value > 65535){
                //定义错误提示
                var str = jQuery(cctbk_verify_lang.sort_error);  
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }else{
                //定义正确提示
                var str = jQuery(cctbk_verify_lang.ok);   
                //追加到父级标签中
                jQuery(this).parent().append(str);
            }
        }
    });

    // 提交点击事件
    jQuery('.add_window .going').click(function(){
        //所有input进行一次失去焦点
        jQuery('.add_window input').trigger('blur');
        //获取错误数
        var error = jQuery('.error').length;
        //判断错误数 验证是否通过
        if(error){
            return false;
        }
        return true;
    })

    // 提交点击事件
    jQuery('.goods_going').click(function(){
        //所有input进行一次失去焦点
        jQuery('.goods_add input').trigger('blur');
        //获取错误数
        var error = jQuery('.error').length;
        //判断错误数 验证是否通过
        if(error){
            return false;
        }
        return true;
    })

    // LOGO设置
    jQuery('.logo_up').click(function(){
        jQuery("input[name='gpic']").click();
    })

    // 一键获取点击事件
    jQuery('.goods_add .gain').click(function(){
        // 加载状态开始
        jQuery('#loding').show();
        // 获取URL地址
        var url = jQuery('.goods_add .gurl').val();
        // 匹配商城
        var store = '';
        if (url.match(/taobao/)) {
            store = cctbk_verify_lang.taobao;
        }else if(url.match(/tmall/)){
            store = cctbk_verify_lang.tmall;
        }

        // 判断商城是否正确
        if(store != cctbk_verify_lang.tmall && store != cctbk_verify_lang.taobao){
            jQuery('#loding').hide();
            alert(cctbk_verify_lang.goods_url_error);
            return false;
        }
        // 所属网站
        if(store == cctbk_verify_lang.taobao){
            jQuery('.goods_add .taobao').attr({'checked':'checked'});
        }else if(store == cctbk_verify_lang.tmall){
            jQuery('.goods_add .tmall').attr({'checked':'checked'});
        }
        // 获取商品ID
        var goodsId = url.match(/(?:\^|\?|&)id=(\d*)/);
        var gid = goodsId[1];
        if (!gid) {
            alert(cctbk_verify_lang.goods_url_error);
            return false;
        }
        // 请求数据
        var web = 'http://s.wangyue.cc/gather.php?d=s.wangyue.cc&v=2.3.0&api=getgoods&type=discuz';
        jQuery.getScript(web,function(){
            get_goods(gid,'setgoods');
        });
    })   
    
    // 采集点击事件
    jQuery('.gather_going').click(function(){
        // 加载状态
        jQuery('.gatherloding').show();
        // 获取频道
        jQuery.each(jQuery('.mychan'), function(k, v) {
            // 判断是否选中
             if(jQuery(this).attr('checked')){
                // 组合频道数组
                channel.unshift(v.value);
             }
        }); 

        chan_i = 0;
        page = 1;
        get_gather_data(page, 5, channel[chan_i]);
    }) 

});

// 采集处理
function caiji(json){
    // console.log(json);
    // 获取商品总数
    var tootal = json.num;
    // 计算页数
    var allpage = Math.ceil(tootal / 5);
    // 循环商品 发送异步
    jQuery.each(json.goods, function(k, v) {
         jQuery.ajax({
             url: 'plugin.php?id=ymg6com_1469958264:ajax',
             type: 'post',
             async:false,
             dataType: 'text',
             data: {'data': v},
             success:function(data){
                // 滚动条固定在底部
                jQuery('.content').scrollTop(jQuery('.content')[0].scrollHeight + 10);
                if(data == 0){
                    // prepend  before
                    jQuery('#gather .content').append('<p style="color:red">' + cctbk_verify_lang.collect + v.title + cctbk_verify_lang.collect_failed + '</p>');
                }else if(data == 3){
                    jQuery('#gather .content').append('<p style="color:red">' + v.title + cctbk_verify_lang.collect_duplicate + '</p>');
                }else if(data == "1"){
                    jQuery('#gather .content').append('<p style="color:green">' + cctbk_verify_lang.collect + v.title + cctbk_verify_lang.collect_success +'</p>');
                } 
             }
         }) 
    });
	alert(cctbk_verify_lang.collect_ok);
    jQuery('.gatherloding').hide();
	return false;
	
	
    console.log('channel->'+channel[chan_i]+'-----page->'+page);
    page++; // 分页自增
    if(page <= allpage){
        get_gather_data(page, 5, channel[chan_i]);
        return;
    }
    page = 1;
    chan_i++;
    if(channel[chan_i]){
        get_gather_data(page, 5, channel[chan_i]);
        return;
    }
    // 关闭加载状态
	alert(cctbk_verify_lang.collect_ok);
    jQuery('.gatherloding').hide();
}

// 获取采集数据
function get_gather_data(page, limit, channel){
    // 组合url
    var url = "http://www.coucai.net/gatherd/getdiscuzgoods.php?channel="+channel+"&cat=6,7,8,9,10,11,12,13,14,15&page="+page+"&limit="+limit+"&callback=caiji";
    jQuery.ajax({
        url: url,
        type: 'get',
        async:false,
        dataType: 'jsonp',
        jsonp: 'jsoncallback',
        data: {param1: 'value1'},
        success:function(json){
            caiji(json);
        }
    })
}

// get_goods 回调处理
function setgoods(json){
    // 设置表单数据
    jQuery('.goods_add .gtitle').val(json.title);                       // 标题
    jQuery('.goods_add .gprice').val(json.price);                       // 商品价格
    jQuery('.goods_add .gwangwang').val(json.nick);                     // 商家旺旺
    jQuery('.goods_add .gtbpic').val(json.pic_url);                     // 淘宝图片
    jQuery('.goods_add .gcowrieid').val(json.num_iid);                  // 商品ID
    jQuery('.goods_add .gbuynum').val(json.volume);                     // 销量
    jQuery('.goods_add .seller_id').val(json.seller_id);                // 商家ID
    jQuery('#tbpic img').remove();
    jQuery('#tbpic').prepend('<img src="' + json.pic_url + '" />');     // 淘宝图片展示
    // 是否包邮
    if(json.freight_payer == 'seller'){
        jQuery('.goods_add .baoyou').attr({'checked':'checked'});
    }
    // 加载完毕
    jQuery('#loding').hide();
} 
