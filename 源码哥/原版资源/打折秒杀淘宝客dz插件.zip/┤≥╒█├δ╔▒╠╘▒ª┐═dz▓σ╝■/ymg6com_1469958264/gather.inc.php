<?php
/**
 * [采集管理]
 */
// 判断常量 安全处理
if(!defined('IN_DISCUZ')) exit('Access Denied');
// 定义css js img 路径常量
define('P_ROOT', 'source/plugin/ymg6com_1469958264');
// 载入函数库
include 'source/plugin/ymg6com_1469958264/function.func.php';
// 载入公共菜单模板
include template('ymg6com_1469958264:adminCommon');

// --------------------------页面数据--------------------------
// 保存当前日期
$day = date('d');
// 获取频道数据
$channel = include 'source/plugin/ymg6com_1469958264/data/channel.inc.php';

// 载入采集模板
include template('ymg6com_1469958264:gather');
