<?php
/**
 * '分类数据'
 */
return array(
    '6' => array(
            'cid' => 6,
            'cname' => lang('plugin/ymg6com_1469958264', 'category_6'),
            'csort' => 0,
            'pid' => 0,
        ),

    '7' => array(
            'cid' => 7,
            'cname' => lang('plugin/ymg6com_1469958264', 'category_7'),
            'csort' => 1,
            'pid' => 0,
        ),

    '8' => array(
            'cid' => 8,
            'cname' => lang('plugin/ymg6com_1469958264', 'category_8'),
            'csort' => 2,
            'pid' => 0,
        ),

    '9' => array(
            'cid' => 9,
            'cname' => lang('plugin/ymg6com_1469958264', 'category_9'),
            'csort' => 3,
            'pid' => 0,
        ),

    '10' => array(
            'cid' => 10,
            'cname' => lang('plugin/ymg6com_1469958264', 'category_10'),
            'csort' => 4,
            'pid' => 0,
        ),

    '11' => array(
            'cid' => 11,
            'cname' => lang('plugin/ymg6com_1469958264', 'category_11'),
            'csort' => 5,
            'pid' => 0,
        ),

    '12' => array(
            'cid' => 12,
            'cname' => lang('plugin/ymg6com_1469958264', 'category_12'),
            'csort' => 6,
            'pid' => 0,
        ),

    '13' => array(
            'cid' => 13,
            'cname' => lang('plugin/ymg6com_1469958264', 'category_13'),
            'csort' => 7,
            'pid' => 0,
        ),

    '14' => array(
            'cid' => 14,
            'cname' => lang('plugin/ymg6com_1469958264', 'category_14'),
            'csort' => 8,
            'pid' => 0,
        ),

    '15' => array(
            'cid' => 15,
            'cname' => lang('plugin/ymg6com_1469958264', 'category_15'),
            'csort' => 9,
            'pid' => 0,
        ),
);