<?php
/**
 * '频道数据'
 */
return array(
    '2' => array(
            'id' => 2,
            'name' => lang('plugin/ymg6com_1469958264', 'channel_1'),
        ),

    '3' => array(
            'id' => 3,
            'name' => lang('plugin/ymg6com_1469958264', 'channel_2'),
        ),

    '4' => array(
            'id' => 4,
            'name' => lang('plugin/ymg6com_1469958264', 'channel_3'),
        ),
);