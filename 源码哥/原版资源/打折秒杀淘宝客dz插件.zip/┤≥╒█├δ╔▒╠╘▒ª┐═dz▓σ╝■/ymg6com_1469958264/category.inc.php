<?php
/**
 * [分类管理]
 */
// 判断常量 安全处理
if(!defined('IN_DISCUZ')) exit('Access Denied');
// 定义css js img 路径常量
define('P_ROOT', 'source/plugin/ymg6com_1469958264');
// 载入公共菜单模板
include template('ymg6com_1469958264:adminCommon');
// 获取分类
$category = include 'source/plugin/ymg6com_1469958264/data/category.inc.php';
// 载入分类模板
include template('ymg6com_1469958264:category');
