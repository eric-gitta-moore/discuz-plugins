<?php  
/**
 * [数据库模型类]
 */
class Model{
	//数据库连接信息 初始为null
	static public $link = null;
	//数据表
	private $table;
	//sql选择
	private $opt = array();

	//****************构造函数连接数据库****************
	public function __construct($table=NULL,$_config){
		//连接数据库
		$this -> _connect($_config['db']['1']['dbhost'],$_config['db']['1']['dbuser'],$_config['db']['1']['dbpw'],$_config['db']['1']['dbname']);
		//设置表名
		$this -> table = 'pre_cctbk_' . $table;
		//执行sql选择
		$this -> _opt();
	}	

	//****************连接数据库****************
	private function _connect($host,$user,$password,$dbmane){
		//如果$link有值 直接跳出
		if(self::$link) return;
		//连接数据库 读取配置项数据库连接信息
		$link = @new Mysqli($host,$user,$password,$dbmane);
		//判断链接是否失败
		if($link->connect_errno) die(lang('plugin/ymg6com_1469958264', 'db_connect_error'));
		//设置字符集
		$charset = 'SET CHARACTER_SET_CLIENT=BINARY,CHARACTER_SET_CONNECTION=UTF8,CHARACTER_SET_RESULTS=UTF8';
		$link->query($charset);
		//把连接信息保存到静态属性中
		self::$link = $link;
	}	

	//****************设置sql选择****************
	private function _opt(){
		$this -> opt = array(
			'field'	=> '*',
			'where'	=> '',
			'group'	=> '',
			'having'=> '',
			'order'	=> '',
			'limit'	=> '',
			'count' => '*',
		);
	}

	//****************链式操作 要查询的字段****************
	public function field($field){
		$this -> opt['field'] = $field;
		return $this;
	}

	//****************链式操作 where 条件****************
	public function where($where){
		$this -> opt['where'] = ' WHERE ' . $where;
		return $this;
	}

	//****************链式操作 group 分组****************
	public function group($group){
		$this -> opt['group'] = ' GROUP BY ' . $group;
		return $this;
	}

	//****************链式操作 having 筛选****************
	public function having($having){
		$this -> opt['having'] = ' HAVING ' . $having;
		return $this;
	}

	//****************链式操作 order 排序****************
	public function order($order){
		$this -> opt['order'] = ' ORDER BY ' . $order;
		return $this;
	}

	//****************链式操作 limit 取多少条****************
	public function limit($limit){
		$this -> opt['limit'] = ' LIMIT ' . $limit;
		return $this;
	}

	//****************有结果集方法****************
	public function query($sql){
		//返回结果集资源
		$result = self::$link -> query($sql);
		//如果sql有错 输出sql
		if(self::$link->errno){
			die(self::$link->error . '<h2 style="color:red">SQL:'.$sql.'</h2>');
		}
		//定义一个空数组
		$rows = array();
		//循环获得数据 压入空数组中
		while($row = $result -> fetch_assoc()){
			$rows[] = $row;
		}
		//释放结果集资源
		$result -> free();
		//返回循环后的数据
		return $rows;
	}

	//****************得到所有数据****************
	public function all(){
		//设置sql查询语句
		$sql = "SELECT " . $this -> opt['field'] . " FROM " . $this -> table . $this -> opt['where'] . $this -> opt['group'] . $this -> opt['having'] . $this -> opt['order'] . $this -> opt['limit'];
		//执行有结果集方法 反出
		return $this -> query($sql);
	}

	//****************得到所有数据 all 的别名 findall****************
	public function findall(){
		return $this -> all();
	}

	//****************得到所有数据 all 的别名 select****************
	public function select(){
		return $this -> all();
	}

	//****************得到一条数据****************
	public function find(){
		//设置只查询1条
		$this -> opt['limit'] = ' LIMIT 1';
		//执行得到数据方法
		$data = $this -> all();
		//返回数组中当前元素
		return current($data);
	}

	//****************count 统计****************
	public function count($count){
		//设置sql语句
		$sql = 'SELECT ' . ' COUNT(' . $this -> opt['count'] . ')' . ' FROM ' . $this -> table . $this -> opt['where'];
		//执行有结果集方法
		$data = $this -> query($sql);
		$data = current($data);
		return (int)$data['COUNT(*)'];
	}

	//****************无结果集方法****************
	public function exe($sql){
		//执行sql
		self::$link -> query($sql);
		//如果sql有错 输出sql
		if(self::$link->errno){
			die(self::$link->error . '<h2 style="color:red">SQL:'.$sql.'</h2>');
		}
		//添加的话返回自增的id 其他返回受影响条数
		return self::$link -> insert_id ? self::$link -> insert_id : self::$link -> affected_rows;
	}

	//****************添加数据****************
	public function add($arr = null){
		// 判断数据是否传人 如果没有传人 用POST数据
		if(is_null($arr)) $arr = $_POST;
		//获得数组的键名 并且组合成字符串
		$strKey = implode(',', array_keys($arr));
		//获得数组的键值 组合成字符串 连接上引号
		$strVal = '"' . implode('","', array_values($arr)) . '"';
		//设置sql插入语句
		$sql = "INSERT INTO " . $this -> table . " ($strKey) " . " VALUES " . " ($strVal) ";
		//执行无结果集方法 反出
		return $this -> exe($sql);
	}

	//****************删除数据数据****************
	public function delete(){
		//判断是否有where语句
		if($this -> opt['where'] == '') die(lang('plugin/ymg6com_1469958264', 'db_delete_where'));
		//设置sql删除语句
		$sql = "DELETE FROM " . $this -> table . $this -> opt['where'];
		//执行无结果集方法 反出
		return $this -> exe($sql);
	}

	//****************修改数据****************		
	public function update($newarr = null){
		//判断是否有where条件
		if($this -> opt['where'] == '') die(lang('plugin/ymg6com_1469958264', 'db_edit_where'));
		if(is_null($newarr)) $newarr = $_POST;
		//定义空字符串
		$str = '';
		//组合修改数据的字符串
		foreach ($newarr as $k => $v) {
			//连接字符串 加上引号
			$str .= $k . "='" . $v . "',";
		}
		//去掉右边的 逗号
		$str = rtrim($str,',');
		//设置sql修改语句
		$sql = "UPDATE " . $this -> table . " SET " . $str . $this -> opt['where'];
		//执行无结果集方法 反出
		return $this -> exe($sql);
	}

	//****************析构函数 关闭数据库资源****************		
	public function __destruct(){
		if(self::$link){
			//关闭资源
			self::$link -> close();
			//赋值为null
			self::$link = null;
		}
	}
}
	