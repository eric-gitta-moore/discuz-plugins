<?php
/**
 * [前台展示]
 */
// 判断常量 安全处理
if(!defined('IN_DISCUZ')) exit('Access Denied');  
// 引入函数库
include 'source/plugin/ymg6com_1469958264/function.func.php';
// 载入配置项
include 'config/config_global.php';
// 定义表前缀
$_pr = $_config['db']['1']['tablepre'];
// 定义css js img 路径常量
define('P_ROOT', 'source/plugin/ymg6com_1469958264');
// 缓存时间
$cacheTime = $_G['cache']['plugin']['ymg6com_1469958264']['cacheTime'];

// 获取分类数据
$ymg6com_1469958264_nav = include 'source/plugin/ymg6com_1469958264/data/category.inc.php';	
// 获取频道数据
$channel = include 'source/plugin/ymg6com_1469958264/data/channel.inc.php';		
// 设置title
$navtitle = $_G['cache']['plugin']['ymg6com_1469958264']['title'];
// 设置keywords
$metakeywords = $_G['cache']['plugin']['ymg6com_1469958264']['cctbk_keywords'];
// 设置description
$metadescription = $_G['cache']['plugin']['ymg6com_1469958264']['cctbk_description'];

//------------------------------商品数据--------------------------------
// 定义分页
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$pageSize = $_G['cache']['plugin']['ymg6com_1469958264']['pageSize'] ? $_G['cache']['plugin']['ymg6com_1469958264']['pageSize'] : 12;
// 定义分页起始数据
$offset = ($page - 1) * $pageSize;

// 定义分类
$cat = isset($_GET['cid']) ? $_GET['cid'] : 0;
// 定义频道
$chan = isset($_GET['cnid']) ? $_GET['cnid'] : 0;

// 组合where条件
$where = ($cat) ? 'category_cid=' . $cat : 'category_cid !=0';
$where2 = ($chan) ? ' and channel_id=' . $chan : ' and channel_id !=0';
// 组合SQL语句
$goodsSql = "SELECT * FROM " . $_pr . "cctbk_goods WHERE " . $where . $where2 . " ORDER BY gaddtime DESC LIMIT " . $offset . "," . $pageSize;
// 获取商品数据 
$ymg6com_1469958264_goods = DB::fetch_all($goodsSql);

// 处理商品数据
foreach ($ymg6com_1469958264_goods as $k => $v) {
	// 处理商品标签
	$ymg6com_1469958264_goods[$k]['gtag'] = explode(',', $v['gtag']);
	// 处理商品结束时间
	$ymg6com_1469958264_goods[$k]['govertime'] = strtotime($v['govertime']);
	// 处理商品状态
	if(strtotime($v['gbegintime']) > time()){
		// 当前时间小于商品开始时间 : 未开始
		$ymg6com_1469958264_goods[$k]['gstate'] = 'nobegin';
	}else if(strtotime($v['gbegintime']) <= time()){
		if(time() >= strtotime($v['govertime'])){
			// 结束
			$ymg6com_1469958264_goods[$k]['gstate'] = 'over';
		}else{
			// 商品开始时间小于当前时间 : 抢购中
			$ymg6com_1469958264_goods[$k]['gstate'] = 'going';
		}
	}

	// 处理商品属性
	if($v['gbegintime'] == date('Y-m-d')){
		// 商品开始时间 == 当前时间 ：新品
		$ymg6com_1469958264_goods[$k]['gattr'] = 'new';
	}else{
		// 其余情况不给属性
		$ymg6com_1469958264_goods[$k]['gattr'] = 'none';
	}
	
	// 处理淘宝图片
	if (!preg_match('/_(\d+?)x(\d+?)\.jpg/', $v['gtbpic'])) {
		$ymg6com_1469958264_goods[$k]['gtbpic'] = $v['gtbpic'] . '_310x310.jpg';
	}
}
//------------------------------分页--------------------------------
// 获取商品总条数
$allGoods = DB::fetch_all("SELECT COUNT(*) FROM " . $_pr . "cctbk_goods WHERE " . $where . $where2);
// 计算总页数
$allPage = ceil($allGoods['0']['COUNT(*)'] / $pageSize);
// 分页
$multipage = multi($allGoods['0']['COUNT(*)'], $pageSize, $page, 'plugin.php?id=ymg6com_1469958264&cnid=' . $chan . '&cid=' . $cat, $allPage);
// LOGO
$logo = S('logo');

// 载入应用模板
include template('ymg6com_1469958264:list');
