<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
echo lang("plugin/nds_antirrepeatpost", "logy_m_g");