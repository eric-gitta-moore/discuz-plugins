<?PHP
/*  nds_antirrepeatpost v3.25
 *  Plugin FOR Discuz! X2.5,X3*
 *  �������ظ����� 
 *	WWW.NWDS.CN | NDS.�������빤����  
 *  update 20151203 singcee
*/
if (! defined ( 'IN_DISCUZ' )) {
	exit ( 'Access Denied' );
}
include_once 'nds_anrpost_function_file.func.php';
class plugin_nds_antirrepeatpost {
	function plugin_nds_antirrepeatpost() {
		global $_G;
		$this->nds_accuracy = intval ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['ndsaccuracy'] );
		$this->exemptgroups = unserialize ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['exemptgroups'] );
		$this->exemptforums = unserialize ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['exemptforums'] );
		$this->checkmode = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['checkmode'];
		$this->checkobject = intval ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['checkobject'] );
		$this->objectlength = intval ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['objectlength'] );
		$this->objectmaxthread = intval ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['objectmaxthread'] );
		$this->operatemode = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['operatemode'];
		$this->mistoadmin = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['mistoadmin'];
		$this->ndsadminuids = trim ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['ndsadminuids'] );
		$this->mistomoderators = trim ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['mistomoderators'] );
		$this->misrpuser = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['misrpuser'];
		$this->bantime = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['bantime'];
		$this->checkreply = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['checkreply'];
		$this->replystrlen = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['replystrlen'];
		$this->ndssptimerpom = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['ndssptimerpom'];
		$this->rpmistoadmin = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['rpmistoadmin'];
		$this->ndssptime = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['ndssptime'];
		$this->ndsspt = isndsspt ( TIMESTAMP, $this->ndssptime );
		$this->operatemode = $this->ndsspt ? $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['ndssptimeom'] : $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['operatemode'];
		$this->bantime = $this->ndsspt ? $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['ndssptimebt'] : $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['bantime'];
		$this->checkchines = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['checkchines'];
		$this->any_lan = unserialize ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['any_lan'] );
		
		return;
	}
}

class plugin_nds_antirrepeatpost_forum extends plugin_nds_antirrepeatpost {
	function viewthread_posttop_output() {
		global $_G;
		$uid = $_G ['thread'] ['authorid'];
		$username = $_G ['thread'] ['author'];
		$ndsrpreturn = array ();
		if ($_G ['inajax'])
			return $ndsrpreturn;
		if (! ($_G ['thread'] ['views'] == 0))
			return $ndsrpreturn;
		if (! ($_G ['thread'] ['displayorder'] == 0))
			return $ndsrpreturn;
		if (in_array ( $_G ['fid'], $this->exemptforums ))
			return $ndsrpreturn;
		if (in_array ( $_G ['groupid'], $this->exemptgroups ))
			return $ndsrpreturn;
		$pstarlength = $starlength = 0;
		$subjectarr = $psubjectarr = array ();
		$isrepost = 0;
		if ($this->checkchines) {
			$is_enrobot = 0;
			$postmess = C::t ( 'forum_post' )->fetch ( 'tid:' . $_G ['tid'], $_G ['forum_firstpid'], true );
			$subject = $postmess ['message'];
			unset ( $postmess );
			$nds_ccln = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['nds_ccln'] < 40 ? 40 : intval ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['nds_ccln'] );
			$nds_ccln = $nds_ccln > 300 ? 300 : $nds_ccln;
			//$string = strip_tags($string);
			$string = cutstr ( $subject, $nds_ccln, $dot = '' );
			$string = preg_replace ( "/\[quote\].+?\[\/quote\]/is", '', $string );
			$string = preg_replace ( "/\[postbg\].+?\[\/postbg\]/is", '', $string );
			$string = preg_replace ( "/\s*\[attach\]*(.+?)\[\/attach\]\s*/is", '', $string );
			$string = str_replace ( array ("[", "]", "=", "/", "img", "font", "size", "color", "{", "}", "flash", "media", "audio", "attach", "code" ), '', $string );
			$string = preg_replace ( "/\s/is", '', $string );
			$strleng = strlen ( $string );
			if ($strleng > $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['nds_ccncn']) {
				$dstrleng = ndsstrlen ( $string );
				in_array('en',$this->any_lan) ? $dstrleng ['cn'] += $dstrleng ['en']:'';
				in_array('jp',$this->any_lan) ? $dstrleng ['cn'] += $dstrleng ['jp']:'';
				in_array('kr',$this->any_lan) ? $dstrleng ['cn'] += $dstrleng ['kr']:'';
				if ($dstrleng ['ln'] <= $strleng) {
					$nds_set_chinese = intval ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['nds_set_chinese'] );
					$is_enrobot = (($dstrleng ['cn'] / $dstrleng ['ln'] * 100) < $nds_set_chinese) ? 1 : 0;
				} else {
					$is_enrobot = 1;
				}
				if ($is_enrobot) {
					$ret = array ();
					$ret = nds_operatemode ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['nds_ccop'], $uid, $this->bantime );
					$notevars = array ('url1' => $ret ['url1'], 'subject1' => $_G ['thread'] ['subject'], 'opmod' => $ret ['opmode'], 'rpuser' => "<a href=\"home.php?mod=space&uid=$uid\">$username</a>" );
					if ($this->mistoadmin) {
						if ($this->ndsadminuids) {
							$ndsadminuids = array ();
							$ndsadminuids = explode ( '|', $this->ndsadminuids );
							foreach ( $ndsadminuids as $ndsadminuid ) {
								notification_add ( $ndsadminuid, 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'isenotice' ), $notevars, 1 );
							}
						} else {
							notification_add ( $_G ['config'] ['admincp'] ['founder'], 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'isenotice' ), $notevars, 1 );
						}
					}
					if ($this->mistomoderators) {
						$moderators = array ();
						$moderators = explode ( '/t', $_G ['forum'] ['moderators'] );
						foreach ( $moderators as $moderator ) {
							notification_add ( $moderator, 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'isenotice' ), $notevars, 1 );
						}
					}
					if ($this->misrpuser) {
						$notevars ['url1'] = 'forum.php?mod=viewthread&tid=' . $_G ['tid'];
						notification_add ( $uid, 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'isenotice2' ), $notevars, '', 1 );
					}
					return $ndsrpreturn;
				}
			}
		}
		
		$this->objectlength ? $sobjectlength = $this->objectlength : $sobjectlength = 300;
		$this->objectmaxthread ? $maxthread = $this->objectmaxthread + 1 : $maxthread = 5;
		if ($this->checkobject == 1 or $this->checkobject == 3) {
			$subject = strtolower ( $_G ['thread'] ['subject'] );
			$subjectarr = nds_str2arr ( $subject );
			$subjectcount = count ( $subjectarr );
		} else {
			if (! $this->checkchines) {
				$postmess = C::t ( 'forum_post' )->fetch ( 'tid:' . $_G ['tid'], $_G ['forum_firstpid'], true );
				$subject = $postmess ['message'];
				unset ( $postmess );
			}
			$subject = cutstr ( $subject, $sobjectlength, $dot = '' );
			$subjectarr = nds_str2arr ( $subject, $this->checkobject );
		}
		if (! empty ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['exemptwords'] )) {
			$exemptwords = trim ( $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['exemptwords'] );
			if (preg_match ( '/' . $exemptwords . '/', $subject ))
				return $ndsrpreturn;
		}
		
		switch ($this->checkobject) {
			case 1 :
				foreach ( C::t ( '#nds_antirrepeatpost#forum_thread_nds' )->fetch_all_by_authorid_displayorder_nds_nottid ( $uid, 0, '=', null, 0, $maxthread, $_G ['tid'] ) as $lastposts ) {
					$isrepost = $tid = 0;
					$psubject = strtolower ( $lastposts ['subject'] );
					if ($subject == $psubject) {
						$isrepost = 100;
						$tid = $lastposts ['tid'];
						break;
					}
					$psubjectarr = nds_str2arr ( $psubject );
					$isrepost = nds_antirmode ( $subjectarr, $psubjectarr, $this->checkmode );
					if ($isrepost >= $this->nds_accuracy) {
						$tid = $lastposts ['tid'];
						break;
					}
				}
				break;
			case 2 :
				foreach ( C::t ( '#nds_antirrepeatpost#forum_post_nds' )->fetch_all_by_authorid_nds_nottid ( 'tid:' . $_G ['tid'], $uid, 'DESC', 0, $maxthread, 1, 0, $_G ['tid'] ) as $lastposts ) {
					$isrepost = $tid = 0;
					$psubject = $lastposts ['message'];
					$psubject2 = $lastposts ['subject'];
					$psubject = cutstr ( $psubject, $sobjectlength, $dot = '' );
					if ($subject == $psubject) {
						$isrepost = 100;
						$tid = $lastposts ['tid'];
						break;
					}
					$psubjectarr = nds_str2arr ( $psubject, $this->checkobject );
					$isrepost = nds_antirmode ( $subjectarr, $psubjectarr, $this->checkmode );
					if ($isrepost >= $this->nds_accuracy) {
						$tid = $lastposts ['tid'];
						break;
					}
				}
				unset ( $psubject );
				unset ( $lastposts );
				break;
			case 3 :
				foreach ( C::t ( '#nds_antirrepeatpost#forum_thread_nds' )->fetch_all_by_authorid_displayorder_nds_nottid ( '', 0, '=', null, 0, $maxthread, $_G ['tid'] ) as $lastposts ) {
					$isrepost = $tid = 0;
					$psubject = strtolower ( $lastposts ['subject'] );
					if ($subject == $psubject) {
						$isrepost = 100;
						$tid = $lastposts ['tid'];
						break;
					}
					$psubjectarr = nds_str2arr ( $psubject );
					$isrepost = nds_antirmode ( $subjectarr, $psubjectarr, $this->checkmode );
					if ($isrepost >= $this->nds_accuracy) {
						$tid = $lastposts ['tid'];
						break;
					}
				}
				break;
		}
		if ($isrepost < $this->nds_accuracy) {
			return $ndsrpreturn;
		} else {
			$ret = array ();
			$ret = nds_operatemode ( $this->operatemode, $uid, $this->bantime );
		}
		$subject2 = empty ( $psubject2 ) ? $psubject : $psubject2;
		$notevars = array ('url1' => $ret ['url1'], 'subject1' => $_G ['thread'] ['subject'], 'url2' => 'forum.php?mod=viewthread&tid=' . $tid, 'subject2' => $subject2, 'continuous' => $isrepost, 'opmod' => $ret ['opmode'], 'rpuser' => "<a href=\"home.php?mod=space&uid=$uid\">$username</a>" );
		if ($this->mistoadmin) {
			if ($this->ndsadminuids) {
				$ndsadminuids = array ();
				$ndsadminuids = explode ( '|', $this->ndsadminuids );
				foreach ( $ndsadminuids as $ndsadminuid ) {
					notification_add ( $ndsadminuid, 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'notice1' ), $notevars, 1 );
				}
			} else {
				notification_add ( $_G ['config'] ['admincp'] ['founder'], 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'notice1' ), $notevars, 1 );
			}
		}
		if ($this->mistomoderators) {
			$moderators = array ();
			$moderators = explode ( '/t', $_G ['forum'] ['moderators'] );
			foreach ( $moderators as $moderator ) {
				notification_add ( $moderator, 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'notice1' ), $notevars, 1 );
			}
		}
		if ($this->misrpuser) {
			$notevars ['url1'] = 'forum.php?mod=viewthread&tid=' . $_G ['tid'];
			notification_add ( $uid, 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'notice2' ), $notevars, '', 1 );
		}
		
		return $ndsrpreturn;
	}
	
	function post_checkreply() {
		
		global $_G;
		if (in_array ( $_G ['fid'], $this->exemptforums ))
			return false;
		if (in_array ( $_G ['groupid'], $this->exemptgroups ))
			return false;
		$isrepost = 0;
		$pid = '';
		if ($this->checkreply && $_POST && $_GET ['action'] == 'reply' && ! in_array ( $_G ['fid'], $this->exemptforums ) && ! in_array ( $_G ['groupid'], $this->exemptgroups )) {
			if (strlen ( $_GET ['message'] ) < $this->replystrlen) {
				return false;
			}
			$replymessage = $_GET ['message'];
			$replymessage = preg_replace ( "/\s*\[quote\][\n\r]*(.+?)[\n\r]*\[\/quote\]\s*/is", '', $replymessage );
			$replymessagearr = nds_str2arr ( $replymessage, 2 );
			$replymessage = cutstr ( $replymessage, $this->objectlength, $dot = '' );
			
			$maxreply = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['maxreply'] ? $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['maxreply'] : 5;
			foreach ( C::t ( '#nds_antirrepeatpost#forum_post_nds' )->fetch_all_by_authorid_nds_nottid ( 'tid:' . $_G ['tid'], $_G ['uid'], 'DESC', 0, $maxreply, null, 0, 0, $this->replystrlen ) as $lastposts ) {
				$isrepost = 0;
				$preplymessage = $lastposts ['message'];
				$preplymessage = preg_replace ( "/\s*\[quote\][\n\r]*(.+?)[\n\r]*\[\/quote\]\s*/is", '', $preplymessage );
				$preplymessage = cutstr ( $preplymessage, $this->objectlength, $dot = '' );
				
				if ($replymessage == $preplymessage) {
					$isrepost = 100;
					break;
				} else {
					//$replymessagearr = nds_str2arr ( $replymessage, 2 );
					$preplymessagearr = nds_str2arr ( $preplymessage, 2 );
					$isrepost = nds_antirmode ( $replymessagearr, $preplymessagearr, 1 );
					if ($isrepost >= $this->nds_accuracy) {
						$pid = $lastposts ['pid'];
						$tid = $lastposts ['tid'];
						$subject2 = $lastposts ['subject'];
						break;
					}
				}
			}
		
		}
		if ($isrepost >= $this->nds_accuracy) {
			$wrmessage = $_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['wrmessage'];
			if (isndsspt ( TIMESTAMP, $this->ndssptime ) && $_G ['adminid'] != 1) {
				banuser ( $_G ['uid'], 4, $this->bantime );
				if ($this->rpmistoadmin) {
					$subject2 = empty ( $psubject2 ) ? $psubject : $psubject2;
					$opmode = ret_opmode_mis ( $this->ndssptime, $this->ndssptimerpom );
					$notevars = array ('url1' => 'forum.php?mod=viewthread&tid=' . $_G ['tid'], 'subject1' => $_G ['thread'] ['subject'], 'url2' => "forum.php?mod=redirect&goto=findpost&ptid='$tid'&pid='$pid'", 'subject2' => $subject2, 'continuous' => $isrepost, 'opmod' => $opmode, 'rpuser' => "<a href=\"home.php?mod=space&uid=" . $_G ['uid'] . "\">" . $_G ['member'] ['username'] . "</a>" );
					if ($this->ndsadminuids) { //$_G ['forum'] ['moderators']
						$ndsadminuids = array ();
						$ndsadminuids = explode ( '|', $this->ndsadminuids );
						foreach ( $ndsadminuids as $ndsadminuid ) {
							notification_add ( $ndsadminuid, 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'notice3' ), $notevars, 1 );
						}
					} else {
						notification_add ( $_G ['config'] ['admincp'] ['founder'], 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'notice3' ), $notevars, 1 );
					}
				} //rpmistoadmin
				if ($this->mistomoderators) {
					$moderators = array ();
					$moderators = explode ( '/t', $_G ['forum'] ['moderators'] );
					foreach ( $moderators as $moderator ) {
						notification_add ( $moderator, 'nds_antirrepost', lang ( 'plugin/nds_antirrepeatpost', 'notice1' ), $notevars, 1 );
					}
				}
				showmessage ( $wrmessage );
			} elseif ($_G ['cache'] ['plugin'] ['nds_antirrepeatpost'] ['misrpuserreply']) {
				showmessage ( $wrmessage, 'forum.php?mod=viewthread&tid=' . $_G ['tid'] );
			}
		} else {
			return false;
		}
	} //post_checkreply
}
//From:www_FX8_co
?>