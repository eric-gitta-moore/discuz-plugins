<?php

/**
 *      [FX8!] (C)2013-2016 Www.fx8.cc.
 *      Դ�������� ȫ���׷� http://www.fx8.cc
 *
 *      $Id: table_forum_thread.php 34511 2014-05-13 05:51:33Z laoguozhang $
 *      nds edit by 2014-12 (nottid)
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_forum_thread_nds extends discuz_table
{
	private $_posttableid = array();
	private $_urlparam = array();

	public function __construct() {

		$this->_table = 'forum_thread';
		$this->_pk    = 'tid';
		$this->_pre_cache_key = 'forum_thread_';
		parent::__construct();
	}
	public function fetch_all_by_authorid_displayorder_nds_nottid($authorid, $displayorder = null, $dglue = '=', $closed = null, $start = 0, $limit = 0, $nottid = 0, $tableid = 0) {
		$nottid = intval($nottid);
		$parameter = array($this->get_table_name($tableid));
		$wherearr = array();
		if(!empty($authorid)) {
			$authorid = dintval($authorid, true);
			$parameter[] = $authorid;
			$wherearr[] = is_array($authorid) && $authorid ? 'authorid IN(%n)' : 'authorid=%d';
		}
		if(getglobal('setting/followforumid')) {
			$parameter[] = getglobal('setting/followforumid');
			$wherearr[] = 'fid<>%d';
		}
		if($displayorder !== null) {
			$parameter[] = $displayorder;
			$dglue = helper_util::check_glue($dglue);
			$wherearr[] = "displayorder{$dglue}%d";
		}
		if($closed !== null) {
			$parameter[] = $closed;
			$wherearr[] = "closed=%d";
		}
		if($nottid) {
			$parameter[] = $nottid;
			$wherearr[] = "tid!=%d";
		}
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return DB::fetch_all("SELECT * FROM %t $wheresql ORDER BY dateline DESC ".DB::limit($start, $limit), $parameter, $this->_pk);
	}
	public function get_table_name($tableid = 0){
		$tableid = intval($tableid);
		return $tableid ? "forum_thread_$tableid" : 'forum_thread';
	}
	
}
//From:www_FX8_co
?>