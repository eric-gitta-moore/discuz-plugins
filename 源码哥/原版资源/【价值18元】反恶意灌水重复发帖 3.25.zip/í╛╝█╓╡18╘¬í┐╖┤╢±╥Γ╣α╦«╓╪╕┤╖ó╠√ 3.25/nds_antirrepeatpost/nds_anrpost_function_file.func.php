<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if (! defined ( 'IN_DISCUZ' )) {
	exit ( 'Access Denied' );
}

function nds_antirmode($subjectarr, $psubjectarr, $setndsmod) {
	$minsubjectcount = count ( $subjectarr ) > count ( $psubjectarr ) ? count ( $psubjectarr ) : count ( $subjectarr );
	$maxsubjectcount = count ( $subjectarr ) > count ( $psubjectarr ) ? count ( $subjectarr ) : count ( $psubjectarr );
	switch ($setndsmod) {
		case 1 :
			$subject = implode ( "", $subjectarr );
			$psubject = implode ( "", $psubjectarr );
			similar_text ( $subject, $psubject, $ndsarprank );
			break;
		case 2 :
			$ndsarprank2 = nds_ld ( $psubjectarr, $subjectarr );
			$ndsarprank2 = $maxsubjectcount - $ndsarprank2;
			$ndsarprank2 = $ndsarprank2 > 0 ? $ndsarprank2 : 0.1;
			if ($ndsarprank2 == $minsubjectcount) {
				$ndsarprank = round ( $ndsarprank2 / $maxsubjectcount, 2 ) * 100;
			} else {
				$ndsarprank = round ( $ndsarprank2 / $minsubjectcount, 2 ) * 100;
			}
			break;
	}
	return $ndsarprank;
}

function nds_str2arr($string, $checkobject = 1) {
	$n = 0;
	$tmp = array ();
	if ($checkobject == 2) {
		do {
			$randchars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwzyz";
			$position = rand () % strlen ( $randchars );
			$replace .= substr ( $randchars, $position, 1 );
		} while ( strlen ( $replace ) < 5 );
		$string = preg_replace ( "/\[quote\].+?\[\/quote\]/is", '', $string );
		$string = preg_replace ( "/\[postbg\].+?\[\/postbg\]/is", '', $string );
		$string = preg_replace ( "/[\s]{2,}/", "", $string ); 
		$string = preg_replace ( "/\s*\[attach\]*(.+?)\[\/attach\]\s*/is", $replace, $string ); 
		$string = str_replace ( array ("[", "]", "=", "/", "img", "font", "size", "color", "{", "}", "flash", "media", "audio", "attach" ), $replace, $string ); 
	}
	$string = preg_replace ( "/\s/is", '', $string );
	if (strtolower ( CHARSET ) == 'utf-8') {
		//$string = iconv ( "UTF-8", "GBK", $string );
		$string = diconv ( $string, "UTF-8", "GBK" );
	}
	$len = strlen ( $string );
	for($i = 0; $i < $len; $i ++) {
		$tmp [] = ord ( $string [$i] ) > 127 ? ((ord ( $string [$i] ) > 175 && ord ( $string [$i] ) < 216) ? $string [$i] . $string [++ $i] : '~') : (ord ( $string [$i] ) > 47 ? $string [$i] : '~');
	}
	return $tmp;
}
function ndsstrlen($str) {
	$count = array ('en' => 0, 'cn' => 0, 'jp' => 0, 'kr' => 0, 'ot' => 0, 'tb' => 0 );
	if (strtolower ( CHARSET ) != 'utf-8') {
		$str = diconv ( $str, "GBK", "UTF-8" );
	}
	$ln = strlen ( $str );
	for($i = 0; $i < $ln; $i ++) {
		$value = ord ( $str [$i] );
		if ($value < 128) {
			if ( $value <58 && $value >34){
			 	$count ['kr'] ++;
			 }else{
				$count ['en'] ++;
			 }
		}
		if ($value > 127) {
			if ($value >= 192 && $value <= 223) {
				$count ['tb'] ++;
				$i ++;
			} elseif ($value >= 224 && $value <= 233) {
				if ($value == 227) {
					$count ['jp'] ++;
				} else {
					$count ['cn'] ++;
				}
				$i = $i + 2;
			} elseif ($value >= 234 && $value <= 238) {
				$count ['kr'] ++;
				$i = $i + 2;
			}elseif ($value >= 240 && $value <= 247) {
				$count ['ot'] ++;
				$i = $i + 3;
			}
		}
		$count ['ln'] ++;
	}
	return $count;
}

function nds_minimum($a, $b, $c) {
	$mi = $a;
	if ($b < $mi) {
		$mi = $b;
	}
	if ($c < $mi) {
		$mi = $c;
	}
	return $mi;
}

function nds_ld($st1, $st2) {
	$d = array ();
	$n = $m = $i = $j = $cost = 0;
	$s_i = '';
	$t_j = '';
	$n = count ( $st1 );
	$m = count ( $st2 );
	if ($n == 0) {
		return $m;
	}
	if ($m == 0) {
		return $n;
	}
	for($i = 0; $i <= $n; $i ++) {
		$d [$i] [0] = $i;
	}
	for($j = 0; $j <= $m; $j ++) {
		$d [0] [$j] = $j;
	}
	for($i = 1; $i <= $n; $i ++) {
		$s_i = $st1 [$i - 1];
		for($j = 1; $j <= $m; $j ++) {
			$t_j = $st2 [$j - 1];
			if ($s_i == $t_j) {
				$cost = 0;
			} else {
				$cost = 1;
			}
			$d [$i] [$j] = nds_minimum ( $d [$i - 1] [$j] + 1, $d [$i] [$j - 1] + 1, $d [$i - 1] [$j - 1] + $cost );
		
		}
	
	}
	return $d [$n] [$m];
}

function banuser($uid, $bangroupid = 4, $bantime = 0) {
	$member = C::t ( '#nds_antirrepeatpost#common_member_nds' )->fetch_by_uid ( $uid );
	if ($member && $member ['groupid'] != 4) {
		$banexpiry = $bantime ? TIMESTAMP + $bantime * 86400 : 0;
		$groupterms = array ();
		$groupterms ['main'] = array ('time' => $banexpiry, 'adminid' => $member ['adminid'], 'groupid' => $member ['groupid'] );
		$groupterms ['ext'] [4] = $banexpiry;
		$data = array ('adminid' => - 1, 'groupid' => 4, 'groupexpiry' => $banexpiry, 'status' => 0 );
		C::t ( '#nds_antirrepeatpost#common_member_nds' )->update_by_uid ( $uid, $data );
		$groupterms = serialize ( $groupterms );
		C::t ( '#nds_antirrepeatpost#common_member_field_forum_nds' )->update_by_uid ( $uid, $groupterms );
		$reason = lang ( 'plugin/nds_antirrepeatpost', 'lanrpsystem' );
		include_once libfile('function/member');
		$crimeaction = 'crime_banspeak';
		crime('recordaction', $uid, $crimeaction, lang('forum/misc', 'crime_reason', array('reason' => $reason)));
	}
	return true;
}

function isndsspt($nowtime = TIMESTAMP, $ndssptime = 24) {
	$time = getdate ( $nowtime );
	switch ($ndssptime) {
		case 1 :
			return ($time ['hours'] >= 0 && $time ['hours'] <= 7);
		case 2 :
			return ($time ['hours'] >= 0 && $time ['hours'] <= 6);
		case 3 :
			return ($time ['hours'] >= 0 && $time ['hours'] <= 5);
		case 4 :
			return ($time ['hours'] >= 1 && $time ['hours'] <= 7);
		case 5 :
			return ($time ['hours'] >= 1 && $time ['hours'] <= 6);
		case 6 :
			return ($time ['hours'] >= 1 && $time ['hours'] <= 5);
		case 7 :
			return ($time ['hours'] >= 2 && $time ['hours'] <= 6);
		case 8 :
			return ($time ['hours'] >= 2 && $time ['hours'] <= 5);
		case 24 :
			return false;
		default :
			return false;
	}
}
function ret_opmode_mis($ndssptime, $ndssptimerpom) {
	if (isndsspt ( TIMESTAMP, $ndssptime )) {
		switch ($ndssptimerpom) {
			case 1 :
				$opmode = lang ( 'plugin/nds_antirrepeatpost', 'rlopck1' );
			case 3 :
				$opmode = lang ( 'plugin/nds_antirrepeatpost', 'rlopck2' );
			case 7 :
				$opmode = lang ( 'plugin/nds_antirrepeatpost', 'rlopck3' );
			case 30 :
				$opmode = lang ( 'plugin/nds_antirrepeatpost', 'rlopck4' );
			case 0 :
				$opmode = lang ( 'plugin/nds_antirrepeatpost', 'rlopck5' );
		}
	} else {
		$opmode = lang ( 'plugin/nds_antirrepeatpost', 'rlopck6' );
	}
	return $opmode;
}

function nds_operatemode($operatemode, $uid, $bantime) {
	global $_G;
	$ret = array ();
	switch ($operatemode) {
		case 1 :
			C::t ( 'forum_thread' )->update_displayorder_by_tid_displayorder ( $_G ['tid'], 0, - 2 );
			updatemoderate ( 'tid', $_G ['tid'] );
			$ret ['opmode'] = lang ( 'plugin/nds_antirrepeatpost', 'lopck1' );
			$ret ['url1'] = 'forum.php?mod=modcp&action=moderate&op=threads&fid=' . $_G ['fid'];
			break;
		case 2 :
			C::t ( 'forum_thread' )->update_displayorder_by_tid_displayorder ( $_G ['tid'], 0, - 1 );
			$ret ['opmode'] = lang ( 'plugin/nds_antirrepeatpost', 'lopck2' );
			$ret ['url1'] = 'forum.php?mod=modcp&action=recyclebin&fid=' . $_G ['fid'];
			break;
		case 3 :
			if ($_G ['adminid'] != 1) {
				$modaction = 'WRN';
				$reason = lang ( 'plugin/nds_antirrepeatpost', 'lreason' );
				$lanrpsystem = lang ( 'plugin/nds_antirrepeatpost', 'lanrpsystem' );
				C::t ( 'forum_post' )->increase_status_by_pid ( 'tid:' . $_G ['tid'], $_G ['forum_firstpid'], 2, '|', true );
				C::t ( 'forum_warning' )->insert ( array ('pid' => $_G ['forum_firstpid'], 'operatorid' => '1', 'operator' => $lanrpsystem, 'authorid' => $uid, 'author' => $username, 'dateline' => TIMESTAMP, 'reason' => $reason ) );
				$war_ateline = $_G ['timestamp'] - $_G ['setting'] ['warningexpiration'] * 86400;
				$authorwarnings = C::t ( 'forum_warning' )->count_by_authorid_dateline ( $uid, $war_ateline );
				if ($authorwarnings >= $_G ['setting'] ['warninglimit']) {
					$bantime_system = $_G ['setting'] ['warningexpiration'];
					banuser ( $uid, 4, $bantime_system );
				}
			}
			$ret ['opmode'] = lang ( 'plugin/nds_antirrepeatpost', 'lopck3' );
			$ret ['url1'] = 'forum.php?mod=viewthread&tid=' . $_G ['tid'];
			break;
		
		case 4 :
			C::t ( 'forum_thread' )->update_displayorder_by_tid_displayorder ( $_G ['tid'], 0, - 2 );
			updatemoderate ( 'tid', $_G ['tid'] );
			if ($_G ['adminid'] != 1) {
				banuser ( $uid, 4, $bantime );
			}
			$ret ['opmode'] = lang ( 'plugin/nds_antirrepeatpost', 'lopck4' );
			$ret ['url1'] = 'forum.php?mod=modcp&action=moderate&op=threads&fid=' . $_G ['fid'];
			break;
		case 5 :
			C::t ( 'forum_thread' )->update_displayorder_by_tid_displayorder ( $_G ['tid'], 0, - 1 );
			if ($_G ['adminid'] != 1) {
				banuser ( $uid, 4, $bantime );
			}
			$ret ['opmode'] = lang ( 'plugin/nds_antirrepeatpost', 'lopck5' );
			$ret ['url1'] = 'forum.php?mod=modcp&action=recyclebin&fid=' . $_G ['fid'];
			break;
		case 6 :
			$ret ['opmode'] = lang ( 'plugin/nds_antirrepeatpost', 'lopck6' );
			$ret ['url1'] = 'forum.php?mod=viewthread&tid=' . $_G ['tid'];
			break;
	
	}
	
	return $ret;
}
//From:www_FX8_co
?>