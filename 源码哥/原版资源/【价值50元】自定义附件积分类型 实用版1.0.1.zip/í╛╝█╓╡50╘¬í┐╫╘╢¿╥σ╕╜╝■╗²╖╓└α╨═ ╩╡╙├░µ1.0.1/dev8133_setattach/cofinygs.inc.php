<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
echo lang("plugin/dev8133_setattach", "logy_m_g");