<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_i9_html5 {
		function global_cpnav_top() {
			return '<link rel="stylesheet" type="text/css" href="source/plugin/i9_html5/style/i9_html5.css"/>';
		}
		function global_usernav_extra2() {
			return '<link rel="stylesheet" type="text/css" href="source/plugin/i9_html5/style/i9_html5.css"/>';
		}
}
?>