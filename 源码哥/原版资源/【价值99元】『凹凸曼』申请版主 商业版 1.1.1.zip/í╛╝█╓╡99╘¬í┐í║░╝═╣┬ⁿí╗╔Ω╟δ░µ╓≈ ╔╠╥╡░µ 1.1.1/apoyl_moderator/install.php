<?php $xhkj5_com = 'w ww.xhkj 5.c om'; ?><?php
/**
 *      [liyuanchao] (C)2014-2015 apoyl.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php  2015-12-10 17:57:00Z liyuanchao $
 */
if(!defined('IN_DISCUZ')){
exit('Acccess Denied');
} 

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_plugin_apoyl_moderator` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `fid` mediumint(8) unsigned NOT NULL default '0',
  `uid` mediumint(8) unsigned NOT NULL default '0',
  `forumname` varchar(255) NOT NULL,
  `username` varchar(15) NOT NULL,
  `realname` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `qq` varchar(255) NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL default '0',
  `handcard` varchar(255) NOT NULL,
  `frontcard` varchar(255) NOT NULL,
  `concard` varchar(255) NOT NULL,
  `reasons` text NOT NULL,
  `status` tinyint(1) NOT NULL default '0',
  `refute` text NOT NULL,
  `modtime` int(10) unsigned NOT NULL default '0',
  `addtime` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `fid` (`fid`,`uid`)
) ENGINE=MyISAM

EOF;
runquery($sql);

$finish = TRUE;
?>