<?php $xhkj5_com = 'w ww.xhkj 5.c om'; ?><?php
/**
 *      [liyuanchao] (C)2014-2015 apoyl.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: moderator.class.php 33953 2015-12-08 11:14:10Z liyuanchao $ modtime:2016-05-19
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class plugin_apoyl_moderator{
    
}

class plugin_apoyl_moderator_forum extends plugin_apoyl_moderator{
    public function index_forum_extra(){
         return $this->_apply('forum');
        }
    private function _showWindow($fid){
         $s="showWindow('moderatorapply','plugin.php?id=apoyl_moderator:apply&fid=".$fid."','get',0);";
         $re='&nbsp;<a href="javascript:;" onclick="'.$s.'" style="color:#c00;">'.lang('plugin/apoyl_moderator', 'title').'</a>';
         return $re;
     }
    public function forumdisplay_subforum_extra(){
         return $this->_apply('subforum');

         
        }
     private function _apply($forum='forum'){
        global $_G;
        $re=array();
        $groups = unserialize($_G['cache']['plugin']['apoyl_moderator']['group']);
        $forums=unserialize($_G['cache']['plugin']['apoyl_moderator'][$forum]);
        if(in_array($_G['groupid'],$groups)){
            foreach ($forums as $v){
                 
                $re[$v]=$this->_showWindow($v);
                }
            }
        return $re;
        }
    public function forumdisplay_forumaction(){
        global $_G;
        $fid=$_G['fid'];
        $groups = unserialize($_G['cache']['plugin']['apoyl_moderator']['group']);
        $forums=unserialize($_G['cache']['plugin']['apoyl_moderator']['myforum']);
        if(!in_array($_G['groupid'], $groups)) return '';
        if(!in_array($fid, $forums)) return '';
        return $this->_showWindow($fid);
    }
}

?>
