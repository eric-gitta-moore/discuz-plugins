<?php $xhkj5_com = 'w ww.xhkj 5.c om'; ?><?php

/**
 *      [liyuanchao] (C)2014-2015 apoyl.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: adminhelp.inc.php  2016-05  liyuanchao $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
showtableheader();
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_wmark')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_index')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_teladv')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_telbigimg')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_picdivision')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_picessence')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_money')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_salary')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_gif')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_hidesection')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoyl_mtime')));

showtablerow('','',array(lang('plugin/apoyl_moderator','addr')));
showtablerow('','',array(lang('plugin/apoyl_moderator','blog')));
showtablerow('','',array(lang('plugin/apoyl_moderator','apoylqq')));
showtablefooter();
?>