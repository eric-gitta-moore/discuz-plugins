<?php $xhkj5_com = 'w ww.xhkj 5.c om'; ?><?php
/**
 *      [liyuanchao] (C)2014-2015 apoyl.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: uninstall.php  2015-12-10 17:56:12Z liyuanchao $
 */

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//删除上传图片
$total=C::t('#apoyl_moderator#apoyl_moderator')->count(9);
$arr=C::t('#apoyl_moderator#apoyl_moderator')->fetcharr(-1,$total['nums']);
require_once libfile('function/home');
foreach ($arr as $v){
    pic_delete($v['handcard'],'');
    pic_delete($v['frontcard'],'');
    pic_delete($v['concard'],'');
}
$sql = <<<EOF
    DROP TABLE IF EXISTS `pre_plugin_apoyl_moderator`;
EOF;
	runquery($sql);


$finish = TRUE;
