<?php $xhkj5_com = 'w ww.xhkj 5.c om'; ?><?php
/**
 *      [liyuanchao] (C)2014-2015 apoyl.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: adminpass.inc.php  2015-12-10 16:23:16Z liyuanchao $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

      $page=isset($_GET['page'])?$_GET['page']:1;
      $prepage=20;
      $start=($page-1)*$prepage;
      $num=C::t('#apoyl_moderator#apoyl_moderator')->count(1);
      $multipage = multi($num['nums'], $prepage, $page, ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=apoyl_moderator&pmod=adminpass');
      showtableheader('');
		showsubtitle(array(lang('plugin/apoyl_moderator','foruminfo'),lang('plugin/apoyl_moderator','meminfo'),lang('plugin/apoyl_moderator','threadinfo'),lang('plugin/apoyl_moderator','reasons'),lang('plugin/apoyl_moderator','handcard'),lang('plugin/apoyl_moderator','frontcard'),lang('plugin/apoyl_moderator','concard')));
		showListp($start,$prepage);
		echo '<tr><td colspan="7"><div class="cuspages right">'.$multipage.'</div></td></tr>';
		showtablefooter();

function showListp($start,$limit){
    global $_G;
    $str='';
    $arr=C::t('#apoyl_moderator#apoyl_moderator')->fetcharr($start,$limit,1,'addtime desc');
    if($arr){
        $passstr=lang('plugin/apoyl_moderator','pass');
        $refusestr=lang('plugin/apoyl_moderator','refuse');
        foreach ($arr as $v){
            $threadinfo=$userinfo='';
            $foruminfo=lang('plugin/apoyl_moderator','forumid').'<a href="forum.php?mod=forumdisplay&fid='.$v['fid'].'" target="_blank">'.$v['fid'].'</a><br/>'.lang('plugin/apoyl_moderator','forumname').'<a href="forum.php?mod=forumdisplay&fid='.$v['fid'].'" target="_blank">'.$v['forumname'].'</a>';
            if($v['handcard'])
                $hdimg='<img src="'.$_G['setting']['attachurl'].$v['handcard'].'" width="100" height="100" title="'.lang('plugin/apoyl_moderator','imgtitle').'" onclick="zoom(this, \''.$_G['setting']['attachurl'].$v['handcard'].'\', 1)"  alt="'.lang('plugin/apoyl_moderator','pre').'"  style="cursor:pointer" >';
            if($v['frontcard'])
                $fdimg='<img src="'.$_G['setting']['attachurl'].$v['frontcard'].'" width="100" height="100" title="'.lang('plugin/apoyl_moderator','imgtitle').'" onclick="zoom(this, \''.$_G['setting']['attachurl'].$v['frontcard'].'\', 1)"  alt="'.lang('plugin/apoyl_moderator','pre').'"  style="cursor:pointer"   >';
            if($v['concard'])
                $cnimg='<img src="'.$_G['setting']['attachurl'].$v['concard'].'" width="100" height="100" title="'.lang('plugin/apoyl_moderator','imgtitle').'"  onclick="zoom(this, \''.$_G['setting']['attachurl'].$v['concard'].'\', 1)"  alt="'.lang('plugin/apoyl_moderator','pre').'"  style="cursor:pointer"  >';
            $userinfo='<li>'.lang('plugin/apoyl_moderator','username').'<a href="home.php?mod=space&uid='.$v['uid'].'" target="_blank">'.$v['username'].'</a><li>';
            if($v['realname'])
                $userinfo.='<li>'.lang('plugin/apoyl_moderator','name').$v['realname'].'<li>';
            if($v['tel'])
                $userinfo.='<li>'.lang('plugin/apoyl_moderator','tel').$v['tel'].'<li>';
            if($v['qq'])
                $userinfo.='<li>'.lang('plugin/apoyl_moderator','qq').$v['qq'].'<li>';
            if($v['sex'])
                $userinfo.='<li>'.lang('plugin/apoyl_moderator','sex').$v['sex'].'<li>';

                $userinfo.='<li>'.lang('plugin/apoyl_moderator','addtime').date('Y-m-d',$v['addtime']).'<li>';
                
  
            $dgarr=C::t('common_member_count')->fetch($v['uid']);
            if($dgarr){
                $threadinfo.='<li>'.lang('plugin/apoyl_moderator','digestposts').$dgarr['digestposts'].'</li>';
                $threadinfo.='<li>'.lang('plugin/apoyl_moderator','threads').$dgarr['threads'].'</li>';
                $threadinfo.='<li>'.lang('plugin/apoyl_moderator','posts').($dgarr['posts']-$dgarr['threads']).'</li>';
                $threadinfo.='<li>'.str_replace('{onlinetime}', $dgarr['oltime'], lang('plugin/apoyl_moderator','onlinetime')).'</li>';
            }
            $linearr=C::t('common_onlinetime')->fetch($v['uid']);
            if($linearr){
                $threadinfo.='<li>'.str_replace('{onlinetimemonth}', intval($linearr['thismonth']/60), lang('plugin/apoyl_moderator','onlinetimemonth')).'</li>';
            }
                
            
        $str.=<<<HTML
        <tr><td>{$foruminfo}</td><td><ul>{$userinfo}</ul></td><td><ul>{$threadinfo}</ul></td><td>{$v[reasons]}</td><td>{$hdimg}</td><td>{$fdimg}</td><td>{$cnimg}</td></tr>
HTML;
        }
    }
    echo $str;
}
?>