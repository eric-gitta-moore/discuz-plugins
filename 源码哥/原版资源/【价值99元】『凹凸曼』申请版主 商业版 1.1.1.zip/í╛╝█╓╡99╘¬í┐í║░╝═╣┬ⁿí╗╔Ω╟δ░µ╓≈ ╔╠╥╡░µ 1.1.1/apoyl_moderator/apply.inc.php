<?php $xhkj5_com = 'w ww.xhkj 5.c om'; ?><?php
/**
 *      [liyuanchao] (C)2014-2015 apoyl.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: apply.inc.php  2015-12-08 16:25:12Z liyuanchao $
 */
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
global $_G;
$fid=intval($_GET['fid']);
$groups = unserialize($_G['cache']['plugin']['apoyl_moderator']['group']);
if(!in_array($_G['groupid'],$groups)){
    showmessage(lang('plugin/apoyl_moderator','error_group'));
}
//是否显示
$name_sw=$_G['cache']['plugin']['apoyl_moderator']['realname'];
$tel_sw=$_G['cache']['plugin']['apoyl_moderator']['tel'];
$sex_sw=$_G['cache']['plugin']['apoyl_moderator']['sex'];
$handcard_sw=$_G['cache']['plugin']['apoyl_moderator']['handcard'];
$frontcard_sw=$_G['cache']['plugin']['apoyl_moderator']['frontcard'];
$concard_sw=$_G['cache']['plugin']['apoyl_moderator']['concard'];
$qq_sw=$_G['cache']['plugin']['apoyl_moderator']['qq'];
$reasons_sw=$_G['cache']['plugin']['apoyl_moderator']['reasons'];


if(submitcheck('sub')){
    $name=dhtmlspecialchars($_GET['name']);
    $tel=dhtmlspecialchars($_GET['tel']);
    $sex=intval($_GET['sex']);
    $qq=intval($_GET['qq']); 
    $frontcard=$_FILES['frontcard'];
    $handcard=$_FILES['handcard'];
    $concard=$_FILES['concard'];
    $reasons=dhtmlspecialchars($_GET['reasons']);
    
    if(!$name&&$name_sw) showmessage(lang('plugin/apoyl_moderator','error_name'));
    if(!$tel&&$tel_sw) showmessage(lang('plugin/apoyl_moderator','error_tel'));
    if(!$sex&&$sex_sw) showmessage(lang('plugin/apoyl_moderator','error_sex'));
    if(!$qq&&$qq_sw) showmessage(lang('plugin/apoyl_moderator','error_qq'));
    if(!$frontcard['tmp_name']&&$frontcard_sw) showmessage(lang('plugin/apoyl_moderator','error_frontcard'));
    if(!$concard['tmp_name']&&$concard_sw) showmessage(lang('plugin/apoyl_moderator','error_concard'));
    if(!$handcard['tmp_name']&&$handcard_sw) showmessage(lang('plugin/apoyl_moderator','error_handcard'));
    if(!$reasons&&$reasons_sw) showmessage(lang('plugin/apoyl_moderator','error_reasons'));

    //是否已经提交过
    $days=$_G['cache']['plugin']['apoyl_moderator']['days'];
    $arr=C::t('#apoyl_moderator#apoyl_moderator')->fetchfirst($_G['uid'],$fid);
    if($arr){
        if($arr['status']>0){
            showmessage(lang('plugin/apoyl_moderator','error_forum'));
        }else if($arr['status']==0){
            showmessage(lang('plugin/apoyl_moderator','error_sub'));
        }else if(($_G['timestamp']<$arr['modtime']+$days*86400)&&$arr['status']<0){
            $moretime=$arr['modtime']+$days*86400-$_G['timestamp'];
            showmessage(str_replace("{hours}", ceil($moretime/3600),lang('plugin/apoyl_moderator','error_verify')));
            }
    }
    //上传处理
   require_once libfile('function/home');
    if($handcard['tmp_name']&&$handcard_sw){
        $picre=pic_upload($handcard,'common');
        $handcard='common/'.$picre['pic'];
    }
    if($frontcard['tmp_name']&&$frontcard_sw){
        $picre=pic_upload($frontcard,'common');
        $frontcard='common/'.$picre['pic'];
    }
    if($concard['tmp_name']&&$concard_sw){
        $picre=pic_upload($concard,'common');
        $concard='common/'.$picre['pic'];
    }
    $fdarr=C::t('forum_forum')->fetch($fid);
    $data=array(
        'fid'=>$fid,
        'uid'=>$_G['uid'],
        'forumname'=>$fdarr['name'],
        'username'=>$_G['username'],
        'realname'=>$name,
        'tel'=>$tel,
        'qq'=>$qq,
        'frontcard'=>$frontcard,
        'handcard'=>$handcard,
        'concard'=>$concard,
        'reasons'=>$reasons,
        'modtime'=>$_G['timestamp'],
        'addtime'=>$_G['timestamp'],
    );
    $r=C::t('#apoyl_moderator#apoyl_moderator')->insert($data);
    if($r)
        showmessage(lang('plugin/apoyl_moderator','success'), '', array(), array('showdialog' => true, 'closetime' => 6));
    else 
        showmessage(lang('plugin/apoyl_moderator','error_fail'));
}


include template('apoyl_moderator:apply');
?>