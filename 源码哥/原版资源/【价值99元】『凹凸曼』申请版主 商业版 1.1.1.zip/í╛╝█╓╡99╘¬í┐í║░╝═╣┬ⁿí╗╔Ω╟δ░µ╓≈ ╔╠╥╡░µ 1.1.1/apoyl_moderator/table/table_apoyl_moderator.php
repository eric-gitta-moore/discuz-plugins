<?php $xhkj5_com = 'w ww.xhkj 5.c om'; ?><?php
/**
 *      [liyuanchao] (C)2014-2015 apoyl.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_apoyl_moderator.php  2015-12-08 16:25:12Z liyuanchao $
 */
if(!defined('IN_DISCUZ')){
exit('Acccess Denied');
} 
class table_apoyl_moderator extends discuz_table{
	public function __construct(){
		$this->_table = 'plugin_apoyl_moderator';
		$this->_pk    = 'id';
		parent::__construct();
	}
	public function fetchfirst($uid,$fid){
	    return DB::fetch_first('SELECT modtime,status FROM %t WHERE  uid=%d and fid=%d  order by addtime desc',array($this->table,$uid,$fid));
	}
	public function fetcharr($start,$limit,$status=0,$orderby='modtime desc'){
	    if($start==-1){
	        $limit='limit '.$limit;
	    }else{
	       $start=empty($start)?0:$start;
	       $limit=empty($limit)?10:$limit;
	       $limit='limit '.$start.','.$limit;
	    }
	    return DB::fetch_all('SELECT * FROM %t WHERE status=%i order by %i %i',array($this->_table,$status,$orderby,$limit));
	}

	public function insert($data){
	    return DB::insert($this->_table, $data);
	}
	public function update($data,$id){
	   return DB::update($this->_table, $data, array('id' => $id));
	    
	}
	public function count($status=0){
	    if($status!=9)
	        $w='WHERE  status='.$status;
	   return DB::fetch_first('SELECT COUNT(*)  as nums FROM %t %i ',array($this->_table,$w));
	}


}
?>