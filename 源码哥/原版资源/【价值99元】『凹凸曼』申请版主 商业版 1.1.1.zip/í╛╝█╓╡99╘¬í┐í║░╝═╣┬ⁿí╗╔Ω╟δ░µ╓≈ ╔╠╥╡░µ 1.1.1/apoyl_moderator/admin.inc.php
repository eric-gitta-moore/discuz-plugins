<?php $xhkj5_com = 'w ww.xhkj 5.c om'; ?><?php
/**
 *      [liyuanchao] (C)2014-2015 apoyl.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: admin.inc.php  2015-12-09 09:22:26Z liyuanchao $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(submitcheck('modsubmit')){
    
    $mtype=$_GET['mtype'];
    $fids=$_GET['fids'];
    $uids=$_GET['uids'];
    $msgs=$_GET['adminmsg'];
    $handcard=$_GET['handcard'];
    $frontcard=$_GET['frontcard'];
    $concard=$_GET['concard'];

    if($mtype){
        
        foreach ($mtype as $k=>$v){
                 //未通过原因不能为空
            if($v<0&&!$msgs[$k])
                cpmsg_error(lang('plugin/apoyl_moderator','error_empty_msg'));
            $data=array('status'=>$v,'refute'=>dhtmlspecialchars($msgs[$k]),'modtime'=>$_G['timestamp']);
                //通过
            if($v>0){
                C::t('#apoyl_moderator#apoyl_moderator')->update($data,$k);
                      //添加版主
                addModerator($uids[$k],$fids[$k]);
                $noticemsg=lang('plugin/apoyl_moderator','success_pass');
                notification_add($uids[$k], 'system', $noticemsg);
               //拒绝
            }else{
                $data['handcard']=$data['frontcard']=$data['concard']='';
                C::t('#apoyl_moderator#apoyl_moderator')->update($data,$k);
                       //删除上传照片
                $attachdir=$_G['setting']['attachdir'];
                if($handcard[$k])
                    @unlink($attachdir.$handcard[$k]);
                if($frontcard[$k])
                    @unlink($attachdir.$frontcard[$k]);
                if($concard[$k])
                    @unlink($attachdir.$concard[$k]);
                       //通知
                $noticemsg=lang('plugin/apoyl_moderator','error_refues').dhtmlspecialchars($msgs[$k]);
                notification_add($uids[$k], 'system', $noticemsg);
            }
                
            
            
        }
        cpmsg(lang('plugin/apoyl_moderator','success_select'),'action=plugins&operation=config&do='.$pluginid.'&identifier=apoyl_moderator&pmod=admin','succeed');

    }else{
         cpmsg_error(lang('plugin/apoyl_moderator','error_select'));
    }
}
      $page=isset($_GET['page'])?$_GET['page']:1;
      $prepage=5;
      $start=($page-1)*$prepage;
      $num=C::t('#apoyl_moderator#apoyl_moderator')->count(0);
      $multipage = multi($num['nums'], $prepage, $page, ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=apoyl_moderator&pmod=admin');
      showtips(lang('plugin/apoyl_moderator','tips'));
      showformheader('plugins&operation=config&do='.$pluginid.'&identifier=apoyl_moderator&pmod=admin');
      showtableheader('');
		showsubtitle(array(lang('plugin/apoyl_moderator','operation'),lang('plugin/apoyl_moderator','foruminfo'),lang('plugin/apoyl_moderator','meminfo'),lang('plugin/apoyl_moderator','threadinfo'),lang('plugin/apoyl_moderator','reasons'),lang('plugin/apoyl_moderator','handcard'),lang('plugin/apoyl_moderator','frontcard'),lang('plugin/apoyl_moderator','concard'),lang('plugin/apoyl_moderator','adminmsg')));
		showList($start,$prepage);
		showsubmit('modsubmit', 'submit', '', '', $multipage);
		showtablefooter();

function addModerator($uid,$fid,$ngp=3){
    $member = C::t('common_member')->fetch($uid);
    if(!$member) {
        cpmsg_error(lang('plugin/apoyl_moderator','error_no_member'));
    } else {

        $data = array();
        if(!in_array($member['adminid'],array(1,2,3,4,5,6,7,8,-1))) {
            $data['groupid'] = $ngp;
        }
        if(!in_array($member['adminid'],array(1,2))) {
            $data['adminid'] = $ngp;
        }
        if(!empty($data)) {
            C::t('common_member')->update($uid, $data);
        }
    
        C::t('forum_moderator')->insert(array(
        'uid' => $uid,
        'fid' => $fid,
        'displayorder' => 0,
        'inherited' => '0',
        ), false, true);
        
        if($fid) {
            $moderators = $tab = '';
            $modorder = array();
            $modmemberarray = C::t('forum_moderator')->fetch_all_no_inherited_by_fid($fid);
            foreach($modmemberarray as $moduid => $modmember) {
                $modorder[] = $moduid;
            }
            $members = C::t('common_member')->fetch_all_username_by_uid($modorder);
            foreach($modorder as $mod) {
                if(!$members[$mod]) {
                    continue;
                }
                $moderators .= $tab.$members[$mod];
                $tab = "\t";
            }
        
            C::t('forum_forumfield')->update($fid, array('moderators' => $moderators));
        }
  
    }
}

function showList($start,$limit){
    global $_G;
    $str='';
    $arr=C::t('#apoyl_moderator#apoyl_moderator')->fetcharr($start,$limit,0,'addtime desc');
    if($arr){
        $passstr=lang('plugin/apoyl_moderator','pass');
        $refusestr=lang('plugin/apoyl_moderator','refuse');
        foreach ($arr as $v){
            $threadinfo=$userinfo='';
            $foruminfo=lang('plugin/apoyl_moderator','forumid').'<a href="forum.php?mod=forumdisplay&fid='.$v['fid'].'" target="_blank">'.$v['fid'].'</a><br/>'.lang('plugin/apoyl_moderator','forumname').'<a href="forum.php?mod=forumdisplay&fid='.$v['fid'].'" target="_blank">'.$v['forumname'].'</a>';
            if($v['handcard'])
                $hdimg='<input type="hidden" name="handcard['.$v['id'].']" value="'.$v['handcard'].'"><img src="'.$_G['setting']['attachurl'].$v['handcard'].'" width="100" height="100" title="'.lang('plugin/apoyl_moderator','imgtitle').'" onclick="zoom(this, \''.$_G['setting']['attachurl'].$v['handcard'].'\', 1)"  alt="'.lang('plugin/apoyl_moderator','pre').'"  style="cursor:pointer" >';
            if($v['frontcard'])
                $fdimg='<input type="hidden" name="frontcard['.$v['id'].']" value="'.$v['frontcard'].'"><img src="'.$_G['setting']['attachurl'].$v['frontcard'].'" width="100" height="100" title="'.lang('plugin/apoyl_moderator','imgtitle').'" onclick="zoom(this, \''.$_G['setting']['attachurl'].$v['frontcard'].'\', 1)"  alt="'.lang('plugin/apoyl_moderator','pre').'"  style="cursor:pointer"   >';
            if($v['concard'])
                $cnimg='<input type="hidden" name="concard['.$v['id'].']" value="'.$v['concard'].'"><img src="'.$_G['setting']['attachurl'].$v['concard'].'" width="100" height="100" title="'.lang('plugin/apoyl_moderator','imgtitle').'"  onclick="zoom(this, \''.$_G['setting']['attachurl'].$v['concard'].'\', 1)"  alt="'.lang('plugin/apoyl_moderator','pre').'"  style="cursor:pointer"  >';
            $userinfo='<li>'.lang('plugin/apoyl_moderator','username').'<a href="home.php?mod=space&uid='.$v['uid'].'" target="_blank">'.$v['username'].'</a><li>';
            if($v['realname'])
                $userinfo.='<li>'.lang('plugin/apoyl_moderator','name').$v['realname'].'<li>';
            if($v['tel'])
                $userinfo.='<li>'.lang('plugin/apoyl_moderator','tel').$v['tel'].'<li>';
            if($v['qq'])
                $userinfo.='<li>'.lang('plugin/apoyl_moderator','qq').$v['qq'].'<li>';
            if($v['sex'])
                $userinfo.='<li>'.lang('plugin/apoyl_moderator','sex').$v['sex'].'<li>';

                $userinfo.='<li>'.lang('plugin/apoyl_moderator','addtime').date('Y-m-d',$v['addtime']).'<li>';
                
  
            $dgarr=C::t('common_member_count')->fetch($v['uid']);
            if($dgarr){
                $threadinfo.='<li>'.lang('plugin/apoyl_moderator','digestposts').$dgarr['digestposts'].'</li>';
                $threadinfo.='<li>'.lang('plugin/apoyl_moderator','threads').$dgarr['threads'].'</li>';
                $threadinfo.='<li>'.lang('plugin/apoyl_moderator','posts').($dgarr['posts']-$dgarr['threads']).'</li>';
                $threadinfo.='<li>'.str_replace('{onlinetime}', $dgarr['oltime'], lang('plugin/apoyl_moderator','onlinetime')).'</li>';
            }
            $linearr=C::t('common_onlinetime')->fetch($v['uid']);
            if($linearr){
                $threadinfo.='<li>'.str_replace('{onlinetimemonth}', intval($linearr['thismonth']/60), lang('plugin/apoyl_moderator','onlinetimemonth')).'</li>';
            }
                
            
        $str.=<<<HTML
        <tr><td><input type="hidden" name="uids[{$v[id]}]" value="{$v[uid]}"><input type="hidden" name="fids[{$v[id]}]" value="{$v[fid]}"><input type="radio" name="mtype[{$v[id]}]" value="1"> {$passstr}<br/> <input type="radio" name="mtype[{$v[id]}]" value="-1"> {$refusestr} </td><td>{$foruminfo}</td><td><ul>{$userinfo}</ul></td><td><ul>{$threadinfo}</ul></td><td>{$v[reasons]}</td><td>{$hdimg}</td><td>{$fdimg}</td><td>{$cnimg}</td><td><textarea name="adminmsg[{$v[id]}]" rows="5" ></textarea></td></tr>
HTML;
        }
    }
    echo $str;
}
?>