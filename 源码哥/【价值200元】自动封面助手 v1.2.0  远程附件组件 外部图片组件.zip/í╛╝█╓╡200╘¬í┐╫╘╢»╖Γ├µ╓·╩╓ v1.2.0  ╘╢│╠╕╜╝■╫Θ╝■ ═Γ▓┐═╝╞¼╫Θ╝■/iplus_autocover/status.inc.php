<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$libs=array(0=>'remote',1=>'img');

showtableheader(lang('plugin/iplus_autocover','tips'));
showsubtitle(array(lang('plugin/iplus_autocover','name'),lang('plugin/iplus_autocover','info'),lang('plugin/iplus_autocover','status'),lang('plugin/iplus_autocover','down')));
foreach($libs as $k=>$lib) {
	if(file_exists(DISCUZ_ROOT.'./source/plugin/iplus_autocover/lib/'.$lib.'.lib.php')) $status='<font color="green">'.lang('plugin/iplus_autocover','status_1').'</font>';
	else $status='<font color="red">'.lang('plugin/iplus_autocover','status_2').'</font>';
	showtablerow('', array('class="td_k"', 'class="td_k"', 'class="td_l"'), array(
		lang('plugin/iplus_autocover',$lib),
		lang('plugin/iplus_autocover',$lib.'info'),	
		$status,
		'<a href="http://www.ymg6.com/gg/addon.php?/?@iplus_autocover.plugin">'.lang('plugin/iplus_autocover','down').'</a>',
	));
			
}
showtablefooter();
?>