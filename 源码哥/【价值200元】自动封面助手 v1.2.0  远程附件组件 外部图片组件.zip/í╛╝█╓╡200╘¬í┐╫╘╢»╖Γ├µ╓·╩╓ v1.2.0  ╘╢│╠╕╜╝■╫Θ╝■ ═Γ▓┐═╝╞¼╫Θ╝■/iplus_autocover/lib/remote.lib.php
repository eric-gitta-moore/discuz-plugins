<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$remote=trim($_G['cache']['plugin']['iplus_autocover']['remote']);
if(!$remote&&$_G['setting']['ftp']['on']) $remote=$_G['setting']['ftp']['attachurl'];								
if($remote){
	$_G['forum_threadlist'][$k]['cover']=1;
	$_G['forum_threadlist'][$k]['coverpath']=$remote.'/forum/'.$pic['attachment'];
	$coverset=1;
	break;
}

?>