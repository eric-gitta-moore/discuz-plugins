<?php echo 'Theme by Jeaviking  http://www.jeavi.name';exit;?>
<!--{template common/header}-->
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jPages.js"></script>
<style id="diy_style" type="text/css"></style>
<div class="wp"> 
  <!--[diy=diy1]-->
  <div id="diy1" class="area"></div>
  <!--[/diy]--> 
</div>
<div class="jv_con_1 mt30 mb30 cl"> 
  <!-- �õ� -->
  <div class="focus_box cl"> 
    <!--[diy=focus_box]-->
    <div id="focus_box" class="area"></div>
    <!--[/diy]--> 
  </div>
  <!-- �õ� �Ҳ� -->
  <div class="todayhot cl">
    <div class="hd"> 
      <!--[diy=todayhott]-->
      <div id="todayhott" class="area"></div>
      <!--[/diy]--> 
    </div>
    <div class="bd"> 
      <!--[diy=todayhot]-->
      <div id="todayhot" class="area"></div>
      <!--[/diy]--> 
    </div>
  </div>
</div>
<div class="jv_con mb30 cl"> 
  <!--[diy=ad-1]-->
  <div id="ad-1" class="area"></div>
  <!--[/diy]--> 
</div>






<div class="jv_con_1 mb30 cl">
  <div class="portal_tit"> 
    <!--[diy=tit-1]-->
    <div id="tit-1" class="area"></div>
    <!--[/diy]--> 
  </div>
  
  <!-- �۽� -->
  
  <div class="con-l cl">
    <div class="selected cl"> 
      <!--[diy=selected-l]-->
      <div id="selected-l" class="area"></div>
      <!--[/diy]--> 
    </div>
    <div class="see cl">
      <div class="sideinfo"> <i></i> <span class="cl"> 
        <!--[diy=sideinfo]-->
        <div id="sideinfo" class="area"></div>
        <!--[/diy]--> 
        </span> </div>
      <div class="pageBtn"> <a class="prev">&lt;</a> <a class="next">&gt;</a> </div>
      <div class="bd"> 
        <!--[diy=jeavi_forum_bd]-->
        <div id="jeavi_forum_bd" class="area"></div>
        <!--[/diy]--> 
      </div>
    </div>
  </div>
  <div class="con-r cl">
    <div class="portal_hot pframe cl"> 
      <!--[diy=portal_hot]-->
      <div id="portal_hot" class="area"></div>
      <!--[/diy]--> 
    </div>
    <div class="like_pic"> 
      <!--[diy=like_pic]-->
      <div id="like_pic" class="area"></div>
      <!--[/diy]--> 
    </div>
  </div>
</div>


<div class="jv_con mb30 cl"> 
  <!--[diy=ad-2]-->
  <div id="ad-2" class="area"></div>
  <!--[/diy]--> 
</div>



<div class="jv_con_1 mb30 cl">
  <div class="portal_tit"> 
    <!--[diy=tit-t]-->
    <div id="tit-t" class="area"></div>
    <!--[/diy]--> 
  </div>
  
  <!-- ͼ�� -->
  <div class="p_pic cl">
    <div class="scroller cl"> 
      <!--[diy=scroller]-->
      <div id="scroller" class="area"></div>
      <!--[/diy]--> 
    </div>
    <div class="p_pic_r cl">
      <ul class="cl">
        <li> 
          <!--[diy=p_pic_r1]-->
          <div id="p_pic_r1" class="area"></div>
          <!--[/diy]--> 
        </li>
        <li> 
          <!--[diy=p_pic_r2]-->
          <div id="p_pic_r2" class="area"></div>
          <!--[/diy]--> 
        </li>
        <li> 
          <!--[diy=p_pic_r3]-->
          <div id="p_pic_r3" class="area"></div>
          <!--[/diy]--> 
        </li>
        <li class="col-double" style="margin-right:0;"> 
          <!--[diy=p_pic_r4]-->
          <div id="p_pic_r4" class="area"></div>
          <!--[/diy]--> 
        </li>
      </ul>
      <ul class="cl">
        <li> 
          <!--[diy=p_pic_r5]-->
          <div id="p_pic_r5" class="area"></div>
          <!--[/diy]--> 
        </li>
        <li> <!--[diy=p_pic_r6]-->
          <div id="p_pic_r6" class="area"></div>
          <!--[/diy]--> 
        </li>
        <li class="col-double"> 
          <!--[diy=p_pic_r7]-->
          <div id="p_pic_r7" class="area"></div>
          <!--[/diy]--> </li>
        <li style="margin-right:0;"> 
          <!--[diy=p_pic_r8]-->
          <div id="p_pic_r8" class="area"></div>
          <!--[/diy]--></li>
      </ul>
    </div>
  </div>
</div>

<div class="jv_con cl"> 
  <!--[diy=ad-2.1]-->
  <div id="ad-2.1" class="area"></div>
  <!--[/diy]--> 
</div>
<div class="jv_con_1 mb30 cl">
  <div class="portal_tit"> 
    <!--[diy=tit-3]-->
    <div id="tit-3" class="area"></div>
    <!--[/diy]--> 
  </div>
  <div class="con-l cl">
    <div class="columns cl"> 
      <!--[diy=photo-small-l]-->
      <div id="photo-small-l" class="area"></div>
      <!--[/diy]--> 
    </div>
  </div>
  <div class="con-r cl"> 
    
    <!-- �������� -->
    <div class="hbody mb30 cl">
      <div class="portal_tit hd cl"> 
        
        <!--[diy=hbodytit]-->
        <div id="hbodytit" class="area"></div>
        <!--[/diy]--> 
      </div>
      <div class=" bd">
        <ul>
          <!--[diy=hbody]-->
          <div id="hbody" class="area"></div>
          <!--[/diy]-->
        </ul>
        <ul>
          <!--[diy=hbody1]-->
          <div id="hbody1" class="area"></div>
          <!--[/diy]-->
        </ul>
      </div>
    </div>
    <!-- �Ƽ��Ķ� -->
    <div class="sbody cl"> 
      <!--[diy=sbody]-->
      <div id="sbody" class="area"></div>
      <!--[/diy]--> 
    </div>
  </div>
</div>
<div class="jv_con mb30 cl"> 
  <!--[diy=ad-3]-->
  <div id="ad-3" class="area"></div>
  <!--[/diy]--> 
</div>

<div class="jv_con mb30 cl">
  <div class="portal_tit hd cl"> 
    
    <!--[diy=linktit]-->
    <div id="linktit" class="area"></div>
    <!--[/diy]--> 
  </div>
  <div class="index_link cl"> 
    <!--[diy=index_link]-->
    <div id="index_link" class="area"></div>
    <!--[/diy]--> 
  </div>
</div>
<script type="text/javascript">
jQuery(".focus_box").slide({ mainCell:".bd ul",titCell:".hd ul",effect:"fold",autoPlay:true,autoPage:true,
startFun:function(i){jQuery(".focus_box .t_box").eq(i).find("h2").css({display:"none",bottom:0}).animate({opacity:"show",bottom:"30px"},300);jQuery(".focus_box .t_box").eq(i).find(".desc").css({display:"none",bottom:0}).animate({opacity:"show",bottom:"10px"},300);}});
jQuery(function() {jQuery("div.holder").jPages({containerID: "hiddenresult",perPage:5,previous: "��һҳ",next: "��һҳ"});});
jQuery(".portal_hot li").hover(function(){ jQuery(this).addClass("on").siblings().removeClass("on")},function(){ });
jQuery(".see").slide({ mainCell:".bd ul",effect:"leftLoop",vis:3,autoPlay:true});
jQuery(".scroller").slide({ mainCell:".bd ul",titCell:".hd ul",effect:"leftLoop",autoPlay:true,autoPage:true});
jQuery('.item').hover(function() {jQuery(".whitebg", this).stop().animate({bottom: '0px'},{queue: false,duration: 300});},function() {jQuery(".whitebg", this).stop().animate({bottom: '-160px'},{queue: false,duration: 300});});
jQuery(".hbody").slide({ titCell:".hd li", mainCell:".bd",delayTime:0 });
</script> 

<!--{template common/footer}--> 
