<?php
/**
 *	[(levrobot.install)] (C)2013-2099 Powered by BBB.Levme.com.
 *	Version: 1.0.0
 *	Date: 2013-5-19 16:01
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_lev_grab`;
CREATE TABLE `pre_lev_grab` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `preday` varchar(255) NOT NULL,
  `listurl` varchar(255) NOT NULL,
  `settings` text,
  `pregsrc` varchar(255) NOT NULL,
  `htmlarea` varchar(255) NOT NULL,
  `autofidmethod` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `pageorder` int(10) NOT NULL DEFAULT '0',
  `fid` int(10) NOT NULL DEFAULT '0',
  `minhour` int(10) NOT NULL DEFAULT '0',
  `maxhour` int(10) NOT NULL DEFAULT '0',
  `ymd` int(10) NOT NULL DEFAULT '0',
  `isdel` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_url`;
CREATE TABLE `pre_lev_grab_url` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `grabid` int(10) NOT NULL DEFAULT '0',
  `pid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `pregsrc` varchar(255) NOT NULL,
  `htmlarea` varchar(255) NOT NULL,
  `autofidmethod` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `imgnum` int(10) NOT NULL DEFAULT '0',
  `settings` text,
  `pageorder` int(10) NOT NULL DEFAULT '0',
  `fid` int(10) NOT NULL DEFAULT '0',
  `tid` int(10) NOT NULL DEFAULT '0',
  `isdel` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img`;
CREATE TABLE `pre_lev_grab_img` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img_0`;
CREATE TABLE `pre_lev_grab_img_0` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img_1`;
CREATE TABLE `pre_lev_grab_img_1` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img_2`;
CREATE TABLE `pre_lev_grab_img_2` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img_3`;
CREATE TABLE `pre_lev_grab_img_3` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img_4`;
CREATE TABLE `pre_lev_grab_img_4` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img_5`;
CREATE TABLE `pre_lev_grab_img_5` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img_6`;
CREATE TABLE `pre_lev_grab_img_6` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img_7`;
CREATE TABLE `pre_lev_grab_img_7` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img_8`;
CREATE TABLE `pre_lev_grab_img_8` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_lev_grab_img_9`;
CREATE TABLE `pre_lev_grab_img_9` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlid` int(10) NOT NULL DEFAULT '0',
  `urlpid` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `imgsize` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `sourcesrc` varchar(255) NOT NULL,
  `sourceurl` varchar(255) NOT NULL,
  `settings` text,
  `tid` int(10) NOT NULL DEFAULT '0',
  `isopen` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

EOF;

runquery($sql);
$finish = true;
?>