<?php

/**
 * Www.fx8.cc [ 专业开发各种Discuz!插件 ]
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 分.享.吧 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'lev_base.php';

class lev_module extends lev_base {
	
	public static function _m($class ='', $method = '', $param = '') {
		if (!$method) $method = $class;
		if ($method[0] !='_') exit(self::$lang['noact']);
		self::ismodule2($class, $method, $param);
	}
	
	public static function __m($class ='', $method = '', $param = '') {
		if (!$method) $method = $class;
		if ($method[1] !='_') exit(self::$lang['noact']);
		self::ismodule2($class, $method, $param);
	}
	
	public static function ismodule2($class = '', $method = '', $param = array()) {
		
		if (!$class) return '';
		
		$ismodule = parent::levloadclass($class.'_module', 'module');
		if ($ismodule) {
			if (!$method) $method = $class;
			if (method_exists($ismodule, $method)) {
				return $ismodule->$method($param);
			}
		}
		return FALSE;
	}
	
}










