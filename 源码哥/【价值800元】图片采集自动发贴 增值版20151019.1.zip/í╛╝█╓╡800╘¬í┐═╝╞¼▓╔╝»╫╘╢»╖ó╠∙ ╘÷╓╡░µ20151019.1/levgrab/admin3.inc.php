<?php
/**
 * Www.fx8.cc
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 ��.��.�� $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once 'lev_enter.php';

$file = str_replace('.inc.php', '', basename(__FILE__));
$murl = 'plugins&operation=config&do='.$pluginid.'&identifier='.$PLNAME.'&pmod='.$file.'&fh='.FORMHASH;
$turl = ADMINSCRIPT.'?action='.$murl;
$table = 'lev_grab';

if ($_GET['fh'] ==FORMHASH && $_GET['ajaxdosubmit'] ==1) {
	ob_clean();
	$tid = lev_module::ismodule2('sendform');
	echo $tid;
	exit();
}elseif ($_GET['fh'] ==FORMHASH && $_GET['do_graburl'] ==1) {
	ob_clean();
	$html = lev_module::ismodule2('grab', '_graburl', array(1));
	exit($html);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['do_grabcon'] ==1) {
	ob_clean();
	$html = lev_module::ismodule2('grab', '_grabimg', array(2));
	exit($html);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['do_grabimg'] ==1) {
	ob_clean();
	$html = lev_module::ismodule2('grab', '_grabimg', array(1));
	exit($html);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['setoption'] ==1) {
	ob_clean();
	$msg = C::t(lev_base::$table)->setoption($table);
	exit($msg);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['setstatus'] ==1) {
	ob_clean();
	$msg = C::t(lev_base::$table)->setstatus($table);
	exit($msg);
}elseif (isset($_GET['doaddsubmit']) && $_GET['formhash'] ==FORMHASH) {
	$name = trim($_GET['name']);
	$preday = lev_class::hourstr($_GET['preday']);
	$addinfo = array(
		'name' => $name,
		'preday'=>$preday[0],
		'minhour'=>$preday[1],
		'maxhour'=>$preday[2],
		'listurl'=>trim($_GET['listurl']),
		'imgsize'=>trim($_GET['imgsize']),
		'fid'=>intval($_GET['fid']),
		'settings'=>serialize($_GET['sets']),
		'isopen'=>intval($_GET['isopen']),
		'uptime' => TIMESTAMP,
	);
	$opid = intval($_GET['opid']);
	$r = C::t(lev_base::$table)->getone($opid);
	if ($r) {
		DB::update($table, $addinfo, array('id'=>$opid));
	}else {
		$addinfo['addtime'] = TIMESTAMP;
		$opid = DB::insert($table, $addinfo, TRUE);
	}
	cpmsg($lev_lang['succeed'], dreferer(), 'succeed');
}elseif (isset($_GET['dosubmit']) && $_GET['formhash'] ==FORMHASH) {
	$insql = lev_base::sqlinstr($_GET['ids']);
	if ($insql) {
		DB::query("DELETE FROM ".DB::table($table)." WHERE `id` IN ({$insql})");
		cpmsg($lev_lang['succeed'], dreferer(), 'succeed');
	}
}

include template($PLNAME.':admin_common');

$bbform = lev_base::bbforum();

$fidoption = '<option vlaue=0>'.$lev_lang['pslt'].'</option>';
foreach ($bbform as $v) {
	$fidoption.= '<option value="'.$v['fid'].'">'.$v['name'].'</option>';
}
for ($i=0; $i<3; $i++) {
	$autofidmethod.= '<option value="'.$i.'">'.$lev_lang['autofidmethod'.$i].'</option>';
}

	showformheader($murl.'&addtmp=1&opid='.$opid);
	showtableheader();
	$html = <<<EOF
	
	<style>.tb.tb2 tr td.t {width:120px;text-align:right;font-weight:bold;} .tb.tb2 td input{vertical-align: middle;}</style>
	<tr><td class=t>{$lev_lang['pgraburl']}</td> 
	<input type=hidden name=conurl1 id=conurl1>
	<input type=hidden name=listurl1 id=listurl1>
	<input type=hidden name=subjects2 id=subjects2>
		<td><input type="text" name="pgraburl" id="pgraburl" style="width:500px;" value="http://www.fx8.cc/">
		<input type="button" value="{$lev_lang['graburl']}" name="dograburl" onclick="do_graburl()" style="padding:1px 15px;" class="btn"> 
		<input type="button" value="{$lev_lang['grabimg']}" name="dograbimg" onclick="do_grabimg()" style="padding:1px 15px;" class="btn"> 
		<!--<input type="button" value="{$lev_lang['grabpregimg']}" name="dograbimg" onclick="do_grabpregimg()" style="padding:1px 15px;" class="btn"> -->
		<label for=downimg><input type=checkbox vlaue=1 id=downimg checked/>{$lev_lang['downimg']}</label> 
		
		<select name=formfid id=formfid><option value=''>{$lev_lang['autofid1']}</option>{$fidoption}</select>
	</td></tr><tr><td class=t>{$lev_lang['pregsrc']}</td><td>
	<input type="text" name="pregsrc" id="pregsrc" style="width:500px;" value="http://t1.fx8.cc/uploads/allimg/150325/0624*">{$lev_lang['pregsrc1']}
	</td></tr><tr><td class=t>{$lev_lang['htmlarea']}</td><td>
	<input type="text" name="htmlarea" id="htmlarea" style="width:500px;" value='id="picBody"===</div>'>{$lev_lang['htmlarea1']}
	</td></tr><tr><td class=t>{$lev_lang['autofidmethod']}</td><td><select name=autofidmethod id=autofidmethod>{$autofidmethod}</select></td></tr>
	<tr><td colspan=2><div id="grab_content"></div>
	<div>{$lev_lang['grabedurl']} 
| <a href="javascript:;" onclick="dotoggle('#grabed_url')">{$lev_lang['toggle']}</a> 
| <a href="javascript:;" onclick="clears()">{$lev_lang['clears']}</a></div>
<div id="grabed_url"><table><tbody></tbody></table></div></td></tr>

	<style>.imgtab img {height: 70px;max-width: 80px;} .tb.tb2.imgtab li {float: left;}</style>
<script>
function viewsrc() {
	var srcstr = '<table><tr><td>{$lev_lang['subimg']}</td></tr>';
	jQuery('.subimgs a').each(function(){
		srcstr += '<tr><td>'+ jQuery(this).attr('href') +'</td></tr>';
	});
	srcstr += '<tr><td>{$lev_lang['pregsrc']}</td></tr>';
	jQuery('.pregsrcimg a').each(function(){
		srcstr += '<tr><td>'+ jQuery(this).attr('href') +'</td></tr>';
	});
	srcstr += '<tr><td>{$lev_lang['htmlarea']}</td></tr>';
	jQuery('.htmlarea a').each(function(){
		srcstr += '<tr><td>'+ jQuery(this).attr('href') +'</td></tr>';
	});
	srcstr += '<tr><td>{$lev_lang['bigimg']}</td></tr>';
	jQuery('.bigimgs a').each(function(){
		srcstr += '<tr><td>'+ this.href +'</td></tr>';
	});
	srcstr += '<tr><td>{$lev_lang['smallimg']}</td></tr>';
	jQuery('.smallimgs a').each(function(){
		srcstr += '<tr><td>'+ this.href +'</td></tr>';
	});
	srcstr += '</table>';
	art.dialog({id:'msg', content:srcstr});
}
function clears() {
	jQuery('#grabed_url tbody').html('');
}
	function do_graburl() {
		var curl = encodeURI(jQuery('#pgraburl').val());
		art.dialog({id:'msg', title:false, content:'{$lev_lang[isgrabing]}'});
		jQuery.get('{$turl}&do_graburl=1', {curl:curl}, function(data){
			art.dialog({id:'msg'}).close();
			jQuery('#grab_content').html(data);
		});
	}

	function do_grabimg() {
		var autofidmethod= jQuery('#autofidmethod').val();
		var htmlarea = urlencode(jQuery('#htmlarea').val());
		var pregsrc = encodeURI(jQuery('#pregsrc').val());
		var curl = encodeURI(jQuery('#pgraburl').val());
		var downimg = jQuery('#downimg').attr('checked') ? 1 : 0;
		art.dialog.tips('{$lev_lang[isgrabing]}', 100000);
		jQuery.get('{$turl}&do_grabimg=1', {curl:curl, downimg:downimg, pregsrc:pregsrc, htmlarea:htmlarea, autofidmethod:autofidmethod}, function(data){
			art.dialog.tips('{$lev_lang[succeed]}');
			jQuery('#grab_content').html(data);
		});
	}
	
	function delztr(obj) {
		jQuery(obj).parent().parent().fadeOut('slow', function(){jQuery(this).remove();});
	}
	function grabimgone(obj) {
		var curl = jQuery(obj).parent().find('input').val();
		jQuery('#pgraburl').val(curl);
		jQuery('#conurl1').val(curl);
		do_grabimg()
	}
	function graburlone(obj) {
		var curl = jQuery(obj).parent().find('input').val();
		jQuery('#pgraburl').val(curl);
		jQuery('#listurl1').val(curl);
		do_graburl()
	}
	
	function autoconimg() {
		var curl = ckdoconurl();
		jQuery('#conurl1').val(curl);
		var html = jQuery('.conurl').find('tr').eq(0).html();
		jQuery('#subjects2').val(jQuery('.conurl tr').eq(0).find('a.cg2c').html());
		if (html) {
			jQuery('.conurl').find('tr').eq(0).fadeOut('slow', function(){
				jQuery('#grabed_url tbody').append('<tr>'+html+'</tr>');
				jQuery('#urlgrabingtips').html(jQuery('.conurl').find('tr td').eq(0).html() +'{$lev_lang['cgrabing']}');
				jQuery('.conurl').find('tr').eq(0).remove();
				jQuery('#pgraburl').val(curl);
				dograbconimg();
			});
		}else {
			art.dialog.tips('{$lev_lang['grabfish2']}');
			art.dialog({id:'isgrabing'}).close();
			jQuery('#urlgrabingtips').html('');
		}
	}
	function ckdoconurl() {
		var pageurls = jQuery('#grabed_url tbody').html();
		var href = '';
		jQuery('.conurl').find('input').each(function(index){
			href = jQuery(this).val();//alert(href);
			if (pageurls.indexOf(href) >=0) {
				jQuery('.conurl').find('tr').eq(0).remove();
			}else {
				return false;
			}
		});
		return href;
	}
	function dograbconimg() {
		var forces = jQuery('#forces').attr('checked') ? 1 : 0;
		var autofidmethod= jQuery('#autofidmethod').val();
		var htmlarea = urlencode(jQuery('#htmlarea').val());
		var pregsrc = encodeURI(jQuery('#pregsrc').val());
		var curl = encodeURI(jQuery('#pgraburl').val());
		var downimg = jQuery('#downimg').attr('checked') ? 1 : 0;
		art.dialog({id:'isgrabing', title:false, top:0, fixed:true, content:'<font color=red>{$lev_lang[isgrabing]}</font>', 
					init:function(){stopautoimg=0;}, close:function(){stopautoimg=1}});
		jQuery.get('{$turl}&do_grabcon=1&autoconurl=1', {curl:curl, downimg:downimg, pregsrc:pregsrc, htmlarea:htmlarea, autofidmethod:autofidmethod, forces:forces}, function(data){
			if (stopautoimg) {
				clearTimeout(_isfunc);
				return false;
			}
			art.dialog.tips('{$lev_lang[grabsuc]}', 3);
			if (parseInt(data) =='-3001') {
				art.dialog.tips('{$lev_lang['grabedurl']}');
				autoconimg();
			}else if (data.indexOf('====') >=0) {
				var arr = data.split('====');
				jQuery('#consubimgs').html(arr[0]);
				jQuery('.pageurl').html(arr[1]);
				_isfunc = window.setTimeout('getpageurl()', 1000);
			}else {
				art.dialog.tips('{$lev_lang[nodata]}');
			}
		});
	}
	
	
	function ckdourl() {
		var pageurls = jQuery('#grabed_url tbody').html();
		var href = '';
		jQuery('.pageurl').find('input').each(function(index){
			href = jQuery(this).val();//alert(href);
			if (pageurls.indexOf(href) >=0) {
				jQuery('.pageurl').find('tr').eq(0).remove();
			}else {
				return false;
			}
		});
		return href;
	}
	function getpageurl() {
		var curl = ckdourl();
		var html = jQuery('.pageurl').find('tr').eq(0).html();
		if (html) {
			jQuery('.pageurl').find('tr').eq(0).fadeOut('slow', function(){
				jQuery('#grabed_url tbody').append('<tr>'+html+'</tr>');
				jQuery('#urlgrabingtips').html(jQuery('.pageurl').find('tr td').eq(0).html() +'{$lev_lang['cgrabing']}');
				jQuery('.pageurl').find('tr').eq(0).remove();
				jQuery('#pgraburl').val(curl);
				autopageimg();
			});
		}else {
			art.dialog.tips('{$lev_lang['grabfish2']}');
			art.dialog({id:'isgrabing'}).close();
			autosendform();
			if (jQuery('#loopgrab').attr('checked')) {
				autoconimg();
			}else {
				jQuery('#urlgrabingtips').html('');
			}
		}
	}
	function autosendform() {
		jQuery("input[name='srct[]']").attr('checked', true);
		repeatimg('srcs[]');
		repeatimg('srcp[]');
		repeatimg('srct[]');
		repeatimg('srch[]');
		repeatimg('srcb[]');
		repeatimg('srci[]');
		formwin();
	}
	function repeatimg(name) {
		var _srcs = '';
		jQuery("input[name='"+name+"']").each(function(index){
			var _src = jQuery(this).val();
			var _tbody = jQuery(this).parent().parent().parent().parent();
			if (_srcs.indexOf('|'+ _src +'|') >=0) {
				_tbody.remove();
			}else {
				_srcs += '|'+ _src +'|';
				jQuery(this).attr('id', 'ckimg'+ index);
				_tbody.find('label').attr('for', 'ckimg'+ index);
			}
		});
	}
	var stopautoimg = 0;
	var isfunc = null;
	function autopageimg() {
		var autofidmethod= jQuery('#autofidmethod').val();
		var htmlarea = urlencode(jQuery('#htmlarea').val());
		var pregsrc = encodeURI(jQuery('#pregsrc').val());
		var curl = encodeURI(jQuery('#pgraburl').val());
		var downimg = jQuery('#downimg').attr('checked') ? 1 : 0;
		art.dialog({id:'isgrabing', title:false, top:0, fixed:true, content:'<font color=red>{$lev_lang[isgrabing]}</font>', 
					init:function(){stopautoimg=0;}, close:function(){stopautoimg=1}});
		jQuery.get('{$turl}&do_grabimg=1&autopage=1', {curl:curl, downimg:downimg, pregsrc:pregsrc, htmlarea:htmlarea, autofidmethod:autofidmethod}, function(data){
			if (stopautoimg) {
				clearTimeout(_isfunc);
				return false;
			}
			art.dialog.tips('{$lev_lang[grabsuc]}', 3);
			if (data) {
				var arr = data.split('====');
				var len = arr.length;
				jQuery('.subimgs').append(arr[0]);
				jQuery('.pageurl').html(arr[1]);
				_isfunc = window.setTimeout('getpageurl()', 1000);
			}else {
				art.dialog.tips('{$lev_lang[nodata]}');
			}
		});
	}
	
	function formwin() {
		var fid = jQuery('#formfid').val();
		if (!fid) {
			art.dialog.tips('{$lev_lang['pslt']}{$lev_lang['autofid1']}');
			jQuery('#formfid').fadeOut().fadeIn().fadeOut().fadeIn();
			return false;
		}
		if (!jQuery("input.srcall").attr('checked')) {
			art.dialog.tips('{$lev_lang['sltpics']}');
			return false;
		}
		ajaxdosubmit();
	}
function ajaxdosubmit() {
	art.dialog.tips('{$lev_lang['sengforming']}', 100000);
	var options = {
	    url:'{$turl}&ajaxdosubmit=1',
	    type:'POST', 
	    success: function(data){
	    	if (parseInt(data) >0) {
	    		art.dialog.tips('{$lev_lang[succeed]}tid.'+ data);
	    	}else {
	    		art.dialog.tips('{$lev_lang[error]}{$lev_lang[sended]}'+ data);
	    	}
		},
		error: function(data) {
			art.dialog.tips('{$lev_lang[error]}'+ data.status +" "+ data.statusText);
		}
	}; 
	jQuery('#cpform').ajaxSubmit(options);
	return false;
}
	
</script>
	
<script type="text/javascript" src="{$PLSTATIC}jquery.form.min.js"></script>

EOF;
	echo $html;
	showtablefooter();
	showformfooter();


