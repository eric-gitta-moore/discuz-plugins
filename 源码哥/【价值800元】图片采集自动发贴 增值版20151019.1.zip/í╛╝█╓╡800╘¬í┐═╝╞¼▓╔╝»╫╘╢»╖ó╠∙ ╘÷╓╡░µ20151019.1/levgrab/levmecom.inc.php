<?php
/**
 * Www.fx8.cc [ 专业开发各种Discuz!插件 ]
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 分.享.吧 $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

header('location:http://www.ymg6.com/gg/addon.php?/?@levmecom');