<?php
/**
 * Www.fx8.cc
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 ��.��.�� $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once 'lev_enter.php';

$file = str_replace('.inc.php', '', basename(__FILE__));
$murl = 'plugins&operation=config&do='.$pluginid.'&identifier='.$PLNAME.'&pmod='.$file.'&fh='.FORMHASH;
$turl = ADMINSCRIPT.'?action='.$murl;
$table = 'lev_grab';

if ($_GET['fh'] ==FORMHASH && $_GET['autourl'] ==1) {
	ob_clean();
	$res = lev_class::_autourl($_GET['opid']);//echo '<pre>';print_r($res);
	if (is_array($res) && $res['conopid'] >0) {
		echo $res['conopid'];exit();
	}
	echo $res;
	exit;
}elseif ($_GET['fh'] ==FORMHASH && $_GET['autograb'] ==1) {
	ob_clean();
	$res = lev_class::_dograb($_GET['opid']);//echo '<pre>';print_r($res);
	if (is_array($res) && $res['conopid'] >0) {
		echo $res['conopid'];exit();
	}
	echo $res;
	exit;
}elseif ($_GET['fh'] ==FORMHASH && $_GET['dograb'] ==1) {
	ob_clean();
	$res = lev_class::_dograb($_GET['opid']);//echo '<pre>';print_r($res);
	foreach ($res['pageurl']['href'] as $k => $v) {
		$listurl .= '<tr><td><input type=checkbox name=pageurls[] value='.$v.'><a target=_blank href="'.$v.'" title='.$res['title'][$k].'>'.$v.'</a></td></tr>';
	}
	foreach ($res['conurl']['href'] as $k => $v) {
		$conurl .= '<tr><td><input type=checkbox name=conurls[] value='.$v.'><a target=_blank href="'.$v.'" title='.$res['title'][$k].'>'.$v.'</a></td></tr>';
	}
	$html = '<table class="tb tb2"><tr><td>'.$lev_lang['listurl'].'</td></tr>'.$listurl;
	$html.= '<tr><td>'.$lev_lang['conurl'].'</td></tr>'.$conurl.'</table>';
	exit($html);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['setoption'] ==1) {
	ob_clean();
	$msg = C::t(lev_base::$table)->setoption($table);
	exit($msg);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['setstatus'] ==1) {
	ob_clean();
	$msg = C::t(lev_base::$table)->setstatus($table);
	exit($msg);
}elseif (isset($_GET['doaddsubmit']) && $_GET['formhash'] ==FORMHASH) {
	$name = trim($_GET['name']);
	$preday = lev_class::hourstr($_GET['preday']);
	$addinfo = array(
		'name' => $name,
		'preday'=>$preday[0],
		'minhour'=>$preday[1],
		'maxhour'=>$preday[2],
		'listurl'=>trim($_GET['listurl']),
		'pregsrc'=>trim($_GET['pregsrc']),
		'htmlarea'=>trim($_GET['htmlarea']),
		'imgsize'=>trim($_GET['imgsize']),
		'autofidmethod'=>intval($_GET['autofidmethod']),
		'fid'=>intval($_GET['fid']),
		'settings'=>serialize($_GET['sets']),
		'isopen'=>intval($_GET['isopen']),
		'uptime' => TIMESTAMP,
	);
	$opid = intval($_GET['opid']);
	$r = C::t(lev_base::$table)->getone($opid);
	if ($r) {
		DB::update($table, $addinfo, array('id'=>$opid));
	}else {
		$addinfo['addtime'] = TIMESTAMP;
		$opid = DB::insert($table, $addinfo, TRUE);
	}
	cpmsg($lev_lang['succeed'], dreferer(), 'succeed');
}elseif (isset($_GET['dosubmit']) && $_GET['formhash'] ==FORMHASH) {
	$insql = lev_base::sqlinstr($_GET['ids']);
	if ($insql) {
		DB::query("DELETE FROM ".DB::table($table)." WHERE `id` IN ({$insql})");
		cpmsg($lev_lang['succeed'], dreferer(), 'succeed');
	}
}

include template($PLNAME.':admin_common');

$bbform = lev_base::bbforum();

$fidoption = '<option vlaue=0>'.$lev_lang['pslt'].'</option>';
foreach ($bbform as $v) {
	$fidoption.= '<option value="'.$v['fid'].'">'.$v['name'].'</option>';
}
for ($i=0; $i<3; $i++) {
	$autofidmethod.= '<option value="'.$i.'">'.$lev_lang['autofidmethod'.$i].'</option>';
}

if (!$_GET['addtmp']) {
	$_subtitle = array (
		'<a href="javascript:;"><label for="chkall">'.$lev_lang['slts'].'</label></a>',
		'ID',
		$lev_lang['name'],
		$lev_lang['fiddesc'],
		$lev_lang['imgsize'],
		$lev_lang['preday'],
		$lev_lang['listurl'],
		$lev_lang['isgrab'],
		$lev_lang['isopen'],
		$lev_lang['addtime'],
		$lev_lang['opt'],
	);
	$hidepage = ' <a href="'.$turl.'&hidepage=1" class=btn>'.$lev_lang['hidepage'].'</a> ';
	$hidepage.= '<a href="'.$turl.'&urlisdel=1" class=btn>'.$lev_lang['nograb'].'</a> ';
	showformheader($murl);
	showtableheader(' <a href="'.$turl.'&addtmp=1" class="btn"> <b>'.$lev_lang['add'].'</b></a> '.$hidepage.$lev_lang['listeg']);
	showsubtitle($_subtitle);
	
	if ($_GET['pidpage']) {
		$pidpage = intval($_GET['pidpage']);
		$where = "pid={$pidpage} OR id={$pidpage}";
	}elseif ($_GET['urlisdel']) {
		$where = "isdel=0";
	}elseif ($_GET['hidepage']) {
		$where = "pid=0";
	}else {
		$where = "1";
	}
	$limit = 50;
	$pageurl = $turl.'&hidepage='.$_GET['hidepage'].'&pidpage='.$pidpage.'&urlisdel='.$_GET['urlisdel'];
	$infos = C::t(lev_base::$table)->levpages($table, $where.' ORDER BY id DESC', $limit, 0, $pageurl);
	$lists = $infos['lists'];
	$pages = $infos['pages'];
	if ($lists) {
		foreach ($lists as $v) {
			$s = unserialize($v['settings']);
			showtablerow(
			'',
			array(
				'width=30',
				'width=45',
			),
			array (
			"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"{$v['id']}\">",
			$v['id'],
			'<a href="'.$turl.'&pidpage='.$v['id'].'">'.$v['name'].'</a>',
			$bbform[$v['fid']]['name'],
			$v['imgsize'],
			'<span title="'.$v['preday'].'">'.cutstr($v['preday'], 6).'</span>',
			'<a href="'.$v['listurl'].'" target=_blank>'.$v['listurl'].'</a>',
			($v['isdel'] ? $lev_lang['yes'] : $lev_lang['no']),
			'<a href="javascript:;" onclick="setstatus(this, '.$v['id'].', \'isopen\')">'.($v['isopen'] ? $lev_lang['yes'] : $lev_lang['no']).'</a>',
			dgmdate($v['addtime'], 'u'),
		//	'<a href="javascript:;" onclick="dograb(\''.$v['id'].'\', 1)">'.$lev_lang['dograb'].'</a> | '.
		//	'<a href="javascript:;" onclick="autograb(\''.$v['id'].'\')">'.$lev_lang['autograb'].'</a> | '.
			'<a href="javascript:;" onclick="listpage(\''.$v['id'].'\')">'.$lev_lang['autograb'].'</a> | '.
			'<a href="'.$turl.'&addtmp=1&opid='.$v['id'].'">'.$lev_lang['edit'].'</a>',
			));
		}
		showsubmit(
			'', 
			'', 
			'', 
			'<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" />
			<label for="chkall">'.$lev_lang['slts'].'</label>&nbsp;&nbsp;<input type="submit" class="btn" name="dosubmit" value="'.$lev_lang['del'].'" onclick="return confirm(\''.$lev_lang['confirm'].'\');"/>
			', 
		$pages);
	}else {
		showtablerow('', array('colspan='.count($_subtitle)), array($lev_lang['nodata']));
	}
	showtablefooter();
	showformfooter();
}else {
	$opid = intval($_GET['opid']);
	$r = C::t(lev_base::$table)->getone($opid);
	$isopen = ($r['isopen'] || !isset($r['isopen'])) ? 'checked' : '';
	$s = unserialize($r['settings']);
	showformheader($murl.'&addtmp=1&opid='.$opid);
	showtableheader('<a href="'.$turl.'"><b>'.$lev_lang['addpage'].'</b></a>');
	$html = <<<EOF
	
	<style>.tb.tb2 tr td.t {width:120px;text-align:right;font-weight:bold;}</style>
	<tr><td class=t>{$lev_lang['name']}</td><td colspan=2><input type="text" name="name" id="name" value="{$r['name']}" style="width:550px;"></td></tr>
	<tr><td class=t>{$lev_lang['preday']}</td><td colspan=2><input type="text" name="preday" id="preday" value="{$r['preday']}" style="width:530px;">
	<a href="javascript:;" onclick="jQuery('#preday').val(24)" style="color:red">{$lev_lang['allday']}</a> {$lev_lang['preday1']}</td></tr>
	<tr><td class=t>{$lev_lang['listurl']}</td><td colspan=2><input type="text" name="listurl" id="listurl" value="{$r['listurl']}" style="width:550px;">{$lev_lang['listurl1']}</td></tr>
	<tr><td class=t>{$lev_lang['fiddesc']}</td><td colspan=2><select name=fid id=fid>{$fidoption}</select>{$lev_lang['fiddesc1']}</td></tr>
	<tr><td class=t>{$lev_lang['pregsrc']}</td><td><input type="text" name="pregsrc" id="pregsrc" style="width:550px;" value="">{$lev_lang['pregsrc1']}</td></tr>
	<tr><td class=t>{$lev_lang['htmlarea']}</td><td colspan=2><textarea name="htmlarea" id="htmlarea" style="width:550px;height:18px">{$r['htmlarea']}</textarea>{$lev_lang['htmlarea1']}</td></tr>
	<tr><td class=t>{$lev_lang['autofidmethod']}</td><td><select name=autofidmethod id=autofidmethod>{$autofidmethod}</select></td></tr>
	<tr><td class=t>{$lev_lang['imgsize']}</td><td colspan=2><input type="text" name="imgsize" id="imgsize" value="{$r['imgsize']}">{$lev_lang['imgsize1']}</td></tr>
	
	<!--
	<tr><td class=t>{$lev_lang['pagenum']}</td><td colspan=2><input type="text" name="pagenum" id="pagenum" value={$r['pagenum']}>{$lev_lang['pagenum1']}</td></tr>
	<tr><td class=t>{$lev_lang['pagestyle']}</td><td colspan=2><input type="text" name="pagestyle" id="pagestyle" value={$r['pagestyle']}>{$lev_lang['pagestyle1']}</td></tr>
	<tr><td class=t>{$lev_lang['listpagestyle']}</td><td colspan=2><input type="text" name="listpagestyle" id="listpagestyle" value={$r['listpagestyle']}>{$lev_lang['listpagestyle1']}</td></tr>
	<tr><td class=t>{$lev_lang['graburls']}</td><td width=700><textarea name=graburls id=graburls style="width:700px;height:200px;">{$r['graburls']}</textarea></td><td>{$lev_lang['graburls1']}</td></tr>
	-->
	
	<tr><td class=t>{$lev_lang['isopen']}</td><td colspan=2><input type=checkbox name=isopen value=1 $isopen></td></tr>
	<tr><td class=t></td><td><input type="submit" value="{$lev_lang['subt']}" name="doaddsubmit" class="btn"></td><td></td></tr>
	<script>
	jQuery('#fid').val('{$r['fid']}');
	</script>
EOF;
	echo $html;
	showtablefooter();
	showformfooter();
}


