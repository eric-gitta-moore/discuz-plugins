<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

EOF;

runquery($sql);
$finish = true;
?>