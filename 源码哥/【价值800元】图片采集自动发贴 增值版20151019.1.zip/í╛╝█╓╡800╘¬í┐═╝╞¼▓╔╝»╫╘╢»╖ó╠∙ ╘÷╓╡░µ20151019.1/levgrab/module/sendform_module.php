<?php

/**
 * Www.fx8.cc
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 分.享.吧 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();

class sendform_module {

	public static function sendform() {
		$lev_lang = lev_base::$lang;
		$fid = intval($_GET['formfid']);
		$curl = $_GET['conurl1'] ? $_GET['conurl1'] : $_GET['pgraburl'];
	
		foreach ($_GET['srct'] as $src) {
			$message.= '[img]'.$src.'[/img]';
			$num++;
		}
		foreach ($_GET['srch'] as $src) {
			$message.= '[img]'.$src.'[/img]';
			$num++;
		}
		foreach ($_GET['srcs'] as $src) {
			$message.= '[img]'.$src.'[/img]';
			$num++;
		}
		foreach ($_GET['srcp'] as $src) {
			$message.= '[img]'.$src.'[/img]';
			$num++;
		}
		foreach ($_GET['srcb'] as $src) {
			$message.= '[img]'.$src.'[/img]';
			$num++;
		}
		foreach ($_GET['srci'] as $src) {
			$message.= '[img]'.$src.'[/img]';
			$num++;
		}

		$subject = $_GET['subjects2'] ? $_GET['subjects2'] : $_GET['subjects'];
		$subject = lev_base::levdiconv($subject).'('.$num.$lev_lang['zhang'].')';
		$ck = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE url='{$curl}'");
		if ($ck['tid'] >0) {
			$cktid = C::t(lev_base::$table)->cktid($ck['tid']);
		}
		
		if ($cktid) {
			lev_module::ismodule2('x_editpost', '', array($cktid['tid'], $cktid['pid'], $subject, $message));
		}else {
			$tid = lev_module::ismodule2('x_newthread', '', array($fid, $subject, $message));
		}
		if ($tid >0) {
			if ($ck) {
				DB::update('lev_grab_url', array('tid'=>$tid, 'isdel'=>1, 'name'=>$subject, 'uptime'=>TIMESTAMP), array('id'=>$ck['id']));
			}else {
				$insert = array(
					'grabid' => -1,
					'name'=> $subject,
					'url' => $curl,
					'fid' => $fid,
					'tid' => $tid,
					'autofidmethod'=>intval($_GET['autofidmethod']), 
					'htmlarea'=>lev_class::levurldecode($_GET['htmlarea']), 
					'pregsrc'=>urldecode($_GET['pregsrc']),
					'isdel' => 1,
					'uptime' => TIMESTAMP,
					'addtime'=> TIMESTAMP,
				);
				$conopid = DB::insert('lev_grab_url', $insert, TRUE);
			}
		}

		return $tid;
	}

	public function sendform2($arr) {
		$pid = $arr[0];
		$urls = $arr[1];
		
		global $_G;
		if ($_GET['dayautograb'] ==2) {
			$_G['uid'] = 0;
			$_G['member']['uid'] = 0;
			$_G['member']['username'] .= '2';
		}
		
		$lang = lev_base::$lang;
		$fid = $urls[$pid]['fid'];
		$tid = $urls[$pid]['tid'];
		if ($fid <1) {
			$pfid = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab')." WHERE id='{$urls[$pid]['grabid']}'");
			$fid = $pfid['fid'];
			if ($pfid['pid'] && !$fid) {
				$pcc = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab')." WHERE id='{$pfid['pid']}'");
				$fid = $pcc['fid'];
			}
		}
		if ($fid) {
			//$imgs = DB::fetch_all("SELECT * FROM ".DB::table('lev_grab_img')." WHERE urlpid='$pid'");
			$imgs = C::t(lev_base::$table)->getimg_urlpid($pid);
			if ($imgs) {
				foreach ($imgs as $r) {
					//if (!$r['width']) continue;
					if (!lev_class::imgsize($urls[$pid]['imgsize'], $r)) continue;
					$message .= '[img]'.$r['src'].'[/img]';
					$imgnum++;
				}
			}else {
				DB::update('lev_grab_url', array('isdel'=>-2), "pid='$pid' OR id='$pid'");//没有抓取到符合条件的图片
				return '//no imgs!'.$urls[$pid]['url'];
			}
			if ($message) {
				$subject = $urls[$pid]['name'].' ('.$imgnum.$lang['zhang'].')';
				if ($tid >0) {
					$cktid = C::t(lev_base::$table)->cktid($tid);
					if ($cktid) {
						lev_module::ismodule2('x_editpost', '', array($tid, $cktid['pid'], $subject, $message));
					}
				}else {
					$cksql = "SELECT * FROM ".DB::table('forum_post')." WHERE fid='{$fid}' AND first=1 AND (subject IN('{$subject}', '{$urls[$pid]['name']}') OR message='{$message}')";
					$cksame = DB::fetch_first($cksql);
					if ($cksame) {
						if ($cksame['subject'] ==$urls[$pid]['name']) {
							DB::update('lev_grab_url', array('isdel'=>1, 'tid'=>-$tid), "pid='$pid' OR id='$pid'");
							return '-'.$cksame['tid'];
						}elseif ($cksame['subject'] ==$subject && $cksame['message'] ==$message) {
							DB::update('lev_grab_url', array('isdel'=>1, 'tid'=>$tid, 'uptime'=>TIMESTAMP), "pid='$pid' OR id='$pid'");
							return 'tided:'.$cksame['tid'];
						}
					}
				}
				if (!$cktid){
					$tid = lev_module::ismodule2('x_newthread', '', array($fid, $subject, $message));
				}
				if ($tid >0) {
					DB::update('lev_grab_url', array('isdel'=>1, 'tid'=>$tid, 'uptime'=>TIMESTAMP), "pid='$pid' OR id='$pid'");
					//DB::update('lev_grab_img', array('tid'=>$tid), array('urlpid'=>$pid));
				}
			}else {
				DB::update('lev_grab_url', array('isdel'=>3, 'uptime'=>TIMESTAMP), "pid='$pid' OR id='$pid'");//图片尺寸不足设置值
				return '//failed: no imgsize isremote!'.$urls[$pid]['url'];
			}
		}else {
			DB::update('lev_grab_url', array('isdel'=>2, 'uptime'=>TIMESTAMP), "pid='$pid' OR id='$pid'");
			return 'no fid!'.$pid;
		}
		return $tid;
	}
	
	public function _sendnotid() {
		global $_G;
		if ($_G['adminid'] <1) {
			echo 'no admin!';
			return '';
		}
		echo $this->sendnotid();
		
	}
	
	public function sendnotid() {
		$rs = DB::fetch_all("SELECT * FROM ".DB::table('lev_grab_url')." WHERE isdel=2 AND pid=0 ORDER BY uptime ASC, id DESC LIMIT 10");//print_r($rs);
		if ($rs) {
			foreach ($rs as $r) {
				$ckfinish = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE (isdel<1 OR imgnum=0) AND pid='{$r['id']}'");
				if (!$ckfinish) {
					$tid = $this->sendform2(array($r['id'], array($r['id']=>$r)));
					$idtotid = $r['id'];
					break;
				}else {
					$cknum++;
					DB::update('lev_grab_url', array('uptime'=>TIMESTAMP), array('id'=>$r['id']));
				}
			}
			if (!$tid) $tid.= 'tid failed nothing!'.$cknum.'.';
		}else {
			$tid = '-1000.nothing';
		}
		return $tid.'.'.$idtotid;
	}
	
	public function sendnotid2($pid) {
		if (!$_GET['sendtid']) return 'no sendtid';
		$rs = DB::fetch_all("SELECT * FROM ".DB::table('lev_grab_url')." WHERE (id='{$pid}' OR pid='{$pid}') ORDER BY uptime ASC, id DESC", array(), 'id');
		if ($rs[$pid]) {
			return $this->sendform2(array($pid, $rs));
		}else {
			return 'no pid!';
		}
	}
	
}







