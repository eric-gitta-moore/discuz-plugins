<?php

/**
 * Www.fx8.cc [ 专业开发各种Discuz!插件 ]
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 分.享.吧 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class x_explode_module {

	public static function init($arr = array()) {
		$fg = $arr[1] ? $arr[1] : '=';
		$br = explode("\n", trim($arr[0]));
		$rs = array();
		foreach ($br as $r) {
			$r = trim($r);
			if ($r) {
				$one = explode($fg, $r);
				//$rs[trim($one[0])] = $one;
				$k = trim($one[0]);
				foreach ($one as $v) $rs[$k][] = trim($v);
			}
		}
		return $rs;
	}
	
}







