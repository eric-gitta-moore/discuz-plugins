<?php

/**
 * Www.fx8.cc [ 专业开发各种Discuz!插件 ]
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 分.享.吧 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class x_selects_module {

	public static function x_selects($arr = array()) {//$arr[0] data; $arr[1] id
		$datas = lev_module::ismodule2('x_explode', 'init', array($arr[0]));
		foreach ($datas as $k => $r) {
			$lv = substr_count($r[0], '.');
			$lvarr[$lv][$k] = $r;
		}
		$selects = self::foroption($lvarr, $arr[1]);
		return $selects;
	}
	
	public static function foroption($lvarr, $id) {
		if ($lvarr) {
			$lev_lang = lev_base::$lang;
			$j = count($lvarr);
			for ($i=0; $i<$j; $i++) {
				$hide = $i ? 'style="display:none;"' : '';
				$select .= "<select $hide class='levselects levselects-{$i}' onchange=\"selects_control('{$id}', {$i}, this)\">";
				$select .= "<option value=''>{$lev_lang['pslt']}</option>";
				foreach ($lvarr[$i] as $k => $r) {
					$select .= "<option value='{$k}'>{$r[1]}</option>";
				}
				$select .= '</select>';
			}
			return "<span class=levselectsbox id=levselectsbox{$id}>{$select}</span>";
		}
		return '';
	}
	
	public static function valstr($arr = array()) {
		$datas = lev_module::ismodule2('x_explode', 'init', array($arr[0]));//print_r($datas);
		$value = $arr[1];
		if (!$arr[2]) {
			$lv = substr_count($value, '.');
			if ($lv >0) {
				$r = explode('.', trim($value));
				for ($i=0; $i<=$lv; $i++) {
					$k = '';
					for ($j=0; $j<=$i; $j++) {
						$k .= $r[$j].'.';
					}
					$k = trim(substr($k, 0, -1));
					$valstr .= $datas[$k][1].' &raquo; ';
				}
				$valstr = substr($valstr, 0, -9);
				return $valstr;
			}
		}
		return $datas[$value][1];
	}
	
	public static function jsinit() {
		$lev_lang = lev_base::$lang;
		$js = <<<EOF
		<script>
		function selects_control(id, idx, obj) {
			var max_idx = jQuery('#levselectsbox'+ id +' select').length - 1;
			var _val = jQuery(obj).val();
			
			jQuery('#value_'+ id).val(_val);
			jQuery('#value_'+ id).attr('checked', true);
			
			_val += '.';
			var val_len = _val.length;
			if (idx <max_idx) {
				var nidx = idx + 1;
				var _box = jQuery('#levselectsbox'+ id +' select.levselects-'+ nidx);
				var _select = '<select class="levselect_'+ nidx +'" onchange="selects_control(\''+ id +'\', '
							+ nidx +', this)">';
				var _option = '';
				_box.find('option').each(function(){
					var v = jQuery(this).attr('value');
					if (v.substr(0, val_len) == _val) {
						_option += '<option value='+ v +'>'+ jQuery(this).html() +'</option>';
					}
				});
				for (i=nidx; i<=max_idx; i++) {
					jQuery('#levselectsbox'+ id +' select.levselect_'+ i).remove();
				}
				if (_option !='') {
					_select += '<option value="">{$lev_lang['pslt']}</option>'+ _option +'</select>';
					jQuery('#levselectsbox'+ id).append(_select);
				}
			}
		}
		</script>
EOF;
		return $js;
	}
	
}







