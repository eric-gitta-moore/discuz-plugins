<?php

/**
 * Www.fx8.cc
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 ��.��.�� $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class grab_module {

	public static function _graburl($arr = array()) {
		$curl = lev_base::levdiconv(urldecode($_GET['curl']));
		$res = lev_module::ismodule2('x_grabimg', 'graburl', array($curl));
		if ($_GET['precode']) {
			echo '<pre>@@@';print_r($res);
		}
		if ($arr[0]) {
			return self::urlhtml($res);
		}
		return $res;
	}
	
	public static function _grabimg($arr = array()) {
		lev_base::$PL_G['downimg'] = $_GET['downimg'];
		$curl = lev_base::levdiconv(urldecode($_GET['curl']));
		$sets = array('autofidmethod'=>intval($_GET['autofidmethod']), 'htmlarea'=>lev_class::levurldecode($_GET['htmlarea']), 'pregsrc'=>urldecode($_GET['pregsrc']));
		$res = lev_module::ismodule2('x_grabimg', '', array($curl, '', $sets));
		if ($_GET['precode']) {
			echo '<pre>@@@';print_r($res);
		}
		if ($_GET['autoconurl'] ==1) {
			if (!$_GET['forces']) {
				$ck = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE url='{$curl}'");
				if ($ck) return '-3001.'.$ck['tid'];
			}
			$urls = self::_graburl();
			$html = self::imghtml($res, 2).'====';
			$html.= self::urlhtml($urls, 2);
			return $html;
		}elseif ($_GET['autopage'] ==1) {
			$urls = self::_graburl();
			$html = self::imghtml($res, 1).'====';
			$html.= self::urlhtml($urls, 2);
			return $html;
		}elseif ($arr[0]) {
			$urls = self::_graburl();
			$html = self::urlhtml($urls, 1);
			$html.= self::imghtml($res);
			return $html;
		}else {
			return $res;
		}
	}
	
	public static function imghtml($res, $type = 0) {
		$lev_lang = lev_base::$lang;
		$img = $res['html'];
		$alt = $res['alt'];
		$local = $res['localsrc'];
		$size = $res['size'];
		$subject = $res['subject'];
		$pregsrcs= $res['pregsrc'];
		$htmlare = $res['htmlareasrc'];
		$subjectsrc = $res['subjectsrc'];
		$tidsrc = $res['tidsrc'];
		foreach ($res['src'] as $k => $v) {
			if ($subjectsrc[$k]) {
				$subimgs.= '<li><table class="imgtab">';
				$subimgs.= '<tr><td><label for=ckimg'.$k.'>'.$img[$k].'</label></td></tr>';
				$subimgs.= '<tr><td><label><input type=checkbox name=srcs[] id=ckimg'.$k.' class=srcall value='.$local[$k].'>'.$size[$k][0].'x'.$size[$k][1].'px</label> ';
				$subimgs.= '<a href="'.$v.'" target=_blank>'.$lev_lang['view'].'</a></td></tr>';
				$subimgs.= '</table></li>';
			}elseif ($size[$k][0] >=410 || $size[$k][1]>=500) {
				$bigimgs.= '<li><table class="imgtab">';
				$bigimgs.= '<tr><td><label for=ckimg'.$k.'>'.$img[$k].'</label></td></tr>';
				$bigimgs.= '<tr><td><label for=ckimg'.$k.'><input type=checkbox name=srcb[] id=ckimg'.$k.' class=srcall value='.$local[$k].'>'.$size[$k][0].'x'.$size[$k][1].'px</label> ';
				$bigimgs.= '<a href="'.$v.'" target=_blank>'.$lev_lang['view'].'</a></td></tr>';
				$bigimgs.= '</table></li>';
			}else {
				$imgs .= '<li><table class="imgtab">';
				$imgs .= '<tr><td><label for=ckimg'.$k.'>'.$img[$k].'</label></td></tr>';
				$imgs .= '<tr><td><label for=ckimg'.$k.'><input type=checkbox name=srci[] id=ckimg'.$k.' class=srcall value='.$local[$k].'>'.$size[$k][0].'x'.$size[$k][1].'px</label> ';
				$imgs .= '<a href="'.$v.'" target=_blank>'.$lev_lang['view'].'</a></td></tr>';
				$imgs .= '</table></li>';
			}
			if ($pregsrcs[$k]) {
				$pregsrc.= '<li><table class="imgtab">';
				$pregsrc.= '<tr><td><label for=ckimg'.$k.'>'.$img[$k].'</label></td></tr>';
				$pregsrc.= '<tr><td><label><input type=checkbox name=srcp[] id=ckimg'.$k.' class=srcall value='.$local[$k].'>'.$size[$k][0].'x'.$size[$k][1].'px</label> ';
				$pregsrc.= '<a href="'.$v.'" target=_blank>'.$lev_lang['view'].'</a></td></tr>';
				$pregsrc.= '</table></li>';
			}
			if ($htmlare[$k]) {
				$htmlarea.= '<li><table class="imgtab">';
				$htmlarea.= '<tr><td><label for=ckimg'.$k.'>'.$img[$k].'</label></td></tr>';
				$htmlarea.= '<tr><td><label><input type=checkbox name=srch[] id=ckimg'.$k.' class=srcall value='.$local[$k].'>'.$size[$k][0].'x'.$size[$k][1].'px</label> ';
				$htmlarea.= '<a href="'.$v.'" target=_blank>'.$lev_lang['view'].'</a></td></tr>';
				$htmlarea.= '</table></li>';
			}
			if ($tidsrc[$k]) {
				$tidsrcs.= '<li><table class="imgtab">';
				$tidsrcs.= '<tr><td><label for=ckimg'.$k.'>'.$img[$k].'</label></td></tr>';
				$tidsrcs.= '<tr><td><label><input type=checkbox name=srct[] id=ckimg'.$k.' class=srcall value='.$local[$k].'>'.$size[$k][0].'x'.$size[$k][1].'px</label> ';
				$tidsrcs.= '<a href="'.$v.'" target=_blank>'.$lev_lang['view'].'</a></td></tr>';
				$tidsrcs.= '</table></li>';
			}
		}
		if ($type ==1) {
			return $tidsrcs;
		}elseif ($type ==2) {
			$ckname = "'srct[]'";
			$title  = $lev_lang['imgmethod'];
			$html = '<table class="tb tb2 imgtab"><tr><td width=100%>'.$lev_lang['websubject'].'<b>'.$res['subject'].'</b> ('.$lev_lang['gong'].count($tidsrc).$lev_lang['tiao'].') ';
			$html.= '&nbsp;&nbsp;&nbsp;<a href="javascript:;" onclick="formwin()">'.$lev_lang['sendform'].'</a>';
			$html.= '<input type=hidden name=subjects value="'.$res['subject'].'"></td></tr>';
			$html.= '<tr><td>'.$title.' | <a href="javascript:;" onclick="dotoggle(\'.subimgs\')">'.$lev_lang['toggle'].'</a> | ';
			$html.= '<a href="javascript:;" onclick="repeatimg('.$ckname.')">'.$lev_lang['repeatimg'].'</a> | ';
			$html.= '<label><input type=checkbox onclick="checkall(this, '.$ckname.')">'.$lev_lang['slts'].'</label></td></tr>';
			$html.= '<tr><td><ul class=subimgs>'.$tidsrcs.'</ul></td></tr>';
		}else {
			$html = '<table class="tb tb2 imgtab"><tr><td width=100%>'.$lev_lang['websubject'].'<b>'.$res['subject'].'</b> ('.$lev_lang['gong'].count($img).$lev_lang['tiao'].')</td></tr>';
			$html.= '<tr><td>'.$lev_lang['subimg'].' | <a href="javascript:;" onclick="dotoggle(\'.subimgs\')">'.$lev_lang['toggle'].'</a> | ';
			$html.= '<a href="javascript:;" onclick="repeatimg(\'srcs\')">'.$lev_lang['repeatimg'].'</a> | <a href="javascript:;" onclick="viewsrc()">'.$lev_lang['sourcesrc'].'</a> | ';
			$html.= '<label><input type=checkbox onclick="checkall(this, \'srcs[]\')">'.$lev_lang['slts'].'</label></td></tr>';
			$html.= '<tr><td><ul class=subimgs>'.$subimgs.'</ul></td></tr>';
			$html.= '<tr><td>'.$lev_lang['pregsrc'].' | <a href="javascript:;" onclick="dotoggle(\'.pregsrcimg\')">'.$lev_lang['toggle'].'</a> | ';
			$html.= '<a href="javascript:;" onclick="repeatimg(\'srcp\')">'.$lev_lang['repeatimg'].'</a> | ';
			$html.= '<label><input type=checkbox onclick="checkall(this, \'srcp[]\')">'.$lev_lang['slts'].'</label></td></tr>';
			$html.= '<tr><td><ul class=pregsrcimg>'.$pregsrc.'</ul></td></tr>';
			$html.= '<tr><td>'.$lev_lang['htmlarea'].' | <a href="javascript:;" onclick="dotoggle(\'.htmlarea\')">'.$lev_lang['toggle'].'</a> | ';
			$html.= '<label><input type=checkbox onclick="checkall(this, \'srch[]\')">'.$lev_lang['slts'].'</label></td></tr>';
			$html.= '<tr><td><ul class=htmlarea>'.$htmlarea.'</ul></td></tr>';
			$html.= '<tr><td>'.$lev_lang['bigimg'].' | <a href="javascript:;" onclick="dotoggle(\'.bigimgs\')">'.$lev_lang['toggle'].'</a> | ';
			$html.= '<label><input type=checkbox onclick="checkall(this, \'srcb[]\')">'.$lev_lang['slts'].'</label></td></tr>';
			$html.= '<tr><td><ul class=bigimgs>'.$bigimgs.'</ul></td></tr>';
			$html.= '<tr><td>'.$lev_lang['smallimg'].' | <a href="javascript:;" onclick="dotoggle(\'.smallimgs\')">'.$lev_lang['toggle'].'</a> | ';
			$html.= '<label><input type=checkbox onclick="checkall(this, \'srci[]\')">'.$lev_lang['slts'].'</label></td></tr>';
			$html.= '<tr><td><ul class=smallimgs>'.$imgs.'</ul></td></tr>';
		}
		$html.= '</table>';
		return $html;

	}

	public static function urlhtml($res, $type = 0) {
		$lev_lang = lev_base::$lang;
	//	$title = $res['title'];
		$html  = $res['html'];
		$pageurls = $res['pageurl']['href'];
		$listurls = $res['listurl']['href'];
		$conurls  = $res['conurl']['href'];
		$delztr   = '<a href="javascript:;" onclick="delztr(this)" style="color:red">'.$lev_lang['del'].'</a>';
		$delztr2  = $type ? '' : ' | <a href="javascript:;" onclick="grabimgone(this)">'.$lev_lang['grabimg'].'</a>';
		$delztr3  = ' | <a href="javascript:;" onclick="graburlone(this)">'.$lev_lang['graburl'].'</a>';
		$n1 = $n2 = $n3 = $n4 = 0;
		foreach ($res['href'] as $k => $v) {
			if ($res['pageurl']['href'][$k]) {
				$n1++;
				$pageurl .= '<tr><td><label for=ckd'.$k.'>'.$n1.'.<input type=checkbox name=url[] id=ckd'.$k.' value='.$v.'>'.$v.'</label> '.$html[$k].' | '.$delztr.$delztr2.$delztr3.'</td></tr>';
			}elseif ($res['listurl']['href'][$k]) {
				$n2++;
				$listurl .= '<tr><td><label for=cka'.$k.'>'.$n2.'.<input type=checkbox name=url[] id=cka'.$k.' value='.$v.'>'.$v.'</label> '.$html[$k].' | '.$delztr.$delztr2.$delztr3.'</td></tr>';
			}elseif ($res['conurl']['href'][$k]) {
				$n3++;
				$conurl  .= '<tr><td><label for=ckb'.$k.'>'.$n3.'.<input type=checkbox name=url[] id=ckb'.$k.' value='.$v.'>'.$v.'</label> '.$html[$k].' | '.$delztr.$delztr2.$delztr3.'</td></tr>';
			}else {
				$n4++;
				$others  .= '<tr><td><label for=ckc'.$k.'>'.$n4.'.<input type=checkbox name=url[] id=ckc'.$k.' value='.$v.'>'.$v.'</label> '.$html[$k].' | '.$delztr.$delztr2.$delztr3.'</td></tr>';
			}
		}
		if ($type ==1) {
			$html = '<table class="tb tb2 ttt"><tr><td width=100%>'.$lev_lang['websubject'].'<b>'.$res['subject'].'</b> ';
			$html.= '<a href="javascript:;" onclick="formwin()">'.$lev_lang['sendform'].'</a><input type=hidden name=subjects value="'.$res['subject'].'"></td></tr>';
			$html.= '<tr><td width=100>'.$lev_lang['pageurl'].' ('.$lev_lang['gong'].$n1.$lev_lang['tiao'].') ';
			$html.= '<a href="javascript:;" onclick="dotoggle(\'.pageurl\')">'.$lev_lang['toggle'].'</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
			$html.= '<a href="javascript:;" onclick="getpageurl()" style="color:red">'.$lev_lang['autograb'].'</a> &nbsp;&nbsp;&nbsp;<span id=urlgrabingtips></span></td></tr>';
			$html.= '<tr><td><div class=pageurl><table>'.$pageurl.'</table></div></td></tr>';
		}elseif ($type ==2) {
			return $pageurl;
		}else {
			$html = '<table class="tb tb2 ttt"><tr><td width=100%>'.$lev_lang['websubject'].'<b>'.$res['subject'].'</b> ('.$lev_lang['gong'].count($html).$lev_lang['tiao'].')</td></tr>';
			$html.= '<tr><td width=100>'.$lev_lang['pageurl'].' ('.$lev_lang['gong'].$n1.$lev_lang['tiao'].') ';
			$html.= ' <a href="javascript:;" onclick="dotoggle(\'.pageurl\')">'.$lev_lang['toggle'].'</a>';
			$html.= ' &nbsp;&nbsp;&nbsp;<span id=urlgrabingtips></span></td></tr>';
			$html.= '<tr><td><div class=pageurl><table>'.$pageurl.'</table></div></td></tr>';
			$html.= '<tr><td>'.$lev_lang['nishi'].$lev_lang['conurl'].' ('.$lev_lang['gong'].$n3.$lev_lang['tiao'].') ';
			$html.= ' <a href="javascript:;" onclick="dotoggle(\'.conurl\')">'.$lev_lang['toggle'].'</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
			$html.= '<a href="javascript:;" onclick="autoconimg()" style="color:red">'.$lev_lang['autograb'].'</a> ';
			$html.= '<label><input type=checkbox id=loopgrab value=1>'.$lev_lang['loopgrab'].'</label> <label><input type=checkbox id=forces value=1>'.$lev_lang['forces'].'</label></td></tr>';
			$html.= '<tr><td><div id=consubimgs></div><div class=conurl><table>'.$conurl.'</table></div></td></tr>';
			$html.= '<tr><td width=100>'.$lev_lang['nishi'].$lev_lang['listurl'].' ('.$lev_lang['gong'].$n2.$lev_lang['tiao'].')';
			$html.= ' <a href="javascript:;" onclick="dotoggle(\'.listurl\')">'.$lev_lang['toggle'].'</a></td></tr><tr><td><div class=listurl><table>'.$listurl.'</table></div></td></tr>';
			$html.= '<tr><td>'.$lev_lang['others'].' ('.$lev_lang['gong'].($n4).$lev_lang['tiao'].')';
			$html.= ' <a href="javascript:;" onclick="dotoggle(\'.others\')">'.$lev_lang['toggle'].'</a></td></tr><tr><td><div class=others><table>'.$others.'</table></div></td></tr>';
		}
		$html.= '</table>';
		return $html;
	}

	public static function levurldecode($str) {
		$str = str_ireplace('%l3C', '<', $str);
		$str = str_ireplace('%l20', ' ', $str);
		$str = str_ireplace('%l22', '"', $str);
		$str = str_ireplace('%l3E', '>', $str);
		$str = str_ireplace('%l28', '(', $str);
		$str = str_ireplace('%l29', ')', $str);
		$str = str_ireplace('%l27', "'", $str);
		return $str;
	}
}







