<?php

/**
 * Www.fx8.cc
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 ��.��.�� $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class x_upload_module {

	public static function up_image($field) {
		if ($_FILES[$field]['size']) {
			$attach = lev_base::upload($_FILES[$field]);
			if ($attach['attachment']) {
				$data = lev_base::$uploadurl.$attach['attachment'];
			}
		}
		return $data;
	}

	public static function up_attach($field) {
		if ($_FILES[$field]['size']) {
			$attach = lev_base::upload($_FILES[$field], 0);
			if ($attach['attachment']) {
				$data = lev_base::$uploadurl.$attach['attachment'];
			}
		}
		return $data;
	}
}







