<?php

/**
 * Www.fx8.cc
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 分.享.吧 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class autograb_module {

	public static $pageids = '', $thispagepid = 0;

	public static function _enter($arr = array()) {
		if (!$arr['onob']) ob_clean();
		$listopid = $arr['listopid']  ? $arr['listopid']  : intval($_GET['listopid']);
		$conopid  = $arr['conopid']   ? $arr['conopid']   : intval($_GET['conopid']);
		$grabimg  = $arr['grabimg']   ? $arr['grabimg']   : intval($_GET['grabimg']);
		$getpidurl= $arr['getpidurl'] ? $arr['getpidurl'] : intval($_GET['getpidurl']);
		if ($listopid >0) {//list
			$rs = self::rslistpage($listopid);//抓取列表页中的分页和内容页，优先输出内容页id和相关msg，无内容页输出未采集列表页id

		}elseif ($getpidurl >0) {//content

			$rs = self::getpidurl($getpidurl);//检查内容本页是否抓取完成。多种处理查看函数注释
			if ($rs['dolistpage'] ==1) {
				$rs = self::rslistpage($rs['id'], $rs);
			}elseif (is_array($rs)) {
				$rs = self::grabmsg($rs['id']);//界面输出显示正在抓取的信息
			}

		}elseif ($conopid >0) {//content

			$rs = self::contentpage($conopid);//抓取内容分页
			if (is_array($rs)) {
				$rs = self::grabimg($rs['id'], $rs);//返回内容主页pid并输出来页面等待下次抓取
			}

		}elseif ($grabimg >0) {
			$rs = self::grabimg($grabimg);
		}
		echo $rs;
	}
	public static function rslistpage($listopid, $r = array()) {
		$rs = self::listpage($listopid, $r);
		if (is_array($rs)) {
			$conopid = $rs[0];
			$listopid = $rs[1];
			if ($conopid >0) {//conopid
				$rs = self::grabmsg($conopid, $rs[2]);
			}elseif ($listopid) {
				$rs = $listopid;
			}else {
				$rs = '-6001.unknown ';
			}
		}
		return $rs;
	}
	public static function grabmsg($conopid, $r = array(), $v = array()) {
		$lev_lang = lev_base::$lang;

		$v = (is_array($v) && !empty($v)) ? $v : C::t(lev_base::$table)->getgraburl($conopid);
		$r = (is_array($r) && !empty($r)) ? $r : C::t(lev_base::$table)->getone($v['grabid']);
		if ($r['pid']) {
			$p = C::t(lev_base::$table)->getone($r['pid']);
			$msg = "<a target=_blank href='{$p['listurl']}'>{$p['name']}</a> {$p['listurl']} &raquo; <br><br>";
			$msg.= "<a target=_blank href='{$r['listurl']}'>{$r['name']}</a> {$r['listurl']} &raquo; <br><br>";
		}else {
			$newlist = 1;
			$msg = "<a target=_blank href='{$r['listurl']}'>{$r['name']}</a> {$r['listurl']} &raquo; <br><br>";
		}
		if ($v['pid']) {
			$c = C::t(lev_base::$table)->getgraburl($v['pid']);
			$msg.= "<a target=_blank href='{$c['url']}'>{$c['name']}</a> {$c['url']} &raquo; <br><br>";
			$msg.= "<a target=_blank href='{$v['url']}'>{$v['name']}</a> {$v['url']} &raquo; ";
		}else {
			$newpage = 1;
			$msg.= "<a target=_blank href='{$v['url']}'>{$v['name']}</a> {$v['url']} &raquo; ";
		}
		$rs = $conopid.'===='.$msg.'<b style=color:red>'.$lev_lang['cgrabing'].'</b>'.'===='.$newpage.'===='.$newlist;
		return $rs;
	}

	public static function listurl() {
		$r = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab')." WHERE isdel<1 ORDER BY uptime ASC");
		if ($r) {
			$r['dolistpage'] = 1;
			return $r;
		}
		//return '-8001.list finish!';
		return self::contenturl();
	}
	public static function contenturl() {
		$r = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE isdel<1 ORDER BY uptime ASC");
		if ($r) {
			return $r;
		}
		return '-7001.content finish!';
	}

	public static function listpage($opid = 0, $r = array()) {
		$opid = intval($opid);
		if ($opid <1) {
			$r = self::listurl();
			if (substr($r['listurl'], 0, 4) !=='http') return '-3001.no listurl';
			$opid = $r['id'];
		}
		if (!is_array($r) || empty($r)) {
			$r = C::t(lev_base::$table)->getone($opid);
		}
		if (empty($r) || !$r['listurl']) return '-2001.no listurl';
		DB::update('lev_grab', array('uptime'=>TIMESTAMP, 'isdel'=>1), array('id'=>$r['id']));
		$res = lev_module::ismodule2('x_grabimg', 'graburl', array($r['listurl'], $r));
		if (!is_array($res)) {
			DB::update('lev_grab', array('uptime'=>TIMESTAMP, 'isdel'=>-1), array('id'=>$r['id']));
			return '-3002.res grab listurl: '.$res;
		}
		$pid = $r['pid'] ? $r['pid'] : $r['id'];
		$page= DB::fetch_all("SELECT * FROM ".DB::table('lev_grab')." WHERE id='$pid' OR pid='$pid' ORDER BY uptime ASC", array(), 'listurl');
		foreach ($res['pageurl']['href'] as $k => $v) {
			if (!$v) continue;
			if ($page[$v]) continue;
			$ck = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab')." WHERE listurl='{$v}'");
			if ($ck) continue;
			$insert = array(
					'pid' => $pid,
					'name'=> $res['title'][$k],
					'listurl' => $v,
					'htmlarea' => $r['htmlarea'],
					'pregsrc' => $r['pregsrc'],
					'autofidmethod' => $r['autofidmethod'],
					'imgsize' => $r['imgsize'],
					'pageorder' => $res['pageurl']['page'][$k],
					'fid' => $r['fid'],
					'uptime' => TIMESTAMP,
					'addtime'=> TIMESTAMP,
			);
			$listopid = DB::insert('lev_grab', $insert, TRUE);
		}
		$imgurl = DB::fetch_all("SELECT * FROM ".DB::table('lev_grab_url')." WHERE grabid='{$r['id']}' ORDER BY uptime ASC", array(), 'url');
		foreach ($res['conurl']['href'] as $k => $v) {
			if (!$v) continue;
			if ($imgurl[$v]) continue;
			$ck = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE url='{$v}'");
			if ($ck) continue;
			$name = $res['title'][$k];
			$insert = array(
					'grabid' => $r['id'],
					'htmlarea' => $r['htmlarea'],
					'pregsrc' => $r['pregsrc'],
					'autofidmethod' => $r['autofidmethod'],
					'isopen' => $r['isopen'],
					'name'=> $name,
					'url' => $v,
					'imgsize' => $r['imgsize'],
					'fid' => $r['fid'],
					'uptime' => TIMESTAMP,
					'addtime'=> TIMESTAMP,
			);
			$conopid = DB::insert('lev_grab_url', $insert, TRUE);
			$conidarr[$conopid] = $conopid;
		}
		if (!$conopid) {
			foreach ($imgurl as $s) {
				if ($s['tid'] || $s['isdel']) continue;
				$conopid = $s['id'];
				break;
			}
		}
		if (!$listopid) {
			foreach ($page as $s) {
				if ($s['isdel'] || $s['id'] ==$opid) continue;
				$listopid = $s['id'];
				$r = '';
				break;
			}
		}
		if (!$listopid && !$conopid) {
			$r = self::listurl();
			if (is_array($r)) {
				if ($r['dolistpage'] ==1) {
					return array(0, $r['id'], $r);
				}else {
					return array($r['id'], '', '');
				}
			}
			return $r;
		}else {
			return array($conopid, $listopid, $r, $conidarr);
		}
	}

	public static function contentpage($id) {
		$r = C::t(lev_base::$table)->getgraburl($id);
		if (substr($r['url'], 0, 4) !=='http') return '-4001.url content'.$id;
		DB::update('lev_grab_url', array('uptime'=>TIMESTAMP, 'isdel'=>1), array('id'=>$id));
		$res = lev_module::ismodule2('x_grabimg', 'graburl', array($r['url'], $r));
		if (!is_array($res)) {
			DB::update('lev_grab_url', array('uptime'=>TIMESTAMP, 'isdel'=>-1), array('id'=>$id));
			return '-3002.res grab conurl: '.$res;
		}
		$pid = $r['pid'] ? $r['pid'] : $r['id'];
		$page= DB::fetch_all("SELECT * FROM ".DB::table('lev_grab_url')." WHERE id='$pid' OR pid='$pid' ORDER BY uptime ASC", array(), 'url');
		foreach ($res['pageurl']['href'] as $k => $v) {
			if (!$v) continue;
			if ($page[$v]) continue;
			$ck = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE url='{$v}'");
			if ($ck) continue;
			$insert = array(
					'pid' => $pid,
					'grabid' => $r['grabid'],
					'imgsize' => $r['imgsize'],
					'htmlarea' => $r['htmlarea'],
					'pregsrc' => $r['pregsrc'],
					'isopen' => $r['isopen'],
					'autofidmethod' => $r['autofidmethod'],
					'name'=> $res['title'][$k],
					'url' => $v,
					'pageorder' => $res['pageurl']['page'][$k],
					'fid' => $r['fid'],
					'uptime' => TIMESTAMP,
					'addtime'=> TIMESTAMP,
			);
			$conpageid = DB::insert('lev_grab_url', $insert, TRUE);
			$pageids[$conpageid] = $conpageid;
		}
		if ($pageids) {
			self::$pageids = $pageids;
		}
		self::$thispagepid = $pid;
		return $r;
	}

	public static function grabimg($opid, $r = array()) {
		$r = (is_array($r) && !empty($r)) ? $r : C::t(lev_base::$table)->getgraburl($opid);
		if (substr($r['url'], 0, 4) !=='http') return '-5001.url content'.$opid;
		if ($r['pid']) {
			$pid = $r['pid'];
			$p = C::t(lev_base::$table)->getgraburl($r['pid']);
		}else {
			$pid = $opid;
			$p = $r;
		}
		DB::update('lev_grab_url', array('isdel'=>1, 'uptime'=>TIMESTAMP), array('id'=>$opid));
		$res = lev_module::ismodule2('x_grabimg', '', array($r['url'], $p['name'], $p));
		if (!is_array($res)) {
			DB::update('lev_grab_url', array('isdel'=>-1, 'uptime'=>TIMESTAMP), array('id'=>$opid));
			return '-3002.res grabimg:'.$res;
		}
		foreach ($res['tidsrc'] as $k => $localsrc) {
			if (!$localsrc) continue;
			$v = $res['src'][$k];
			$name = $res['alt'][$k];
			$width= $res['size'][$k][0];
			$height= $res['size'][$k][1];
			$ck = C::t(lev_base::$table)->getimgone($localsrc, $v);
			if ($ck) {//echo '++==';
				C::t(lev_base::$table)->updateimg(array('src'=>$localsrc, 'urlpid'=>$pid, 'urlid'=>$r['id']), array('sourcesrc'=>$v));
			}else {
				C::t(lev_base::$table)->insertimg(array('urlid'=>$r['id'], 'name'=>$name, 'urlpid'=>$pid, 'uptime'=>TIMESTAMP, 'addtime'=>TIMESTAMP,
															'width'=>$width, 'height'=>$height, 'src'=>$localsrc, 'sourcesrc'=>$v));
			}
			$imgnum ++;
		}
		DB::update('lev_grab_url', array('isdel'=>2, 'uptime'=>TIMESTAMP, 'imgnum'=>$imgnum), array('id'=>$opid));
		return $pid;
	}

	public static function getpidurl($pid) {
		$rs = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE isdel=0 AND (id='$pid' OR pid='$pid') ORDER BY uptime ASC");//本页是否抓取完成包括分页
		if (empty($rs)) {
			lev_module::ismodule2('sendform', 'sendnotid2', $pid);
			$_rs = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE grabid>0 AND (id='$pid' OR pid='$pid')");//查询来自相同列表页的列表id
			if ($_rs) {
				$rs = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE isdel=0 AND grabid='{$_rs['grabid']}' ORDER BY uptime ASC");//查询来自相同列表页的内容页
				if ($rs) return $rs;
				$rs = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab')." WHERE id='{$_rs['grabid']}'");//查询相同列表页取pid
				if (!empty($rs)) {
					$pid = $rs['pid'] ? $rs['pid'] : $rs['id'];
					$rs = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab')." WHERE isdel=0 AND (id='{$pid}' OR pid='{$pid}') ORDER BY uptime ASC");//根据pid获取最早加入的列表id
					if ($rs) {
						$rs['dolistpage'] = 1;
						return $rs;
					}
				}
			}
			return self::listurl();
		}
		return $rs;
	}


	public static function _fromuser() {
		$r = lev_class::grabr();//print_r($r);
		echo '//';
		if (is_array($r)) {
			$_GET['dayautograb'] = 2;
			$rs = self::listpage($r['id'], $r);
			if (is_array($rs)) {
				$conopid = $rs[0];
				$listopid = $rs[1];
				if ($conopid >0) {//conopid
					echo 'pid.';
					self::_enter(array('conopid'=>$conopid, 'onob'=>1));
					echo '.'.$conopid.'.';
					if (is_array(self::$pageids)) {
						$pageids = self::$pageids;
						self::$pageids = '';
						foreach ($pageids as $pagid) {
							if ($pagid ==$conopid) continue;
							self::_enter(array('conopid'=>$pagid, 'onob'=>1));
							echo '.'.$pagid.'-';
							break;
						}
					}
					//$pid = self::$thispagepid;
					//if (!self::$pageids && $pid) {
						//$_GET['sendtid'] = 'checked';
						//$sendrs = lev_module::ismodule2('sendform', 'sendnotid2', $pid);
						//echo 'grab send: '.$sendrs.'|';
					//}
					DB::update('lev_grab', array('uptime'=>TIMESTAMP), array('id'=>$r['id']));
				}elseif ($listopid) {
					echo $listopid.'.listopid';
				}else {
					echo '-6001.unknown ';
				}
			}else {
				echo $rs;
			}
			if (!$conopid) {
				DB::update('lev_grab', array('uptime'=>TIMESTAMP +3600), array('id'=>$r['id']));
			}
		}else {
			echo 'no preday!';
		}
		if ((self::$pageids || !$pid) && rand(1, 5) >1) {
			echo lev_module::ismodule2('sendform', 'sendnotid');
			echo '.tid.';
		}
	}

}







