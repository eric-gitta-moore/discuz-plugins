<?php

/**
 * Www.fx8.cc
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 分.享.吧 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(60*50);

class x_grabimg_module {

	public static $isgbk = 0;

	public static function x_grabimg($arr = array()) {
		$curl = trim($arr[0]);
		$subject = $arr[1];
		$sets = $arr[2];
		if (substr($curl, 0, 4) =='http') {
			$con = lev_module::ismodule2('x_curl', 'doCurl', array('url'=>$curl, 'referer'=>$curl));
		}else {
			$con = $curl;
		}
		if (!$con) return '-2001.nothing content';

		self::isgbk($con);
		$imgarrs = self::explode_img($con, $curl);
		$imgarrs['subject'] = self::html_title($con);
		$imgarrs['curl'] = $curl;
		$imgarrs['sets'] = $sets;
		if (is_array($imgarrs)) {
			$imgarrs['htmlareasrc'] = self::htmlarea_img($con, $imgarrs, $curl, $sets['htmlarea']);
			$imgarrs['subjectsrc'] = self::subject_img($imgarrs, $subject);
			$imgarrs['pregsrc'] = self::pregsrc($imgarrs, $sets['pregsrc']);
			$imgarrs['tidsrc'] = self::tidsrc($imgarrs, $sets['autofidmethod']);
			
			$imgarrs = self::downsize($imgarrs);
		}
		
		return $imgarrs;
	}
	public static function downsize($imgarrs) {
		foreach ($imgarrs['src'] as $k => $src) {
			$alt = $imgarrs['alt'][$k];
			$size = '';
			if ($imgarrs['tidsrc'][$k]) {
				$size = self::imgsize($src);
				$src = $size[1];
				$imgarrs['tidsrc'][$k] = $size[1];
				if ($imgarrs['htmlareasrc'][$k]) $imgarrs['htmlareasrc'][$k] = $size[1];
				if ($imgarrs['subjectsrc'][$k]) $imgarrs['subjectsrc'][$k] = $size[1];
				if ($imgarrs['pregsrc'][$k]) $imgarrs['pregsrc'][$k] = $size[1];
			}
			$imgarrs['localsrc'][$k] = $src;
			$imgarrs['html'][$k] = '<img src="'.$src.'" alt="'.$alt.'" title="'.$alt.'">';
			$imgarrs['size'][$k] = $size[0];
		}
		return $imgarrs;
	}
	public static function tidsrc($imgarrs, $method = 0) {
		if ($method ==2) {
			if (is_array($imgarrs['pregsrc'])) $tidsrc = $imgarrs['pregsrc'];
		}elseif ($method ==1) {
			if (is_array($imgarrs['subjectsrc'])) $tidsrc = $imgarrs['subjectsrc'];
		}else {
			$tidsrc = $imgarrs['htmlareasrc'];
		}
		if (!$tidsrc) {
			if (is_array($imgarrs['htmlareasrc'])) return $imgarrs['htmlareasrc'];
			if (is_array($imgarrs['subjectsrc'])) return $imgarrs['subjectsrc'];
			if (is_array($imgarrs['pregsrc'])) return $imgarrs['pregsrc'];
		}
		return $tidsrc;
	}
	public static function subject_img($imgarrs, $subject = '') {
		$subject = $subject ? $subject : $imgarrs['subject'];
		if ($subject) {
			foreach ($imgarrs['localsrc'] as $k => $v) {
				if (!$v) continue;
				$alt = $imgarrs['alt'][$k];
				if (strpos($v, 'logo.') !==FALSE) continue;
				if (!self::besimilar($subject, $alt)) continue;
				$subjectimg[$k] = $v;
			}
		}
		return $subjectimg;
	}
	public static function pregsrc($imgarrs, $preg) {
		if (!$preg) return '';
		foreach ($imgarrs['src'] as $k => $v) {
			$localsrc = $imgarrs['localsrc'][$k];
			if (!$localsrc) continue;
			$ck = lev_module::ismodule2('x_preg', '', array($preg, $v));
			if ($ck >0) $pregsrc[$k] = $localsrc;
		}
		return $pregsrc;
	}

	public static function graburl($arr = array()) {
		$curl = trim($arr[0]);
	//	$sets = $arr[1];
		if (substr($curl, 0, 4) =='http') {
			$con = lev_module::ismodule2('x_curl', 'doCurl', array('url'=>$curl, 'referer'=>$curl));
		}else {
			$con = $curl;
		}
		if (!$con) return '-2001.nothing content';

		self::isgbk($con);
		$aarrs = self::explode_url($con, $curl);
		$aarrs['subject'] = self::html_title($con);

		$pageconurl = self::pageconurl($aarrs, $curl);
		$aarrs['pageurl'] = $pageconurl[0];
		$aarrs['conurl']  = $pageconurl[1];
		$aarrs['listurl'] = $pageconurl[2];

		return $aarrs;
	}
	public static function imgsize($src) {
		$imgsrc = self::downimg($src);
		if (!$imgsrc) {
			return '0';
		}elseif ($imgsrc !=$src) {
			$imgsize = getimagesize($imgsrc);
		}
		return array($imgsize, $imgsrc);
	}
	
	public static function explode_img($str, $curl) {
		if (stripos($str, '<img') ===FALSE) return FALSE;
		$con = str_ireplace(array("\r\n", "\r", "\n"), ' ', $str);
		$imgarr = explode('<img', $con);
		if (strpos($str, '<IMG') !==FALSE) {
			$imgarr2 = explode('<IMG', $con);
			$imgarr  = array_merge((array)$imgarr, (array)$imgarr2);
		}
		$pattern = "/<(img|IMG).*?src.*?=.*?[\'|\"](.*?(?:[\.gif|\.jpg|\.png]).*?)[\'|\"].*?[\/]?>/";
		$pattalt = "/<(img|IMG).*?(alt|title).*?=.*?[\'|\"](.*?)[\'|\"].*?[\/]?>/";
		foreach ($imgarr as $r) {
			$one = explode('>', $r);
			if (stripos($one[0], 'src') ===FALSE) continue;
			$img = '<img '.$one[0].'>';
			preg_match_all($pattern, $img, $src, PREG_INTERNAL_ERROR);
			$src = trim($src[2][0]);
			if (in_array($src, $imgs[2])) continue;
			preg_match_all($pattalt, $img, $alt, PREG_INTERNAL_ERROR);
			$alt = lev_base::levdiconv(trim(self::ckgbk($alt[3][0])));
			$src = self::fullurl($src, $curl);
			$imgs['alt'][] = $alt;
			$imgs['src'][] = $src;
			$imgs['html'][] = '<img src="'.$src.'" alt="'.$alt.'" title="'.$alt.'">';
			$imgs['localsrc'][] = $src;
		}
		return $imgs;
	}
	public static function htmlarea_img($html, $imgarrs, $curl, $htmlarea ='') {
		if ($htmlarea) {
			$html = str_ireplace(array("\r\n", "\r", "\n"), ' ', $html);
			$biaoji = explode('===', $htmlarea);
			$html = strstr($html, $biaoji[0]);
			$str  = explode($biaoji[1], $html);
			$imgs = self::explode_img($str[0], $curl);
			foreach ($imgs['src'] as $src) {
				foreach ($imgarrs['src'] as $k => $v) {
					if ($src ==$v) {
						$local = $imgarrs['localsrc'][$k];
						if ($local) $imgsrc[$k] = $local;
						break;
					}
				}
			}
		}//print_r($imgs);
		return $imgsrc;
	}
	
	public static function _brsimilar($arr) {
		return self::besimilar($arr[0], $arr[1]);
	}
	public static function besimilar($str1, $str2, $ck2 = 0) {
		if (stripos($str1, $str2) !==FALSE) return TRUE;
		if (stripos($str2, $str1) !==FALSE) return TRUE;
		$length1 = strlen($str1);
		$lena1 = intval($length1/3);
		$front1 = cutstr($str1, $lena1, '');
		if (strpos($str2, $front1) !==FALSE) return TRUE;
		$back1 = str_replace($front1, '', $str1);
		if (strpos($str2, $back1) !==FALSE) return TRUE;
		$back1 = str_replace(cutstr($str1, $lena1*2, ''), '', $str1);
		$center1 = str_replace(array($front1, $back1), '', $str1);
		if (strpos($str2, $center1) !==FALSE) return TRUE;
		if (!$ck2) {
			return self::besimilar($str2, $str1, 1);
		}
		return false;
	}

	public static function downimg($src) {
		$fullsrc = $src;
		if ($fullsrc) {
			$name = basename($src);
			$ext = strtolower(strstr($name, '.'));
			if (in_array($ext, array('.jpeg', '.jpg', '.gif', '.bmp', '.png'))) {
				$imgto = dirname($src);
				if ($imgto) {
					$fullname = '/'.str_ireplace(array('/', '\\', ' ', ':', '*', '"', '?', '<', '>', '|', '%', '#', ',', '{', '}', 'http', '.', '+', '-', '$', '&', '='), '', $imgto);
				}
				$imgpub = '/'.strlen($name).$fullname;
				$_fullsrc = lev_base::$PLSTATIC.'grabimg'.$imgpub;
				dmkdir($_fullsrc, 0777, FALSE);
				$_fullsrc.= '/'.$name;
				$filename = DISCUZ_ROOT.$_fullsrc;
				if (!is_file($filename) || !filesize($filename)) {
					//$ck = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_img')." WHERE sourcesrc='{$src}'");
					//$ck = C::t(lev_base::$table)->getimgone($_fullsrc);
					//if ($ck['src'] && is_file($ck['src'])) return $ck['src'];
					
					if (!lev_base::$PL_G['downimg']) return $src;
					
					$img = lev_module::ismodule2('x_curl', 'doCurl', array('url'=>$fullsrc, 'time'=>1060));
					if (!$img || stripos($img, '<html') !==FALSE) return '0';
					file_put_contents($filename, $img);
				}
				return $_fullsrc;
			}
		}
		return FALSE;
	}

	public static function pageconurl($arrs, $curl) {
		if (substr($curl, 0, 4) !='http') return '';
		$baseurl = self::baseurl($curl);
		$domain  = self::baseurl($curl, 1);
		$pageurl = $conurl = array();
		foreach ($arrs['title'] as $k => $r) {
			$a = trim($arrs['href'][$k]);
			$hname = str_ireplace($baseurl, '', $a);
			if (strpos($a, './') !==FALSE) continue;
			if (strpos($a, $domain) !==0 || in_array($a, array($baseurl, $baseurl.'#'))) continue;
			if (in_array($a, $pageurl['href']) || in_array($a, $conurl['href'])) continue; 
			$num = trim(str_ireplace(lev_base::levdiconv(array('第', '页', '张', '篇')), '', $r));
			if (is_numeric($num) && $num >1 && strlen($r) <4) {
				$pageurl['href'][$k] = $a;
				$pageurl['page'][$k] = $num;
			}elseif (in_array($r, lev_base::levdiconv(array('末页', '尾页', '最后一页', '下一页', '下一张', '下张图', '下张画')))) {//strpos($r, '下一') !==FALSE || 
				$pageurl['href'][$k] = $a;
				$pageurl['page'][$k] = end($pageurl['page']) +1;
			}elseif (substr($a, -1, 1) =='/' || strpos($hname, '.') ===FALSE || strpos($hname, 'list') !==FALSE) {
				$listurl['href'][$k] = $a;
			}elseif (strlen($r) >15 && strpos($hname, '.') !==FALSE && !in_array($r, lev_base::levdiconv(array('上一页', '首页', '前一页')))) {
				$conurl['href'][$k] = $a;
			}
		}
		//print_r($pageurl);print_r($conurl);print_r($arrs);
		return array($pageurl, $conurl, $listurl);
	}
	public static function pageurl($arrs, $curl) {
		if (substr($curl, 0, 4) !='http') return '';
		$baseurl = self::baseurl($curl);
		$domain  = self::baseurl($curl, 1);
		$pageurl = array();
		foreach ($arrs['title'] as $k => $r) {
			$a = $arrs['href'][$k];
			$hname = str_ireplace($baseurl, '', $a);
			if (strpos($a, './') !==FALSE) continue;
			if (strpos($a, $domain) !==0 || in_array($a, array($baseurl, $baseurl.'#'))) continue;
			if (in_array($a, $pageurl['href']) || in_array($a, $conurl['href'])) continue; 
			$num = floatval($r);
			if ($num >1 && strlen($r) <4) {
				$pageurl['href'][$k] = $a;
				$pageurl['page'][$k] = $num;
			}elseif (strpos($r, '下一') !==FALSE || in_array($r, array('末页', '尾页', '最后一页'))) {
				$pageurl['href'][$k] = $a;
				$pageurl['page'][$k] = end($pageurl['page']) +1;
			}elseif (substr($a, -1, 1) =='/' || strpos($hname, '.') ===FALSE || strpos($hname, 'list') !==FALSE) {
				$listurl['href'][$k] = $a;
			}elseif (strlen($r) >15 && strpos($hname, '.') !==FALSE && !in_array($r, array('上一页', '首页', '前一页'))) {
				$conurl['href'][$k] = $a;
			}
		}
		//print_r($pageurl);print_r($conurl);print_r($arrs);
		return array($pageurl, $conurl, $listurl);
	}
	public static function baseurl($curl, $domain =0) {
		$urls = explode('/', $curl);//print_r($urls);
		if ($domain) return $urls[0].'//'.$urls[2];
		$num  = count($urls);
		if ($num >3 && strpos(end($urls), '.') !==FALSE) {
			array_pop($urls);
		}
		foreach ($urls as $v) {
			$baseurl .= $v.'/';
		}
		$baseurl = str_replace('//', '/', $baseurl);
		$baseurl = str_replace(':/', '://', $baseurl);
		return $baseurl;
	}

	public static function explode_url($str, $curl) {
		if (stripos($str, '<a') ===FALSE) return FALSE;
		$con = str_ireplace(array("\r\n", "\r", "\n", "%>"), ' ', $str);
		$con = str_replace(array('<A', '</A>'), array('<a', '</a>'), $con);
		$aarr = explode('<a', $con);
		$pattern = "/<(a|A).*?href.*?=.*?[\'|\"](.*?)[\'|\"].*?[\/]?>/";
		$pattalt = "/<(a|A).*?(alt|title).*?=.*?[\'|\"](.*?)[\'|\"].*?[\/]?>/";
		foreach ($aarr as $r) {
			if (stripos($r, 'href') ===FALSE) continue;
			$one = explode('</a>', $r);
			$one[0] = self::ckgbk($one[0]);
			//$tits   = explode('>', $one[0]);
			//$title  = trim($tits[1]);
			$a = '<a '.$one[0].'</a>';
			$title = trim(strip_tags($a));
			if (!$title) {
				preg_match_all($pattalt, $a, $_tit, PREG_INTERNAL_ERROR);
				$title = $_tit[3][0];
			}
			preg_match_all($pattern, $a, $href, PREG_INTERNAL_ERROR);
			$href = trim($href[2][0]);
			if (stripos($href, 'javascript:') ===0 || stripos($href, '<') ===0) continue;
			$href = self::fullurl($href, $curl);
			if (in_array($href, $as['href'])) {
				if (floatval($title) >1 && strlen($title) <4) {
					foreach ($as['href'] as $k => $v) {
						if ($href ==$v) {
							unset($as['title'][$k], $as['href'][$k], $as['html'][$k]);
							break;
						}
					}
				}else {
					continue;
				}
			}
			$title = lev_base::levdiconv($title);
			$as['title'][] = $title;
			$as['href'][] = $href;
			$as['html'][] = '<a class="cg2c" href="'.$href.'" title="'.$title.'" target=_blank>'.$title.'</a>';
		}
		return $as;
	}

	public static function ckgbk($arr) {
		$str = is_array($arr) ? $arr[0] : $arr;
		$ckgbk = json_encode($str);
		if ($ckgbk ==="null" || self::$isgbk) {
			$arr = lev_base::levdiconv($arr, 'gbk', 'utf-8');
		}
		return $arr;
	}
	public static function isgbk($html) {
		$charset = stristr($html, 'charset');
		$one = explode('>', $charset);
		if (stripos($one[0], 'gbk') !==FALSE || stripos($one[0], 'gb2312') !==FALSE) self::$isgbk = TRUE;
	}

	public static function html_title($html) {
		$title = strstr($html, '<title>');
		if (!$title) {
			$title = strstr($html, '<TITLE>');
			$pre = '</TITLE>';
		}else {
			$pre = '</title>';
		}
		if ($title) {
			$_title = explode($pre, $title);
			$title = $_title[0];
		}
		if (strpos($title, '-') !=FALSE) {
			$_title = explode('-', $title);
			$title = $_title[0];
		}
		if ($title) {
			$title = substr($title, 7);
			$title = self::ckgbk($title);
		}
		return lev_base::levdiconv($title);
	}

	public static function fullurl($a, $curl) {
		if (substr($a, 0, 4) =='http') {
			$fullurl = $a;
		}else {
			$str2 = substr($a, 0, 2);
			if (substr($a, 0, 1) =='/') {
				$urls = explode('/', $curl);
				$fullurl = $urls[0].'//'.$urls[2].'/'.$a;
			}elseif ($str2 =='./' || substr($a, 0, 1) !='/') {
				$basesrc = self::baseurl($curl);
				$fullurl = $basesrc.$a;
			}
		}
		//$fullurl = str_replace(array('//', '/./', '/../'), '/', $fullurl);
		return $fullurl;
	}
	
}







