<?php

/**
 * Www.fx8.cc [ 专业开发各种Discuz!插件 ]
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 分.享.吧 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'lev_module.php';

class lev_class extends lev_module {

	public static function _dograbimg($id) {
		$r = C::t(lev_base::$table)->getgraburl($id);
		if (substr($r['url'], 0, 4) !=='http') return '-20002.url'.$id;
		$res = lev_module::ismodule2('x_grabimg', 'graburl', array($r['url'], $r));
		$pid = $r['pid'] ? $r['pid'] : $r['id'];
		$page= DB::fetch_all("SELECT * FROM ".DB::table('lev_grab_url')." WHERE pid='$pid'", array(), 'url');
		foreach ($res['pageurl']['href'] as $k => $v) {
			if ($v) {
				if ($page[$v]) continue;
				$ck = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE url='{$v}'");
				if ($ck) continue;
				$insert = array(
					'pid' => $pid,
					'grabid' => $r['grabid'],
					'imgsize' => $r['imgsize'],
					'htmlarea' => $r['htmlarea'],
					'pregsrc' => $r['pregsrc'],
					'isopen' => $r['isopen'],
					'autofidmethod' => $r['autofidmethod'],
					'name'=> $res['title'][$k],
					'url' => $v,
					'pageorder' => $res['pageurl']['page'][$k],
					'fid' => $r['fid'],
					'uptime' => TIMESTAMP,
					'addtime'=> TIMESTAMP,
				);
				DB::insert('lev_grab_url', $insert);
			}
		}
		if ($_GET['autograbimg'] ==2) {
			$pid = self::dograbimg($pid);
			return $pid;
		}
		return $res;
	}
	public static function dograbimg($pid) {
		$urls = DB::fetch_all("SELECT * FROM ".DB::table('lev_grab_url')." WHERE isdel=0 AND (id='$pid' OR pid='$pid') ORDER BY pageorder DESC, id DESC", array(), 'id');
		if (empty($urls)) return '-2001';
		if (empty($urls[$pid])) {
			$urls[$pid] = C::t(lev_base::$table)->getgraburl($pid);
		}
		//$imgs = DB::fetch_all("SELECT * FROM ".DB::table('lev_grab_img')." WHERE urlpid='$pid'");
		$imgs = C::t(lev_base::$table)->getimg_urlpid($pid);
		foreach ($imgs as $r) {
			$urlid[$r['urlid']] = $r['urlid'];
			$src[] = $r['sourcesrc'];
		}
		foreach ($urls as $r) {
			if ($r['isdel']) continue;
			if ($urlid[$r['id']]) continue;
			$res = lev_module::ismodule2('x_grabimg', '', array($r['url'], $urls[$pid]['name'], $urls[$pid]));
			foreach ($res['tidsrc'] as $k => $localsrc) {
				if (!$localsrc) continue;
				$v = $res['src'][$k];
				$name = $res['alt'][$k];
				$width= $res['size'][$k][0];
				$height= $res['size'][$k][1];
				if (in_array($v, $src)) {//echo '++==';
					C::t(lev_base::$table)->updateimg(array('src'=>$localsrc, 'urlpid'=>$pid, 'urlid'=>$r['id']), array('sourcesrc'=>$v));
				}else {
					C::t(lev_base::$table)->insertimg(array('urlid'=>$r['id'], 'name'=>$name, 'urlpid'=>$pid, 'uptime'=>TIMESTAMP, 'addtime'=>TIMESTAMP, 
															'width'=>$width, 'height'=>$height, 'src'=>$localsrc, 'sourcesrc'=>$v));
				}
			}
			if ($res['tidsrc'] && !in_array($v, $src) && $localsrc) return $r['id'];
		}
		$tid = lev_module::ismodule2('sendform', 'sendform2', array($pid, $urls));
		
		$grabid = $urls[$pid]['grabid'];
		if ($grabid >0) {
			$rs = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE isdel=0 AND grabid='{$grabid}' AND tid=0 AND id!='$pid' ORDER BY pageorder DESC, id DESC");
			if ($rs) return $rs['id'];
			DB::update('lev_grab', array('isdel'=>1, 'isopen'=>0), array('id'=>$grabid));
		}else {
			$rs = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE isdel=0 AND tid=0 AND id!='$pid' ORDER BY pageorder DESC, id DESC");
			if ($rs) return $rs['id'];
		}
		
		return '1000';//抓取完毕
	}
	public static function imgsize($imgsize, $r = array()) {
		//if (!$r['width']) return FALSE;
		$imgsize = $r['imgsize'] ? $r['imgsize'] : $imgsize;
		if ($imgsize) {
			$arr = explode('=', trim($imgsize));
			$w = intval($arr[0]);
			$h = intval($arr[1]);
			if ($w >$r['width'] || $h >$r['height']) return FALSE;
		}
		return true;
	}
	
	public static function _autourl() {
		$r = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab')." WHERE isdel=0 ORDER BY pageorder DESC, uptime ASC");//print_r($r);
		if ($r) {
			DB::update('lev_grab', array('uptime'=>TIMESTAMP), array('id'=>$r['id']));
			return self::_dograb($r['id']);
		}else {
			return '-3001.noautourl';
		}
	}
	public static function _dograb($id, $racu = 0) {
		$r = C::t(lev_base::$table)->getone($id);
		$curl = $r['listurl'];
		if (!$curl) return '-3002.nocurl';
		$res = lev_module::ismodule2('x_grabimg', 'graburl', array($curl, $r));
		$pid = $r['pid'] ? $r['pid'] : $r['id'];
		$page= DB::fetch_all("SELECT * FROM ".DB::table('lev_grab')." WHERE pid='$pid' ORDER BY pageorder DESC, id DESC", array(), 'listurl');
		foreach ($res['pageurl']['href'] as $k => $v) {
			if ($v) {
				if ($page[$v]) continue;
				$ck = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab')." WHERE listurl='{$v}'");
				if ($ck) continue;
				$insert = array(
					'pid' => $pid,
					'name'=> $res['title'][$k],
					'listurl' => $v,
					'htmlarea' => $r['htmlarea'],
					'pregsrc' => $r['pregsrc'],
					'autofidmethod' => $r['autofidmethod'],
					'imgsize' => $r['imgsize'],
					'pageorder' => $res['pageurl']['page'][$k],
					'fid' => $r['fid'],
					'uptime' => TIMESTAMP,
					'addtime'=> TIMESTAMP,
				);
				$listopid = DB::insert('lev_grab', $insert, TRUE);
			}
		}
		$imgurl = DB::fetch_all("SELECT * FROM ".DB::table('lev_grab_url')." WHERE grabid='{$r['id']}' ORDER BY pageorder DESC, id DESC", array(), 'url');
		foreach ($res['conurl']['href'] as $k => $v) {
			if ($v) {
				if ($imgurl[$v]) continue;
				$ck = DB::fetch_first("SELECT * FROM ".DB::table('lev_grab_url')." WHERE url='{$v}'");
				if ($ck) continue;
				$insert = array(
					'grabid' => $r['id'],
					'htmlarea' => $r['htmlarea'],
					'pregsrc' => $r['pregsrc'],
					'autofidmethod' => $r['autofidmethod'],
					'isopen' => $r['isopen'],
					'name'=> $res['title'][$k],
					'url' => $v,
					'imgsize' => $r['imgsize'],
					'fid' => $r['fid'],
					'uptime' => TIMESTAMP,
					'addtime'=> TIMESTAMP,
				);
				$conopid = DB::insert('lev_grab_url', $insert, TRUE);
			}
		}
		if (!$conopid) {
			foreach ($imgurl as $s) {
				if ($s['tid'] || $s['isdel']) continue;
				$conopid = $s['id'];
				break;
			}
		}
		if (!$conopid) {
			return '1000';
			if ($racu >5) return '-3002.racu';
			$racu = intval($racu);
			$racu ++;
			if (!$listopid) {
				DB::update('lev_grab', array('isdel'=>2), array('id'=>$id));
				foreach ($page as $s) {
					if ($s['isdel'] || $s['id'] ==$id) continue;
					$listopid = $s['id'];
					break;
				}
			}
			if (!$listopid && !$_GET['dayautograb']) {
				$rc = self::_autourl();
				if (is_array($rc)) return self::_dograb($rc['id'], $racu);
			}else {
				return self::_dograb($listopid, $racu);
			}
		}
		$res['conopid'] = $conopid;
		return $res;
		//foreach ($res[])
	}
	
	public static function _autograb($start) {
		$r = self::grabr($start);
		if (is_array($r)) {
			$rs = self::_dograb($r['id']);
			if (is_array($rs) && $rs['conopid']) {
				$_GET['autograbimg'] = 2;
				$_GET['dayautograb'] = 2;
				$rs = self::_dograbimg($rs['conopid']);//print_r($rs);
			}
			echo '//'.$rs;
		}
	}
	public static function grabr() {
		$hour = intval(date('H', TIMESTAMP));
		$url = C::t(lev_base::$table)->getpreday();
		if ($url) {
		//	$ymd = date('Ymd', TIMESTAMP);
			foreach ($url as $r){
				$preday = self::preday($r['preday']);
				if (in_array($hour, $preday)) {
					//DB::update('lev_grab', array('uptime'=>TIMESTAMP), array('id'=>$r['id']));
					//C::t(lev_base::$table)->updateymd('lev_grab', $r['id']);
					return $r;
				}
			}
		}
		return FALSE;
	}
	
	public static function preday($preday) {
		if (!$preday && !is_numeric($preday)) return '';
		if ($preday ==24) {
			for ($i=0; $i<24; $i++) $hours[] = $i;
			return $hours;
		}
		$arr = explode('=', $preday);
		foreach ($arr as $v) {
			$v = trim($v);
			if (!is_numeric($v)) continue;
			$hour = ($v >23 || $v <0) ? 23 : $v;
			if ($hours && in_array($hour, $hours)) continue;
			$hours[] = $hour;
		}
		return $hours;
	}
	
	public static function hourstr($preday) {
		if (!$preday && !is_numeric($preday)) return '';
		if ($preday ==24) {
			return array(24, 0, 24);
		}
		$arr = self::preday($preday);
		sort($arr);
		foreach ($arr as $v) {
			$str .= $v.'=';
		}
		$str = substr($str, 0, -1);
		return array($str, $arr[0], end($arr));
	}
	
	public static function besimilar($str1, $str2) {
		return lev_module::ismodule2('x_grabimg', '_brsimilar', array($str1, $str2));
	}

}













