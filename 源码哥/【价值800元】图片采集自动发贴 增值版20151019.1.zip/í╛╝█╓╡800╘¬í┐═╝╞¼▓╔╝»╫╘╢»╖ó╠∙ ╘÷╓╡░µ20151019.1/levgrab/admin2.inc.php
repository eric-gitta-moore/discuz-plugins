<?php
/**
 * Www.fx8.cc
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 ��.��.�� $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once 'lev_enter.php';

$tabid = intval($_GET['tabid']);
$tabid = ($tabid >=0 && $tabid <10) ? $tabid : 0;

$file = str_replace('.inc.php', '', basename(__FILE__));
$murl = 'plugins&operation=config&do='.$pluginid.'&identifier='.$PLNAME.'&pmod='.$file.'&fh='.FORMHASH.'&tabid='.$tabid;
$turl = ADMINSCRIPT.'?action='.$murl;
$table = 'lev_grab_img_'.$tabid;
if ($_GET['fh'] ==FORMHASH && $_GET['dograbimg'] ==1) {
	ob_clean();
	$res = lev_class::_dograbimg($_GET['opid']);//echo '<pre>';print_r($res);
	foreach ($res['pageurl']['href'] as $k => $v) {
		$listurl .= '<tr><td><a target=_blank href="'.$v.'" title='.$res['title'][$k].'>'.$v.'</a></td></tr>';
	}
	foreach ($res['conurl']['href'] as $k => $v) {
		$conurl .= '<tr><td><a target=_blank href="'.$v.'" title='.$res['title'][$k].'>'.$v.'</a></td></tr>';
	}
	$html = '<table class="tb tb2"><tr><td>'.$lev_lang['listurl'].'</td></tr>'.$listurl;
	$html.= '<tr><td>'.$lev_lang['conurl'].'</td></tr>'.$conurl.'</table>';
	exit($html);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['dograb'] ==1) {
	ob_clean();
	$res = lev_class::_dograb($_GET['opid']);//echo '<pre>';print_r($res);
	foreach ($res['pageurl']['href'] as $k => $v) {
		$listurl .= '<tr><td><a target=_blank href="'.$v.'" title='.$res['title'][$k].'>'.$v.'</a></td></tr>';
	}
	foreach ($res['conurl']['href'] as $k => $v) {
		$conurl .= '<tr><td><a target=_blank href="'.$v.'" title='.$res['title'][$k].'>'.$v.'</a></td></tr>';
	}
	$html = '<table class="tb tb2"><tr><td>'.$lev_lang['listurl'].'</td></tr>'.$listurl;
	$html.= '<tr><td>'.$lev_lang['conurl'].'</td></tr>'.$conurl.'</table>';
	exit($html);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['setoption'] ==1) {
	ob_clean();
	$msg = C::t(lev_base::$table)->setoption($table);
	exit($msg);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['setstatus'] ==1) {
	ob_clean();
	$msg = C::t(lev_base::$table)->setstatus($table);
	exit($msg);
}elseif (isset($_GET['doaddsubmit']) && $_GET['formhash'] ==FORMHASH) {
	$name = trim($_GET['name']);
	$preday = lev_class::hourstr($_GET['preday']);
	$addinfo = array(
		'name' => $name,
		'url'=>trim($_GET['url']),
		'fid'=>intval($_GET['fid']),
		'settings'=>serialize($_GET['sets']),
		'isopen'=>intval($_GET['isopen']),
		'uptime' => TIMESTAMP,
	);
	$opid = intval($_GET['opid']);
	$r = C::t(lev_base::$table)->getone($opid);
	if ($r) {
		DB::update($table, $addinfo, array('id'=>$opid));
	}else {
		$addinfo['addtime'] = TIMESTAMP;
		$opid = DB::insert($table, $addinfo, TRUE);
	}
	cpmsg($lev_lang['succeed'], dreferer(), 'succeed');
}elseif (isset($_GET['dosubmit']) && $_GET['formhash'] ==FORMHASH) {
	$insql = lev_base::sqlinstr($_GET['ids']);
	if ($insql) {
		DB::query("DELETE FROM ".DB::table($table)." WHERE `id` IN ({$insql})");
		cpmsg($lev_lang['succeed'], dreferer(), 'succeed');
	}
}

include template($PLNAME.':admin_common');

$bbform = lev_base::bbforum();

$fidoption = '<option vlaue=0>'.$lev_lang['pslt'].'</option>';
foreach ($bbform as $v) {
	$fidoption.= '<option value="'.$v['fid'].'">'.$v['name'].'</option>';
}

if (!$_GET['addtmp']) {
	for ($i=0; $i<10; $i++) {
		$isslt = $i ==$tabid ? 'color:red' : '';
		$tabstrs.= '<a href="'.$turl.'&tabid='.$i.'" style="'.$isslt.'">'.$lev_lang['tabname'].$i.'</a> | ';
	}
	$_subtitle = array (
		'<a href="javascript:;"><label for="chkall">'.$lev_lang['slts'].'</label></a>',
		'ID',
		$lev_lang['name'],
		$lev_lang['imglocal'],
		$lev_lang['imgsource'],
		$lev_lang['addtime'],
	);
	showformheader($murl);
	showtableheader($tabstrs);
	showsubtitle($_subtitle);
	
	$where = "1";
	$limit = 50;
	$infos = C::t(lev_base::$table)->levpages($table, $where.' ORDER BY id DESC', $limit, 0, $turl.'&tabid='.$tabid);
	$lists = $infos['lists'];
	$pages = $infos['pages'];
	if ($lists) {
		foreach ($lists as $v) {
			$s = unserialize($v['settings']);
			showtablerow(
			'',
			array(
				'width=30',
				'width=45',
			),
			array (
			"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"{$v['id']}\">",
			$v['id'],
			$v['name'],
			'<a href="'.$v['src'].'" target=_blank>'.$v['src'].'</a>',
			'<a href="'.$v['sourcesrc'].'" target=_blank>'.$v['sourcesrc'].'</a>',
			dgmdate($v['addtime'], 'u'),
			));
		}
		showsubmit(
			'', 
			'', 
			'', 
			'<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" />
			<label for="chkall">'.$lev_lang['slts'].'</label>&nbsp;&nbsp;<input type="submit" class="btn" name="dosubmit" value="'.$lev_lang['del'].'" onclick="return confirm(\''.$lev_lang['confirm'].'\');"/>
			', 
		$pages);
	}else {
		showtablerow('', array('colspan='.count($_subtitle)), array($lev_lang['nodata']));
	}
	showtablefooter();
	showformfooter();
}else {
	$opid = intval($_GET['opid']);
	$r = C::t(lev_base::$table)->getgraburl($opid);
	if ($r['grabid']) {
		$p = C::t(lev_base::$table)->getone($r['grabid']);
		$sourceurl = $lev_lang['sourceurl'].'<a href="'.$p['listurl'].'" title="'.$p['listurl'].'" target=_blank>'.$p['name'].'</a>';
	}
	$isopen = ($r['isopen'] || !isset($r['isopen'])) ? 'checked' : '';
	$s = unserialize($r['settings']);
	showformheader($murl.'&addtmp=1&opid='.$opid);
	showtableheader('<a href="'.$turl.'"><b>'.$lev_lang['addpage'].'</b></a>');
	$html = <<<EOF
	
	<style>.tb.tb2 tr td.t {width:120px;text-align:right;font-weight:bold;}</style>
	<tr><td class=t></td><td colspan=2>{$sourceurl}</td></tr>
	<tr><td class=t>{$lev_lang['name']}</td><td colspan=2><input type="text" name="name" id="name" value="{$r['name']}" style="width:550px;"></td></tr>
	<tr><td class=t>{$lev_lang['imgurl']}</td><td colspan=2><input type="text" name="url" id="listurl" value="{$r['url']}" style="width:550px;">{$lev_lang['imgurl1']}</td></tr>
	<tr><td class=t>{$lev_lang['fiddesc']}</td><td colspan=2><select name=fid id=fid>{$fidoption}</select>{$lev_lang['fiddesc1']}</td></tr>
	
	<tr><td class=t>{$lev_lang['isopen']}</td><td colspan=2><input type=checkbox name=isopen value=1 $isopen></td></tr>
	<tr><td class=t></td><td><input type="submit" value="{$lev_lang['subt']}" name="doaddsubmit" class="btn"></td><td></td></tr>
	<script>
	jQuery('#fid').val('{$r['fid']}');
	</script>
EOF;
	echo $html;
	showtablefooter();
	showformfooter();
}


