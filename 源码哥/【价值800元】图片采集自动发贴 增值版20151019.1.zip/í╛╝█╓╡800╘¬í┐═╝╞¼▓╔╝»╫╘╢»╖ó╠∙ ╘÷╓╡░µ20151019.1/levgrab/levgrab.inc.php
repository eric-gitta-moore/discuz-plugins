<?php

/**
 * 
 *
 * Copyright (c) 2014-2016 
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 ��.��.�� $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


require_once 'lev_enter.php';

$imgarr = lev_module::ismodule2('x_grabimg', 'graburl', array('http://www.fx8.cc/a/TGOD/77545.html'));

print_r($imgarr);

include template('diy:levgrab', '', $diydir);


















