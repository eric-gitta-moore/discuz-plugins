<?php

/**
 * Www.fx8.cc [ 专业开发各种Discuz!插件 ]
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 分.享.吧 $
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_levgrab {

	public static $aidarr = array();
	
	public static function post_top() {
	}

	
	public function forumdisplay_thread_subject_output() {
		global $_G;//print_r($_G['forum_threadlist']);
		$tidinsql = self::sqlinstr($_G['forum_threadlist'], 'tid');
		if ($tidinsql) {
			$r = DB::fetch_all("SELECT * FROM ".DB::table('forum_post')." WHERE tid IN ($tidinsql)", array(), 'tid');
			foreach ($_G['forum_threadlist'] as $key => $v) {
				if (!$v['coverpath']) {
					$imgs = self::x_bbcode(array($r[$v['tid']]['message'], '[img]'));
					if (is_array($imgs)) {
						$_G['forum_threadlist'][$key]['cover'] = 1;
						$_G['forum_threadlist'][$key]['coverpath'] = $imgs[0];
					//}elseif ($imgs = self::x_bbcode(array($r[$v['tid']]['message'], '[attach]'))) {//print_r($imgs);
					//	$src = getforumimg($imgs[0], 0, 300, 0, 2);
					//	$_G['forum_threadlist'][$key]['cover'] = 1;
					//	$_G['forum_threadlist'][$key]['coverpath'] = $src;
					}elseif ($imgs = C::t('forum_attachment_n')->fetch_max_image('tid:'.$v['tid'], 'tid', $v['tid'])) {
						$src = getforumimg($imgs['aid'], 0, 300, 0, 2);
						$_G['forum_threadlist'][$key]['cover'] = 1;
						$_G['forum_threadlist'][$key]['coverpath'] = $src;
					}
				}
			}
		}
	}
	
	public static function viewthread_postbottom_output() {
		if (!self::ckforum()) return '';
		global $postlist;//print_r($postlist);
		foreach ($postlist as $r) {
			foreach ($r['attachments'] as $v) {
				if (!$v['isimage']) continue;
				if (in_array($v['aid'], self::$aidarr)) continue;
				$src = self::attbasedir($v['remote']).$v['attachment'];
				$postlist[$r['pid']]['message'].= '<a id="levgrab_full" href="'.$src.'" onclick="return hs.expand(this)"><img src="'.$src.'" style="max-width:700px;"></a>';
				$postlist[$r['pid']]['attachments'] = array();
			}
		}
	}
	
	public static function discuzcode($value) {
		if (!self::ckforum()) return '';
		global $_G, $postlist;//echo '<pre>';print_r($_G['discuzcodemessage']);
		if (stripos($_G['discuzcodemessage'], '<img') !==FALSE) {
			$pattern="/<[img|IMG].*?src=[\'|\"](.*?(?:[\.gif|\.jpg|\.png]))[\'|\"].*?[\/]?>/";
			$imgnum = preg_match_all($pattern, $_G['discuzcodemessage'], $imgarr, PREG_INTERNAL_ERROR);
			if ($imgarr[0]) {
				$imgarr[0] = array_unique($imgarr[0]);
				foreach ($imgarr[0] as $imgh) {
					$img = '<a id="levgrab_full" href="'.$src.'" onclick="return hs.expand(this)">'.$imgh.'</a>';
					$_G['discuzcodemessage'] = str_ireplace($imgh, $img, $_G['discuzcodemessage']);
				}
			}
		}
		$imgs = self::x_bbcode(array($_G['discuzcodemessage'], '[img]'));
		$atts = self::x_bbcode(array($_G['discuzcodemessage'], '[attach]'));//print_r($imgs2);
		if ($atts && $_G['thread']['attachment'] ==2) {
			$atttab = getattachtablebytid($_G['thread']['tid']);
			$aidstr = self::sqlinstr($atts);
			if ($aidstr) {
				self::$aidarr = $atts;
				$attach = DB::fetch_all("SELECT * FROM ".DB::table($atttab)." WHERE aid IN($aidstr)", array(), 'aid');
				foreach ($atts as $aid) {
					$v = $attach[$aid];
					if (!$v['isimage']) continue;
					$src = self::attbasedir($v['remote']).$v['attachment'];
					$img = '<a id="levgrab_full" href="'.$src.'" onclick="return hs.expand(this)"><img src="'.$src.'" style="max-width:700px;"></a>';
					$_G['discuzcodemessage'] = str_ireplace('[attach]'.$aid.'[/attach]', $img, $_G['discuzcodemessage']);
				}
			}
		}
		foreach ($imgs as $src) {
			$img = '<a id="levgrab_full" href="'.$src.'" onclick="return hs.expand(this)"><img src="'.$src.'" style="max-width:700px;"></a>';
			$_G['discuzcodemessage'] = str_ireplace($src.'[/img]', $img, $_G['discuzcodemessage']);
		}
		$_G['discuzcodemessage'] = preg_replace(array("/\[img=(\d{1,4})[x|\,](\d{1,4})\]/ies"), '', $_G['discuzcodemessage']);
		$_G['discuzcodemessage'] = str_ireplace('[img]', '', $_G['discuzcodemessage']);
	}
	
	public static function global_footer() {
		if (self::$PL_G['autograb']) {
			$js = '<script language="javascript" type="text/javascript" src="'.self::$lm.'autograb._fromuser"></script>';
		}
		if (!self::ckforum()) return $js;
		$PLSTATIC = self::$PLSTATIC;
		$lev_lang = self::$lang;
		$intervaltime = self::$PL_G['seconds'] >0 ? self::$PL_G['seconds'] : 2;
		$intervaltime*= 1000;
		$hookval = intval(self::$PL_G['hookval']);
		include template('levgrab:hook'.$hookval);
		return $return.$js;
	}

	public static function ckforum() {
		global $_G;//print_r($_G);
		if ($_G['setting']['hookscript']['global']['global']['module']['levpics']) return FALSE;
		$ckforum = unserialize(self::$PL_G['ckforum']);
		if ($ckforum[0] && !in_array($_G['thread']['fid'], $ckforum)) return FALSE;
		return true;
	}
	public static function x_bbcode($arr = array()) {
		$message = $arr[0];
		$bbcode1 = $arr[1];
		if (!$bbcode1 || !$message) return '';
		
		$bbcode2 = str_replace('[', '[/', $arr[1]);
		if (strpos($message, $bbcode1) !==FALSE) {
			$arr = explode($bbcode1, $message);
			foreach ($arr as $r) {
				if (strpos($r, $bbcode2) ===FALSE) continue;
				$one = explode($bbcode2, $r);
				$res[] = trim($one[0]);
			}
		}
		if ($bbcode1 =='[img]') {
			if (strpos($message, '[img') !==FALSE) {
				$imgs = explode('[/img]', $message);
				foreach ($imgs as $r) {
					$one = strstr($r, '[img');
					$res[] = preg_replace(array("/\[img=(\d{1,4})[x|\,](\d{1,4})\]/ies"), '', $one);
				}
			}
		}
		return $res;
	}
	public static function attbasedir($remote = 0) {//X2.5 up
			if($remote) {
				$imgsrc = self::$_G['setting']['ftp']['attachurl'].'forum/';
			} else {
				$imgsrc = self::$_G['siteurl'].self::$_G['setting']['attachurl'].'forum/';
			}
		return $imgsrc;
	}
	
	public static $PL_G, $_G, $PLNAME, $PLSTATIC, $PLURL, $lang = array(), $table, $navtitle, $uploadurl, $remote, $talk;
	public static $lm, $lm2, $loadjs;
	
	public function __construct() {
		self::_init();
	}
	
	public static function _init() {

		global $_G;
		self::$_G     = $_G;
		self::$PLNAME = 'levgrab';
		self::$PL_G   = self::$_G['cache']['plugin'][self::$PLNAME];//print_r($PL_G);

		self::$PLSTATIC = 'source/plugin/'.self::$PLNAME.'/statics/';
		self::$PLURL    = 'plugin.php?id='.self::$PLNAME;
		self::$uploadurl= self::$PLSTATIC.'upload/common/';
		self::$remote   = 'plugin.php?id='.self::$PLNAME.':l&fh='.FORMHASH.'&m=';
		self::$lm       = self::$remote.'_m.';
		self::$lm2      = self::$remote.'__m.';
		self::$loadjs   = self::$remote.'__m.x_loadjs.__init';
		self::$lang     = self::levlang();
	}

	//return $instr = 1,2,3,4,5,6
	public static function sqlinstr($array, $key = '') {
		if (!is_array($array)) {
			$array = (array)unserialize($array);
			$key = '';
		}
		$instr = '';
		if ($key) {
			foreach ($array as $v) {
				if (is_numeric($v[$key])) $instr .= $v[$key].',';
			}
		}else {
			foreach ($array as $v) {
				if (is_numeric($v)) $instr .= $v.',';
			}
		}
		if ($instr) $instr = substr($instr, 0, -1);
		return $instr;
	}
	
	public static function levlang($string = '', $key = 0) {
		$sets  = $string ? $string : (!$key ? self::$PL_G['levlang'] : '');
		$lang  = array();
		if ($sets) {
			$array = explode("\n", $sets);
			foreach ($array as $r) {
				$thisr  = explode('->', trim($r));
				$lang[trim($thisr[0])] = trim($thisr[1]);
			}
			if (!$key) {
				$lang['extscore'] = self::$_G['setting']['extcredits'][self::$PL_G['scoretype']]['title'];
				$flang = lang('plugin/levgrab');
				if (is_array($flang)) $lang = $lang + $flang;
			}
		}
		return $lang;
	}

	public static function _levdiconv($string, $in_charset = 'utf-8', $out_charset = CHARSET) {
		if(is_array($string)) {
			foreach($string as $key => $val) {
				$string[$key] = diconv($val, $in_charset, $out_charset);
			}
		} else {
			$string = diconv($string, $in_charset, $out_charset);
		}
		return $string;
	}
	
	public static function _isopen($key = 'close') {
		$isopen = unserialize(self::$PL_G['isopen']);
		if (is_array($isopen) && in_array($key, $isopen)) return TRUE;
		return FALSE;
	}
	
	public static function loadjs() {
		$js = '<script language="javascript" type="text/javascript" src="'.self::$loadjs.'"></script>';
		return $js;
	}
	
	
}

class plugin_levgrab_forum extends plugin_levgrab {}
















