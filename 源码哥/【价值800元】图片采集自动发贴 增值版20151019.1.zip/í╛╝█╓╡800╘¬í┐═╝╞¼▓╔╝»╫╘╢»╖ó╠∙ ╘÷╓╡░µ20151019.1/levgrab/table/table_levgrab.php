<?php

/**
 * Www.fx8.cc
 *
 * Copyright (c) 2014-2016 http://www.fx8.cc All rights reserved.
 *
 * Author: FX8 <154606914@qq.com>
 *
 * Date: 2013-02-17 16:22:17 ��.��.�� $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_levgrab extends discuz_table {
	
	public static $table = 'lev_grab', $table2 = 'lev_grab_url', $table3 = 'lev_grab_img';
	
	public static function getimgone($imgsrc, $sourcesrc) {
		$tab = self::getimgtabname($imgsrc);
		$res = DB::fetch_first("SELECT * FROM ".DB::table($tab)." WHERE src='{$imgsrc}' AND sourcesrc='{$sourcesrc}'");
		return $res;
	}
	public static function insertimg($data) {
		$tab = self::getimgtabname($data['src']);
		$nid = DB::insert($tab, $data, TRUE);
		return $nid;
	}
	public static function updateimg($data, $if) {
		$tab = self::getimgtabname($data['src']);
		DB::update($tab, $data, $if);
	}
	public static function getimg_urlpid($pid) {
		for ($i=0; $i<10; $i++) {
			$rs[$i] = DB::fetch_all("SELECT * FROM ".DB::table('lev_grab_img_'.$i)." WHERE urlpid='$pid'");
		}
		for ($i=0; $i<10; $i++) {
			foreach ($rs[$i] as $v) {
				$res[] = $v;
			}
		}
		return $res;
	}
	
	public static function getimgtabname($imgsrc) {
		return 'lev_grab_img_'.self::getimgtabid($imgsrc);
	}
	public static function getimgtabid($imgsrc) {
		$imgname = basename($imgsrc);
		$tabid   = substr(strlen($imgname), -1, 1);
		return intval($tabid);
	}
	
	public static function getpreday() {
		$hour = intval(date('H', TIMESTAMP));
		$ymd = date('Ymd', TIMESTAMP);
		$sql = "SELECT * FROM ".DB::table(self::$table)." WHERE preday!='' AND isopen=1 AND minhour<=$hour AND maxhour>=$hour AND ymd<$ymd AND listurl!='' ORDER BY uptime ASC LIMIT 500";
		$res = DB::fetch_all($sql);
		return $res;
	}
	
	public static function getgraburl($opid) {
		$rs = DB::fetch_first("SELECT * FROM ".DB::table(self::$table2)." WHERE id='$opid'");
		return $rs;
	}
	
	public static function getone($opid) {
		$rs = DB::fetch_first("SELECT * FROM ".DB::table(self::$table)." WHERE id='$opid'");
		return $rs;
	}
	
	public static function updateymd($table, $id) {
		$id = intval($id);
		$ymd = date('Ymd', TIMESTAMP);
		DB::update($table, array('ymd'=>$ymd), array('id'=>$id));
	}
	
	public static function cktid($tid) {
		$sql = "SELECT * FROM ".DB::table('forum_thread')." a LEFT JOIN ".DB::table('forum_post')." b ON(a.tid=b.tid) WHERE a.tid='{$tid}' AND a.displayorder>=0 AND first=1";
		$res = DB::fetch_first($sql);
		return $res;
	}
	
	public static function setstatus($table) {
		global $_G;
		if ($_G['adminid']!=1) exit('-1');
		$id = intval($_GET['opid']);
		$name = trim($_GET['name']);
		if ($id <1) {
			exit('-1');
		}
		$rs = DB::fetch_first("SELECT * FROM ".DB::table($table)." WHERE id=$id");
		if (isset($rs[$name])) {
			$value = $rs[$name] ? 0 : 1;
			DB::update($table, array($name=>$value), array('id'=>$id));
			echo $value;exit();
		}else {
			exit('-2');
		}
	}

	public static function setoption($table) {
		global $_G;
		if ($_G['adminid']!=1) exit('-1');
		$opid = intval($_GET['opid']);
		$name = trim($_GET['name']);
		$value= trim(lev_base::levdiconv($_GET['value']));
		DB::update($table, array($name=>$value), array('id'=>$opid));
		exit('1');
	}
	
	public static function deldata($table) {
		$insql = lev_base::sqlinstr($_GET['ids']);
		if ($insql) {
			DB::query("DELETE FROM ".DB::table($table)." WHERE `id` IN ({$insql})");
		}
	}
	
	public static function levpages($table, $where = '', $limit = 20, $start = 0, $url = '', $feilds = '*', $nopage = 0) {
		if (!$url) $url = lev_base::$PLURL;

		$where = $table ? DB::table($table).' WHERE '.$where : $where ;
		$page  = $nopage ? 1 : max(intval($_GET['page']), 1);
		$total = DB::result_first("SELECT COUNT(*) FROM ".$where);
		$start = ($page - 1) * $limit + $start;
		$sql   = "SELECT ".$feilds." FROM ".$where." ".DB::limit($start, $limit);
		$lists = DB::fetch_all($sql);//print_r($lists);
		$pages = multi($total, $limit, $page, $url);//print_r($pages);
		$infos = array('pages'=>$pages, 'lists'=>$lists, 'total'=>$total);

		return $infos;
	}

	public static function citys() {
		$citys = DB::fetch_all("SELECT * FROM ".DB::table('common_district'), array(), 'id');
		return $citys;
	}
	public static function mycity($id, $all = false) {
		static $citys;
		if (empty($citys)) {
			$citys = self::citys();
		}
		if ($all) {
			$mycity = self::allmycity($citys, $id);
		}else {
			$mycity = $citys[$id]['name'];
		}
		return $mycity;
	}
	public static function allmycity($citys, $id, $mycity = '') {
		$mycity = $mycity ? $citys[$id]['name'].' &raquo; '.$mycity : $citys[$id]['name'];
		if ($citys[$id]['upid']) {
			return self::allmycity($citys, $citys[$id]['upid'], $mycity);
		}else {
			return $mycity;
		}
	}
	
}








