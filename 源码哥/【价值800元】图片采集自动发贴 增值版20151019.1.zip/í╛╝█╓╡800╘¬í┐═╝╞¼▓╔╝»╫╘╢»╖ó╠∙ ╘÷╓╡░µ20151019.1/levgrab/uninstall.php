<?php
/**
 *	Version: 1.0
 *	Date: 2013-8-16 22:44
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

EOF;

runquery($sql);
$finish = true;
?>