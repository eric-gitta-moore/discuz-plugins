<?php
/*
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
/**
 *	[¥������������(tianchai_hot.{modulename})] (C)2013-2099 Powered by ����.
 *	Version: 3.3
 *	Date: 2013-2-6 08:08
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_tianchai_hot {

}


class plugin_tianchai_hot_forum extends plugin_tianchai_hot {
		

		function viewthread_postbottom_output(){

			global $_G;
			if($_G['cache']['plugin']['tianchai_hot']['position']!=1)
				return;

			$forums = (array)unserialize($_G['cache']['plugin']['tianchai_hot']['forumlist']);
			if (in_array($_G['forum']['fid'], $forums)) return ;
			
			$tid  = $_G['thread']['tid'];
			if (empty($tid)){
				return ;
			}

			$title1 = $_G['cache']['plugin']['tianchai_hot']['title1'];
			$title2 = $_G['cache']['plugin']['tianchai_hot']['title2'];
			$numori = $_G['cache']['plugin']['tianchai_hot']['num'] ? $_G['cache']['plugin']['tianchai_hot']['num'] : '5';
			$num = $numori * 2;
			$length = $_G['cache']['plugin']['tianchai_hot']['length'] ? $_G['cache']['plugin']['tianchai_hot']['length'] : '40';
			$authorid = $_G['thread']['authorid'];
				
			if($_G['cache']['plugin']['tianchai_hot']['anonymous'])
			{
				$where= "`tid`=$tid and `first`=1 and `invisible`=0 ";
				$sql = "SELECT `anonymous` FROM ".DB::table('forum_post')." WHERE  $where";
				$query = DB::fetch_first($sql);

				if($query['anonymous'])
					return ;
			}
			
			/*
			if($_G['cache']['plugin']['tianchai_hot']['secret'])
			{
				$count_1 = DB::query("select count(fid) from ".DB::table('forum_forum'));
				$count_2 = DB::fetch($count_1);
				$count = $count_2['count(fid)'];
				$count = $count-1;

				$where= "a.status=1 and b.password=''";
				$sql = "SELECT a.fid, a.name, b.viewperm FROM ".DB::table('forum_forum')." a inner join ".DB::table('forum_forumfield')." b on a.fid = b.fid WHERE  $where  ORDER BY a.fid asc LIMIT 0,$count";
				
				$query = DB::query($sql);

				$forum_list = array();
				while($t_row = DB::fetch($query)){
					
					$t_row['viewperm'] = $t_row['viewperm']."\t"; 

					$forum_list[] = $t_row;
				}
			}
			*/

			
			$new_list = array();
			$sortway1 = "`dateline`";
			if($_G['cache']['plugin']['tianchai_hot']['anonymous'])
			{
				$where= DB::table('forum_thread').".`authorid`=".$authorid." and ".DB::table('forum_thread').".`tid`!=".$tid." and ".DB::table('forum_post').".`anonymous`=0 and ".DB::table('forum_post').".`invisible`=0 and ".DB::table('forum_post').".`first`=1 ";
				
				$sql = "SELECT ".DB::table('forum_thread').".`tid`, ".DB::table('forum_thread').".`subject`,".DB::table('forum_thread').".`fid` FROM ".DB::table('forum_thread')." inner join ".DB::table('forum_post')." on ".DB::table('forum_thread').".tid = ".DB::table('forum_post').".tid WHERE  $where  ORDER BY ".DB::table('forum_thread').".".$sortway1." DESC LIMIT 0,".$num;
				
				$query = DB::query($sql);
			}
			else
			{
				$where= " `authorid`=".$authorid." and `tid`!=".$tid." and displayorder>=0 ";
				$query = DB::query("SELECT `tid`, `subject`, `fid` FROM ".DB::table('forum_thread')." WHERE  $where  ORDER BY ".$sortway1." DESC LIMIT 0,".$num);
			}
			
			$my_count = 0;
			while($t_row = DB::fetch($query)){

				if (in_array($t_row['fid'], $forums)) continue;
				$t_row['subject'] = strip_tags(cutstr($t_row['subject'],$length, '...')); 
			
				/*
				if($_G['cache']['plugin']['tianchai_hot']['secret'])
				{
					$fid = $t_row['fid'];
					
					$flag=0;
					foreach($forum_list as $forum_row )
					{
						if($forum_row['fid']==$fid)
						{
							$flag=1; $forum_name=$forum_row['name']2013-1-24; $forum_viewperm=$forum_row['viewperm']; break;
						}
					}
					
					if( $flag ) 
					{
						
						if($forum_viewperm!="\t" && strpos( $forum_viewperm, "\t".$_G['groupid']."\t" )==FALSE )
							continue;	
					}
					else
						continue;
				}
				*/
				
				$new_list[] = $t_row;

				$my_count = $my_count + 1;
				if($my_count==$numori)
					break;
			}
			
			$hot_list = array();
			$rank = $_G['cache']['plugin']['tianchai_hot']['sortway'];
			if($rank==1) $sortway2="`views`";
			else if($rank==2) $sortway2="replies";
			else if($rank==3) $sortway2="recommends";
			else if($rank==4) $sortway2="heats";
			else $sortway2="`views`";
		
			$now = time();
			$interval = $_G['cache']['plugin']['tianchai_hot']['interval'];
			if($interval==1) $time_interval = $now-86400;
			else if($interval==2) $time_interval = $now-172800;
			else if($interval==3) $time_interval = $now-259200;
			else if($interval==4) $time_interval = $now-604800;
			else if($interval==5) $time_interval = $now-1209600;
			else if($interval==6) $time_interval = $now-2592000;
			else if($interval==7) $time_interval = $now-7776000;
			else if($interval==8) $time_interval = $now-15552000;
			else if($interval==9) $time_interval = $now-31104000;
			else if($interval==10) $time_interval = 0;
			else $time_interval = 0;

			if($_G['cache']['plugin']['tianchai_hot']['anonymous'])
			{
				$where= DB::table('forum_thread').".`authorid`=".$authorid." and ".DB::table('forum_thread').".`tid`!=".$tid." and ".DB::table('forum_post').".`anonymous`=0 and ".DB::table('forum_post').".`invisible`=0 and ".DB::table('forum_post').".`first`=1 and ".DB::table('forum_thread').".`dateline`>=$time_interval ";
				
				$sql = "SELECT ".DB::table('forum_thread').".`tid`, ".DB::table('forum_thread').".`subject`,".DB::table('forum_thread').".`fid` FROM ".DB::table('forum_thread')." inner join ".DB::table('forum_post')." on ".DB::table('forum_thread').".tid = ".DB::table('forum_post').".tid WHERE  $where  ORDER BY ".DB::table('forum_thread').".".$sortway2." DESC LIMIT 0,".$num;
				
				$query = DB::query($sql);
			}
			else
			{
				$where= " `authorid`=".$authorid." and `tid`!=".$tid." and `dateline`>=$time_interval and displayorder>=0 ";
				$query = DB::query("SELECT `tid`, `subject`, `fid` FROM ".DB::table('forum_thread')." WHERE  $where  ORDER BY ".$sortway2." DESC LIMIT 0,".$num);
			}
			$my_count=0;
			while($t_row = DB::fetch($query)){
				
				if (in_array($t_row['fid'], $forums)) continue;
				$t_row['subject'] = strip_tags(cutstr($t_row['subject'],$length, '...')); 
				
				/*
				if($_G['cache']['plugin']['tianchai_hot']['secret'])
				{
					$fid = $t_row['fid'];
					
					$flag=0;
					foreach($forum_list as $forum_row )
					{
						if($forum_row['fid']==$fid)
						{
							$flag=1; $forum_name=$forum_row['name']; $forum_viewperm=$forum_row['viewperm']; break;
						}
					}
					
					if( $flag ) 
					{
						
						if($forum_viewperm!="\t" && strpos( $forum_viewperm, "\t".$_G['groupid']."\t" )==FALSE ) 
							continue;	
					}
					else
						continue;
				}
				*/
				
				
				$hot_list[] = $t_row;

				$my_count = $my_count + 1;
				if($my_count==$numori)
					break;
			}

			if(!$hot_list || !$new_list)
				return;

			$titlecolor = $_G['cache']['plugin']['tianchai_hot']['titlecolor'] ? $_G['cache']['plugin']['tianchai_hot']['titlecolor'] : "#484848";
			$threadcolor = $_G['cache']['plugin']['tianchai_hot']['threadcolor'] ? $_G['cache']['plugin']['tianchai_hot']['threadcolor'] : "#0088CC";

			$style = $interval = $_G['cache']['plugin']['tianchai_hot']['style'];
			$nomore = $_G['cache']['plugin']['tianchai_hot']['nomore'];
			if($style==1)
				include template('tianchai_hot:list1');
			else if($style==2)
				include template('tianchai_hot:list2');
			else if($style==3)
				include template('tianchai_hot:list3');
			else if($style==4)
				include template('tianchai_hot:list4');
			else if($style==5)
				include template('tianchai_hot:list5');
			else
				include template('tianchai_hot:list1');
			


			//return $list;		
			if( $_G['cache']['plugin']['tianchai_hot']['onlyfirst'] )
			{
				$a_list = array();
				$a_list[0] =  $list;
				return $a_list;
			}
			else
			{
				$b_list = array();
				if(!empty($_G['forum_firstpid'])) $b_list[0] =  $list;//����¥����
					else  $b_list=array();
				return $b_list;		
			}
		}


		function viewthread_modaction(){


			global $_G;
			if($_G['cache']['plugin']['tianchai_hot']['position']!=2)
				return;

		
			$forums = (array)unserialize($_G['cache']['plugin']['tianchai_hot']['forumlist']);
			if (in_array($_G['forum']['fid'], $forums)) return ;
			
			$tid  = $_G['thread']['tid'];
			if (empty($tid)){
				return ;
			}

			$title1 = $_G['cache']['plugin']['tianchai_hot']['title1'];
			$title2 = $_G['cache']['plugin']['tianchai_hot']['title2'];
			$numori = $_G['cache']['plugin']['tianchai_hot']['num'] ? $_G['cache']['plugin']['tianchai_hot']['num'] : '5';
			$num = $numori * 2;
			$length = $_G['cache']['plugin']['tianchai_hot']['length'] ? $_G['cache']['plugin']['tianchai_hot']['length'] : '40';
			$authorid = $_G['thread']['authorid'];
				
			if($_G['cache']['plugin']['tianchai_hot']['anonymous'])
			{
				$where= "`tid`=$tid and `first`=1 and `invisible`=0 ";
				$sql = "SELECT `anonymous` FROM ".DB::table('forum_post')." WHERE  $where";
				$query = DB::fetch_first($sql);

				if($query['anonymous'])
					return ;
			}
			
			/*
			if($_G['cache']['plugin']['tianchai_hot']['secret'])
			{
				$count_1 = DB::query("select count(fid) from ".DB::table('forum_forum'));
				$count_2 = DB::fetch($count_1);
				$count = $count_2['count(fid)'];
				$count = $count-1;

				$where= "a.status=1 and b.password=''";
				$sql = "SELECT a.fid, a.name, b.viewperm FROM ".DB::table('forum_forum')." a inner join ".DB::table('forum_forumfield')." b on a.fid = b.fid WHERE  $where  ORDER BY a.fid asc LIMIT 0,$count";
				
				$query = DB::query($sql);

				$forum_list = array();
				while($t_row = DB::fetch($query)){
					
					$t_row['viewperm'] = $t_row['viewperm']."\t"; 

					$forum_list[] = $t_row;
				}
			}
			*/

			
			$new_list = array();
			$sortway1 = "`dateline`";
			if($_G['cache']['plugin']['tianchai_hot']['anonymous'])
			{
				$where= DB::table('forum_thread').".`authorid`=".$authorid." and ".DB::table('forum_thread').".`tid`!=".$tid." and ".DB::table('forum_post').".`anonymous`=0 and ".DB::table('forum_post').".`invisible`=0 and ".DB::table('forum_post').".`first`=1 ";
				
				$sql = "SELECT ".DB::table('forum_thread').".`tid`, ".DB::table('forum_thread').".`subject`,".DB::table('forum_thread').".`fid` FROM ".DB::table('forum_thread')." inner join ".DB::table('forum_post')." on ".DB::table('forum_thread').".tid = ".DB::table('forum_post').".tid WHERE  $where  ORDER BY ".DB::table('forum_thread').".".$sortway1." DESC LIMIT 0,".$num;
				
				$query = DB::query($sql);
			}
			else
			{
				$where= " `authorid`=".$authorid." and `tid`!=".$tid." and displayorder>=0 ";
				$query = DB::query("SELECT `tid`, `subject`, `fid` FROM ".DB::table('forum_thread')." WHERE  $where  ORDER BY ".$sortway1." DESC LIMIT 0,".$num);
			}
			
			$my_count = 0;
			while($t_row = DB::fetch($query)){
				
				if (in_array($t_row['fid'], $forums)) continue;
				$t_row['subject'] = strip_tags(cutstr($t_row['subject'],$length, '...')); 
			
				/*
				if($_G['cache']['plugin']['tianchai_hot']['secret'])
				{
					$fid = $t_row['fid'];
					
					$flag=0;
					foreach($forum_list as $forum_row )
					{
						if($forum_row['fid']==$fid)
						{
							$flag=1; $forum_name=$forum_row['name']2013-1-24; $forum_viewperm=$forum_row['viewperm']; break;
						}
					}
					
					if( $flag ) 
					{
						
						if($forum_viewperm!="\t" && strpos( $forum_viewperm, "\t".$_G['groupid']."\t" )==FALSE )
							continue;	
					}
					else
						continue;
				}
				*/
				
				$new_list[] = $t_row;

				$my_count = $my_count + 1;
				if($my_count==$numori)
					break;
			}
			
			$hot_list = array();
			$rank = $_G['cache']['plugin']['tianchai_hot']['sortway'];
			if($rank==1) $sortway2="`views`";
			else if($rank==2) $sortway2="replies";
			else if($rank==3) $sortway2="recommends";
	        else if($rank==4) $sortway2="heats";
	        else $sortway2="`views`";
		
			$now = time();
			$interval = $_G['cache']['plugin']['tianchai_hot']['interval'];
			if($interval==1) $time_interval = $now-86400;
			else if($interval==2) $time_interval = $now-172800;
			else if($interval==3) $time_interval = $now-259200;
	        else if($interval==4) $time_interval = $now-604800;
			else if($interval==5) $time_interval = $now-1209600;
			else if($interval==6) $time_interval = $now-2592000;
			else if($interval==7) $time_interval = $now-7776000;
			else if($interval==8) $time_interval = $now-15552000;
			else if($interval==9) $time_interval = $now-31104000;
			else if($interval==10) $time_interval = 0;
	        else $time_interval = 0;

			if($_G['cache']['plugin']['tianchai_hot']['anonymous'])
			{
				$where= DB::table('forum_thread').".`authorid`=".$authorid." and ".DB::table('forum_thread').".`tid`!=".$tid." and ".DB::table('forum_post').".`anonymous`=0 and ".DB::table('forum_post').".`invisible`=0 and ".DB::table('forum_post').".`first`=1 and ".DB::table('forum_thread').".`dateline`>=$time_interval ";
				
				$sql = "SELECT ".DB::table('forum_thread').".`tid`, ".DB::table('forum_thread').".`subject`,".DB::table('forum_thread').".`fid` FROM ".DB::table('forum_thread')." inner join ".DB::table('forum_post')." on ".DB::table('forum_thread').".tid = ".DB::table('forum_post').".tid WHERE  $where  ORDER BY ".DB::table('forum_thread').".".$sortway2." DESC LIMIT 0,".$num;
				
				$query = DB::query($sql);
			}
			else
			{
				$where= " `authorid`=".$authorid." and `tid`!=".$tid." and `dateline`>=$time_interval and displayorder>=0 ";
				$query = DB::query("SELECT `tid`, `subject`, `fid` FROM ".DB::table('forum_thread')." WHERE  $where  ORDER BY ".$sortway2." DESC LIMIT 0,".$num);
			}
			$my_count=0;
			while($t_row = DB::fetch($query)){
				
				if (in_array($t_row['fid'], $forums)) continue;
				$t_row['subject'] = strip_tags(cutstr($t_row['subject'],$length, '...')); 
				
				/*
				if($_G['cache']['plugin']['tianchai_hot']['secret'])
				{
					$fid = $t_row['fid'];
					
					$flag=0;
					foreach($forum_list as $forum_row )
					{
						if($forum_row['fid']==$fid)
						{
							$flag=1; $forum_name=$forum_row['name']; $forum_viewperm=$forum_row['viewperm']; break;
						}
					}
					
					if( $flag ) 
					{
						
						if($forum_viewperm!="\t" && strpos( $forum_viewperm, "\t".$_G['groupid']."\t" )==FALSE ) 
							continue;	
					}
					else
						continue;
				}
				*/
				
				
				$hot_list[] = $t_row;

				$my_count = $my_count + 1;
				if($my_count==$numori)
					break;
			}

			if(!$hot_list || !$new_list)
				return;

			$titlecolor = $_G['cache']['plugin']['tianchai_hot']['titlecolor'] ? $_G['cache']['plugin']['tianchai_hot']['titlecolor'] : "#484848";
			$threadcolor = $_G['cache']['plugin']['tianchai_hot']['threadcolor'] ? $_G['cache']['plugin']['tianchai_hot']['threadcolor'] : "#0088CC";

			$style = $interval = $_G['cache']['plugin']['tianchai_hot']['style'];
			$nomore = $_G['cache']['plugin']['tianchai_hot']['nomore'];
			if($style==1)
				include template('tianchai_hot:list1');
			else if($style==2)
				include template('tianchai_hot:list2');
			else if($style==3)
				include template('tianchai_hot:list3');
			else if($style==4)
				include template('tianchai_hot:list4');
			else if($style==5)
				include template('tianchai_hot:list5');
			else
				include template('tianchai_hot:list1');
			

			return $list;	
		}

	  	function viewthread_postsightmlafter_output(){
			
			global $_G;
			if($_G['cache']['plugin']['tianchai_hot']['position']!=3)
				return;
		
			$forums = (array)unserialize($_G['cache']['plugin']['tianchai_hot']['forumlist']);
			if (in_array($_G['forum']['fid'], $forums)) return ;
			
			$tid  = $_G['thread']['tid'];
			if (empty($tid)){
				return ;
			}

			$title1 = $_G['cache']['plugin']['tianchai_hot']['title1'];
			$title2 = $_G['cache']['plugin']['tianchai_hot']['title2'];
			$numori = $_G['cache']['plugin']['tianchai_hot']['num'] ? $_G['cache']['plugin']['tianchai_hot']['num'] : '5';
			$num = $numori * 2;
			$length = $_G['cache']['plugin']['tianchai_hot']['length'] ? $_G['cache']['plugin']['tianchai_hot']['length'] : '40';
			$authorid = $_G['thread']['authorid'];
				
			if($_G['cache']['plugin']['tianchai_hot']['anonymous'])
			{
				$where= "`tid`=$tid and `first`=1 and `invisible`=0 ";
				$sql = "SELECT `anonymous` FROM ".DB::table('forum_post')." WHERE  $where";
				$query = DB::fetch_first($sql);

				if($query['anonymous'])
					return ;
			}
			
			/*
			if($_G['cache']['plugin']['tianchai_hot']['secret'])
			{
				$count_1 = DB::query("select count(fid) from ".DB::table('forum_forum'));
				$count_2 = DB::fetch($count_1);
				$count = $count_2['count(fid)'];
				$count = $count-1;

				$where= "a.status=1 and b.password=''";
				$sql = "SELECT a.fid, a.name, b.viewperm FROM ".DB::table('forum_forum')." a inner join ".DB::table('forum_forumfield')." b on a.fid = b.fid WHERE  $where  ORDER BY a.fid asc LIMIT 0,$count";
				
				$query = DB::query($sql);

				$forum_list = array();
				while($t_row = DB::fetch($query)){
					
					$t_row['viewperm'] = $t_row['viewperm']."\t"; 

					$forum_list[] = $t_row;
				}
			}
			*/

			
			$new_list = array();
			$sortway1 = "`dateline`";
			if($_G['cache']['plugin']['tianchai_hot']['anonymous'])
			{
				$where= DB::table('forum_thread').".`authorid`=".$authorid." and ".DB::table('forum_thread').".`tid`!=".$tid." and ".DB::table('forum_post').".`anonymous`=0 and ".DB::table('forum_post').".`invisible`=0 and ".DB::table('forum_post').".`first`=1 ";
				
				$sql = "SELECT ".DB::table('forum_thread').".`tid`, ".DB::table('forum_thread').".`subject`,".DB::table('forum_thread').".`fid` FROM ".DB::table('forum_thread')." inner join ".DB::table('forum_post')." on ".DB::table('forum_thread').".tid = ".DB::table('forum_post').".tid WHERE  $where  ORDER BY ".DB::table('forum_thread').".".$sortway1." DESC LIMIT 0,".$num;
				
				$query = DB::query($sql);
			}
			else
			{
				$where= " `authorid`=".$authorid." and `tid`!=".$tid." and displayorder>=0 ";
				$query = DB::query("SELECT `tid`, `subject`, `fid` FROM ".DB::table('forum_thread')." WHERE  $where  ORDER BY ".$sortway1." DESC LIMIT 0,".$num);
			}
			
			$my_count = 0;
			while($t_row = DB::fetch($query)){
				
				if (in_array($t_row['fid'], $forums)) continue;
				$t_row['subject'] = strip_tags(cutstr($t_row['subject'],$length, '...')); 
			
				/*
				if($_G['cache']['plugin']['tianchai_hot']['secret'])
				{
					$fid = $t_row['fid'];
					
					$flag=0;
					foreach($forum_list as $forum_row )
					{
						if($forum_row['fid']==$fid)
						{
							$flag=1; $forum_name=$forum_row['name']2013-1-24; $forum_viewperm=$forum_row['viewperm']; break;
						}
					}
					
					if( $flag ) 
					{
						
						if($forum_viewperm!="\t" && strpos( $forum_viewperm, "\t".$_G['groupid']."\t" )==FALSE )
							continue;	
					}
					else
						continue;
				}
				*/
				
				$new_list[] = $t_row;

				$my_count = $my_count + 1;
				if($my_count==$numori)
					break;
			}
			
			$hot_list = array();
			$rank = $_G['cache']['plugin']['tianchai_hot']['sortway'];
			if($rank==1) $sortway2="`views`";
			else if($rank==2) $sortway2="replies";
			else if($rank==3) $sortway2="recommends";
	        else if($rank==4) $sortway2="heats";
	        else $sortway2="`views`";
		
			$now = time();
			$interval = $_G['cache']['plugin']['tianchai_hot']['interval'];
			if($interval==1) $time_interval = $now-86400;
			else if($interval==2) $time_interval = $now-172800;
			else if($interval==3) $time_interval = $now-259200;
	        else if($interval==4) $time_interval = $now-604800;
			else if($interval==5) $time_interval = $now-1209600;
			else if($interval==6) $time_interval = $now-2592000;
			else if($interval==7) $time_interval = $now-7776000;
			else if($interval==8) $time_interval = $now-15552000;
			else if($interval==9) $time_interval = $now-31104000;
			else if($interval==10) $time_interval = 0;
	        else $time_interval = 0;

			if($_G['cache']['plugin']['tianchai_hot']['anonymous'])
			{
				$where= DB::table('forum_thread').".`authorid`=".$authorid." and ".DB::table('forum_thread').".`tid`!=".$tid." and ".DB::table('forum_post').".`anonymous`=0 and ".DB::table('forum_post').".`invisible`=0 and ".DB::table('forum_post').".`first`=1 and ".DB::table('forum_thread').".`dateline`>=$time_interval ";
				
				$sql = "SELECT ".DB::table('forum_thread').".`tid`, ".DB::table('forum_thread').".`subject`,".DB::table('forum_thread').".`fid` FROM ".DB::table('forum_thread')." inner join ".DB::table('forum_post')." on ".DB::table('forum_thread').".tid = ".DB::table('forum_post').".tid WHERE  $where  ORDER BY ".DB::table('forum_thread').".".$sortway2." DESC LIMIT 0,".$num;
				
				$query = DB::query($sql);
			}
			else
			{
				$where= " `authorid`=".$authorid." and `tid`!=".$tid." and `dateline`>=$time_interval and displayorder>=0 ";
				$query = DB::query("SELECT `tid`, `subject`, `fid` FROM ".DB::table('forum_thread')." WHERE  $where  ORDER BY ".$sortway2." DESC LIMIT 0,".$num);
			}
			$my_count=0;
			while($t_row = DB::fetch($query)){
				
				if (in_array($t_row['fid'], $forums)) continue;
				$t_row['subject'] = strip_tags(cutstr($t_row['subject'],$length, '...')); 
				
				/*
				if($_G['cache']['plugin']['tianchai_hot']['secret'])
				{
					$fid = $t_row['fid'];
					
					$flag=0;
					foreach($forum_list as $forum_row )
					{
						if($forum_row['fid']==$fid)
						{
							$flag=1; $forum_name=$forum_row['name']; $forum_viewperm=$forum_row['viewperm']; break;
						}
					}
					
					if( $flag ) 
					{
						
						if($forum_viewperm!="\t" && strpos( $forum_viewperm, "\t".$_G['groupid']."\t" )==FALSE ) 
							continue;	
					}
					else
						continue;
				}
				*/
				
				
				$hot_list[] = $t_row;

				$my_count = $my_count + 1;
				if($my_count==$numori)
					break;
			}

			if(!$hot_list || !$new_list)
				return;

			$titlecolor = $_G['cache']['plugin']['tianchai_hot']['titlecolor'] ? $_G['cache']['plugin']['tianchai_hot']['titlecolor'] : "#484848";
			$threadcolor = $_G['cache']['plugin']['tianchai_hot']['threadcolor'] ? $_G['cache']['plugin']['tianchai_hot']['threadcolor'] : "#0088CC";

			$style = $interval = $_G['cache']['plugin']['tianchai_hot']['style'];
			$nomore = $_G['cache']['plugin']['tianchai_hot']['nomore'];
			if($style==1)
				include template('tianchai_hot:list1');
			else if($style==2)
				include template('tianchai_hot:list2');
			else if($style==3)
				include template('tianchai_hot:list3');
			else if($style==4)
				include template('tianchai_hot:list4');
			else if($style==5)
				include template('tianchai_hot:list5');
			else
				include template('tianchai_hot:list1');
			

			//return $list;		
			if( $_G['cache']['plugin']['tianchai_hot']['onlyfirst'] )
			{
				$a_list = array();
				$a_list[0] =  $list;
				return $a_list;
			}
			else
			{
				$b_list = array();
				if(!empty($_G['forum_firstpid'])) $b_list[0] =  $list;//����¥����
					else  $b_list=array();
				return $b_list;		
			}
		}

}
?>