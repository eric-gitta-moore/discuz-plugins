<?php echo 'UCNET DESIGN - UCX1 // QQ:97509752 // COPYRIGHT (c) 2016 ��ҵģ�屣���У��뵽�����Ϲ�������ģ�壡';exit;?>
<div class="uc-user">
<!--{template common/pubsearchform}-->
<!--{if $_G['uid']}-->
<div class="uc-user-menu">
	<div class="uc-item uc-message" id="ucheader_pm">
		<a href="home.php?mod=space&do=pm" title="˽��" id="ucheader_pm_tit"><i class="ico-message ico-white ico-gray"></i></a>
		<div class="uc-box">
			<div class="uc-tit">˽��</div>
			<div class="uc-con">
				<ul id="ucheader_pm_con">
					<!--{eval $headpmlistnew = 0;}-->
					<!--{eval $headpmlist = DB::fetch_all("SELECT * FROM " .DB::table('ucenter_pm_members'). " m LEFT JOIN " .DB::table('ucenter_pm_lists'). " t ON m.plid=t.plid WHERE m.uid=".$_G['uid']." ORDER BY m.lastdateline DESC LIMIT 10");}-->
					<!--{loop $headpmlist $key $value}-->
						<!--{eval $users = explode('_', $value['min_max']);}-->
						<!--{if $users[1] == $_G['uid']}-->
							<!--{eval $touid = $users[0];}-->
						<!--{else}-->
							<!--{eval $touid = $users[1];}-->
						<!--{/if}-->
						<!--{eval $c = unserialize($value[lastmessage]); $userinfo = getuserbyuid($touid); $tousername = $userinfo['username'];}-->
						<li id="ucheader_pm_{$value[plid]}">
							<a class="uc-li-avatar" target="_blank" title="{$tousername}" href="home.php?mod=space&uid=$touid">
								<!--{avatar($touid,small)}-->
							</a>
							<div>
								<div>
									<!--{if $c['lastauthorid'] == $_G['uid']}-->
										���� <a class="uc-li-name" target="_blank" title="{$tousername}" href="home.php?mod=space&uid=$touid">{$tousername}</a> ˵
									<!--{else}-->
										<a class="uc-li-name" target="_blank" title="{$tousername}" href="home.php?mod=space&uid=$touid">{$tousername}</a> ����˵
									<!--{/if}-->
									<!--{if $value['isnew']>0}--><i class="dot" id="ucheader_pm_{$value[plid]}_dot"></i><!--{/if}-->
									<span class="uc-li-date" style="margin-left:10px"><!--{date($value[lastdateline], 'u')}--></span>
									<p>{$c[lastsummary]}</p>
									<a class="uc-li-more" href="javascript:void(0)" onClick="_ucChangeNotiStatus('message',{'method':'click','id':$value[plid],'touid':$touid});">�鿴</a>
								</div>
								<div class="clear"></div>
							</div>
						</li>
					<!--{/loop}-->
				</ul>
			</div>
			<a href="home.php?mod=space&do=pm" class="uc-more">�鿴ȫ����Ϣ</a>
		</div>

	</div>
	<div class="uc-item uc-notice">
		<a href="home.php?mod=space&do=notice&view=mypost" title="��Ϣ" id="ucheader_notice_tit"><i class="ico-notice ico-white ico-gray"></i></a>
		<div class="uc-box uc-tabs">
			<div class="uc-tit hd">
				<ul>
					<!--{eval $headnoterelpylist = DB::fetch_all("SELECT * FROM " .DB::table('home_notification'). " WHERE uid=".$_G['uid']." AND new=1 AND note LIKE '%�ظ�����������%' ORDER BY dateline DESC");}-->
					<!--{eval $headnoterelpylist2 = DB::fetch_all("SELECT * FROM " .DB::table('home_notification'). " WHERE uid=".$_G['uid']." AND new=1 AND note NOT LIKE '%�ظ�����������%' ORDER BY dateline DESC");}-->
					<li id="ucheader_replys_tit" onClick="$('ucheader_replys_tit').className='on';$('ucheader_system_tit').className='';$('ucheader_replys_list').style.display='';$('ucheader_system_list').style.display='none';" class="on">
						<a href="javascript:void(0)" id="ucheader_replys_tit_a">���»ظ�</a>
					</li>
					<li id="ucheader_system_tit" onClick="$('ucheader_replys_tit').className='';$('ucheader_system_tit').className='on';$('ucheader_replys_list').style.display='none';$('ucheader_system_list').style.display='';">
						<a href="javascript:void(0)" id="ucheader_system_tit_a">ϵͳ��Ϣ</a>
					</li>
				</ul>
			</div>
			<div class="uc-con bd" id="ucheader_notice_con">
				<div id="ucheader_replys_list">
					<ul>
						<!--{eval $replys_ids = ''}-->
						<!--{loop $headnoterelpylist $key $value}-->
						<!--{eval preg_match_all("/<a[^<>]*href=\"([^\"]+)\"[^<>]*>([^<>]+)<\/a>/i", $value[note], $matches);}-->
						<li id="ucheader_replys_{$value[id]}">
							<!--{if $value[authorid]}-->
							<a class="uc-li-avatar" target="_blank" title="{$value[author]}" href="home.php?mod=space&uid={$value[authorid]}">
								<!--{avatar($value[authorid],small)}-->
							</a>
							<!--{else}-->
							<a class="uc-li-avatar" title="ϵͳ����Ա" href="javascript:void(0)">
								<img src="{IMGDIR}/systempm.png" alt="systempm" />
							</a>
							<!--{/if}-->
							<div>
									<div>
									<!--{if $value[authorid] && $value[authorid] !=1 }-->
									<a class="uc-li-name" target="_blank" title="{$value[author]}" href="home.php?mod=space&uid={$value[authorid]}">{$value[author]}</a> �ظ�����������
									<!--{else}-->
									<a class="uc-li-name" target="_blank" title="{$value[author]}" href="javascript:void(0)">{$value[author]}</a> �ظ�����������
									<!--{/if}-->
									<!--{if $value['new']>0}--><!--{eval $replys_ids .= $value[id].','}--><i class="dot" id="ucheader_notice_{$value[id]}_dot"></i><!--{/if}-->
									<span class="uc-li-date" style="margin-left:10px"><!--{date($value[dateline], 'u')}--></span>
									<p>{$matches[0][1]}</p>
									<a class="uc-li-more" href="javascript:void(0)" onClick="_ucChangeNotiStatus('replys',{'method':'click','id':'$value[id]','url':'{$matches[1][1]}'});">�鿴</a>
									</div>
								<div class="clear"></div>
							</div>
						</li>
						<!--{/loop}-->
					</ul>
					<div class="uc-more cl">
						<a href="home.php?mod=space&do=notice&view=mypost">�鿴ȫ��</a>
						<a href="javascript:void(0)" class="y" style="display:none" id="ucheader_replys_btn">����ȫ��</a>
					</div>
				</div>
				<div id="ucheader_system_list" style="display:none;">
					<ul>
						<!--{eval $system_ids = ''}-->
						<!--{loop $headnoterelpylist2 $key $value}-->
						<!--{eval preg_match_all("/<a[^<>]*href=\"([^\"]+)\"[^<>]*>([^<>]+)<\/a>/i", $value[note], $matches);}-->
						<li id="ucheader_system_{$value[id]}">
							<a class="uc-li-avatar" title="ϵͳ����Ա" href="javascript:void(0)">
								<img src="{IMGDIR}/systempm.png" alt="systempm" />
							</a>
							<div>
								<div>
									<a class="uc-li-name" target="_blank" title="{$value[author]}" href="javascript:void(0)">ϵͳ����Ա</a>
									<!--{if $value['new']>0}--><!--{eval $system_ids .= $value[id].','}--><i class="dot" id="ucheader_notice_{$value[id]}_dot"></i><!--{/if}-->
									<span class="uc-li-date" style="margin-left:10px"><!--{date($value[dateline], 'u')}--></span>
									<p>{$value[note]}</p>
									<a class="uc-li-more" href="javascript:void(0)" onClick="_ucChangeNotiStatus('system',{'method':'click','id':'$value[id]','type':'$value['type']'});">�鿴</a>
								</div>
								<div class="clear"></div>
							</div>
						</li>
						<!--{/loop}-->
					</ul>
					<div class="uc-more cl">
						<a href="home.php?mod=space&do=notice&view=system">�鿴ȫ��</a>
						<a href="javascript:void(0)" class="y" style="display:none" id="ucheader_system_btn">����ȫ��</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="uc-item uc-upload">
		<a onclick="showWindow('nav', this.href, 'get', 0)" href="forum.php?mod=misc&amp;action=nav" title="������Ʒ"><i class="ico-upload ico-white ico-gray"></i></a>
		<!--{if count($uc['global'])>0}-->
		<div class="uc-box">
			<div class="uc-con">
				<dl>
					<!--{loop $uc['global']['fast_publish'] $item}-->
					<dd><a href="forum.php?mod=post&action=newthread&fid=$item['fid']">{$item['txt']}</a></dd>
					<!--{/loop}-->
				</dl>
			</div>
		</div>
		<!--{/if}-->
	</div>
	<div class="uc-item uc-qmenu">
		<a href="javascript:;" onMouseOver="showForummenu($_G[fid])" title="��ݵ���"><i class="ico-th-large ico-white ico-gray"></i></a>
		<div class="uc-box">
			<div class="uc-nav">
				<!--{hook/global_qmenu_top}-->
				<!--{if $_G['uid']}-->
					<ul class="cl nav">
						<!--{loop $_G['setting']['mynavs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->
								<li>$nav[code]</li>
							<!--{/if}-->
						<!--{/loop}-->
					</ul>
				<!--{elseif $_G[connectguest]}-->
					<div class="ptm pbw hm">
						{lang connect_fill_profile_to_visit}
					</div>
				<!--{else}-->
					<div class="ptm pbw hm">
						{lang my_nav_login}
					</div>
				<!--{/if}-->
				<!--{if $_G['setting']['showfjump']}--><div id="fjump_menu" class="btda"></div><!--{/if}-->
				<!--{hook/global_qmenu_bottom}-->
			</div>
		</div>
	</div>
	<div class="uc-item uc-avatar">
		<a href="home.php?mod=space&uid=$_G[uid]" title="{$_G[member][username]}"><!--{avatar($_G['uid'],small)}--></a>
		<div class="uc-box">
			<div class="uc-im">
				<div class="uc-im-top">
					<span class="z"><a href="home.php?mod=spacecp&ac=avatar"><!--{avatar($_G['uid'],small)}--><i>�޸�ͷ��</i></a></span>
					<div class="z">
						<p>
							<!--{if $_G['group']['allowinvisible']}-->
							<span id="loginstatus">
								<a id="loginstatusid" href="member.php?mod=switchstatus" title="{lang login_switch_invisible_mode}" onclick="ajaxget(this.href, 'loginstatus');return false;" class="xi2"></a>
							</span>
							<span><a href="home.php?mod=space&uid=$_G[uid]">��ҳ</a></span>
							<!--{/if}-->
							<span><a href="home.php?mod=spacecp">����</a></span>
							<span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">�˳�</a></span>
						</p>
						<p>
							<!--{hook/global_usernav_extra2}-->
							<!--{hook/global_usernav_extra3}-->
							<a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}:$_G[member][credits]</a>
							<a href="home.php?mod=spacecp&ac=usergroup">{lang usergroup}:$_G[group][grouptitle]</a>
						</p>
					</div>
				</div>
				<div class="uc-im-mid">
					<!--{hook/global_usernav_extra1}-->
					<!--{hook/global_usernav_extra4}-->
				</div>
				<!--{if ($_G['uid'] && $_G['group']['radminid'] > 1) || ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3)) || ($_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)) || (check_diy_perm($topic))}-->
				<div class="uc-im-bot">
					<!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
						<span><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></span>
					<!--{/if}-->
					<!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
						<span><a href="portal.php?mod=portalcp" target="_blank"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></span>
					<!--{/if}-->
					<!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
						<span><a href="admin.php" target="_blank">��������</a></span>
					<!--{if check_diy_perm($topic)}-->
						<span><a href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();">DIY�༭</a></span>
					<!--{/if}-->
					<!--{/if}-->
				</div>
				<!--{/if}-->
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">


	_ucChangeNotiStatus('load');
	function _ucChangeNotiStatus(o,v){
		var object = typeof(o)!=="undefined"?o:'';
		var method = typeof(v)!=="undefined"?(typeof(v['method'])!=="undefined"?v['method']:'load'):'load';
		if(object!==''){
			if(object=='load'){
				_ucChangeNotiStatus('message',{'method':'load'});
				_ucChangeNotiStatus('system',{'method':'load'});
				_ucChangeNotiStatus('replys',{'method':'load'});
				var wptit = $('ucheader_notice_tit');
				var wpcon = $('ucheader_notice_con');
				var wpmat = wpcon.innerHTML.match(/ucheader_notice_.*?_dot/g);
				var wplen = wpmat==null?0:wpmat.length;
				if(wplen>0){
					var wpel = document.createElement('em');
					wpel.id = 'ucheader_notice_num';
					wpel.innerHTML = wplen;
					wptit.appendChild(wpel);
				}
			}else if(object=='message'){
				var tit = $('ucheader_pm_tit');
				var con = $('ucheader_pm_con');
				var num = $('ucheader_pm_num');
				if(method=='load'){
					var mat = con.innerHTML.match(/ucheader_pm_.*?_dot/g);
					var len = mat==null?0:mat.length;
					if(len>0){
						var el = document.createElement('em');
						el.id = 'ucheader_pm_num';
						el.innerHTML = len;
						tit.appendChild(el);
					}
				}
				if(method=='click'){
					var id = v['id'];
					var touid=v['touid'];
					var el = document.createElement("a");
					document.body.appendChild(el);
					el.href = 'home.php?mod=space&do=pm&subop=view&touid='+touid+'#last';
					el.target = '_blank';
					el.click();
					document.body.removeChild(el);
					$('ucheader_pm_'+id+'_dot')?ajaxget('home.php?mod=spacecp&ac=pm&op=setpmstatus&plids='+id, '', 'ajaxwaitid', '', 'none', _ucChangeNotiStatus('message',{'method':'delete','id':id})):'';
				}
				if(method=='delete'){
					var id = v['id'];
					$('ucheader_pm_'+id+'_dot').parentNode.removeChild($('ucheader_pm_'+id+'_dot'));
					if(parseInt(num.innerHTML)-1<1){
						num.parentNode.removeChild(num);
					} else {
						num.innerHTML = parseInt(num.innerHTML)-1;
					}
				}
			}else{
				var wptit = $('ucheader_notice_tit');
				var wpcon = $('ucheader_notice_con');
				var wpnum = $('ucheader_notice_num');
				if(object=='system'){
					var tit = $('ucheader_system_tit_a');
					var con = $('ucheader_system_list');
					var btn = $('ucheader_system_btn');
					if(method=='load'){
						var mat = con.innerHTML.match(/ucheader_notice_.*?_dot/g);
						var len = mat==null?0:mat.length;
						if(len>0){
							var el = document.createElement('i');
							el.id = 'ucheader_system_tit_dot'
							el.className = 'dot';
							tit.appendChild(el);
							btn.setAttribute('onclick',"_ucChangeNotiStatus('system',{'method':'delete','type':'all','id':'{$system_ids}'})");
							btn.style.display = 'block';
							btn.parentNode.children[0].className='z';
						}
					}
					if(method=='click'){
						var id = v['id'];
						var type=v['type'];
						var el = document.createElement("a");
						document.body.appendChild(el);
						if(type=='system'){
							el.href = 'home.php?mod=space&do=notice&view=system';
						} else if(type=='follow'){
							el.href = 'home.php?mod=follow';
						} else if(type=='follower'){
							el.href = 'home.php?mod=follow&do=follower';
						} else if(type=='verifyuser'){
							el.href = 'admin.php?action=moderate&operation=members';
						} else if(type=='verifyrecycle'){
							el.href = 'admin.php?action=recyclebin';
						} else if(type=='friend'){
							el.href = 'home.php?mod=space&do=notice&view=interactive';
						} else if(type=='doing'){
							el.href = 'home.php?mod=space&do=notice&view=interactive';
						} else if(type=='sharenotice'){
							el.href = 'home.php?mod=space&do=notice&view=interactive';
						}
						el.target = '_blank';
						el.click();
						document.body.removeChild(el);
						$('ucheader_notice_'+id+'_dot')?ajaxget('forum.php?ucUpdateMessageType='+type+'&ucUpdateMessageID='+id, '', 'ajaxwaitid', '', 'none', _ucChangeNotiStatus('system',{'method':'delete','id':id})):'';
					}
					if(method=='delete'){
						var id = v['id'];
						var type = v['type'];
						if(type == 'all') {
							ajaxget('forum.php?ucUpdateMessageType=other&ucUpdateMessageID='+id, '', 'ajaxwaitid', '', 'none', function(){
								var ids = id.split(',');
								for(var i=0;i<ids.length;i++){
									if($('ucheader_notice_'+ids[i]+'_dot')){
										$('ucheader_notice_'+ids[i]+'_dot').parentNode.removeChild($('ucheader_notice_'+ids[i]+'_dot'));
									}
								}
								var smat = con.innerHTML.match(/ucheader_notice_.*?_dot/g);
								var slen = smat==null?0:smat.length;
								if(slen<=0){
									$('ucheader_system_tit_dot').parentNode.removeChild($('ucheader_system_tit_dot'));
								}
								var wpmat = wpcon.innerHTML.match(/ucheader_notice_.*?_dot/g);
								var wplen = wpmat==null?0:wpmat.length;
								if(wplen>0){
									wpnum.innerHTML = wplen;
								} else {
									wpnum.parentNode.removeChild(wpnum);
								}
							});
						} else {
							$('ucheader_notice_'+id+'_dot').parentNode.removeChild($('ucheader_notice_'+id+'_dot'));
							var smat = con.innerHTML.match(/ucheader_notice_.*?_dot/g);
							var slen = smat==null?0:smat.length;
							if(slen<=0){
								$('ucheader_system_tit_dot').parentNode.removeChild($('ucheader_system_tit_dot'));
							}
							if(parseInt(wpnum.innerHTML)-1<1){
								wpnum.parentNode.removeChild(wpnum);
							} else {
								wpnum.innerHTML = parseInt(wpnum.innerHTML)-1;
							}
						}
					}
				}else if(object=='replys'){
					var tit = $('ucheader_replys_tit_a');
					var con = $('ucheader_replys_list');
					var btn = $('ucheader_replys_btn');
					if(method=='load'){
						var mat = con.innerHTML.match(/ucheader_notice_.*?_dot/g);
						var len = mat==null?0:mat.length;
						if(len>0){
							var el = document.createElement('i');
							el.id = 'ucheader_replys_tit_dot'
							el.className = 'dot';
							tit.appendChild(el);
							btn.setAttribute('onclick',"_ucChangeNotiStatus('replys',{'method':'delete','type':'all','id':'{$replys_ids}'})");
							btn.style.display = 'block';
							btn.parentNode.children[0].className='z';
						}
					}
					if(method=='click'){
						var id = v['id'];
						var url=v['url'];
						var el = document.createElement("a");
						document.body.appendChild(el);
						el.href = url;
						el.target = '_blank';
						el.click();
						document.body.removeChild(el);
						$('ucheader_notice_'+id+'_dot')?ajaxget('forum.php?ucUpdateMessageType=post&ucUpdateMessageID='+id, '', 'ajaxwaitid', '', 'none', _ucChangeNotiStatus('replys',{'method':'delete','id':id})):'';
					}
					if(method=='delete'){
						var id = v['id'];
						var type = v['type'];
						if(type == 'all') {
							ajaxget('forum.php?ucUpdateMessageType=post&ucUpdateMessageID='+id, '', 'ajaxwaitid', '', 'none', function(){
								var ids = id.split(',');
								for(var i=0;i<ids.length;i++){
									if($('ucheader_notice_'+ids[i]+'_dot')){
										$('ucheader_notice_'+ids[i]+'_dot').parentNode.removeChild($('ucheader_notice_'+ids[i]+'_dot'));
									}
								}
								var smat = con.innerHTML.match(/ucheader_notice_.*?_dot/g);
								var slen = smat==null?0:smat.length;
								if(slen<=0){
									$('ucheader_replys_tit_dot').parentNode.removeChild($('ucheader_replys_tit_dot'));
								}
								var wpmat = wpcon.innerHTML.match(/ucheader_notice_.*?_dot/g);
								var wplen = wpmat==null?0:wpmat.length;
								if(wplen>0){
									wpnum.innerHTML = wplen;
								} else {
									wpnum.parentNode.removeChild(wpnum);
								}
							});
						} else {
							$('ucheader_notice_'+id+'_dot').parentNode.removeChild($('ucheader_notice_'+id+'_dot'));
							var smat = con.innerHTML.match(/ucheader_notice_.*?_dot/g);
							var slen = smat==null?0:smat.length;
							if(slen<=0){
								$('ucheader_replys_tit_dot').parentNode.removeChild($('ucheader_replys_tit_dot'));
							}
							if(parseInt(wpnum.innerHTML)-1<1){
								wpnum.parentNode.removeChild(wpnum);
							} else {
								wpnum.innerHTML = parseInt(wpnum.innerHTML)-1;
							}
						}
					}
				}
			}
		}
	}
</script>
<!--{elseif !empty($_G['cookie']['loginuser'])}-->
<p>
	<strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
</p>
<!--{elseif !$_G[connectguest]}-->
	<!--{template member/login_simple}-->
<!--{else}-->
<div class="uc-user-menu" id="um">
	<div class="uc-item uc-avatar">
		<a href="javascript:void(0)" title="{$_G[member][username]}"><!--{avatar(0,small)}--></a>
		<div class="uc-box">
			<div class="uc-con">
				<!--{hook/global_usernav_extra1}-->
				<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
			</div>
		</div>
	</div>
</div>
<!--{/if}-->
</div>