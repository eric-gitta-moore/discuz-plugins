<?php echo 'www.ymg6.com';exit;?>

<div class="uc-footer-top">

	<div class="wp cl">

		<a href="$_G['setting']['siteurl']" class="logo z">$_G['setting']['sitename']</a>

		<div id="frt" class="menu z">

			<div class="uc-menu-item">

					<h2>Ƶ��</h2>

					<a href="#">ԭ����Ʒ</a>

					<a href="#">����̳�</a>

			</div>

			<div class="uc-menu-item">

					<h2>����</h2>

					<a href="#">��������</a>

					<a href="#">��������</a>

			</div>

			<div class="uc-menu-item">

					<h2>��ϵ</h2>

					<a href="#">��ϵ����</a>

					<a href="tencent://message/?uin=97509752&������ѯ&Menu=yes">���߿ͷ�</a>

			</div>

		</div>

		<div class="info z">

			<h2>��վ���</h2>

			<p>Դ���(www.ymg6.com)������г������Լ��Ŷӵļ���������ۣ���Ҫ����Discuzģ�������Ӫ������վ���裡</p>

		</div>

		<div class="y">

			<div class="social cl">

				<a href="#" target="_blank" title="��ע�ٷ�΢��"><img src="{$_G['style']['styleimgdir']}img/icons/social_wx.jpg" height="36"></a>

				<a href="#" target="_blank" title="��ע����΢��"><img src="{$_G['style']['styleimgdir']}img/icons/social_wb.jpg" height="36"></a>

				<a href="#" target="_blank" title="��עQQ�ռ�"><img src="{$_G['style']['styleimgdir']}img/icons/social_qq.jpg" height="36"></a>

			</div>

			<div class="nav cl">

				<!--{loop $_G['setting']['footernavs'] $nav}--><!--{if $nav['available'] && ($nav['type'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1)) ||

						!$nav['type'] && ($nav['id'] == 'stat' && $_G['group']['allowstatdata'] || $nav['id'] == 'report' && $_G['uid'] || $nav['id'] == 'archiver' || $nav['id'] == 'mobile' || $nav['id'] == 'darkroom'))}--><span class="pipe">/</span>$nav[code]<!--{/if}--><!--{/loop}-->			

				<!--{if $_G['setting']['statcode']}--><span class="pipe">/</span>$_G['setting']['statcode']<!--{/if}--> <!--{hook/global_footerlink}--> <!--{if $_G['setting']['site_qq']}--><span class="pipe">/</span><a href="http://wpa.qq.com/msgrd?V=3&uin=$_G['setting']['site_qq']&Site=$_G['setting']['bbname']&Menu=yes&from=discuz" target="_blank" title="QQ">�ͷ�QQ��{$_G['setting']['site_qq']}</a><!--{/if}-->

			</div>

		</div>

	</div>

</div>

<div class="uc-footer-bot">

	<div class="wp">

		<div class="z">

			<span class="copy">Copyright &copy; 2008-2015 <a href="$_G['setting']['siteurl']" rel="nofollow" target="_blank">$_G['setting']['sitename']</a> ��Ȩ����</span>

			<span class="by">Powered by <a href="http://www.discuz.net" target="_blank">Discuz!</a> <em>$_G['setting']['version']</em> <!--{if !empty($_G['setting']['boardlicensed'])}--> <a href="http://license.comsenz.com/?pid=1&host=$_SERVER[HTTP_HOST]" target="_blank">Licensed</a><!--{/if}--> ����֧�֣�<a href="http://www.ymg6.com" target="_blank">Դ���</a><!--{if $_G['setting']['icp']}--> <a href="http://www.miitbeian.gov.cn/" target="_blank">$_G['setting']['icp']</a><!--{/if}--></span>

		</div>

		<div class="y">{lang time_now}<span id="debuginfo"><!--{if debuginfo()}-->, Processed in $_G[debuginfo][time] second(s), $_G[debuginfo][queries] queries<!--{if $_G['gzipcompress']}-->, Gzip On<!--{/if}--><!--{if C::memory()->type}-->, <!--{echo ucwords(C::memory()->type)}--> On<!--{/if}-->.<!--{/if}--></span></div>

	</div>

</div>