<?php echo 'www.ymg6.com';exit;?>

<!--{subtemplate common/header_common}-->

<!--{subtemplate common/uc_config}-->

	<meta name="application-name" content="$_G['setting']['bbname']" />

	<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />

	<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->

	<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />

	<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->

	<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->

	<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->

		<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />

	<!--{/if}-->

	<script type="text/javascript">window.onerror=function(){return true;} </script>

	<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->

	<!--{if widthauto()}-->

		<link rel="stylesheet" id="css_widthauto" type="text/css" href='data/cache/style_{STYLEID}_widthauto.css?{VERHASH}' />

		<script type="text/javascript">HTMLNODE.className += ' widthauto'</script>

	<!--{/if}-->

	<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/css/icon.css?{VERHASH}">

	<!--{subtemplate common/header_width}-->

	<!--{if $ucre !== 0}-->

		<!--{if $ucwp > 1180}-->

			<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/css/respond.1780.css?{VERHASH}">

		<!--{/if}-->

		<!--{if $ucwp > 880}-->

			<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/css/respond.1180.css?{VERHASH}">

		<!--{/if}-->

		<!--{if $ucwp > 580}-->

			<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/css/respond.880.css?{VERHASH}">

		<!--{/if}-->

		<script type="text/javascript" src="{$_G['style']['styleimgdir']}/js/respond.js?{VERHASH}"></script>

	<!--{/if}-->

	<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->

		<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>

	<!--{elseif $_G['basescript'] == 'home' || $_G['basescript'] == 'userapp'}-->

		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>

	<!--{elseif $_G['basescript'] == 'portal'}-->

		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>

	<!--{/if}-->

	<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->

		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>

	<!--{/if}-->

	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->

		<link rel="stylesheet" type="text/css" id="diy_common" href="data/cache/style_{STYLEID}_css_diy.css?{VERHASH}" />

	<!--{/if}-->

</head>



<body id="nv_{$_G[basescript]}" class="pg_{CURMODULE}{if $_G['basescript'] === 'portal' && CURMODULE === 'list' && !empty($cat)} {$cat['bodycss']}{/if}" onkeydown="if(event.keyCode==27) return false;">

	<div id="append_parent"></div><div id="ajaxwaitid"></div>

	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->

		<!--{template common/header_diy}-->

	<!--{/if}-->

	<!--{if check_diy_perm($topic)}-->

		<!--{template common/header_diynav}-->

	<!--{/if}-->

	<!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->

		$diynav

	<!--{/if}-->

	<!--{if empty($topic) || $topic['useheader']}-->

		<!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->

			<div class="xi1 bm bm_c">

				{lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a>

			</div>

		<!--{/if}-->

		<!--{ad/headerbanner/wp a_h}-->

		<div class="uc-header" id="ucheader">

			<!--{hook/global_cpnav_top}-->

			<!--{eval $mnid = getcurrentnav();}-->

			<div class="wp">

				<div class="uc-logo">

					<!--{if !isset($_G['setting']['navlogos'][$mnid])}-->

						<a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']"></a>

					<!--{else}-->

						$_G['setting']['navlogos'][$mnid]

					<!--{/if}-->

				</div>

				<div class="uc-menu">

					<a href="javascript:void(0)" onClick="$('header_menu').className == 'uc-menu-ul'?$('header_menu').className += ' open':$('header_menu').className = 'uc-menu-ul';" class="uc-menu-ico"><i class="ico-align-justify ico-white ico-gray ico-hover"></i></a>

					<ul class="uc-menu-ul" id="header_menu">

						<!--{loop $_G['setting']['navs'] $nav}-->

							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->

								<li {if $mnid == $nav[navid]}class="on" {/if}$nav[nav]></li>

							<!--{/if}-->

						<!--{/loop}-->

					</ul>

					<!--{hook/global_nav_extra}-->

				</div>

				<!--{template common/header_userstatus}-->

				<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->

					<ul class="p_pop h_pop" id="plugin_menu" style="display:none">

						<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->

							 <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->

								 <li>$module[url]</li>

							 <!--{/if}-->

						<!--{/loop}-->

					</ul>

				<!--{/if}-->

			</div>

		</div>

		<!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->

			<div id="shortcut">

				<span><a href="javascript:;" id="shortcutcloseid" title="{lang close}">{lang close}</a></span>

				{lang shortcut_notice}

				<a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a>

			</div>

			<script type="text/javascript">setTimeout(setShortcut, 2000);</script>

		<!--{/if}-->

		<div class="uc-header-place"></div>

		<div class="uc-header-menu-sub">

			$_G[setting][menunavs]

			<div id="mu" class="wp cl">

			<!--{if $_G['setting']['subnavs']}-->

				<!--{loop $_G['setting']['subnavs'] $navid $subnav}-->

					<!--{if $_G['setting']['navsubhover'] || $mnid == $navid}-->

					<ul class="cl {if $mnid == $navid}current{/if}" id="snav_$navid" style="display:{if $mnid != $navid}none{/if}">

					$subnav

					</ul>

					<!--{/if}-->

				<!--{/loop}-->

			<!--{/if}-->

			</div>

		</div>

		<ul id="scbar_type_menu" class="searchmenu" style="display: none;"><!--{echo implode('', $slist);}--></ul>

		<script type="text/javascript">

			initSearchmenu('scbar', '$searchparams[url]');

		</script>

		<!--{ad/subnavbanner/a_mu}-->

		<!--{hook/global_header}-->

	<!--{/if}-->

	<!--{eval $uctype = $uc['index']['list_type'] ? $uc['index']['list_type'] : 0;}-->

	<!--{if $_G['basescript'] == 'forum' && CURMODULE == 'index'}-->

		<!--{if $uctype == 0 || (!empty($_G[fid]) && !empty($gid) && $_G[fid] !== $gid)}-->

			<div id="wp" class="wp">

		<!--{/if}-->

	<!--{else}-->

		<div id="wp" class="wp">

	<!--{/if}-->