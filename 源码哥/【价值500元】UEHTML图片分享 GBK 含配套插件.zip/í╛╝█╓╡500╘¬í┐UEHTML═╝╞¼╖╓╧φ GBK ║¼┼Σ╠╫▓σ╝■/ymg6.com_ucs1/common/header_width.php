<?php echo 'www.ymg6.com';exit;?>

<!--{eval}-->

	$ucwp = intval($uc['global']['width']) ? intval($uc['global']['width']) : 1780;

	$ucre = $uc['global']['respond'];

<!--{/eval}-->

<style type="text/css">

	<!--{if $ucre == 1}-->

		body { overflow-x:hidden; }

	<!--{/if}-->

	<!--{if $ucwp == 1180}-->

			.ct2 .mn { width:880px; }

			.ct2 .uc-piclist ul { width:900px; }

			.ct2_a .mn { width:1010px; overflow:visible; }

			.wp{ width:1180px; }

			#wp .wp{ width:1180px; }

			.uc-header .uc-menu-ul { max-width:500px; height:60px; overflow:hidden; }

			.uc-piclist { width:1180px; }

			.uc-ngrid .uc-ngrid-3-tit{display:none;}

			.uc-ngrid .uc-ngrid-3{display:none;}

			.uc-piclist ul { width:1200px; }

			.uc-postview-main { width:880px; }

			.uc-module .i2 { display:none; }

			.uc-footer-top .info { display:none; }

			.uc-thread-footer-share span { display:none; }

			.bdshare-button-style0-16 .uc-thread-footer-share-box a { margin-left:0; }

	<!--{/if}-->

	<!--{if $ucwp == 880}-->

			.uc-postview-side { display:none; }

			.wp,#hd .wp,#wp,#wp .wp{ width:880px; }

			.ct2_a .mn { width:710px; }

			.ct2 .mn { width:880px; }

			.ct2 .sd { display:none; }

			.uc-piclist { width:880px; }

			.uc-piclist ul { width:900px; }

			.uc-header .uc-menu { position:relative; width:50px; height:50px; }

			.uc-header .uc-menu-ico { display:block; }

			.uc-header .uc-menu ul { display:none; max-width:100%; overflow:hidden; position:fixed; top:60px; left:0; right:0; padding:20px; height:auto; background:#FFFFFF; box-shadow:0 5px 5px rgba(0,0,0,.2); }

			.uc-header .uc-menu ul.open { display:block; }

			.uc-header .uc-menu ul li { margin-bottom:10px; }

			.uc-header-menu-sub .p_pop li a { min-width:100px; }

			.uc-header .uc-menu ul li a { color:#555; display:block; width:120px; text-align:center; padding:0; height:40px; line-height:40px; position:relative; z-index:10; }

			.uc-header .uc-menu ul li:hover { background:none; }

			.uc-header .uc-menu ul li a:hover { color:#1F8902; }

			.uc-header .uc-menu ul li a + dl { position:relative; z-index:99; top:0; visibility:visible; opacity:1; background:#F1F1F1; padding:10px 0px; margin:-51px -20px 0px -20px; width:auto; border-bottom:1px solid #F1F1F1; }

			.uc-header .uc-menu ul li dl dd { float:left; border:0px; }

			.uc-header .uc-menu ul li:hover dl dd { border:0px; }

			.uc-header .uc-menu ul li dl dd a,

			.uc-header .uc-menu ul li:hover dl dd a { display:inline-block; text-indent:0px; background:none; height:50px; line-height:50px; color:#888; border:0px; margin-left:30px; font-size:14px; }

			.uc-header .uc-menu ul li dl dd a:hover,

			.uc-header .uc-menu ul li:hover dl dd a:hover { background:none; color:#444; }

			.uc-header .uc-menu-ul > li.on { background:{HIGHLIGHTLINK}; color:#FFF; }

			.uc-header .uc-menu ul li a:hover,.uc-header .uc-menu-ul li:hover, .uc-header .uc-menu-ul li.hover { background-color:#444; color:#FFF; }

			.uc-footer-bot .y { display:none; }

			.uc-footer-bot .z { float:none; display:block; text-align:center; }

			.uc-module .i1 { display:none; }

			.uc-module .i3 { display:none; }

			.uc-thread-footer-share { position:relative; overflow:visible; }

			.uc-thread-footer-share span { display:block; }

			.uc-thread-footer-share:hover .uc-thread-footer-share-box { display:block; }

			.uc-thread-footer-share-box { position:absolute; top:25px; right:-20px; display:none; width:100px; border:1px solid #DDD; background:#FFF; z-index:10; }

			.uc-thread-footer-share-box:after { top:-4px; width:0px; left:50%; margin-left:-6px; height:0px; border-width:0 6px 6px; border-style:solid; border-color:transparent transparent #FFF transparent; content:""; position:absolute; z-index:0; }

			.uc-thread-footer-share-box:before { top:-6px; width:0px; left:50%; margin-left:-6px; height:0px; border-width:0 6px 6px; border-style:solid; border-color:transparent transparent #DDD transparent; content:""; position:absolute; z-index:0; }

			.bdshare-button-style0-16 .uc-thread-footer-share-box a { display:block; float:none; margin-left:10px; text-align:left; overflow:hidden; padding-bottom:6px; border-bottom:1px solid #EEE; }

			.uc-postlist-th.th1 .z ul li { margin-right:5px; }

			.uc-postlist-th.th1 .y a { margin-right:10px; }

			.uc-f-nav { display:none; }

	<!--{/if}-->

	<!--{if $ucwp == 580}-->

			.uc-piclist { width:580px; }

			.uc-piclist ul { width:600px; }

			.uc-catlist .fl_tb .fl_icn_g { display:none; }

			.uc-catlist .fl_tb .fl_g dl { padding-left:0; margin-left:0; }

			.uc-catlist .fl_tb .fl_g dl dd em:first-child { display:none; }

			.uc-ngrid .uc-ngrid-4-tit{display:none;}

			.uc-ngrid .uc-ngrid-4{display:none;}

			.uc-postlist-th-bot div.z { float:none; }

			.uc-postlist-th-bot div.y { float:none; border-top:1px solid #F1F1F1; padding-top:10px; margin-top:20px; }

			.uc-postlist-th.th1 #pt .y { display:block; }

			.uc-postlist-th.th1 .uc-postlist-th-bot div.z { float:left; }

			.uc-postlist-th.th1 .uc-postlist-th-bot div.y { float:right; border-top:0; padding-top:0px; margin-top:0px; margin-left:-20px; }

			.uc-postlist-th.th1 #filter_time { display:none; }

			.uc-footer-top .menu { display:none; }

			.uc-pagelist .pg a,

			.uc-pagelist .pg strong,

			.uc-pagelist .pg label { margin-right:0px; height:34px; padding:0 12px; font:bold small-caps 13px/34px Verdana,'Microsoft YaHei',Helvetica,sans-serif; }

			.uc-pagelist .pg strong { padding:0 13px; height:36px; line-height:36px; }

			.uc-pagelist .pg label { display:none; }

			.uc-pagelist .pg a.prev { background-position:-4px -43px; }

			.uc-pagelist .pg a.nxt { background-position:right -43px; }

			.uc-pagelist .pg a.prev:hover { background-position:-4px -83px; }

			.uc-pagelist .pg a.nxt:hover { background-position:right -83px; }

			.uc-header .uc-user-search { display:none; }

			.uc-header .uc-user-search-btn { display:block; }

			.uc-toolbar .uc-filter div.other { width:120px; }

			.uc-toolbar .uc-filter div.other:hover .other-menu { display:block; }

			.uc-toolbar .uc-filter div.other .other-tit { display:block; }

			.uc-toolbar .uc-filter div.other .other-menu { display:none; width:118px; background:#FFF; border:1px solid #EEE; border-top:0; height:auto; }

			.uc-toolbar .uc-filter div.other .other-menu div.uc-li { width:118px; position:relative; margin:0; height:36px; }

			.uc-toolbar .uc-filter div.other .other-menu div.uc-li span { display:block; margin:0; width:118px; border:0; border-bottom:1px solid #EEE; height:35px; line-height:35px; }

			.uc-toolbar .uc-filter div.other .other-menu div.uc-li span i { display:none; }

			.uc-toolbar .uc-filter div.other .other-menu div.uc-li:hover span { background-color:#369; border-color:#369; color:#FFF; }

			.uc-toolbar .uc-filter div.other .other-menu div.uc-li ul { position:absolute; left:118px; top:0; }

			.uc-postlist-top-favorite span { display:none; }

			.uc-postlist-top-catinfo .z div.z { display:none; }

			.uc-postview-main { width:580px; }

			.uc-member { width:510px; margin:0 auto; position:relative; }

			.uc-member .wp { background:none; width:510px; }

			.uc-member .uc-member-head { text-align:center; padding:50px 0 20px 0; }

			.uc-member .p_tip,.uc-member .p_chk { opacity:0; filter:progid:DXImageTransform.Microsoft.Alpha(opacity=0); }

			.uc-member .uc-member-logo { float:none; display:inline-block; }

			.uc-member .uc-member-info { float:none; display:inline-block; }

			.uc-member .uc-member-menu { float:none; display:block; }

			.uc-member .uc-member-menu li { float:none; display:inline-block; }

			.uc-member .uc-member-main { padding:0; }

			.uc-member .uc-member-form { padding-bottom:0; }

			.uc-member .uc-member-form { float:none; width:410px; margin:0; padding:30px 50px; border:0; }

			.uc-member .uc-member-side { float:none; margin-top:0; width:100%; padding:20px 0; border-top:1px solid #E5E5E5; overflow:hidden; }

			.uc-member .uc-member-side.p { display:none; }

			.uc-member .uc-member-side span { border-bottom:0; font-size:13px; margin:0 50px 0px 50px; padding-bottom:0px; }

			.uc-member .uc-member-side p { margin:0 28px 0px 50px; }

			.uc-member .uc-member-side p a { float:left; margin:0; margin-right:20px; margin-top:10px; }

		

			.ct2 .mn { width:580px; }

			.ct2 .uc-piclist ul { width:600px; }

			.ct2_a .mn { width:410px; }

			#pt .y { display:none; }

			.wp,#hd .wp,#wp,#wp .wp{ width:580px; }

	<!--{/if}-->

</style>