function getStyle(obj, name) {
	if (obj.currentStyle) {
		return obj.currentStyle[name];
	} else {
		return getComputedStyle(obj, false)[name];
	}
}
function getByClass(oParent, nClass) {
	var eLe = oParent.getElementsByTagName('*');
	var aRrent = [];
	for (var i = 0; i < eLe.length; i++) {
		if (eLe[i].className == nClass) {
			aRrent.push(eLe[i]);
		}
	}
	return aRrent;
}
function startMove(obj, att, add) {
	clearInterval(obj.timer);
	obj.timer = setInterval(function() {
		var cutt = 0;
		if (att == 'opacity') {
			cutt = Math.round(parseFloat(getStyle(obj, att)));
		} else {
			cutt = Math.round(parseInt(getStyle(obj, att)));
		}
		var speed = (add - cutt) / 4;
		speed = speed > 0 ? Math.ceil(speed) : Math.floor(speed);
		if (cutt == add) {
			clearInterval(obj.timer);
		} else {
			if (att == 'opacity') {
				obj.style.opacity = (cutt + speed) / 100;
				obj.style.filter = 'alpha(opacity:' + (cutt + speed) + ')';
			} else {
				obj.style[att] = cutt + speed + 'px';
			}
		}
	},
	30);
}
function ucSlide(o,u) {
	if(typeof(o) == 'object'){
		var oElem = o;
	} else {
		var oElem = document.getElementById(o);
	}
	var oPrev = getByClass(oElem, 'prev')[0];
	var oNext = getByClass(oElem, 'next')[0];
	var oList = getByClass(oElem, 'list')[0];
	var oItems = oList.getElementsByTagName('dd');
	var now = 0;
	oPrev.onclick = function() {
		now--;
		if (now == -1) {
			now = oItems.length;
		}
		startMove(oList,'left',-(now*oItems[0].offsetWidth));
	}
	oNext.onclick = function() {
		now++;
		if (now == oItems.length) {
			now = 0;
		}
		startMove(oList,'left',-(now*oItems[0].offsetWidth));
	}
	var timer = setInterval(oNext.onclick, 3000);
	oElem.onmouseover = function() {
		clearInterval(timer);
	}
	oElem.onmouseout = function() {
		timer = setInterval(oNext.onclick, 3000);
	}
}