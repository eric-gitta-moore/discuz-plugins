<?php echo 'www.ymg6.com';exit;?>

<!--{template common/header}--></div>

<!--{eval $loginhash = 'L'.random(4);}-->

<!--{if empty($_GET['infloat'])}-->

	<style>

		.uc-header, .uc-header-place, .uc-footer { display:none; }

	</style>

	<div id="ct" class="uc-member">

		<div class="nfl" id="main_succeed" style="display: none">

			<div class="f_c altw">

				<div class="alert_right">

					<p id="succeedmessage"></p>

					<p id="succeedlocation" class="alert_btnleft"></p>

					<p class="alert_btnleft"><a id="succeedmessage_href">{lang message_forward}</a></p>

				</div>

			</div>

		</div>

		<!--{template member/header}-->

		<div class="uc-member-main" id="main_message">

			<div class="wp cl">

<!--{else}-->

			<div class="uc-member fixed {if isset($_GET['frommessage'])} uc-fwin{/if}{if !empty($_G['setting']['pluginhooks']['logging_method'])} method{/if}">

<!--{/if}-->

				<div id="main_messaqge_$loginhash">

					<div id="layer_login_$loginhash">

						<div class="uc-member-form z">

								<div class="uc-member-form-tit cl">

									<!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}-->

									<div class="uc-member-form-close"{if !$float} style="cursor:move" onmousedown="dragMenu($('fwin_login'), event, 1)"{/if}>

										<i class="ico-remove" onclick="hideWindow('$_GET[handlekey]', 0, 1);" title="{lang close}"></i>

									</div>

									<!--{/if}-->

									<span class="y">

										<!--{hook/logging_side_top}-->

										û���˺ţ�<a href="member.php?mod={$_G[setting][regname]}" class="xi2">����ע��</a>

									</span>

									<!--{if !$secchecklogin2}-->

										<span class="z">��ӭ����</span>

									<!--{else}-->

										<span class="z">{lang login_seccheck2}</span>

									<!--{/if}-->

								</div>

								<!--{hook/logging_top}-->

								<form method="post" autocomplete="off" name="login" id="loginform_$loginhash" class="cl" onsubmit="{if $this->setting['pwdsafety']}pwmd5('password3_$loginhash');{/if}pwdclear = 1;ajaxpost('loginform_$loginhash', 'returnmessage_$loginhash', 'returnmessage_$loginhash', 'onerror');return false;" action="member.php?mod=logging&action=login&loginsubmit=yes{if !empty($_GET['handlekey'])}&handlekey=$_GET[handlekey]{/if}{if isset($_GET['frommessage'])}&frommessage{/if}&loginhash=$loginhash">

									<div class="cl">

										<input type="hidden" name="formhash" value="{FORMHASH}" />

										<input type="hidden" name="referer" value="{echo dreferer()}" />

										<!--{if $auth}-->

											<input type="hidden" name="auth" value="$auth" />

										<!--{/if}-->

										

										<!--{if $invite}-->

										<div class="rfm">

											<table>

												<tr>

													<th>{lang register_from}</th>

													<td><a href="home.php?mod=space&uid=$invite[uid]" target="_blank">$invite[username]</a></td>

												</tr>

											</table>

										</div>

										<!--{/if}-->

						

										<!--{if !$auth}-->

						

										<!--{if $this->setting['autoidselect']}-->

										<!--{else}-->

											<div class="rfm uc-member-select">

												<table>

													<tr>

														<th>

															��¼��ʽ:

														</th>

														<td>

															<div id="loginfield">

																<em>

																	<input type="radio" name="loginfield" id="loginfield_username" value="username" checked onClick="loginfieldyz(this,'��¼�˺�','�����������û���')">

																	<label for="loginfield_username" id="loginfield_username_label" class="on">�˺ŵ�¼</label>

																</em>

																<!--{if getglobal('setting/uidlogin')}-->

																<em>

																	<input type="radio" name="loginfield" id="loginfield_uid" value="uid" onClick="loginfieldyz(this,'UID���','����������UID���')">

																	<label for="loginfield_uid" id="loginfield_uid_label">UID��¼</label>

																</em>

																<!--{/if}-->

																<em>

																	<input type="radio" name="loginfield" id="loginfield_email" value="email" onClick="loginfieldyz(this,'�����ַ','���������������ַ')">

																	<label for="loginfield_email" id="loginfield_email_label">�����¼</label>

																</em>

																<script type="text/javascript">

																	function loginfieldyz(obj,text,tip){

																		var label = $('loginfield').getElementsByTagName('label');

																		for(var i=0;i<label.length;i++){

																			label[i].className ='';

																		}

																		$(obj.id+'_label').className = 'on';

																		$('username').innerHTML = text;

																		$('username_$loginhash').setAttribute('placeholder',tip);

																	}

																</script>

															</div>

															<!--{if !$this->setting['bbclosed'] && empty($_GET['infloat'])}--><a href="javascript:;" onclick="ajaxget('member.php?mod=clearcookies&formhash={FORMHASH}', 'returnmessage_$loginhash', 'returnmessage_$loginhash');return false;" title="{lang login_clearcookies}" class="y">{lang login_clearcookies}</a><!--{/if}-->

														</td>

													</tr>

												</table>

											</div>

										<!--{/if}-->

										<div class="rfm">

											<table>

												<tr>

													<th>

														<label for="username_$loginhash" id="username">��¼�˺�:</label>

													</th>

													<td><input type="text" name="username" id="username_$loginhash" placeholder="�����������û���" autocomplete="off" size="30" class="px p_fre" tabindex="1" value="$username" /></td>

												</tr>

											</table>

										</div>

										<div class="rfm">

											<table>

												<tr>

													<th><label for="password3_$loginhash">��¼{lang login_password}:</label></th>

													<td><input type="password" id="password3_$loginhash" placeholder="����������" name="password" onfocus="clearpwd()" size="30" class="px p_fre" tabindex="1" /></td>

												</tr>

											</table>

										</div>

										<!--{/if}-->

						

										<!--{if empty($_GET['auth']) || $questionexist}-->

										<div class="rfm s">

											<table>

												<tr>

													<th>{lang security_q}:</th>

													<td>

													<select id="loginquestionid_$loginhash" width="213" name="questionid"{if !$questionexist} onchange="if($('loginquestionid_$loginhash').value > 0) {$('loginanswer_row_$loginhash').style.display='';} else {$('loginanswer_row_$loginhash').style.display='none';}"<!--{/if}-->>

														<option value="0"><!--{if $questionexist}-->{lang security_question_0}<!--{else}-->{lang security_question}<!--{/if}--></option>

														<option value="1">{lang security_question_1}</option>

														<option value="2">{lang security_question_2}</option>

														<option value="3">{lang security_question_3}</option>

														<option value="4">{lang security_question_4}</option>

														<option value="5">{lang security_question_5}</option>

														<option value="6">{lang security_question_6}</option>

														<option value="7">{lang security_question_7}</option>

													</select></td>

												</tr>

											</table>

										</div>

										<div class="rfm" id="loginanswer_row_$loginhash" {if !$questionexist} style="display:none"{/if}>

											<table>

												<tr>

													<th>��ȫ{lang security_a}:</th>

													<td><input type="text" name="answer" id="loginanswer_$loginhash" placeholder="�������" autocomplete="off" size="30" class="px p_fre" tabindex="1" /></td>

												</tr>

											</table>

										</div>

										<!--{/if}-->

						

										<!--{if $seccodecheck}-->

											<!--{block sectpl}--><div class="rfm code"><table><tr><th>��֤ͼ��:<br><br><sec></th><td><sec><br /><sec></td></tr></table></div><!--{/block}-->

											<!--{subtemplate common/seccheck}-->

										<!--{/if}-->

										<script>

											<!--{eval $vmid = 'c'.$sechash;}-->

											var secjsTimer = setInterval(

												function(){

													if($('seccodeverify_$vmid')){

														clearInterval(secjsTimer);

														$('seccodeverify_$vmid').setAttribute('tabindex','1');

														$('seccodeverify_$vmid').setAttribute('placeholder','��������֤��');

														$('checkseccodeverify_$vmid').className = 'codespan';

													}

												}

											,500);

										</script>

										<!--{hook/logging_input}-->

										<div class="rfm mbw bw0">

											<table width="100%">

												<tr>

													<th>&nbsp;</th>

													<td>

														<button class="pn pnc" type="submit" name="loginsubmit" value="true" tabindex="1"><strong>{lang login}</strong></button>

														<label for="cookietime_$loginhash"><input type="checkbox" class="pc" name="cookietime" id="cookietime_$loginhash" tabindex="1" value="2592000" $cookietimecheck />{lang login_permanent}</label>

														<a href="javascript:;" onclick="display('layer_login_$loginhash');display('layer_lostpw_$loginhash');" class="y" title="{lang getpassword}">{lang getpassword}</a>

													</td>

												</tr>

											</table>

										</div>

									</div>

								</form>

							</div>

							<!--{if !empty($_G['setting']['pluginhooks']['logging_method'])}-->

							<div class="uc-member-side y">

								<span>�������˺ŵ�¼</span>

								<p class="cl"><!--{hook/logging_method}--></p>

							</div>

							<!--{else}-->

							<div class="uc-member-side p y">

								<div class="uc-member-side-pic">

									<img src="{$_G['style']['styleimgdir']}img/login_pic.png" />

								</div>

							</div>

							<!--{/if}-->

						</div>

					</div>

					<!--{if $_G['setting']['pwdsafety']}-->

						<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>

					<!--{/if}-->

					<div id="layer_lostpw_$loginhash" style="display: none;">

						<div class="uc-member-form z">

							<div class="uc-member-form-tit cl">

								<!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}-->

								<div class="uc-member-form-close"{if !$float} style="cursor:move" onmousedown="dragMenu($('fwin_login'), event, 1)"{/if}>

									<i class="ico-remove" onclick="hideWindow('$_GET[handlekey]', 0, 1);" title="{lang close}"></i>

								</div>

								<!--{/if}-->

								<span class="y">

									<!--{hook/logging_side_top}-->

									û���˺ţ�<a href="member.php?mod={$_G[setting][regname]}" class="xi2">����ע��</a>

								</span>

								<span class="z">�һ�����</span>

							</div>

							<form method="post" autocomplete="off" id="lostpwform_$loginhash" class="cl" onsubmit="ajaxpost('lostpwform_$loginhash', 'returnmessage3_$loginhash', 'returnmessage3_$loginhash', 'onerror');return false;" action="member.php?mod=lostpasswd&lostpwsubmit=yes&infloat=yes">

								<div class="c cl">

									<input type="hidden" name="formhash" value="{FORMHASH}" />

									<input type="hidden" name="handlekey" value="lostpwform" />

									<div class="rfm">

										<table>

											<tr>

												<th><label for="lostpw_email">��ȫ����:</label></th>

												<td><input type="text" name="email" id="lostpw_email" size="30" value=""  tabindex="1" class="px p_fre" /></td>

											</tr>

										</table>

									</div>

									<div class="rfm">

										<table>

											<tr>

												<th><label for="lostpw_username">{lang username}:</label></th>

												<td><input type="text" name="username" id="lostpw_username" size="30" value=""  tabindex="1" class="px p_fre" /></td>

											</tr>

										</table>

									</div>

					

									<div class="rfm mbw bw0">

										<table>

											<tr>

												<th></th>

												<td>

													<button class="pn pnc" type="submit" name="lostpwsubmit" value="true" tabindex="100"><span>{lang submit}</span></button>

													<a href="javascript:;" onclick="display('layer_login_$loginhash');display('layer_lostpw_$loginhash');" class="y" title="���ص�¼">���ص�¼</a>

												</td>

											</tr>

										</table>

									</div>

								</div>

							</form>

						</div>

					</div>

					<div id="layer_message_$loginhash"{if empty($_GET['infloat'])} class="f_c blr nfl"{/if} style="display: none;">

						<h3 class="flb" id="layer_header_$loginhash">

							<!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}-->

							<em>{lang login_member}</em>

							<span><a href="javascript:;" class="flbc" onclick="hideWindow('login')" title="{lang close}">{lang close}</a></span>

							<!--{/if}-->

						</h3>

						<div class="c"><div class="alert_right">

							<div id="messageleft_$loginhash"></div>

							<p class="alert_btnleft" id="messageright_$loginhash"></p>

						</div>

					</div>

					<script type="text/javascript" reload="1">

					var hdyzc = 0;

					var hdyz = setInterval(

						function(){

							if($('gt_page_logging_input')){

								clearInterval(hdyz);

								var obj = $('gt_page_logging_input');

								var th = obj.getElementsByTagName('th')[0];

								th.innerHTML = '������֤:';

							} else if($('gt_float_logging_input')){

								clearInterval(hdyz);

								var obj = $('gt_float_logging_input');

								var th = obj.getElementsByTagName('th')[0];

								th.innerHTML = '������֤:';

							} else {

								if(hdyzc<20){

									hdyzc++;

								} else {

									clearInterval(hdyz);

								}

							}

						}

					,500);

					var maskc = 0;

					var mask = setInterval(

						function(){

							if($('fwin_login')){

								clearInterval(mask);

								var table = $('fwin_login').getElementsByTagName('table')[0];

								$('fwin_login').className = $('fwin_login').className + ' uc-mask';

								table.setAttribute('style',$('fwin_login').getAttribute('style'));

								$('fwin_login').removeAttribute('style')

							} else {

								if(maskc<20){

									maskc++;

								} else {

									clearInterval(maskc);

								}

							}

						}

					,500);

					<!--{if !isset($_GET['viewlostpw'])}-->

						var pwdclear = 0;

						function initinput_login() {

							document.body.focus();

							<!--{if !$auth}-->

								if($('loginform_$loginhash')) {

									$('loginform_$loginhash').username.focus();

								}

								<!--{if !$this->setting['autoidselect']}-->

									simulateSelect('loginfield_$loginhash');

								<!--{/if}-->

							<!--{elseif $seccodecheck && !(empty($_GET['auth']) || $questionexist)}-->

								if($('loginform_$loginhash')) {

									safescript('seccodefocus', function() {$('loginform_$loginhash').seccodeverify.focus()}, 500, 10);

								}			

							<!--{/if}-->

						}

						initinput_login();

						<!--{if $this->setting['sitemessage']['login']}-->

						showPrompt('custominfo_login_$loginhash', 'mouseover', '<!--{echo trim($this->setting['sitemessage'][login][array_rand($this->setting['sitemessage'][login])])}-->', $this->setting['sitemessage'][time]);

						<!--{/if}-->

					

						function clearpwd() {

							if(pwdclear) {

								$('password3_$loginhash').value = '';

							}

							pwdclear = 0;

						}

					<!--{else}-->

						display('layer_login_$loginhash');

						display('layer_lostpw_$loginhash');

						$('lostpw_email').focus();

					<!--{/if}-->

					</script>



<!--{eval updatesession();}-->

<!--{if empty($_GET['infloat'])}-->

					</div>

				</div>

			</div>

			<div class="uc-member-foot">

				<div class="wp cl">

					<div class="z">Powered by <a href="http://www.discuz.net" target="_blank">Discuz!</a> <em>$_G['setting']['version']</em> <!--{if !empty($_G['setting']['boardlicensed'])}--> <a href="http://license.comsenz.com/?pid=1&host=$_SERVER[HTTP_HOST]" target="_blank">Licensed</a><!--{/if}--> ����֧�֣�<a href="http://www.uc-net.com" target="_blank">�Ŵ�����</a><!--{if $_G['setting']['icp']}--> <a href="http://www.miitbeian.gov.cn/" target="_blank">$_G['setting']['icp']</a><!--{/if}--></div>

					<div class="y"><!--{loop $_G['setting']['footernavs'] $nav}--><!--{if $nav['available'] && ($nav['type'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1)) ||

						!$nav['type'] && ($nav['id'] == 'stat' && $_G['group']['allowstatdata'] || $nav['id'] == 'report' && $_G['uid'] || $nav['id'] == 'archiver' || $nav['id'] == 'mobile' || $nav['id'] == 'darkroom'))}--><span class="pipe">/</span>$nav[code]<!--{/if}--><!--{/loop}-->			

				<!--{if $_G['setting']['statcode']}--><span class="pipe">/</span>$_G['setting']['statcode']<!--{/if}--> <!--{hook/global_footerlink}--> <!--{if $_G['setting']['site_qq']}--><span class="pipe">/</span><a href="http://wpa.qq.com/msgrd?V=3&uin=$_G['setting']['site_qq']&Site=$_G['setting']['bbname']&Menu=yes&from=discuz" target="_blank" title="QQ">�ͷ�QQ��{$_G['setting']['site_qq']}</a><!--{/if}--></div>

				</div>

			</div>

		</div>

<!--{else}-->

	</div>

<!--{/if}-->









<!--{template common/footer}-->