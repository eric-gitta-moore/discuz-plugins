<?php echo 'www.ymg6.com';exit;?>

<!--{template common/header}--></div>

<script type="text/javascript">

	var strongpw = new Array();

	<!--{if $_G['setting']['strongpw']}-->

		<!--{loop $_G['setting']['strongpw'] $key $val}-->

		strongpw[$key] = $val;

		<!--{/loop}-->

	<!--{/if}-->

	var pwlength = <!--{if $_G['setting']['pwlength']}-->$_G['setting']['pwlength']<!--{else}-->0<!--{/if}-->;

</script>

<script type="text/javascript" src="{$this->setting[jspath]}register.js?{VERHASH}"></script>



	<style>

		.uc-header, .uc-header-place, .uc-footer { display:none; }

	</style>

	<div id="ct" class="uc-member r">

		<div class="nfl" id="main_succeed" style="display: none">

			<div class="f_c altw">

				<div class="alert_right">

					<p id="succeedmessage"></p>

					<p id="succeedlocation" class="alert_btnleft"></p>

					<p class="alert_btnleft"><a id="succeedmessage_href">{lang message_forward}</a></p>

				</div>

			</div>

		</div>

		<!--{template member/header}-->

		<div class="uc-member-main" id="main_message">

			<div class="wp cl">

				<div class="uc-member-form z">

					<div class="uc-member-form-tit cl">

						<!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}-->

						<div class="uc-member-form-close"{if !$float} style="cursor:move" onmousedown="dragMenu($('fwin_login'), event, 1)"{/if}>

							<i class="ico-remove" onclick="hideWindow('$_GET[handlekey]', 0, 1);" title="{lang close}"></i>

						</div>

						<!--{/if}-->

						<span class="y">

							<!--{hook/logging_side_top}-->

							�����˺ţ�<a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" onclick="showWindow('login', this.href);return false;" class="xi2">������¼</a>

						</span>

						<span class="z">���û�ע��</span>

					</div>

					<p id="returnmessage4"></p>

					

					<!--{if $this->showregisterform}-->

						<form method="post" autocomplete="off" name="register" id="registerform" enctype="multipart/form-data" onsubmit="checksubmit();return false;" action="member.php?mod=$regname">

							<div id="layer_reg">

								<input type="hidden" name="regsubmit" value="yes" />

								<input type="hidden" name="formhash" value="{FORMHASH}" />

								<input type="hidden" name="referer" value="$dreferer" />

								<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />

								<!--{if $_G['setting']['sendregisterurl']}-->

									<input type="hidden" name="hash" value="$_GET[hash]" />

								<!--{/if}-->

								<div class="mtw">

									<div id="reginfo_a">

										<!--{hook/register_top}-->

										<!--{if $sendurl}-->

											<div class="rfm">

												<table>

													<tr>

														<th><span class="rq">*</span><label for="{$this->setting['reginput']['email']}">{lang email}:</label></th>

														<td>

															<input type="text" id="{$this->setting['reginput']['email']}" name="$this->setting['reginput']['email']" autocomplete="off" size="25" tabindex="1" class="px" required /><br /><em id="emailmore">&nbsp;</em>

															<input type="hidden" name="handlekey" value="sendregister"/>

														</td>

														<td class="tipcol"><i id="tip_{$this->setting['reginput']['email']}" class="p_tip">{lang register_email_tips}</i><kbd id="chk_{$this->setting['reginput']['email']}" class="p_chk"></kbd></td>

													</tr>

												</table>

												<table>

													<tr>

														<th>&nbsp;</th>

														<td class="tipwide">

															{lang register_validate_email_tips}

														</td>

													</tr>

												</table>

												<script type="text/javascript">

													function succeedhandle_sendregister(url, msg, values) {

														showDialog(msg, 'notice');

													}

												</script>

											</div>

										<!--{else}-->

											<!--{if $invite}-->

												<!--{if $invite['uid']}-->

												<div class="rfm">

													<table>

														<tr>

															<th>{lang register_from}:</th>

															<td><a href="home.php?mod=space&uid=$invite[uid]" target="_blank">$invite[username]</a></td>

														</tr>

													</table>

												</div>

												<!--{else}-->

												<div class="rfm">

													<table>

														<tr>

															<th><label for="invitecode">{lang invite_code}:</label></th>

															<td>$_GET[invitecode]<input type="hidden" id="invitecode" name="invitecode" value="$_GET[invitecode]" /></td>

														</tr>

													</table>

												</div>

												<!--{eval $invitecode = 1;}-->

												<!--{/if}-->

											<!--{/if}-->

					

											<!--{if empty($invite) && $this->setting['regstatus'] == 2 && !$invitestatus}-->

											<div class="rfm">

												<table>

													<tr>

														<th><span class="rq">*</span><label for="invitecode">{lang invite_code}:</label></th>

														<td><input type="text" id="invitecode" name="invitecode" autocomplete="off" size="25" onblur="checkinvite()" tabindex="1" class="px" required /><!--{if $this->setting['inviteconfig']['buyinvitecode'] && $this->setting['inviteconfig']['invitecodeprice'] && ($this->setting[ec_tenpay_bargainor] || $this->setting[ec_tenpay_opentrans_chnid] || $this->setting[ec_account])}--><p><a href="misc.php?mod=buyinvitecode" target="_blank" class="xi2">{lang register_buyinvitecode}</a></p><!--{/if}--></td>

														<td class="tipcol"><i id="tip_invitecode" class="p_tip"><!--{if $this->setting['inviteconfig']['invitecodeprompt']}-->$this->setting[inviteconfig][invitecodeprompt]<!--{/if}--></i><kbd id="chk_invitecode" class="p_chk"></kbd></td>

													</tr>

												</table>

											</div>

											<!--{eval $invitecode = 1;}-->

											<!--{/if}-->

					

											<!--{if $_GET[action] != 'activation'}-->

												<div class="rfm">

													<table>

														<tr>

															<th><span class="rq">*</span><label for="{$this->setting['reginput']['username']}">{lang username}:</label></th>

															<td><input type="text" id="{$this->setting['reginput']['username']}" name="" placeholder="�������û���" class="px" tabindex="1" value="{echo dhtmlspecialchars($_GET[defaultusername])}" autocomplete="off" size="25" maxlength="15" required /></td>

															<td class="tipcol"><i id="tip_{$this->setting['reginput']['username']}" class="p_tip">{lang register_username_tips}</i><kbd id="chk_{$this->setting['reginput']['username']}" class="p_chk"></kbd></td>

														</tr>

													</table>

												</div>

					

												<div class="rfm">

													<table>

														<tr>

															<th><span class="rq">*</span><label for="{$this->setting['reginput']['password']}">{lang password}:</label></th>

															<td><input type="password" id="{$this->setting['reginput']['password']}" name="" placeholder="����������" size="25" tabindex="1" class="px" required /></td>

															<td class="tipcol"><i id="tip_{$this->setting['reginput']['password']}" class="p_tip">{lang register_password_tips}<!--{if $_G['setting']['pwlength']}-->, {lang register_password_length_tips1} $_G['setting']['pwlength'] {lang register_password_length_tips2}<!--{/if}--></i><kbd id="chk_{$this->setting['reginput']['password']}" class="p_chk"></kbd></td>

														</tr>

													</table>

												</div>

					

												<div class="rfm">

													<table>

														<tr>

															<th><span class="rq">*</span><label for="{$this->setting['reginput']['password2']}">{lang password_confirm}:</label></th>

															<td><input type="password" id="{$this->setting['reginput']['password2']}" name="" placeholder="��ȷ������" size="25" tabindex="1" value="" class="px" required /></td>

															<td class="tipcol"><i id="tip_{$this->setting['reginput']['password2']}" class="p_tip">{lang register_repassword_tips}</i><kbd id="chk_{$this->setting['reginput']['password2']}" class="p_chk"></kbd></td>

														</tr>

													</table>

												</div>

					

												<div class="rfm">

													<table>

														<tr>

															<th><!--{if !$_G['setting']['forgeemail']}--><span class="rq">*</span><!--{/if}--><label for="{$this->setting['reginput']['email']}">{lang email}:</label></th>

															<td><input type="text" id="{$this->setting['reginput']['email']}" name="" autocomplete="off" placeholder="�����������ַ" size="25" tabindex="1" class="px" value="$hash[0]" {if !$_G['setting']['forgeemail']}required{/if} /><br /><em id="emailmore">&nbsp;</em></td>

															<td class="tipcol"><i id="tip_{$this->setting['reginput']['email']}" class="p_tip">{lang register_email_tips}</i><kbd id="chk_{$this->setting['reginput']['email']}" class="p_chk"></kbd></td>

														</tr>

													</table>

												</div>

											<!--{/if}-->

					

											<!--{if $_GET[action] == 'activation'}-->

											<div id="activation_user" class="rfm">

												<table>

													<tr>

														<th>{lang username}:</th>

														<td><strong>$username</strong></td>

													</tr>

												</table>

											</div>

											<!--{/if}-->

					

											<!--{if $this->setting['regverify'] == 2}-->

											<div class="rfm">

												<table>

													<tr>

														<th><span class="rq">*</span><label for="regmessage">{lang register_message}:</label></th>

														<td><input id="regmessage" name="regmessage" class="px" autocomplete="off" size="25" tabindex="1" required /></td>

														<td class="tipcol"><i id="tip_regmessage" class="p_tip">{lang register_message1}</i></td>

													</tr>

												</table>

											</div>

											<!--{/if}-->

					

											<!--{if empty($invite) && $this->setting['regstatus'] == 3}-->

											<div class="rfm">

												<table>

													<tr>

														<th><label for="invitecode">{lang invite_code}:</label></th>

														<td><input type="text" name="invitecode" autocomplete="off" size="25" id="invitecode"{if $this->setting['regstatus'] == 2} onblur="checkinvite()"{/if} tabindex="1" class="px" /></td>

													</tr>

												</table>

											</div>

											<!--{eval $invitecode = 1;}-->

											<!--{/if}-->

					

											<!--{loop $_G['cache']['fields_register'] $field}-->

												<!--{if $htmls[$field['fieldid']]}-->

												<div class="rfm">

													<table>

														<tr>

															<th><!--{if $field['required']}--><span class="rq">*</span><!--{/if}--><label for="$field['fieldid']">$field[title]:</label></th>

															<td>$htmls[$field['fieldid']]</td>

															<td class="tipcol"><i id="tip_$field['fieldid']" class="p_tip"><!--{if $field['description']}--><!--{echo dhtmlspecialchars($field[description])}--><!--{/if}--></i><kbd id="chk_$field['fieldid']" class="p_chk"></kbd></td>

														</tr>

													</table>

												</div>

												<!--{/if}-->

											<!--{/loop}-->

										<!--{/if}-->

										<!--{hook/register_input}-->

					

										<!--{if $secqaacheck || $seccodecheck}-->

											<!--{block sectpl}--><div class="rfm code"><table><tr><th><span class="rq">*</span><sec>: </th><td><sec><br /><sec></td></tr></table></div><!--{/block}-->

											<!--{subtemplate common/seccheck}-->

										<!--{/if}-->

										<script>

											<!--{eval $vmid = 'c'.$sechash;}-->

											var secjsTimer = setInterval(

												function(){

													if($('seccodeverify_$vmid')){

														clearInterval(secjsTimer);

														$('seccodeverify_$vmid').setAttribute('tabindex','1');

														$('seccodeverify_$vmid').setAttribute('placeholder','��������֤��');

														$('checkseccodeverify_$vmid').className = 'codespan';

													}

												}

											,500);

										</script>

									</div>

								</div>

							</div>					

							<div id="layer_reginfo_b">

								<div class="rfm mbw bw0">

									<table width="100%">

										<tr>

											<th>&nbsp;</th>

											<td>

												<span id="reginfo_a_btn">

													<!--{if $_GET[action] != 'activation'}--><em>&nbsp;</em><!--{/if}-->

														<button class="pn pnc" id="registerformsubmit" type="submit" name="regsubmit" value="true" tabindex="1"><strong><!--{if $_GET[action] == 'activation'}-->{lang activation}<!--{else}-->{lang submit}<!--{/if}--></strong></button>

													<!--{if $bbrules}-->

														<input type="checkbox" class="pc" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" /> <label for="agreebbrule">{lang agree}<a href="javascript:;" onclick="showBBRule()">{lang rulemessage}</a></label>

													<!--{/if}-->

												</span>

											</td>

											<td><!--{if $this->setting['sitemessage'][register]}--><a href="javascript:;" id="custominfo_register" class="y"><img src="{IMGDIR}/info_small.gif" alt="{lang faq}" /></a><!--{/if}--></td>

										</tr>

									</table>

								</div>

								<!--{if !empty($_G['setting']['pluginhooks']['register_logging_method'])}-->

									<div class="rfm bw0 {if empty($_GET['infloat'])} mbw{/if}">

										<hr class="l" />

										<table>

											<tr>

												<th>{lang login_method}:</th>

												<td><!--{hook/register_logging_method}--></td>

											</tr>

										</table>

									</div>

								<!--{/if}-->

							</div>

						</form>

					<!--{/if}-->

					<!--{hook/register_bottom}-->

				</div>

				<!--{if !empty($_G['setting']['pluginhooks']['logging_method'])}-->

				<div class="uc-member-side y">

					<span>Ҳ��ʹ�������˺�<br>��ע�����һ��</span>

					<p class="cl"><!--{hook/logging_method}--></p>

				</div>

				<!--{/if}-->

			</div>

		</div>

		<div class="uc-member-foot">

			<div class="wp cl">

				<div class="z">Powered by <a href="http://www.discuz.net" target="_blank">Discuz!</a> <em>$_G['setting']['version']</em> <!--{if !empty($_G['setting']['boardlicensed'])}--> <a href="http://license.comsenz.com/?pid=1&host=$_SERVER[HTTP_HOST]" target="_blank">Licensed</a><!--{/if}--> ����֧�֣�<a href="http://www.uc-net.com" target="_blank">�Ŵ�����</a><!--{if $_G['setting']['icp']}--> <a href="http://www.miitbeian.gov.cn/" target="_blank">$_G['setting']['icp']</a><!--{/if}--></div>

				<div class="y"><!--{loop $_G['setting']['footernavs'] $nav}--><!--{if $nav['available'] && ($nav['type'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1)) ||

					!$nav['type'] && ($nav['id'] == 'stat' && $_G['group']['allowstatdata'] || $nav['id'] == 'report' && $_G['uid'] || $nav['id'] == 'archiver' || $nav['id'] == 'mobile' || $nav['id'] == 'darkroom'))}--><span class="pipe">/</span>$nav[code]<!--{/if}--><!--{/loop}-->			

			<!--{if $_G['setting']['statcode']}--><span class="pipe">/</span>$_G['setting']['statcode']<!--{/if}--> <!--{hook/global_footerlink}--> <!--{if $_G['setting']['site_qq']}--><span class="pipe">/</span><a href="http://wpa.qq.com/msgrd?V=3&uin=$_G['setting']['site_qq']&Site=$_G['setting']['bbname']&Menu=yes&from=discuz" target="_blank" title="QQ">�ͷ�QQ��{$_G['setting']['site_qq']}</a><!--{/if}--></div>

			</div>

		</div>

		<div id="layer_regmessage"class="f_c blr nfl" style="display: none">

			<div class="c"><div class="alert_right">

				<div id="messageleft1"></div>

				<p class="alert_btnleft" id="messageright1"></p>

			</div>

		</div>

		<div id="layer_bbrule" style="display: none">

		<div class="c" style="width:700px;height:350px;overflow:auto">$bbrulestxt</div>

		<p class="fsb pns cl hm">

			<button class="pn pnc" onclick="$('agreebbrule').checked = true;hideMenu('fwin_dialog', 'dialog');{if $this->setting['sitemessage'][register] && ($bbrules && $bbrulesforce)}showRegprompt();{/if}"><span>{lang agree}</span></button>

			<button class="pn" onclick="location.href='$_G[siteurl]'"><span>{lang disagree}</span></button>

		</p>

		</div>

		

		<script type="text/javascript">

		var ignoreEmail = <!--{if $_G['setting']['forgeemail']}-->true<!--{else}-->false<!--{/if}-->;

		<!--{if $bbrules && $bbrulesforce}-->

			showBBRule();

		<!--{/if}-->

		<!--{if $this->showregisterform}-->

			<!--{if $sendurl}-->

			addMailEvent($('{$this->setting['reginput']['email']}'));

			<!--{else}-->

			addFormEvent('registerform', <!--{if $_GET[action] != 'activation' && !($bbrules && $bbrulesforce) && !empty($invitecode)}-->1<!--{else}-->0<!--{/if}-->);

			<!--{/if}-->

			<!--{if $this->setting['sitemessage'][register]}-->

				function showRegprompt() {

					showPrompt('custominfo_register', 'mouseover', '<!--{echo trim($this->setting['sitemessage'][register][array_rand($this->setting['sitemessage'][register])])}-->', $this->setting['sitemessage'][time]);

				}

				<!--{if !($bbrules && $bbrulesforce)}-->

					showRegprompt();

				<!--{/if}-->

			<!--{/if}-->

			function showBBRule() {

				showDialog($('layer_bbrule').innerHTML, 'info', '<!--{echo addslashes($this->setting['bbname']);}--> {lang rulemessage}');

				$('fwin_dialog_close').style.display = 'none';

			}

		<!--{/if}-->

		</script>

	</div>

<!--{template common/footer}-->