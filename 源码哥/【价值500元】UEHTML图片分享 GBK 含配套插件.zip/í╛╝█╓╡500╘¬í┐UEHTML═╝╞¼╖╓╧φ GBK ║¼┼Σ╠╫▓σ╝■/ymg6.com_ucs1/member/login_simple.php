<?php echo 'www.ymg6.com';exit;?>

<!--{eval $referer=$_SERVER["REQUEST_URI"];}-->

<div class="uc-user-login">

	<div class="uc-item uc-log">

		<a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href);return false;" hidefocus="true">{lang login}</a>

		<div class="uc-box">

			<div class="uc-con">

				<dl>

					<dd><a href="connect.php?mod=login&amp;op=init&amp;referer={$referer}&amp;statfrom=login"><i class="ico-soc-qq ico-gray"></i>��ѶQQ</a></li>

					<dd><a href="plugin.php?id=wechat:login"><i class="ico-soc-weixin ico-gray"></i>΢�ŵ�¼</a></li>

				</dl>

			</div>

		</div>

	</div>

	<div class="uc-item uc-reg">

		<a href="member.php?mod={$_G[setting][regname]}" hidefocus="true">ע��</a>

	</div>

</div>