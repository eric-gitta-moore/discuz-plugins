<?php echo 'www.ymg6.com';exit;?>

<!--{template common/header}-->

<div class="info-detail">

	<!--{hook/space_card_top}-->

	<div class="info-detail-layer">

		<div class="info-detail-con">

			<div class="info-detail-con-top cl">

				<div class="user-avatar">

					<a href="home.php?mod=space&uid=$space[uid]" target="_blank" title="{lang enter}{$space[username]}{lang someone_space}"><!--{avatar($space[uid],small)}--></a>

				</div>

				<div class="user-info">

					<!--{eval $user_data = DB::fetch_first("SELECT SUM(views) AS views FROM ".DB::table('forum_thread')." WHERE authorid=$space[uid]"); $user_view = empty($user_data['views'])?0:$user_data['views'];}-->

					<!--{eval $user_data = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid=$space[uid]");}-->

					<div class="cl">

						<a href="home.php?mod=space&uid={$space[uid]}" class="username" target="_blank" title="{lang enter}{$space[username]}{lang someone_space}">{$space[username]}</a>

						<!--{if $_G['uid'] !== $space[uid]}-->

							<a class="btn" href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" id="a_sendpm_$space[uid]" onclick="showWindow('showMsgBox', this.href, 'get', 0)"><i class="ico-message ico-white"></i>��˽��</a>

							<!--{eval $follow = 0;}-->

							<!--{eval $follow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $space[uid]);}-->

							<!--{if !$follow}-->

								<a id="followmod" class="btn green" onclick="showWindow(this.id, this.href, 'get', 0);followmod_change(this,'{FORMHASH}','$space[uid]');" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"><i class="ico-plus ico-white"></i>�ӹ�ע</a>

							<!--{else}-->

								<a id="followmod" class="btn orange" onclick="showWindow(this.id, this.href, 'get', 0);followmod_change(this,'{FORMHASH}','$space[uid]');" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]"><i class="ico-minus ico-white"></i>�ѹ�ע</a>

							<!--{/if}-->

						<!--{else}-->

							<a class="btn" href="home.php?mod=spacecp&ac=avatar">����ͷ��</a>

							<a class="btn green" href="home.php?mod=spacecp&ac=profile">�޸�����</a>

						<!--{/if}-->

					</div>

					<div class="cl">

						<span>{if $space[sightml]}$space[sightml]{else}��һ������ʲôҲû����{/if}</span>

					</div>

				</div>

			</div>

			<div class="info-detail-con-mid cl">

				<table class="ucinfo">

					<tr>

						<td><i class="ico-gray ico-fire"></i>������$user_view</td>

						<td><i class="ico-gray ico-user"></i>��˿��$user_data['follower']</td>

						<td><i class="ico-gray ico-book"></i>��Ʒ��$user_data['threads']</td>

					</tr>

				</table>

			</div>

			<!--{hook/space_card_baseinfo_middle}-->

			<div class="info-detail-con-bot cl">

				<!--{eval $userthread = C::t('forum_thread')->fetch_all_by_authorid($space[uid], 0,6);}-->

				<ul class="cl">

				<!--{loop $userthread $item}-->

					<li>

						<a href="forum.php?mod=viewthread&tid={$item['tid']}" title="$item[subject] by $item[author]" target="_blank">

							<!--{if $item['cover']}-->

								<!--{eval $item['coverpath'] = ($item['cover'] < 0 ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/threadcover/'.substr(md5($item['tid']), 0, 2).'/'.substr(md5($item['tid']), 2, 2).'/'.$item['tid'].'.jpg';}-->

								<img src="$item['coverpath']" alt="$item[subject] by $item[author]" width="120" height="77" />

							<!--{else}-->

								<span class="nopic s" style="width:120px; height:77px;" title="$item[subject] by $item[author]"></span>

							<!--{/if}-->

						</a>

					</li>

				<!--{/loop}-->

				</ul>

			</div>

			<!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->

			<div class="info-detail-con-manage">

				<div class="info-detail-con-manage-con">

					<!--{if checkperm('allowedituser')}-->

						<a href="{if $_G[adminid] == 1}admin.php?action=members&operation=search&username=$encodeusername&submit=yes&frames=yes{else}forum.php?mod=modcp&action=member&op=edit&uid=$space[uid]{/if}" target="_blank" class="xi1">{lang user_edit}</a>

					<!--{/if}-->

					<!--{if checkperm('allowbanuser')}-->

						<a href="{if $_G[adminid] == 1}admin.php?action=members&operation=ban&username=$encodeusername&frames=yes{else}forum.php?mod=modcp&action=member&op=ban&uid=$space[uid]{/if}" target="_blank" class="xi1">{lang user_ban}</a>

					<!--{/if}-->

					<a href="forum.php?mod=modcp&action=thread&op=post&do=search&searchsubmit=1&users=$encodeusername" target="_blank" class="xi1">{lang manage_post}</a>

				</div>

			</div>

			<!--{/if}-->

		</div>

	</div>

</div>

<!--{template common/footer}-->