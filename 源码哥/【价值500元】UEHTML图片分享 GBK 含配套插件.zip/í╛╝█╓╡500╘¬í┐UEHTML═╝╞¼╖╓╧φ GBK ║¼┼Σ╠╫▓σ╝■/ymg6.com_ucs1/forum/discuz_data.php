<?php echo 'www.ymg6.com';exit;?>

<!--{eval}-->

	if($uctype!==0){

		$ucgtw = $uc['global']['thumb_width'] ? $uc['global']['thumb_width'] : 280;

		$ucgth = $uc['global']['thumb_height'] ? $uc['global']['thumb_height'] : 180;

		$uctw=$uc['index']['width'] ? $uc['index']['width'] : $ucgtw;

		$ucth=$uc['index']['height'] ? $uc['index']['height'] : $ucgth;

		$ucch=$uc['index']['con'] ? $uc['index']['con'] : 130;

		$uccm=$uc['index']['word'] ? $uc['index']['word'] : 200;

		$page = intval($_G['page']) ? intval($_G['page']) : 1;

		$limit = intval($uc['index']['list_limit']) ? intval($uc['index']['list_limit']) : 22;

		$start = ($page-1)*$limit<0?0:($page-1)*$limit;

		$ucsort = $_GET['type'] ? $_GET['type'] : $uc['index']['list_sort'];

		$ucdate = $_GET['date'] ? $_GET['date'] : 0;

		$ucorder = $_GET['order'];

		if(intval($_G['fid']) && intval($gid) && intval($_G['fid']) == intval($gid)){

			$ginfo = forumselect(FALSE, 1);

			foreach($ginfo[$_G['fid']][sub] as $key => $val){

				$ucfids[] = $key;

			}

		} else {

			$ucfids = $uc['index']['list_fids'] ? $uc['index']['list_fids'] : 0;

		}

		$ucover = $uc['index']['list_iscover'] ? $uc['index']['list_iscover'] : 0;

		switch ($ucsort) {

			case 'hot' :

				$addsql = (empty($addsql)?' ':' AND').' heats>=3';

				break;

			case 'digest' :

				$addsql = (empty($addsql)?' ':' AND').' digest>0';

				break;

			default :

				$addsql = '';

		}

		if(getglobal('setting/followforumid')) {

			$addsql .= (empty($addsql) ? ' ' : ' AND').DB::field('fid', getglobal('setting/followforumid'), '<>');

		}

		$ucfids = dintval($ucfids, true);

		if($ucfids) {

			$fidsql = is_array($ucfids) && $ucfids ? ' fid IN('.dimplode($ucfids).')' : ' fid='.$ucfids;

		}

		if($ucdate) {

			$addsql .= (empty($addsql)?' ':' AND').' dateline > '.(TIMESTAMP - intval($ucdate));

		}

		if($ucsort == 'newthread') {

			$orderby = 'tid';

		} elseif($ucsort == 'reply') {

			$orderby = 'replies';

		} elseif($ucsort == 'heart') {

			$orderby = 'recommends';

		} else {

			$orderby = 'lastpost';

		}

		if($ucover == 1) {

			$addsql .= (empty($addsql)?' ':' AND').' cover > 0';

		}

		$cousql = $addsql.(empty($addsql)?' ':' AND').' displayorder>=0 ORDER BY '.$orderby.' DESC ';

		$addsql .= (empty($addsql)?' ':' AND').' displayorder>=0 ORDER BY '.$orderby.' DESC '.DB::limit($start, $limit);

		$list = DB::fetch_all("SELECT * FROM ".DB::table('forum_thread')." WHERE ".$fidsql.(empty($fidsql)?' ':' AND').$addsql);

		$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_thread')." WHERE ".$fidsql.(empty($fidsql)?' ':' AND').$cousql);

		if($count>0) {

			foreach($list as $k => $v){

				$list[$k]['coverpath'] = $list[$k]['cover']?(($list[$k]['cover'] < 0 ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/threadcover/'.substr(md5($list[$k]['tid']), 0, 2).'/'.substr(md5($list[$k]['tid']), 2, 2).'/'.$list[$k]['tid'].'.jpg'):'';

			}

			$multipage = multi($count, $limit, $page, 'forum.php?'.(intval($gid)?'gid='.intval($gid):'').$pageavtion);

		}

		if(intval($gid)) {

			$ucatlist = forumselect(FALSE, 1);

			$forumname = $ucatlist[$gid]['sub'];

		}

	}

<!--{/eval}-->