<?php echo 'www.ymg6.com';exit;?>

		<div class="fl" style="border:0;">

			<div class="uc-ngrid cl">

				<table width="100%" cellspacing="0" cellpadding="0"><tr>

				<tr>

					<!--{if !$_G['setting']['grid']['gridtype']}-->

					<th class="uc-ngrid-1-tit"><span class="tit_newimg"></span>{lang latest_images}</th>

					<!--{/if}-->

					<th class="uc-ngrid-2-tit"><span class="tit_subject"></span>{lang collection_lastthread}</th>

					<th class="uc-ngrid-3-tit"><span class="tit_replay"></span>{lang show_newthreads}</th>

					<th class="uc-ngrid-4-tit"><span class="tit_hottie"></span>{lang hot_thread}</th>

					<!--{if $_G['setting']['grid']['gridtype']}-->

					<th class="uc-ngrid-5-tit"><span class="tit_goodtie"></span>{lang post_digest_thread}</th>

					<!--{/if}-->

				</tr>

				<tr>

				<!--{if !$_G['setting']['grid']['gridtype']}-->

					<td valign="top" class="uc-ngrid-1">

						<div class="uc-ngrid-slide">

							<div id="fade_focus" class="uc-ngrid-slide-box">

								<div class="loading"></div>

								<ul style="display:none;">

									<!--{loop $grids['slide'] $stid $svalue}-->

									<li><a href="{$svalue[url]}" target="_blank" style="background-image:url({$svalue[image]})" title="{$svalue[subject]}"></a></li>

									<!--{/loop}-->

								</ul>

							</div>

						</div>

					</td>

					<script language="javascript" type="text/javascript">

						var interv = 5000;

						var interv2 = 10;

						var opac1 = 60;

						var source = "fade_focus"

						function getTag(tag, obj) {

							if (obj == null) {

								return document.getElementsByTagName(tag)

							} else {

								return obj.getElementsByTagName(tag)

							}

						}

						var opac = 0,

						j = 0,

						num,

						timer, timer2, timer3;

						var id = $(source);

						id.removeChild(getTag("div", id)[0]);

						var li = getTag("li", id);

						var div = document.createElement("div");

						var title = document.createElement("div");

						var span = document.createElement("span");

						var button = document.createElement("div");

						button.className = "uc-ngrid-slide-num";

						for (var i = 0; i < li.length; i++) {

							var a = document.createElement("a");

							a.innerHTML = i + 1;

							a.onclick = function() {

								clearTimeout(timer);

								clearTimeout(timer2);

								clearTimeout(timer3);

								j = parseInt(this.innerHTML) - 1;

								opac = 0;

								fadeon();

							};

							a.className = "";

							a.onmouseover = function() {

								this.className = "on"

							};

							a.onmouseout = function() {

								this.className = "";

								sc(j)

							};

							button.appendChild(a);

						}

					

						function alpha(obj, n) {

							if (document.all) {

								obj.style.filter = "alpha(opacity=" + n + ")";

							} else {

								obj.style.opacity = (n / 100);

							}

						}

						function sc(n) {

							for (var i = 0; i < li.length; i++) {

								button.childNodes[i].className = "";

							};

							button.childNodes[n].className = "on";

						}

						title.className = "uc-ngrid-slide-tit";

						title.appendChild(span);

						alpha(title, opac1);

						id.className = "uc-ngrid-slide-box";

						div.className = "uc-ngrid-slide-img";

						id.appendChild(div);

						id.appendChild(title);

						id.appendChild(button);

						var fadeon = function() {

							opac += 5;

							div.innerHTML = li[j].innerHTML;

							span.innerHTML = getTag("a", li[j])[0].title;

							alpha(div, opac);

							sc(j);

							num = -2;

							if (opac < 100) {

								timer = setTimeout(fadeon, interv2)

							} else {

								timer2 = setTimeout(fadeout, interv);

							};

						}

						var fadeout = function() {

							opac -= 5;

							div.innerHTML = li[j].innerHTML;

							alpha(div, opac);

							num = 2;

							if (opac > 0) {

								timer = setTimeout(fadeout, interv2)

							} else {

								if (j < li.length - 1) {

									j++

								} else {

									j = 0

								};

								fadeon()

							};

						}

						fadeon();

					</script>

				<!--{/if}-->

				<td valign="top" class="uc-ngrid-2">

					<div class="uc-ngrid-list">

						<ul>

							<!--{loop $grids['newthread'] $thread}-->

								<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->

									<!--{eval $thread[tid]=$thread[closed];}-->

								<!--{/if}-->

								<li>

									<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if} title="$thread[oldsubject]">

										<span class="z">$thread[subject]</span>

										<span class="y">$thread[dateline]</span>

									</a>

								</li>

							<!--{/loop}-->

						</ul>

					</div>

				</td>

				<td valign="top" class="uc-ngrid-3">

					<div class="uc-ngrid-list">

						<ul>

							<!--{loop $grids['newreply'] $thread}-->

								<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->

									<!--{eval $thread[tid]=$thread[closed];}-->

								<!--{/if}-->

								<li>

									<a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if} title="$thread[oldsubject]">

										<span class="z">$thread[subject]</span>

										<span class="y">$thread[dateline]</span>

									</a>

								</li>

							<!--{/loop}-->

						</ul>

					</div>

				</td>

				<td valign="top" class="uc-ngrid-4"{if !$_G['setting']['grid']['gridtype']}style="border-right:0;"{/if}>

					<div class="uc-ngrid-list">

						<ul>

							<!--{loop $grids['hot'] $thread}-->

								<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->

									<!--{eval $thread[tid]=$thread[closed];}-->

								<!--{/if}-->

								<li>

									<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if} title="$thread[oldsubject]">

										<span class="z">$thread[subject]</span>

										<span class="y">{lang show}��$thread[views]</span>

									</a>

								</li>

							<!--{/loop}-->

						</ul>

					</div>

				</td>

				<!--{if $_G['setting']['grid']['gridtype']}-->

					<td valign="top" class="uc-ngrid-5">

						<div class="uc-ngrid-list">

							<ul>

								<!--{loop $grids['digest'] $thread}-->

									<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->

										<!--{eval $thread[tid]=$thread[closed];}-->

									<!--{/if}-->

									<li>

										<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if} title="$thread[oldsubject]">

											<span class="z">$thread[subject]</span>

											<span class="y">{lang show}��$thread[views]</span>

										</a>

									</li>

								<!--{/loop}-->

							</ul>

						</div>

					</td>

				<!--{/if}-->

				</tr>

				</table>

			</div>

		</div>