<?php echo 'www.ymg6.com';exit;?>

<!--{template common/header}-->

<!--{eval}-->

	$ucgtw = $uc['global']['thumb_width'] ? $uc['global']['thumb_width'] : 280;

	$ucgth = $uc['global']['thumb_height'] ? $uc['global']['thumb_height'] : 180;

	if($_G[fid]){

		if(in_array($_G[fid],$uc['layout']['list_type_1_fids'])) {

			$uclt=1;

			$uctw=$uc['layout']['list_type_1_width'] ? $uc['layout']['list_type_1_width'] : $ucgtw;

			$ucth=$uc['layout']['list_type_1_height'] ? $uc['layout']['list_type_1_height'] : $ucgth;

		} else if (in_array($_G[fid],$uc['layout']['list_type_2_fids'])) {

			$uclt=2;

			$uctw=$uc['layout']['list_type_2_width'] ? $uc['layout']['list_type_2_width'] : $ucgtw;

			$ucth=0;

		} else if(in_array($_G[fid],$uc['layout']['list_type_3_fids'])) {

			$uclt=3;

			$uctw=$uc['layout']['list_type_3_width'] ? $uc['layout']['list_type_3_width'] : $ucgtw;

			$ucth=$uc['layout']['list_type_3_height'] ? $uc['layout']['list_type_3_height'] : $ucgth;

			$ucch=$uc['layout']['list_type_3_con'] ? $uc['layout']['list_type_3_con'] : 130;

			$uccm=$uc['layout']['list_type_3_word'] ? $uc['layout']['list_type_3_word'] : 200;

		} else if(in_array($_G[fid],$uc['layout']['list_type_4_fids'])) {

			$uclt=4;

			$uctw=$uc['layout']['list_type_4_width'] ? $uc['layout']['list_type_4_width'] : $ucgtw;

			$ucth=0;

			$uccm=$uc['layout']['list_type_4_word'] ? $uc['layout']['list_type_4_word'] : 200;

		} else {

			$uclt=0;

			$uctw=$ucgtw;

			$ucth=$ucgth;

		}

	}

<!--{/eval}-->



<!--{if $_G['forum']['ismoderator']}-->

	<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>

<!--{/if}-->

<style id="diy_style" type="text/css"></style>

<!--[diy=diynavtop]--><div id="diynavtop" class="area"></div><!--[/diy]-->

<!--{if $uclt == 0}-->

<div id="pt" class="bm cl"><div class="z"><a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a><em>&raquo;</em><a href="forum.php">{$_G[setting][navs][2][navname]}</a>$navigation</div></div>

<!--{/if}-->

<!--{ad/text/wp a_t}-->

<div class="wp"><!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]--></div>









<div id="ct" class="wp cl{if $_G['forum']['allowside'] && $uclt==0} ct2{/if}"{if $leftside && $uclt==0} style="margin-left:{$_G['leftsidewidth_mwidth']}px"{/if}>

	<!--{if $uclt == 0}-->

	<div class="uc-postlist-top cl">

		<!--{eval}-->

			if($_G['uid']){$favfids = C::t('home_favorite')->fetch_all_by_uid_idtype($_G['uid'], 'fid');foreach($favfids as $val){if($val['id'] == $_G[fid]){$isFav = $val['favid'];}}}

		<!--{/eval}-->

		<div class="uc-postlist-top-favorite">

			<!--{if $isFav}-->

				<a id="a_delete" href="home.php?mod=spacecp&ac=favorite&op=delete&favid={$isFav}" onclick="showWindow(this.id, this.href, 'get', 0)">+ ȡ����ע</a>

			<!--{else}-->

				<a id="a_favorite" href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" onclick="showWindow(this.id, this.href, 'get', 0)">+ ��ע���</a>

			<!--{/if}-->

			<span>������<i id="number_favorite_num">{if $_G[forum][favtimes]}$_G[forum][favtimes]{else}0{/if}</i>��ע</span>

		</div>

		<div class="uc-postlist-top-manage">

			<!--{if rssforumperm($_G['forum']) && $_G[setting][rssstatus] && !$_GET['archiveid'] && !$subforumonly}-->

				<a href="forum.php?mod=rss&fid=$_G[fid]&auth=$rssauth" class="fa_rss" target="_blank" title="RSS">{lang rss_subscribe_this}</a>

			<!--{/if}-->

			<!--{if !empty($forumarchive)}-->

				<i class="pipe">/</i>

				<a id="forumarchive" href="javascript:;" class="fa_achv" onmouseover="showMenu(this.id)"><!--{if $_GET['archiveid']}-->$forumarchive[$_GET['archiveid']]['displayname']<!--{else}-->{lang forum_archive}<!--{/if}--></a>

			<!--{/if}-->

			<!--{hook/forumdisplay_forumaction}-->

			<!--{if $_G['forum']['ismoderator']}-->

			<!--{if $_G['forum']['recyclebin']}-->

				<i class="pipe">/</i>

				<a href="{if $_G['adminid'] == 1}admin.php?mod=forum&action=recyclebin&frames=yes{elseif $_G['forum']['ismoderator']}forum.php?mod=modcp&action=recyclebin&fid=$_G[fid]{/if}" class="fa_bin" target="_blank">{lang forum_recyclebin}</a>

			<!--{/if}-->

			<!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->

				<i class="pipe">/</i>

				<!--{if $_G['forum']['status'] != 3}-->

					<a href="forum.php?mod=modcp&fid=$_G[fid]">{lang modcp}</a>

				<!--{else}-->

					<a href="forum.php?mod=group&action=manage&fid=$_G[fid]">{lang modcp}</a>

				<!--{/if}-->

			<!--{/if}-->

			<!--{hook/forumdisplay_modlink}-->

			<!--{/if}-->

		</div>

		<div class="uc-postlist-top-catbanner"><div class="img"{if $_G[forum][banner] && !$subforumonly} style="background-image:url({$_G[forum][banner]})"{/if} title="$_G['forum'][name]" ></div></div>

		<div class="uc-postlist-top-catinfo">

			<div class="top cl">

				<div class="z">

					<h1 class="z"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">$_G['forum'][name]</a></h1>

					<div class="z">

					<!--{if (!empty($_G[forum][domain]) && !empty($_G['setting']['domain']['root']['forum'])) || $moderatedby || ($_G['page'] == 1 && $_G['forum']['rules'])}-->

					<!--{if $moderatedby}-->

					<span>{lang forum_modedby}: $moderatedby<i class="pipe">/</i></span>

					<!--{/if}-->

					<!--{/if}-->

					<!--{if !$subforumonly}-->

						<span>{lang index_today}: <strong class="xi1">$_G[forum][todayposts]</strong><!--{if $_G[forum][todayposts]}--><b class="ico-arrow-{if $_G[forum][todayposts] < $_G[forum][yesterdayposts]}down{else}up{/if} ico-gray">&nbsp;</b><!--{/if}--><i class="pipe">/</i></span>

						<span>{lang index_threads}: <strong class="xi1">$_G[forum][threads]</strong><!--{if $_G[forum][rank]}--><i class="pipe">/</i><!--{/if}--></span>

						<!--{if $_G[forum][rank]}-->

						<span>{lang rank}: <strong class="xi1" title="{lang previous_rank}:$_G[forum][oldrank]">$_G[forum][rank]</strong><b class="ico-arrow-{if $_G[forum][rank] <= $_G[forum][oldrank]}up{else}down{/if} ico-gray">&nbsp;</b></span>

						<!--{/if}-->

					<!--{/if}-->

					</div>

				</div>

				<div class="y"><!--{if !$_GET['archiveid']}--><a href="javascript:;" id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})"{if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} title="{lang send_posts}">����������</a><!--{/if}--><!--{hook/forumdisplay_postbutton_top}--></div>

			</div>

			<div class="bot cl">

				<!--{if (!empty($_G[forum][domain]) && !empty($_G['setting']['domain']['root']['forum'])) || $moderatedby || ($_G['page'] == 1 && $_G['forum']['rules'])}-->

					<!--{if !empty($_G[forum][domain]) && !empty($_G['setting']['domain']['root']['forum'])}-->

						<div class="pbn">{lang forum_domain}: <a href="http://{$_G[forum][domain]}.{$_G['setting']['domain']['root']['forum']}" id="group_link">http://{$_G[forum][domain]}.{$_G['setting']['domain']['root']['forum']}</a></div>

					<!--{/if}-->

					<!--{if $_G['forum']['rules']}-->

						<div id="forum_rules_{$_G[fid]}" style="$collapse['forum_rules'];">

							<div class="xg2">$_G['forum'][rules]</div>

						</div>

					<!--{else}-->

						<div>������޼��</div>

					<!--{/if}-->

				<!--{/if}-->

			</div>

		</div>

	</div>

	<!--{/if}-->

	<!--{hook/forumdisplay_top}-->

	

	<div class="mn">

		

		<!--{if $subexists && $_G['page'] == 1 && $uclt == 0}-->

			<!--{template forum/forumdisplay_subforum}-->

		<!--{/if}-->

		

		

		<div class="drag">

			<!--[diy=diy4]--><div id="diy4" class="area"></div><!--[/diy]-->

		</div>

		<!--{if !empty($_G['forum']['recommendlist']) && $uclt == 0}-->

			<div class="bm bmw">

				<div class="bm_h cl">

					<h2>{lang forum_recommend}</h2>

				</div>

				<div class="bm_c cl">

					<!--{subtemplate forum/recommend}-->

				</div>

			</div>

		<!--{/if}-->

		

		<!--{hook/forumdisplay_middle}-->

		

		<!--{if !$subforumonly}-->

			<!--{if $recommendgroups && !$_G['forum']['allowside'] && $uclt == 0}-->

				<!--{template forum/forumdisplay_groups}-->

			<!--{/if}-->

			<!--{if $threadmodcount && $uclt == 0}--><div class="bm"><div class="ntc_l hm xi2"><strong>{lang forum_moderate_unhandled}</strong></div></div><!--{/if}-->

			<!--{if $livethread && $uclt == 0}-->

				<!--{template forum/forumdisplay_live}-->

			<!--{/if}-->

			

			

			<!--{if empty($_G['forum']['sortmode'])}-->

				<!--{subtemplate forum/forumdisplay_list}-->

			<!--{else}-->

				<!--{subtemplate forum/forumdisplay_sort}-->

			<!--{/if}-->

		<!--{/if}-->

	

	

	

		<!--[diy=diyfastposttop]--><div id="diyfastposttop" class="area"></div><!--[/diy]-->

		<!--{if $fastpost && $uclt == 0}-->

			<!--{template forum/forumdisplay_fastpost}-->

		<!--{/if}-->

		<!--{hook/forumdisplay_bottom}-->

		<!--[diy=diyforumdisplaybottom]--><div id="diyforumdisplaybottom" class="area"></div><!--[/diy]-->

		

	</div>

	

	<!--{if $_G['forum']['allowside'] && $uclt == 0}-->

		<div class="sd">

			<!--{hook/forumdisplay_side_top}-->

			<!--{if !$subforumonly}-->

				<div class="bm">

					<div class="bm_h">

						<h2>{lang their}: <!--{eval echo cutstr($_G['cache']['forums'][$_G['forum']['fup']]['name'], 22, '')}--></h2>

					</div>

					<div class="bm_c">

						<ul class="xl xl2 cl">

						<!--{loop $_G['cache']['forums'] $bforum}-->

							<!--{if $bforum['fup'] == $_G['forum']['fup'] && $bforum['status']}-->

								<li><a href="forum.php?mod=forumdisplay&fid=$bforum[fid]">$bforum['name']</a></li>

							<!--{/if}-->

						<!--{/loop}-->

						</ul>

					</div>

				</div>



				<!--{if $recommendgroups}-->

				<div class="bm">

					<div class="bm_h cl">

						<h2>{lang recommended_groups}</h2>

					</div>

					<div class="bm_c cl">

						<ul class="ml mls cl">

						<!--{loop $recommendgroups $key $group}-->

							<li>

							<a href="forum.php?mod=group&fid=$group[fid]" title="$group[name]" target="_blank" class="avt"><img src="$group[icon]" alt="$group[name]"></a>

							<p><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a></p>

							</li>

						<!--{/loop}-->

						</ul>

					</div>

				</div>

				<!--{/if}-->



				<!--{if !($_G['forum']['simple'] & 1) && $_G[setting][whosonlinestatus]}-->

					<div class="bm">

						<!--{if $detailstatus}-->

						<div class="bm_h cl">

							<span class="o y"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&page=$page&showoldetails=no#online"><img src="{IMGDIR}/collapsed_no.gif" alt="" /></a></span>

							<h2>{lang forum_activeusers} ($onlinenum)</h2>

						</div>

						<div class="bm_c">

							<ul class="ml mls cl">

							<!--{loop $whosonline $key $online}-->

								<li>

								<a href="home.php?mod=space&uid=$online[uid]" class="avt"><!--{avatar($online[uid],small)}--></a>

								<!--{if $online['uid']}-->

									<p><a href="home.php?mod=space&uid=$online[uid]">$online[username]</a></p>

								<!--{else}-->

									<p>$online[username]</p>

								<!--{/if}-->

								<span>$online[lastactivity]{LF}</span>

								</li>

							<!--{/loop}-->

							</ul>

						</div>

						<!--{else}-->

						<div class="bm_h cl">

							<span class="o y"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&page=$page&showoldetails=yes#online" class="nobdr"><img src="{IMGDIR}/collapsed_yes.gif" alt="" /></a></span>

							<h2>{lang forum_activeusers} ($onlinenum)</h2>

						</div>

						<!--{/if}-->

					</div>

				<!--{/if}-->

			<!--{/if}-->

			<div class="drag">

				<!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->

			</div>

			<!--{hook/forumdisplay_side_bottom}-->

		</div>

	<!--{/if}-->

</div>

</div>	

	













<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->

	<ul class="p_pop" id="newspecial_menu" style="display: none">

		<!--{if !$_G['forum']['allowspecialonly']}--><li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">{lang post_newthread}</a></li><!--{/if}-->

		<!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->

			<!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->

				<!--{if $_G['forum']['threadsorts']['show'][$id]}-->

					<li class="popupmenu_option"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id">$threadsorts</a></li>

				<!--{/if}-->

			<!--{/loop}-->

		<!--{/if}-->

		<!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->

		<!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->

		<!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->

		<!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->

		<!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->

		<!--{if $_G['setting']['threadplugins']}-->

			<!--{loop $_G['forum']['threadplugin'] $tpid}-->

				<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->

					<li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url(source/plugin/$tpid/$_G[setting][threadplugins][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>

				<!--{/if}-->

			<!--{/loop}-->

		<!--{/if}-->

	</ul>

<!--{/if}-->





<!--{if $_G['setting']['threadmaxpages'] > 1 && $page && !$subforumonly && $uclt == 0}-->

	<script type="text/javascript">document.onkeyup = function(e){keyPageScroll(e, <!--{if $page > 1}-->1<!--{else}-->0<!--{/if}-->, <!--{if $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->1<!--{else}-->0<!--{/if}-->, 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}', $page);}</script>

<!--{/if}-->



<!--{if empty($_G['forum']['picstyle']) && $_GET['orderby'] == 'lastpost' && empty($_GET['filter']) && $uclt == 0 }-->

	<script type="text/javascript">checkForumnew_handle = setTimeout(function () {checkForumnew($_G[fid], lasttime);}, checkForumtimeout);</script>

<!--{/if}-->

<div class="wp mtn">

	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->

</div>

<!--{template common/footer}-->

