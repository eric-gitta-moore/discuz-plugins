<?php echo 'www.ymg6.com';exit;?>

<div class="uc-catlist">

	<div class="bm bmw fl{if $_G['forum']['forumcolumns']} flg{/if}">

		<div class="bm_h cl">

			<span class="o"><img id="recommendgroups_{$_G[forum][fid]}_img" src="{IMGDIR}/$collapseimg[recommendgroups]" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('recommendgroups_{$_G[forum][fid]}');" /></span>

			<h2>{lang recommended_groups}</h2>

		</div>

		<div class="bm_c" id="recommendgroups_{$_G[forum][fid]}" style="$collapse[recommendgroups]">

			<table cellspacing="0" cellpadding="0" class="fl_tb">

				<!--{loop $recommendgroups $key $group}-->

				<!--{if $_G['forum']['forumcolumns']}-->

					<!--{if $key && ($key % $_G['forum']['forumcolumns'] == 0)}-->

						</tr>

						<!--{if $key < $_G['forum']['forumcolumns']}-->

							<tr class="fl_row">

						<!--{/if}-->

					<!--{/if}-->

					<td class="fl_g">

						<div class="fl_g_inner">

							<div class="fl_icn_g">

								<a href="forum.php?mod=group&fid=$group[fid]" title="$group[name]" target="_blank"><img src="$group[icon]" alt="$group[name]" /></a>

							</div>

							<dl>

								<dt><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><span class="xg1 xw0"> ($group[membernum] {lang activity_member_unit})</span></dt>

								<dd><em>{lang forum_threads}: $group[threads]</em></dd>

								<dd>

									<!--{if is_array($group['lastpost'])}-->

										<!--{if $_G['forum']['forumcolumns'] < 3}-->

										<a href="forum.php?mod=redirect&tid=$group[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($group[lastpost][subject], 30)}--></a> <cite>$group[lastpost][dateline] <!--{if $group['lastpost']['author']}--><a href="home.php?mod=space&username={$group[lastpost][encode_author]}">{$group[lastpost][author]}</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>

										<!--{else}-->

											<a href="forum.php?mod=redirect&tid=$group[lastpost][tid]&goto=lastpost#lastpost" class="xi2">$group[lastpost][dateline]</a>

										<!--{/if}-->				<!--{else}-->

									{lang never}

									<!--{/if}-->

								</dd>

							</dl>

						</div>

					</td>

				<!--{else}-->

					<tr {if $key != 0}class="fl_row"{/if}>

						<td class="fl_icn">

							<a href="forum.php?mod=group&fid=$group[fid]" title="$group[name]" target="_blank"><img src="$group[icon]" alt="$group[name]" /></a>

						</td>

						<td>

							<h2><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><span class="xg1 xw0"> ($group[membernum] {lang activity_member_unit})</span></h2>

							<p><!--{echo cutstr($group[description], 100)}--></p>

						</td>

						<td class="fl_i">

							<span class="xi2">$group[threads] {lang index_threads}</span>

						</td>

						<td class="fl_by">

							<div>

								<!--{if is_array($group['lastpost'])}-->

								<a href="forum.php?mod=redirect&tid=$group[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($group[lastpost][subject], 30)}--></a> <cite>$group[lastpost][dateline] <!--{if $group['lastpost']['author']}--><a href="home.php?mod=space&username={$group[lastpost][encode_author]}">{$group[lastpost][author]}</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>

								<!--{else}-->

								{lang never}

								<!--{/if}-->

							</div>

						</td>

					</tr>

				<!--{/if}-->

				<!--{/loop}-->

			</table>

		</div>

	</div>

</div>