<?php echo 'www.ymg6.com';exit;?>

<script type="text/javascript">var postminchars = parseInt('$_G[setting][minpostsize]'),postmaxchars = parseInt('$_G[setting][maxpostsize]'), disablepostctrl = parseInt('{$_G[group][disablepostctrl]}');</script>



<div class="uc-comment-fast-top" id="f_pst">

<!--{if $_G['uid']}-->

	<p>��ǰ�˺ţ�<a href="home.php?mod=space&uid=$_G[uid]" c="1" target="_blank">{$_G[member][username]}</a><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">�˳�</a></p>

	<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes{if $_GET['ordertype'] != 1}&infloat=yes&handlekey=fastpost{/if}{if $_GET[from]}&from=$_GET[from]{/if}"{if $_GET['ordertype'] != 1} onSubmit="return fastpostvalidate(this)"{/if}>

		<!--{hook/viewthread_fastpost_content}-->

		<span id="fastpostreturn"></span>

		<div class="uc-comment-avatar"><a href="home.php?mod=space&uid=$_G[uid]" c="1" target="_blank"><!--{echo avatar($_G['uid'])}--></a></div>

		<div class="uc-comment-form" id="fastposteditor">

			<input type="hidden" name="formhash" value="{FORMHASH}" />

			<input type="hidden" name="usesig" value="$usesigcheck" />

			<input type="hidden" name="subject" value="  " />

			<textarea rows="6" cols="80" name="message" id="fastpostmessage" onKeyDown="seditor_ctlent(event, {if $_GET['ordertype'] != 1}'fastpostvalidate($(\'fastpostform\'))'{else}'$(\'fastpostform\').submit()'{/if});" tabindex="4"{eval echo getreplybg($_G['forum']['replybg']);}></textarea>

			<button {if $allowpostreply}type="submit" {elseif !$_G['uid']}type="button" onclick="showWindow('login', 'member.php?mod=logging&action=login&guestmessage=yes')" {/if}{if !$seccodecheck}onmouseover="checkpostrule('seccheck_fastpost', 'ac=reply');this.onmouseover=null" {/if}name="replysubmit" value="replysubmit" tabindex="5">{lang post_newreply}</button>

		</div>

		<div class="uc-comment-toolbar cl">

			<!--{eval $seditor = array('fastpost', array('at', 'smilies'), !$allowfastpost ? 1 : 0);}-->

			<div id="fastpostsubmit"></div>

			<!--{hook/viewthread_fastpost_btn_extra}-->

			<!--{hook/viewthread_fastpost_ctrl_extra}-->

			<!--{subtemplate common/seditor}-->

			<!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->

			<label class="ftid sslt z">

				<select id="stand" name="stand">

					<option value="">{lang debate_viewpoint}</option>

					<option value="0">{lang debate_neutral}</option>

					<option value="1">{lang debate_square}</option>

					<option value="2">{lang debate_opponent}</option>

				</select>

			</label>

			<script type="text/javascript">simulateSelect('stand');</script>

			<!--{/if}-->

			<div id="seccheck_fastpost">

			<!--{if $allowpostreply && ($secqaacheck || $seccodecheck)}-->

				<!--{template forum/seccheck_post}-->

			<!--{/if}-->

			</div>

		</div>

	</form>

<!--{else}-->

	<p>ֻ�е�¼֮��ſ������ۣ�����<a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href);return false;" hidefocus="true">����</a>���е�¼</p>

<!--{/if}-->

</div>