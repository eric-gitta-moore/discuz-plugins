<?php echo 'www.ymg6.com';exit;?>

<div id="livethread" class="tl bm bmw uc-postlist-top-live cl" style="padding:10px 15px;">

	<div class="livethreadtitle vm">

		<span class="replynumber xg1">{lang reply} <span id="livereplies" class="xi1">$livethread[replies]</span></span>

		<a href="forum.php?mod=viewthread&tid=$livethread[tid]" target="_blank">$livethread[subject]</a> <img src="{IMGDIR}/livethreadtitle.png" />

	</div>

	<div class="livethreadcon">$livemessage</div>

	<div id="livereplycontentout">

		<div id="livereplycontent">

		</div>

	</div>

	<div id="liverefresh">{lang forum_live_newreply_refresh}</div>

	<div id="livefastreply">

		<form id="livereplypostform" method="post" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$livethread[tid]&replysubmit=yes&infloat=yes&handlekey=livereplypost&inajax=1" onsubmit="return livereplypostvalidate(this)">

			<div id="livefastcomment">

				<textarea id="livereplymessage" name="message" style="color:gray;<!--{if !$liveallowpostreply}-->display:none;<!--{/if}-->">{lang forum_live_fastreply_notice}</textarea>

				<!--{if !$liveallowpostreply}-->

					<div>

						<!--{if !$_G[uid]}-->

							{lang login_to_reply} <a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)" class="xi2">{lang login}</a> | <a href="member.php?mod={$_G[setting][regname]}" class="xi2">$_G['setting']['reglinkname']</a>

						<!--{else}-->

							{lang no_permission_to_post}<a href="javascript:;" onclick="ajaxpost('livereplypostform', 'livereplypostreturn', 'livereplypostreturn', 'onerror', $('livereplysubmit'));" class="xi2">{lang click_to_show_reason}</a>

						<!--{/if}-->

					</div>

				<!--{/if}-->

			</div>

			<div id="livepostsubmit" style="display:none;">

			<!--{if $secqaacheck || $seccodecheck}-->

				<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id)"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->

				<div class="mtm sec" style="text-align:right;"><!--{subtemplate common/seccheck}--></div>

			<!--{/if}-->

			<p class="ptm pnpost" style="margin-bottom:10px;">

			<button type="submit" name="replysubmit" class="pn pnc vm" style="float:right;" value="replysubmit" id="livereplysubmit">

				<strong>{lang forum_live_post}</strong>

			</button>

			</p>

			</div>

			<input type="hidden" name="formhash" value="{FORMHASH}">

			<input type="hidden" name="subject" value="  ">

		</form>

	</div>

	<span id="livereplypostreturn"></span>

</div>

<script type="text/javascript">

	var postminchars = parseInt('$_G['setting']['minpostsize']');

	var postmaxchars = parseInt('$_G['setting']['maxpostsize']');

	var disablepostctrl = parseInt('{$_G['group']['disablepostctrl']}');

	var replycontentlist = new Array();

	var addreplylist = new Array();

	var timeoutid = timeid = movescrollid = waitescrollid = null;

	var replycontentnum = 0;

	getnewlivepostlist(1);

	timeid = setInterval(getnewlivepostlist, 5000);

	$('livereplycontent').style.position = 'absolute';

	$('livereplycontent').style.width = ($('livereplycontentout').clientWidth - 50) + 'px';

	$('livereplymessage').onfocus = function() {

		if(this.style.color == 'gray') {

			this.value = '';

			this.style.color = 'black';

			$('livepostsubmit').style.display = 'block';

			this.style.height = '56px';

			$('livefastcomment').style.height = '57px';

		}

	};

	$('livereplymessage').onblur = function() {

		if(this.value == '') {

			this.style.color = 'gray';

			this.value = '{lang forum_live_fastreply_notice}';

		}

	};



	$('liverefresh').onclick = function() {

		$('livereplycontent').style.position = 'absolute';

		getnewlivepostlist();

		this.style.display = 'none';

	};



	$('livereplycontentout').onmouseover = function(e) {



		if($('livereplycontent').style.position == 'absolute' && $('livereplycontent').clientHeight > 215) {

			$('livereplycontent').style.position = 'static';

			this.scrollTop = this.scrollHeight;

		}



		if(this.scrollTop + this.clientHeight != this.scrollHeight) {

			clearInterval(timeid);

			clearTimeout(timeoutid);

			clearInterval(movescrollid);

			timeid = timeoutid = movescrollid = null;



			if(waitescrollid == null) {

				waitescrollid = setTimeout(function() {

					$('liverefresh').style.display = 'block';

				}, 60000 * 10);

			}

		} else {

			clearTimeout(waitescrollid);

			waitescrollid = null;

		}

	};



	$('livereplycontentout').onmouseout = function(e) {

		if(this.scrollTop + this.clientHeight == this.scrollHeight) {

			$('livereplycontent').style.position = 'absolute';

			clearInterval(timeid);

			timeid = setInterval(getnewlivepostlist, 10000);

		}

	};



	function getnewlivepostlist(first) {

		var x = new Ajax('JSON');

		x.getJSON('forum.php?mod=misc&action=livelastpost&fid=$livethread[fid]', function(s, x) {

			var count = s.data.count;

			$('livereplies').innerHTML = count;

			var newpostlist = s.data.list;

			for(i in newpostlist) {

				var postid = i;

				var postcontent = '';

				postcontent += newpostlist[i].authorid ? '<dt><a href="home.php?mod=space&uid=' + newpostlist[i].authorid + '" target="_blank">' + newpostlist[i].avatar + '</a></dt>' : '<dt></dt>';

				postcontent += newpostlist[i].authorid ? '<dd><a href="home.php?mod=space&uid=' + newpostlist[i].authorid + '" target="_blank">' + newpostlist[i].author + '</a></dd>' : '<dd>' + newpostlist[i].author + '</dd>';

				postcontent += '<dd>' + htmlspecialchars(newpostlist[i].message) + '</dd>';

				postcontent += '<dd class="dateline">' + newpostlist[i].dateline + '</dd>';

				if(replycontentlist[postid]) {

					$('livereply_' + postid).innerHTML = postcontent;

					continue;

				}

				addreplylist[postid] = '<dl id="livereply_' + postid + '">' + postcontent + '</dl>';

			}

			if(first) {

				for(i in addreplylist) {

					replycontentlist[i] = addreplylist[i];

					replycontentnum++;

					var div = document.createElement('div');

					div.innerHTML = addreplylist[i];

					$('livereplycontent').appendChild(div);

					delete addreplylist[i];

				}

			} else {

				livecontentfacemove();

			}

		});

	}



	function livecontentfacemove() {

		//note �Ӷ�����ȡ������

		var reply = '';

		for(i in addreplylist) {

			reply = replycontentlist[i] = addreplylist[i];

			replycontentnum++;

			delete addreplylist[i];

			break;

		}

		if(reply) {

			var div = document.createElement('div');

			div.innerHTML = reply;

			var oldclientHeight = $('livereplycontent').clientHeight;

			$('livereplycontent').appendChild(div);

			$('livereplycontentout').style.overflowY = 'hidden';

			$('livereplycontent').style.bottom = oldclientHeight - $('livereplycontent').clientHeight + 'px';



			if(replycontentnum > 20) {

				$('livereplycontent').removeChild($('livereplycontent').firstChild);

				for(i in replycontentlist) {

					delete replycontentlist[i];

					break;

				}

				replycontentnum--;

			}



			if(!movescrollid) {

				movescrollid = setInterval(function() {

					if(parseInt($('livereplycontent').style.bottom) < 0) {

						$('livereplycontent').style.bottom =

							((parseInt($('livereplycontent').style.bottom) + 5) > 0 ? 0 : (parseInt($('livereplycontent').style.bottom) + 5)) + 'px';

					} else {

						$('livereplycontentout').style.overflowY = 'auto';

						clearInterval(movescrollid);

						movescrollid = null;

						timeoutid = setTimeout(livecontentfacemove, 1000);

					}

				}, 100);

			}

		}

	}



	function livereplypostvalidate(theform) {

		var s;

		if(theform.message.value == '' || $('livereplymessage').style.color == 'gray') {

			s = '{lang forum_live_nocontent_error}';

		}

		if(!disablepostctrl && ((postminchars != 0 && mb_strlen(theform.message.value) < postminchars) || (postmaxchars != 0 && mb_strlen(theform.message.value) > postmaxchars))) {

			s = {lang forum_live_nolength_error};

		}

		if(s) {

			showError(s);

			doane();

			$('livereplysubmit').disabled = false;

			return false;

		}

		$('livereplysubmit').disabled = true;

		theform.message.value = theform.message.value.replace(/([^>=\]"'\/]|^)((((https?|ftp):\/\/)|www\.)([\w\-]+\.)*[\w\-\u4e00-\u9fa5]+\.([\.a-zA-Z0-9]+|\u4E2D\u56FD|\u7F51\u7EDC|\u516C\u53F8)((\?|\/|:)+[\w\.\/=\?%\-&~`@':+!]*)+\.(jpg|gif|png|bmp))/ig, '$1[img]$2[/img]');

		theform.message.value = parseurl(theform.message.value);

		ajaxpost('livereplypostform', 'livereplypostreturn', 'livereplypostreturn', 'onerror', $('livereplysubmit'));

		return false;

	}



	function succeedhandle_livereplypost(url, msg, param) {

		$('livereplymessage').value = '';

		$('livereplycontent').style.position = 'absolute';

		if(param['sechash']) {

			updatesecqaa(param['sechash']);

			updateseccode(param['sechash']);

		}

		getnewlivepostlist();

	}

</script>