<?php echo 'www.ymg6.com';exit;?>

<!--{eval}-->

	function ison($fid,$ucid,$istype = 0){

		$return = '';

		if($istype == 0){

			if($fid == $ucid){

				$return = ' class="on"';

			} else {

				$fid_info = C::t('forum_forum')->fetch_info_by_fid($ucid);

				if($fid == $fid_info['fup']){

					$return = ' class="on"';

				} else {

					$fup_info = C::t('forum_forum')->fetch_info_by_fid($fid_info['fup']);

					if($fid == $fup_info['fup']){

						$return = ' class="on"';

					}

				}

			}

		} else {

			if($fid == $ucid){

				$return = ' class="on"';

			}

		}

		return $return;

	}

	function ucatlist($ucid) {

		$str = '';

		$forumlist = forumselect(FALSE, 1);

		foreach($forumlist as $gid => $cat){

			$str .= '<li><a href="forum.php?gid='.$gid.'"'.ison($gid,$ucid).'>'.$cat['name'].'</a>';

			if($cat['sub']){

				$li = '<ul>';

				foreach($forumlist[$gid]['sub'] as $fid => $name){

					$catinfo = C::t('forum_forum')->fetch_info_by_fid($fid);

					$cattype = unserialize($catinfo['threadtypes']);

					$li .= '<li><a href="forum.php?mod=forumdisplay&fid='.$fid.'"'.ison($fid,$ucid).'>'.$name.'</a>';

					if($forumlist[$gid]['child'][$fid]){

						$li .= '<ul>';

						foreach($forumlist[$gid]['child'][$fid] as $fid => $name){

							$li .= '<li><a href="forum.php?mod=forumdisplay&fid='.$fid.'"'.ison($fid,$ucid).'>'.$name.'</a></li>';

						}

						$li .= '</ul>';

					} else if($cattype['types']) {

						$li .= '<ul>';

						foreach($cattype['types'] as $typeid => $typename){

							$li .= '<li><a href="forum.php?mod=forumdisplay&fid='.$fid.'&filter=typeid&typeid='.$typeid.'"'.ison($typeid,$_GET['typeid']).'>'.$typename.'</a></li>';

						}

						$li .= '</ul>';

					}

					$li .='</li>';

				}

				$li .= '</ul>';

				$str .= $li;

			}

			$str .= '</li>';

		}

		return $str;

	}

	$forumlist = ucatlist($_G[fid]);

<!--{/eval}-->

<div class="uc-grid cl">

	<div class="uc-toolbar" id="uctoolbar">

		<div class="wp">

			<div class="uc-filter">

				<div class="uc-f-type">

					<span><i class="ico-th ico-gray"></i><em>{if $_GET['gid']}{$_G['forum'][name]}{elseif $_G['forum'][name]}$_G['forum'][name]{else}ȫ��{/if}</em><i class="ico-down ico-gray"></i></span>

					<ul>

						<li><a href="forum.php">ȫ��</a></li>

						{$forumlist}

					</ul>

				</div>

				<!--{if intval($_G['fid']) && intval($gid) && intval($_G['fid']) !== intval($gid)}-->

					<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->

						<div class="uc-f-sort">

							<span><i class="ico-bookmark ico-gray"></i><em><!--{if $_G['forum']['threadtypes']['types'][$_GET['typeid']]}-->{$_G['forum']['threadtypes']['types'][$_GET['typeid']]}<!--{else}-->ȫ������<!--{/if}--></em><i class="ico-down ico-gray"></i></span>

							<ul>

								<!--{hook/forumdisplay_threadtype_inner}-->

								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['typeid'] && !$_GET['sortid']}class="on"{/if}>{lang forum_viewall}</a></li>

								<!--{if $_G['forum']['threadtypes']}-->

									<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->

										<!--{if $_GET['typeid'] == $id}-->

										<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="on">$name</a></li>

										<!--{else}-->

										<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>

										<!--{/if}-->

									<!--{/loop}-->

								<!--{/if}-->

								<!--{if $_G['forum']['threadsorts']}-->

									<!--{if $_G['forum']['threadtypes']}--><li><span class="pipe">|</span></li><!--{/if}-->

									<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->

										<!--{if $_GET['sortid'] == $id}-->

										<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="on">$name</a></li>

										<!--{else}-->

										<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>

										<!--{/if}-->

									<!--{/loop}-->

								<!--{/if}-->

								<!--{hook/forumdisplay_filter_extra}-->

							</ul>

						</div>

					<!--{/if}-->

					<div class="z other">

						<span class="other-tit"><i class="ico-th-list ico-gray"></i><em>����ѡ��</em><i class="ico-down ico-gray"></i></span>

						<div class="other-menu">

							<div class="uc-f-sort uc-li">

								<span><i class="ico-th-list ico-gray"></i><em><!--{if $_GET['filter'] == 'lastpost'}-->{lang latest}����<!--{elseif $_GET['filter'] == 'heat'}-->{lang order_heats}����<!--{elseif $_GET['filter'] == 'hot'}-->{lang hot_thread}����<!--{elseif $_GET['filter'] == 'digest'}-->{lang digest_posts}����<!--{else}-->����ɸѡ<!--{/if}--></em><i class="ico-down ico-gray"></i></span>

								<ul>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]"{if $_GET['filter'] !== 'lastpost' &&  $_GET['filter'] !== 'heat' && $_GET['filter'] !== 'hot' && $_GET['filter'] !== 'digest'} class="on"{/if}>ȫ������</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['filter'] == 'lastpost'} class="on"{/if}>{lang latest}����</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['filter'] == 'heat'} class="on"{/if}>{lang order_heats}����</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=hot"{if $_GET['filter'] == 'hot'} class="on"{/if}>{lang hot_thread}����</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['filter'] == 'digest'} class="on"{/if}>{lang digest_posts}����</a></li><strong></strong>

								</ul>

							</div>

							<div class="uc-f-sort uc-li">

								<span><i class="ico-calendar ico-gray"></i><em><!--{if !$_GET['dateline']}-->{lang all}{lang search_any_date}<!--{elseif $_GET['dateline'] == '86400'}-->{lang last_1_days}<!--{elseif $_GET['dateline'] == '172800'}-->{lang last_2_days}<!--{elseif $_GET['dateline'] == '604800'}-->{lang list_one_week}<!--{elseif $_GET['dateline'] == '2592000'}-->{lang list_one_month}<!--{elseif $_GET['dateline'] == '7948800'}-->{lang list_three_month}<!--{else}-->����ʱ��<!--{/if}--></em><i class="ico-down ico-gray"></i></span>

								<ul>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['dateline']}class="on"{/if}>{lang all}{lang search_any_date}</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '86400'}class="on"{/if}>{lang last_1_days}</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '172800'}class="on"{/if}>{lang last_2_days}</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '604800'}class="on"{/if}>{lang list_one_week}</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '2592000'}class="on"{/if}>{lang list_one_month}</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '7948800'}class="on"{/if}>{lang list_three_month}</a></li>

								</ul>

							</div>

							<div class="uc-f-sort uc-li">

								<span><i class="ico-glass ico-gray"></i><em><!--{if $_GET['orderby'] == 'dateline'}-->{lang list_post_time}<!--{elseif $_GET['orderby'] == 'replies'}-->{lang replies}<!--{elseif $_GET['orderby'] == 'views'}-->{lang views}<!--{else}-->Ĭ������<!--{/if}--></em><i class="ico-down ico-gray"></i></span>

								<ul>

									<li><a href="forum.php?mod=forumdisplay&fid={$_G[fid]}{$forumdisplayadd[author]}" {if $_GET['orderby'] !== 'dateline' && $_GET['orderby'] !== 'replies' && $_GET['orderby'] !== 'views'}class="on"{/if}>Ĭ������</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'dateline'}class="on"{/if}>{lang list_post_time}</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'replies'}class="on"{/if}>{lang replies}</a></li>

									<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'views'}class="on"{/if}>{lang views}</a></li>

								</ul>

							</div>

							<div class="uc-f-sort uc-li" id="clearstickthread" style="display: none;">

								<span><a href="javascript:;" onclick="clearStickThread()" class="uc-field" title="{lang showdisplayorder}"><i class="ico-eye-open ico-hover"></i><em>{lang showdisplayorder}</em></a></span>

							</div>

							<!--{if $_GET['filter'] == 'hot'}-->

								<div class="uc-f-sort uc-li" id="hottime" value="$ctime" fid="$_G[fid]" onclick="showcalendar(event, this, false, false, false, false, function(){viewhot(this);});">

									<script type="text/javascript" src="{$_G[setting][jspath]}calendar.js?{VERHASH}"></script>

									<span><i class="ico-calendar ico-gray"></i><em>$ctime</em><i class="ico-down ico-gray"></i></span>

									

								</div>

							<!--{/if}-->

							<div class="uc-f-sort uc-li">

								<span><i class="ico-asterisk ico-gray"></i><em>������</em><i class="ico-down ico-gray"></i></span>

								<ul>

									<!--{if rssforumperm($_G['forum']) && $_G[setting][rssstatus] && !$_GET['archiveid'] && !$subforumonly}-->

										<li><a href="forum.php?mod=rss&fid=$_G[fid]&auth=$rssauth" target="_blank" title="RSS">{lang rss_subscribe_this}</a></li>

									<!--{/if}-->

									<!--{if !empty($forumarchive)}-->

										<li><a id="forumarchive" href="javascript:;" onmouseover="showMenu(this.id)"><!--{if $_GET['archiveid']}-->$forumarchive[$_GET['archiveid']]['displayname']<!--{else}-->{lang forum_archive}<!--{/if}--></a></li>

									<!--{/if}-->

									<!--{hook/forumdisplay_forumaction}-->

									<!--{if $_G['forum']['ismoderator']}-->

									<!--{if $_G['forum']['recyclebin']}-->

										<li><a href="{if $_G['adminid'] == 1}admin.php?mod=forum&action=recyclebin&frames=yes{elseif $_G['forum']['ismoderator']}forum.php?mod=modcp&action=recyclebin&fid=$_G[fid]{/if}" target="_blank">{lang forum_recyclebin}</a></li>

									<!--{/if}-->

									<!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->

										<!--{if $_G['forum']['status'] != 3}-->

											<li><a href="forum.php?mod=modcp&fid=$_G[fid]">{lang modcp}</a></li>

										<!--{else}-->

											<li><a href="forum.php?mod=group&action=manage&fid=$_G[fid]">{lang modcp}</a></li>

										<!--{/if}-->

									<!--{/if}-->

									<!--{hook/forumdisplay_modlink}-->

									<!--{/if}-->

								</ul>

							</div>

						</div>

					</div>

				<!--{else}-->

				<div class="uc-f-sort">

					<span><i class="ico-{if $ucsort=='hot'}fire{elseif $ucsort=='digest'}star{elseif $ucsort=='heart'}heart{elseif $ucsort=='reply'}comment{else}time{/if} ico-hover"></i><em><!--{if $ucsort=='hot'}-->��������<!--{elseif $ucsort=='digest'}-->�Ƽ�����<!--{elseif $ucsort=='heart'}-->���ϲ��<!--{elseif $ucsort=='reply'}-->�������<!--{else}-->���·���<!--{/if}--></em><i class="ico-down ico-gray"></i></span>

					<ul>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}type=hot{if $_GET['date']}&date={$_GET['date']}{/if}"{if $ucsort=='hot'} class="on"{/if}><i class="ico-fire ico-hover"></i><em>��������</em></a></li>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}type=digest{if $_GET['date']}&date={$_GET['date']}{/if}"{if $ucsort=='digest'} class="on"{/if}><i class="ico-star ico-hover"></i><em>�Ƽ�����</em></a></li>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}type=heart{if $_GET['date']}&date={$_GET['date']}{/if}"{if $ucsort=='heart'} class="on"{/if}><i class="ico-heart ico-hover"></i><em>���ϲ��</em></a></li>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}type=reply{if $_GET['date']}&date={$_GET['date']}{/if}"{if $ucsort=='reply'} class="on"{/if}><i class="ico-comment ico-hover"></i><em>�������</em></a></li>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}type=newthread{if $_GET['date']}&date={$_GET['date']}{/if}"{if $ucsort=='newthread'} class="on"{/if}><i class="ico-time ico-hover"></i><em>���·���</em></a></li>

					</ul>

				</div>

				<div class="uc-f-date">

					<span><i class="ico-calendar ico-hover"></i><em>{if $ucdate=='86400'}һ����{elseif $ucdate=='172800'}������{elseif $ucdate=='604800'}һ����{elseif $ucdate=='2592000'}һ����{elseif $ucdate=='7948800'}һ����{else}����ʱ��{/if}</em><i class="ico-down ico-gray"></i></span>

					<ul>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}{if $_GET['type']}type={$_GET['type']}{/if}"{if $ucdate=='0'} class="on"{/if}>����</a></li>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}{if $_GET['type']}type={$_GET['type']}&{/if}date=86400"{if $ucdate=='86400'} class="on"{/if}>һ����</a></li>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}{if $_GET['type']}type={$_GET['type']}&{/if}date=172800"{if $ucdate=='172800'} class="on"{/if}>������</a></li>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}{if $_GET['type']}type={$_GET['type']}&{/if}date=604800"{if $ucdate=='604800'} class="on"{/if}>һ����</a></li>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}{if $_GET['type']}type={$_GET['type']}&{/if}date=2592000"{if $ucdate=='2592000'} class="on"{/if}>һ����</a></li>

						<li><a href="forum.php?{if intval($gid)}gid={$gid}&{/if}{if $_GET['type']}type={$_GET['type']}&{/if}date=7948800"{if $ucdate=='7948800'} class="on"{/if}>һ����</a></li>

					</ul>

				</div>

				<!--{/if}-->

			</div>

			<div class="uc-f-nav">

				<a href="./" class="nvhm" title="{lang homepage}"></a><em>&rsaquo;</em><a href="forum.php">{$_G[setting][navs][2][navname]}</a>$navigation

			</div>

		</div>

	</div>

</div>

<div class="uc-grid-place" id="ucgrid"></div>

<script type="text/javascript">

	setFixed(60);

	_attachEvent(window, 'scroll', function(){setFixed(60);});

	function setFixed(n){

		var scrollTop=(document.body.scrollTop||document.documentElement.scrollTop)+n;

		if(scrollTop>$('ucgrid').offsetTop){

			$('uctoolbar').className = 'uc-toolbar fixed';

			$('uctoolbar').style.top = $('ucheader').offsetHeight+'px';

		} else {

			$('uctoolbar').className = 'uc-toolbar';

			$('uctoolbar').style.top = '';

		}

	}

</script>