<?php echo 'www.ymg6.com';exit;?>

	<!--{if $quicksearchlist && !$_GET['archiveid']}-->

		<!--{subtemplate forum/search_sortoption}-->

	<!--{/if}-->

	<!--{if $uclt == 0}-->

		<!--{hook/forumdisplay_threadtype_extra}-->

		<div class="uc-postlist-th cl">

			<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->

			<div class="uc-postlist-th-top">

				<ul id="thread_types" class="ttp cl">

					<!--{hook/forumdisplay_threadtype_inner}-->

					<li id="ttp_all" {if !$_GET['typeid'] && !$_GET['sortid']}class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a></li>

					<!--{if $_G['forum']['threadtypes']}-->

						<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->

							<!--{if $_GET['typeid'] == $id}-->

							<li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="xg1 num">$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>

							<!--{else}-->

							<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="xg1 num">$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>

							<!--{/if}-->

						<!--{/loop}-->

					<!--{/if}-->

					<!--{if $_G['forum']['threadsorts']}-->

						<!--{if $_G['forum']['threadtypes']}--><li><span class="pipe">|</span></li><!--{/if}-->

						<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->

							<!--{if $_GET['sortid'] == $id}-->

							<li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>

							<!--{else}-->

							<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>

							<!--{/if}-->

						<!--{/loop}-->

					<!--{/if}-->

					<!--{hook/forumdisplay_filter_extra}-->

				</ul>

				<script type="text/javascript">showTypes('thread_types');</script>

			</div>

			<!--{/if}-->

			<!--{if CURMODULE != 'guide'}-->

				<div class="uc-postlist-th-bot cl">

					<div class="z cl">

						<a id="filter_special" href="javascript:;" class="uc-field" onclick="showMenu(this.id)"><i class="ico-th ico-hover"></i><em><!--{if $_GET['specialtype'] == 'poll'}-->{lang thread_poll}<!--{elseif $_GET['specialtype'] == 'trade'}-->{lang thread_trade}<!--{elseif $_GET['specialtype'] == 'reward'}-->{lang thread_reward}<!--{elseif $_GET['specialtype'] == 'activity'}-->{lang thread_activity}<!--{elseif $_GET['specialtype'] == 'debate'}-->{lang thread_debate}<!--{else}-->{lang threads_all}<!--{/if}--></em><i class="ico-down ico-gray"></i></a>

						<!--{if $_GET['specialtype'] == 'reward'}-->

							<a id="filter_reward" href="javascript:;" class="uc-field" onclick="showMenu(this.id)"><i class="ico-screenshot ico-hover"></i><em><!--{if $_GET['rewardtype'] == ''}-->{lang all_reward}<!--{elseif $_GET['rewardtype'] == '1'}-->{lang rewarding}<!--{elseif $_GET['rewardtype'] == '2'}-->{lang reward_solved}<!--{/if}--></em><i class="ico-down ico-gray"></i></a>&nbsp;

						<!--{/if}-->

						<a id="filter_time" href="javascript:;" class="uc-field" onclick="showMenu(this.id)"><i class="ico-calendar ico-hover"></i><em><!--{if !$_GET['dateline']}-->{lang all}{lang search_any_date}<!--{elseif $_GET['dateline'] == '86400'}-->{lang last_1_days}<!--{elseif $_GET['dateline'] == '172800'}-->{lang last_2_days}<!--{elseif $_GET['dateline'] == '604800'}-->{lang list_one_week}<!--{elseif $_GET['dateline'] == '2592000'}-->{lang list_one_month}<!--{elseif $_GET['dateline'] == '7948800'}-->{lang list_three_month}<!--{else}-->����ʱ��<!--{/if}--></em><i class="ico-down ico-gray"></i></a>

						<a id="filter_sort" href="javascript:;" class="uc-field" onclick="showMenu(this.id)"><i class="ico-glass ico-hover"></i><em><!--{if $_GET['orderby'] == 'dateline'}-->{lang list_post_time}<!--{elseif $_GET['orderby'] == 'replies'}-->{lang replies}<!--{elseif $_GET['orderby'] == 'views'}-->{lang views}<!--{else}-->Ĭ������<!--{/if}--></em><i class="ico-down ico-gray"></i></a>

						<!--{if empty($_G['forum']['picstyle']) && $_GET['orderby'] == 'lastpost' && (!$_G['setting']['forumseparator'] || !$separatepos) && !$_GET['filter']}-->

							<a href="javascript:;" onclick="checkForumnew_btn('{$_G['fid']}')" title="{lang showupgrade}" class="forumrefresh min"></a>

						<!--{/if}-->

						<!--{if $_GET['filter'] == 'hot'}-->

							<a>

							<script type="text/javascript" src="{$_G[setting][jspath]}calendar.js?{VERHASH}"></script>

							<span>$ctime</span>

							<img src="{IMGDIR}/date_magnify.png" class="cur1" alt="" id="hottime" value="$ctime" fid="$_G[fid]" onclick="showcalendar(event, this, false, false, false, false, function(){viewhot(this);});" align="absmiddle" />

							</a>

						<!--{/if}-->

						<a href="javascript:;" id="clearstickthread" onclick="clearStickThread()" class="uc-field" style="display: none;" title="{lang showdisplayorder}"><i class="ico-eye-open ico-hover"></i><em>{lang showdisplayorder}</em></a>

						<!--{hook/forumdisplay_filter_extra}-->

					</div>

					<div class="y cl">

						<ul>

							<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xi2{if $_GET['filter'] == 'lastpost'} xw1{/if}">{lang latest}</a></li>

							<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xi2{if $_GET['filter'] == 'heat'} xw1{/if}">{lang order_heats}</a></li>

							<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=hot" class="xi2{if $_GET['filter'] == 'hot'} xw1{/if}">{lang hot_thread}</a></li>

							<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xi2{if $_GET['filter'] == 'digest'} xw1{/if}">{lang digest_posts}</a></li>

						</ul>

						<span id="atarget" {if $_G['cookie']['atarget'] > 0}onclick="setatarget(-1)" class="y atarget_1"{else}onclick="setatarget(1)" class="y"{/if} title="{lang new_window_thread}">{lang new_window}</span>

						<!--{if !empty($_G['forum']['picstyle'])}-->

						<span><a{if empty($_G['cookie']['forumdefstyle'])} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=yes" class="chked"{else} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" class="unchk"{/if} title="{lang view_thread_imagemode}{lang view_thread}">{lang view_thread_imagemode}</a></span>

						<!--{/if}-->

					</div>

				</div>

			<!--{else}-->

				{lang title}

			<!--{/if}-->

			<table class="uc-postlist{if (empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']) && $uclt == 0}{else} nbd{/if}" cellspacing="0" cellpadding="0">

				<!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->

					<tbody>

						<tr class="uc-hover">

							<td class="ava"><a href="home.php?mod=space&uid=$announcement[authorid]" c="1" target="_blank"><!--{avatar($announcement[authorid],small)}--></a></td>

							<td class="con">

								<div class="con-top cl">

									<span class="icn ann" title="{lang announcement}"></span>

									<span class="tit"><!--{if empty($announcement['type'])}--><a href="forum.php?mod=announcement&id=$announcement[id]#$announcement[id]" target="_blank">$announcement[subject]</a><!--{else}--><a href="$announcement[message]" target="_blank">$announcement[subject]</a><!--{/if}--></span>

								</div>

								<div class="con-bot">

									<span class="user"><a href="home.php?mod=space&uid=$announcement[authorid]" c="1">$announcement[author]</a></span>

									<span class="time">$announcement[starttime] ����</span>

								</div>

							</td>

						</tr>

					</tbody>

				<!--{/if}-->

			</table>

			<div class="p_pop" id="filter_special_menu" style="display:none;" style="display:none" change="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter='+$('filter_special').value">

				<ul>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all}{lang forum_threads}</a></li>

					<!--{if $showpoll}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_poll}</a></li><!--{/if}-->

					<!--{if $showtrade}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_trade}</a></li><!--{/if}-->

					<!--{if $showreward}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_reward}</a></li><!--{/if}-->

					<!--{if $showactivity}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_activity}</a></li><!--{/if}-->

					<!--{if $showdebate}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_debate}</a></li><!--{/if}-->

				</ul>

			</div>

			<div class="p_pop" id="filter_reward_menu" style="display:none" change="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype='+$('filter_reward').value">

				<ul>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all_reward}</a></li>

					<!--{if $showpoll}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1">{lang rewarding}</a></li><!--{/if}-->

					<!--{if $showtrade}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2">{lang reward_solved}</a></li><!--{/if}-->

				</ul>

			</div>

			<div class="p_pop" id="filter_time_menu" style="display:none;">

				<ul>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['dateline']}class="xw1"{/if}>{lang all}{lang search_any_date}</a></li>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '86400'}class="xw1"{/if}>{lang last_1_days}</a></li>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '172800'}class="xw1"{/if}>{lang last_2_days}</a></li>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '604800'}class="xw1"{/if}>{lang list_one_week}</a></li>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '2592000'}class="xw1"{/if}>{lang list_one_month}</a></li>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '7948800'}class="xw1"{/if}>{lang list_three_month}</a></li>

				</ul>

			</div>

			<div class="p_pop" id="filter_sort_menu" style="display:none;">

				<ul>

					<li><a href="forum.php?mod=forumdisplay&fid={$_G[fid]}{$forumdisplayadd[author]}" {if $_GET['orderby'] !== 'dateline' && $_GET['orderby'] !== 'replies' && $_GET['orderby'] !== 'views'}class="xw1"{/if}>Ĭ������</a></li>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'dateline'}class="xw1"{/if}>{lang list_post_time}</a></li>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'replies'}class="xw1"{/if}>{lang replies}</a></li>

					<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'views'}class="xw1"{/if}>{lang views}</a></li>

				</ul>

			</div>

		</div>

	<!--{elseif $uclt == 1 || $uclt == 2 || $uclt == 3 || $uclt == 4}-->

		<!--{subtemplate forum/discuz_toolbar}-->

	<!--{/if}-->

	<div id="threadlist"{if $_G['uid']} style="position: relative;"{/if}>

		<!--{if (empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']) && $uclt == 0}-->

			<script type="text/javascript">var lasttime = $_G['timestamp'];var listcolspan= '{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}6{else}5{/if}';</script>

		<!--{/if}-->

		<div id="forumnew" style="display:none"></div>

		<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">

			<input type="hidden" name="formhash" value="{FORMHASH}" />

			<input type="hidden" name="listextra" value="$extra" />

			<table summary="forum_$_G[fid]" class="uc-postlist" cellspacing="0" cellpadding="0" id="threadlisttableid"{if (empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']) && $uclt == 0}{else} style="display:none;"{/if}>

				<!--{if !$separatepos || !$_G['setting']['forumseparator']}-->

					<tbody id="separatorline" class="emptb"><tr><td></td><td></td></tr></tbody>

				<!--{/if}-->

				

				<!--{if $_G['forum_threadcount']}-->

					<!--{if (empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']) && $uclt == 0}-->

						<!--�����б���ʼ-->

						<!--{loop $_G['forum_threadlist'] $key $thread}-->

							<!--{if $_G[setting][forumseparator] == 1 && $separatepos == $key + 1}-->

								<tbody id="separatorline">

									<tr class="ts">

										<td><!--{if $_GET['orderby'] == 'lastpost' && !$_GET['filter']}--><a href="javascript:;" style="margin-left:20px;" onclick="checkForumnew_btn('{$_G['fid']}')" title="{lang showupgrade}" class="forumrefresh">ˢ��</a><!--{else}-->&nbsp;<!--{/if}--></td>

										<td></td>

									</tr>

								</tbody>

								<script type="text/javascript">hideStickThread();</script>

							<!--{/if}-->

							<!--{if $separatepos <= $key + 1}-->

								<!--{ad/threadlist}-->

							<!--{/if}-->

							

							<tbody id="$thread[id]"{if $_G['hiddenexists'] && $thread['hidden']} style='display:none'{/if}>

								<tr class="uc-hover">

									<td class="ava">

										<a href="home.php?mod=space&uid=$thread[authorid]" target="_blank"><!--{avatar($thread[authorid],small)}--></a>

										<!--{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}-->

											<span class="chk">

												<!--{if $thread['fid'] == $_G[fid]}-->

													<!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->

														<input onclick="tmodclick(this)" type="checkbox" name="moderate[]" value="$thread[tid]" />

													<!--{else}-->

														<input type="checkbox" disabled="disabled" />

													<!--{/if}-->

												<!--{else}-->

													<input type="checkbox" disabled="disabled" />

												<!--{/if}-->

											</span>

										<!--{/if}-->

									</td>

									<td class="con">

										<div class="con-top cl">

											<span class="tit"><a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if}>$thread[subject]</a></span>

											<span class="icn">

												<!--{if $_G['setting']['threadhidethreshold'] && $thread['hidden'] >= $_G['setting']['threadhidethreshold']}--><span class="xg1">{lang hidden}</span>&nbsp;<!--{/if}-->

												<!--{if $thread[icon] >= 0}-->

													<img src="{STATICURL}image/stamp/{$_G[cache][stamps][$thread[icon]][url]}" alt="{$_G[cache][stamps][$thread[icon]][text]}" align="absmiddle" />

												<!--{/if}-->

												<!--{if $thread['rushreply']}-->

													<img src="{IMGDIR}/rushreply_s.png" alt="{lang rushreply}" align="absmiddle" />

													<!--{if $rushinfo[$thread[tid]]}-->

													<span id="rushtimer_$thread[tid]"> {lang havemore_special} <span id="rushtimer_body_$thread[tid]"></span> <script language="javascript">settimer($rushinfo[$thread[tid]]['timer'], 'rushtimer_body_$thread[tid]');</script>{if $rushinfo[$thread[tid]]['timertype'] == 'start'} {lang header_start} {else} {lang over} {/if} {lang right_special}</span>

													<!--{/if}-->

												<!--{/if}-->

												<!--{if $stemplate && $sortid}-->$stemplate[$sortid][$thread[tid]]<!--{/if}-->

												<!--{if $thread['readperm']}--> - [{lang readperm} <span class="xw1">$thread[readperm]</span>]<!--{/if}-->

												<!--{if $thread['price'] > 0}-->

													<!--{if $thread['special'] == '3'}-->

													- <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1" title="{lang show_rewarding_only}"><span class="xi1">[{lang thread_reward} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span></a>

													<!--{else}-->

													- [{lang price} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]

													<!--{/if}-->

												<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->

													- <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2" title="{lang show_rewarded_only}">[{lang reward_solved}]</a>

												<!--{/if}-->

												<!--{if $thread['attachment'] == 2}-->

													<img src="{STATICURL}image/filetype/image_s.gif" alt="attach_img" title="{lang attach_img}" align="absmiddle" />

												<!--{elseif $thread['attachment'] == 1}-->

													<img src="{STATICURL}image/filetype/common.gif" alt="attachment" title="{lang attachment}" align="absmiddle" />

												<!--{/if}-->

												<!--{if $thread['mobile']}-->

													<img src="{IMGDIR}/mobile-attach-$thread['mobile'].png" alt="{lang post_mobile}" align="absmiddle" />

												<!--{/if}-->

												<!--{if $thread['digest'] > 0 && $filter != 'digest'}-->

													<img src="{IMGDIR}/digest_$thread[digest].gif" align="absmiddle" alt="digest" title="{lang thread_digest} $thread[digest]" />

												<!--{/if}-->

												<!--{if $thread['displayorder'] == 0}-->

													<!--{if $thread[recommendicon] && $filter != 'recommend'}-->

														<img src="{IMGDIR}/recommend_$thread[recommendicon].gif" align="absmiddle" alt="recommend" title="{lang thread_recommend} $thread[recommends]" />

													<!--{/if}-->

													<!--{if $thread[heatlevel]}-->

														<img src="{IMGDIR}/hot_$thread[heatlevel].gif" align="absmiddle" alt="heatlevel" title="{lang heats}: {$thread[heats]}" />

													<!--{/if}-->

													<!--{if $thread['rate'] > 0}-->

														<img src="{IMGDIR}/agree.gif" align="absmiddle" alt="agree" title="{lang rate_credit_add}" />

													<!--{elseif $thread['rate'] < 0}-->

														<img src="{IMGDIR}/disagree.gif" align="absmiddle" alt="disagree" title="{lang posts_deducted}" />

													<!--{/if}-->

												<!--{/if}-->

												<!--{if $thread['replycredit'] > 0}-->

													- <span class="xi1">[{lang replycredit} <strong> $thread['replycredit']</strong> ]</span>

												<!--{/if}-->

												<!--{hook/forumdisplay_thread_subject $key}-->

												<!--{if $thread[multipage]}-->

													<span class="tps">$thread[multipage]</span>

												<!--{/if}-->

												<!--{if $thread['weeknew']}-->

													<a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost" class="xi1">New</a>

												<!--{/if}-->

												<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->

													<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->

														<!--{eval $thread[tid]=$thread[closed];}-->

													<!--{/if}-->

													<!--{if $groupnames[$thread[tid]]}-->

														<span class="fromg xg1"> [{lang from}: <a href="forum.php?mod=group&fid={$groupnames[$thread[tid]][fid]}" target="_blank" class="xg1">{$groupnames[$thread[tid]][name]}</a>]</span>

													<!--{/if}-->

												<!--{/if}-->

											</span>

											<span class="mng">

												<a href="javascript:;" id="content_$thread[tid]" class="showcontent y" title="{lang content_actions}" onclick="CONTENT_TID='$thread[tid]';CONTENT_ID='$thread[id]';showMenu({'ctrlid':this.id,'menuid':'content_menu'})"></a>

												<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->

													<a href="javascript:void(0);" onclick="hideStickThread('$thread[tid]')" class="showhide y" title="{lang hidedisplayorder}">{lang hidedisplayorder}</a></em>

												<!--{/if}-->

												<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->

														<!--{eval $thread[tid]=$thread[closed];}-->

												<!--{/if}-->

												<!--{if !$_G['setting']['forumdisplaythreadpreview'] && !($thread['readperm'] && $thread['readperm'] > $_G['group']['readaccess'] && !$_G['forum']['ismoderator'] && $thread['authorid'] != $_G['uid'])}-->

													<!--{if !(!empty($_G['setting']['antitheft']['allow']) && empty($_G['setting']['antitheft']['disable']['thread']) && empty($_G['forum']['noantitheft']))}-->

														<a class="tdpre y" href="javascript:void(0);" onclick="previewThread('{echo $thread['moved'] ? $thread[closed] : $thread[tid]}', '$thread[id]');">{lang preview}</a>

													<!--{/if}-->

												<!--{/if}-->

												<!--{hook/forumdisplay_thread $key}-->

												<!--{if $thread['moved']}-->

													{lang thread_moved}:<!--{eval $thread[tid]=$thread[closed];}-->

												<!--{/if}-->

											</span>

										</div>

										<div class="con-bot">

											<span class="y">

												<em><i class="ico-eye-open ico-gray"></i><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></em>

												<em><i class="ico-comment ico-gray"></i><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">$thread[allreplies]</a></em>

											</span>

											<!--{hook/forumdisplay_author $key}-->

											<em>

											<!--{if $thread['authorid'] && $thread['author']}-->

												<a href="home.php?mod=space&uid=$thread[authorid]" c="1"{if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if}>$thread[author]</a> <!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}-->

											<!--{else}-->

												$_G[setting][anonymoustext]

											<!--{/if}-->		

											</em>

											<em><span{if $thread['istoday']} class="xi1"{/if}>$thread[dateline]</span> ����<!--{if $thread[typehtml] || $thread[sorthtml]}-->��<!--{/if}--></em>

											<!--{if $thread[typehtml]}-->

											<em><a href="forum.php?mod=forumdisplay&fid={$thread[fid]}&amp;filter=typeid&amp;typeid={$thread[typeid]}">{$thread[typename]}</a></em>

											<!--{/if}-->

											<!--{if $thread[sorthtml]}-->

											<em><a href="forum.php?mod=forumdisplay&fid={$thread[fid]}&filter=sortid&sortid={$thread['sortid']}">{$_G['forum']['threadsorts']['types'][$thread['sortid']]}</a></em>

											<!--{/if}-->

											<em>���ظ��� <a href="{if $thread[digest] != -2 && !$thread[ordertype]}forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost$highlight#lastpost{else}forum.php?mod=viewthread&tid=$thread[tid]{if !$thread[ordertype]}&page={echo max(1, $thread[pages]);}{/if}{/if}" >$thread[lastpost]</a></em>

											<em>

												<a href="forum.php?mod=viewthread&tid=$thread[icontid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" title="{if $thread['displayorder'] == 1}{lang thread_type1} - {/if}

													{if $thread['displayorder'] == 2}{lang thread_type2} - {/if}

													{if $thread['displayorder'] == 3}{lang thread_type3} - {/if}

													{if $thread['displayorder'] == 4}{lang thread_type4} - {/if}

													{if $thread[folder] == 'lock'}{lang closed_thread} - {/if}

													{if $thread['special'] == 1}{lang thread_poll} - {/if}

													{if $thread['special'] == 2}{lang thread_trade} - {/if}

													{if $thread['special'] == 3}{lang thread_reward} - {/if}

													{if $thread['special'] == 4}{lang thread_activity} - {/if}

													{if $thread['special'] == 5}{lang thread_debate} - {/if}

													{if $thread[folder] == 'new'}{lang have_newreplies} - {/if}

													{if $thread['replies'] == '0' && $thread['dbdateline']>time()-43200}������ - {/if}

													{lang target_blank}" target="_blank">

												<!--{if $thread[folder] == 'lock'}-->

													{lang closed_thread}

												<!--{elseif $thread['special'] == 1}-->

													{lang thread_poll}

												<!--{elseif $thread['special'] == 2}-->

													{lang thread_trade}

												<!--{elseif $thread['special'] == 3}-->

													{lang thread_reward}

												<!--{elseif $thread['special'] == 4}-->

													{lang thread_activity}

												<!--{elseif $thread['special'] == 5}-->

													{lang thread_debate}

												<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->

													�ö�

												<!--{/if}-->

												</a>

											</em>

										</div>

									</td>

								</tr>

							</tbody>

						<!--{/loop}-->

						</table>

						<div id="hiddenthread"{if $thread['hidden']} class="last"{/if}><a href="javascript:;" onclick="display_blocked_thread()">{lang other_reply_hide}</a></div>

						<!--�����б�����-->

					<!--{else}-->

						</table>

						<!--{hook/forumdisplay_threadtype_extra}-->

						<!--{if $uclt !== 0}-->

							<!--{eval}-->

								foreach($_G['forum_threadlist'] as $k => $v){

									$_G['forum_threadlist'][$k]['coverpath'] = $_G['forum_threadlist'][$k]['cover']?(($_G['forum_threadlist'][$k]['cover'] < 0 ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/threadcover/'.substr(md5($_G['forum_threadlist'][$k]['tid']), 0, 2).'/'.substr(md5($_G['forum_threadlist'][$k]['tid']), 2, 2).'/'.$_G['forum_threadlist'][$k]['tid'].'.jpg'):'';

								}

							<!--{/eval}-->

						<!--{/if}-->

						<div class="uc-piclist{if $uclt == 3 || $uclt == 4} uc-article{/if}">

							<ul id="waterfall" class="cl">

								<!--{loop $_G['forum_threadlist'] $key $thread}-->

									<!--{if $_G['hiddenexists'] && $thread['hidden']}-->

										<!--{eval continue;}-->

									<!--{/if}-->

									<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->

										<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->

											<!--{eval $thread[tid]=$thread[closed];}-->

										<!--{/if}-->

									<!--{/if}-->

									<li style="width:{$uctw}px">

										<!--{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}-->

											<div style="position:absolute;margin:1px;padding:2px;background:#FFF; z-index:1;">

											<!--{if $thread['fid'] == $_G[fid]}-->

												<!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->

													<input onclick="tmodclick(this)" type="checkbox" name="moderate[]" value="$thread[tid]" />

												<!--{else}-->

													<input type="checkbox" disabled="disabled" />

												<!--{/if}-->

											<!--{else}-->

												<input type="checkbox" disabled="disabled" />

											<!--{/if}-->

											</div>

										<!--{/if}-->

										<div class="uc-piclist-con-top">

											<div class="uc-thumb">

												<a href="forum.php?mod=viewthread&tid={$thread[tid]}&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra={$extra}" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="{$thread[subject]} by {$thread[author]}" class="z">

													<!--{if $thread['cover']}-->

														<img src="{$thread[coverpath]}" alt="{$thread[subject]} by {$thread[author]}" width="{$uctw}" {if $uclt == 1 || $uclt == 3 || $uclt == 0}height="{$ucth}"{/if} />

													<!--{else}-->

														<span class="nopic" style="width:{$uctw}px; height:{$ucgth}px;" title="{$thread[subject]} by {$thread[author]}"></span>

													<!--{/if}-->

												</a>

											</div>

											<!--{if $uclt == 1 || $uclt == 2 || $uclt == 0}-->

											<div class="uc-title">

												<a href="forum.php?mod=viewthread&tid={$thread[tid]}&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra={$extra}"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="{$thread[subject]} by {$thread[author]}" class="uc-title-a"><span>{$thread[subject]}</span></a>

												<!--{hook/forumdisplay_thread $key}-->

												<div class="uc-title-bg"></div>

											</div>

											<!--{/if}-->

										</div>

										<div class="uc-piclist-con-bot">

											<!--{if $uclt == 3 || $uclt == 4}-->

												<div class="uc-title">

													<a href="forum.php?mod=viewthread&tid={$thread[tid]}&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra={$extra}"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="{$thread[subject]} by {$thread[author]}" class="uc-title-a"><span>{$thread[subject]}</span></a>

													<!--{hook/forumdisplay_thread $key}-->

												</div>

												<div class="uc-author">

													<!--{if $thread['authorid'] && $thread['author']}-->

														<a href="home.php?mod=space&uid={$thread[authorid]}" c="1" title="{$thread[author]}" target="_blank">{$thread[author]}</a>

													<!--{else}-->

														<a href="javascript:void(0)">{$_G[setting][anonymoustext]}</a>

													<!--{/if}-->

													<span><i class="ico-time ico-gray"></i>{eval echo dgmdate($thread['dateline'], 'u', '9999', getglobal('setting/dateformat'))}</span>								

												</div>

												<div class="uc-summary"{if $uclt == 3} style="height:{$ucch}px;overflow:hidden;"{/if}>

												<!--{eval}-->

													$query = DB::fetch_first("SELECT message, tid FROM ".DB::table('forum_post')." WHERE tid = ".$thread['tid']." AND first=1");

													$thread['summary'] = cutstr($query['message'], $uccm, '');

													echo $thread['summary'];

												<!--{/eval}-->

												</div>

												<div class="uc-stat">

													<span title="{lang show}"><i class="ico-eye-open ico-gray"></i>{$thread[views]}</span>

													<span title="{lang reply}"><i class="ico-comment ico-gray"></i>{$thread[replies]}</span>

													<span title="{lang like}"><i class="ico-heart ico-gray"></i><!--{if $thread[recommends]}-->{$thread[recommends]}<!--{else}-->0<!--{/if}--></span>

													<!--{if $livethread['tid'] == $thread['tid'] }-->

														<a href="forum.php?mod=viewthread&tid=$thread[icontid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="uc-forumname" target="_blank">ֱ��</a>

													<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->

														<a href="forum.php?mod=viewthread&tid=$thread[icontid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="uc-forumname" target="_blank">�ö�</a>

													<!--{elseif $thread['digest'] > 0}-->

														<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="uc-forumname" target="_blank">����</a>

													<!--{else}-->

														<!--{loop $_G['forum']['recommendlist'] $rtid $recommend}-->

															<!--{if $rtid == $thread['tid']}-->

																<!--{eval $isrec=1;}-->

															<!--{/if}-->

														<!--{/loop}-->

														<!--{if $isrec == 1}-->

															<a href="forum.php?mod=viewthread&tid={$thread[icontid]}&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="uc-forumname" target="_blank">�Ƽ�</a>

														<!--{else}-->

															<!--{if $thread['typeid'] > 0}-->

																<a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter=typeid&typeid={$thread['typeid']}" class="uc-forumname">{$_G['forum']['threadtypes']['types'][$thread['typeid']]}</a>

															<!--{else}-->

																<span class="dateline"><i class="ico-time ico-gray"></i>{$thread['dateline']}</span>

															<!--{/if}-->

														<!--{/if}-->

														<!--{eval $isrec=0;}-->

													<!--{/if}-->

												</div>

											<!--{else}-->

												<div class="uc-stat">

													<span title="{lang show}"><i class="ico-eye-open ico-gray"></i>{$thread[views]}</span>

													<span title="{lang reply}"><i class="ico-comment ico-gray"></i>{$thread[replies]}</span>

													<span title="{lang like}"><i class="ico-heart ico-gray"></i><!--{if $thread[recommends]}-->{$thread[recommends]}<!--{else}-->0<!--{/if}--></span>

												</div>

												<div class="uc-author">

													<!--{hook/forumdisplay_author $key}-->

													<!--{if $thread['authorid'] && $thread['author']}-->

														<a href="home.php?mod=space&uid={$thread[authorid]}" c="1" class="z" title="{$thread[author]}" target="_blank"><!--{avatar($thread[authorid],middle)}--><span>{$thread[author]}</span></a>

													<!--{else}-->

														<a href="javascript:void(0)">{$_G[setting][anonymoustext]}</a>

													<!--{/if}-->

													

													<!--{if $livethread['tid'] == $thread['tid'] }-->

														<a href="forum.php?mod=viewthread&tid=$thread[icontid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="uc-forumname" target="_blank">ֱ��</a>

													<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->

														<a href="forum.php?mod=viewthread&tid=$thread[icontid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="uc-forumname" target="_blank">�ö�</a>

													<!--{elseif $thread['digest'] > 0}-->

														<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="uc-forumname" target="_blank">����</a>

													<!--{else}-->

														<!--{loop $_G['forum']['recommendlist'] $rtid $recommend}-->

															<!--{if $rtid == $thread['tid']}-->

																<!--{eval $isrec=1;}-->

															<!--{/if}-->

														<!--{/loop}-->

														<!--{if $isrec == 1}-->

															<a href="forum.php?mod=viewthread&tid={$thread[icontid]}&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="uc-forumname" target="_blank">�Ƽ�</a>

														<!--{else}-->

															<!--{if $thread['typeid'] > 0}-->

																<a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter=typeid&typeid={$thread['typeid']}" class="uc-forumname">{$_G['forum']['threadtypes']['types'][$thread['typeid']]}</a>

															<!--{else}-->

																<span class="dateline"><i class="ico-time ico-gray"></i>{$thread['dateline']}</span>

															<!--{/if}-->

														<!--{/if}-->

														<!--{eval $isrec=0;}-->

													<!--{/if}-->

												</div>

											<!--{/if}-->

										</div>

									</li>

								<!--{/loop}-->

							</ul>

						</div>

						<div id="tmppic" style="display: none;"></div>

					<!--{/if}-->

			<!--{else}-->

					<tbody class="bw0_all"><tr><th colspan="2"><p class="emp">{lang forum_nothreads}</p></th></tr></tbody>

				</table>

			<!--{/if}-->



			<!--{if $_G['forum']['ismoderator'] && $_G['forum_threadcount']}-->

				<!--{template forum/topicadmin_modlayer}-->

			<!--{/if}-->

		</form>

	</div>

	<!--{hook/forumdisplay_threadlist_bottom}-->



<!--{if $multipage && $filter != 'hot'}-->

	<!--{if !($_G[forum][picstyle] && !$_G[cookie][forumdefstyle]) && $uclt == 0}-->

		<a class="bm_h" href="javascript:;" rel="$multipage_more" curpage="$page" id="autopbn" totalpage="$maxpage" picstyle="$_G[forum][picstyle]" forumdefstyle="$_G[cookie][forumdefstyle]">{lang next_page_extra}</a>

		<script type="text/javascript" src="{$_G[setting][jspath]}autoloadpage.js?{VERHASH}"></script>

	<!--{else}-->

		<div id="pgbtn" class="pgbtn"><a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}&page=$nextpage" hidefocus="true">{lang next_page_extra}</a></div>

	<!--{/if}-->

<!--{/if}-->

<span id="fd_page_bottom"><div class="uc-pagelist cl">$multipage</div></span>



<!--{if (empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']) && $uclt == 0}-->

<!--{else}-->

<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/masonry.pkgd.min.js"></script>

<script type="text/javascript" src="{$_G[setting][jspath]}redef.js?{VERHASH}"></script>

<script type="text/javascript" reload="1">

var wf = {};



_attachEvent(window, "load", function () {

	if($("waterfall")) {

		var ele = $('waterfall');

		new Masonry(ele, {itemSelector:'li',animate:false,columnWidth:$ucgtw+20});

	}



	<!--{if $page < $_G['page_next'] && !$subforumonly}-->

		var page = $page + 1,

			maxpage = Math.min($page + 10,$maxpage + 1),

			stopload = 0,

			scrolltimer = null,

			tmpelems = [],

			tmpimgs = [],

			markloaded = [],

			imgsloaded = 0,

			loadready = 0,

			showready = 1,

			nxtpgurl = 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&page=',

			wfloading = "<img src=\"{IMGDIR}/loading.gif\" alt=\"\" width=\"16\" height=\"16\" class=\"vm\" /> {lang onloading}...",

			pgbtn = $("pgbtn").getElementsByTagName("a")[0];



		function loadmore() {

			var url = nxtpgurl + page + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));

			var x = new Ajax("HTML");

			x.get(url, function (s) {

				s = s.replace(/\n|\r/g, "");

				if(s.indexOf("id=\"pgbtn\"") == -1) {

					$("pgbtn").style.display = "none";

					stopload++;

					window.onscroll = null;

				}



				s = s.substring(s.indexOf("<ul id=\"waterfall\""), s.indexOf("<div id=\"tmppic\""));

				s = s.replace("id=\"waterfall\"", "");

				$("tmppic").innerHTML = s;

				loadready = 1;

			});

		}



		window.onscroll = function () {

			if(scrolltimer == null) {

				scrolltimer = setTimeout(function () {

					try {

						if(page < maxpage && stopload < 2 && showready && ((document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.clientHeight + 500) >= document.documentElement.scrollHeight) {

							pgbtn.innerHTML = wfloading;

							loadready = 0;

							showready = 0;

							loadmore();

							tmpelems = $("tmppic").getElementsByTagName("li");

							var waitingtimer = setInterval(function () {

								stopload >= 2 && clearInterval(waitingtimer);

								if(loadready && stopload < 2) {

									if(!tmpelems.length) {

										page++;

										pgbtn.href = nxtpgurl + Math.min(page, $maxpage);

										pgbtn.innerHTML = "{lang next_page_extra}";

										showready = 1;

										clearInterval(waitingtimer);

									}

									for(var i = 0, j = tmpelems.length; i < j; i++) {

										if(tmpelems[i]) {

											tmpimgs = tmpelems[i].getElementsByTagName("img");

											imgsloaded = 0;

											for(var m = 0, n = tmpimgs.length; m < n; m++) {

												tmpimgs[m].onerror = function () {

													this.style.display = "none";

												};

												markloaded[m] = tmpimgs[m].complete ? 1 : 0;

												imgsloaded += markloaded[m];

											}

											if(imgsloaded == tmpimgs.length) {

												$("waterfall").appendChild(tmpelems[i]);

												var ele = $('waterfall');

												new Masonry(ele, {itemSelector:'li',animate:false,columnWidth:$ucgtw+20});

											}

										}

									}

								}

							}, 40);

						}

					} catch(e) {}

					scrolltimer = null;

				}, 320);

			}

		};

	<!--{/if}-->

});

</script>

<!--{/if}-->















