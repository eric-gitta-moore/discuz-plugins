<?php echo 'www.ymg6.com';exit;?>

<!--{eval $uctopbgimg = $uc['topbar']['bgimg'] ? $uc['topbar']['bgimg'] : $_G['style']['styleimgdir'].'img/scbg.jpg'}-->

<!--{if $uc['topbar']['type'] == 1}-->

<div class="uc-searchbar" style="background-image:url({$uctopbgimg}); background-color:{$uc['topbar']['bgcolor']}">

	<p class="uc-ctitle" style="color:{$uc['topbar']['title_color']};">{$uc['topbar']['title']}</p>

	<form method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" onsubmit="searchFocus($('scbar_txt'))" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">

		<input type="hidden" name="mod" value="forum" />

		<input type="hidden" name="formhash" value="{FORMHASH}" />

		<input type="hidden" name="srchtype" value="title" />

		<input type="hidden" name="srhfid" value="$_G[fid]" />

		<input type="hidden" name="srhlocality" value="$_G['basescript']::{CURMODULE}" />

		<input type="hidden" name="searchsubmit" value="true" />

		<label class="cl">

			<input type="text" class="uc-sctxt" name="srchtxt" autocomplete="off" x-webkit-speech speech placeholder="{lang enter_content}">

			<button type="submit" class="uc-scbtn"><i class="ico-search ico-white"></i>��&nbsp;��</button>

		</label>

	</form>

</div>

<!--{elseif $uc['topbar']['type'] == 2}-->

<div class="uc-threadbar" style="background-image:url({$uctopbgimg}); background-color:{$uc['topbar']['bgcolor']}">

	<p class="uc-ctitle" style="color:{$uc['topbar']['title_color']};">{$uc['topbar']['title']}</p>

	<a onclick="showWindow('nav', this.href, 'get', 0)" href="forum.php?mod=misc&amp;action=nav" title="������Ʒ"><span><i class="ico-upload ico-white"></i>����һ����Ʒ</span></a>

</div>

<!--{elseif $uc['topbar']['type'] == 3}-->

<div class="uc-countdownbar{if $uc['topbar']['time_html']} html{/if}" style="background-image:url({$uctopbgimg}); background-color:{$uc['topbar']['bgcolor']}">

	<p class="uc-ctitle" style="color:{$uc['topbar']['title_color']};">{$uc['topbar']['title']}</p>

	<div class="countdown{if $uc['topbar']['time_html']} html{/if}" id="b_u_time"></div>

	<!--{if $uc['topbar']['time_html']}-->

		<p>{$uc['topbar']['time_html']}</p>

	<!--{/if}-->

	<link href="{$_G['style']['styleimgdir']}js/jcountdown/jcountdown.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/jcountdown/jquery.min.js"></script>

	<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/jcountdown/jquery.jcountdown.min.js"></script>

	<script>

		var UCJQ = jQuery.noConflict();

		UCJQ(function(){

			var b = new Date;

			var b = -b.getTimezoneOffset() / 60;

			var i = "{eval echo date('Y/m/d H:i:s',strtotime($uc['topbar']['time']))}";

			var config = {

				timeText: i, //����ʱʱ��

				timeZone: b, //ʱ��

				style: "slide", //��ʾ����ʽ����ѡֵ��flip,slide,metal,crystal

				color: "{$uc['topbar']['type']['time_color']}", //��ʾ����ɫ����ѡֵwhite,black

				width: 0, //����ʱ����

				textGroupSpace: 15, //�졢ʱ���֡���֮����

				textSpace: 0, //����֮����

				reflection: 0, //�Ƿ���ʾ��Ӱ

				reflectionOpacity: 10, //��Ӱ͸����

				reflectionBlur: 0, //��Ӱģ���̶�

				dayTextNumber: 3, //����ʱ�������ָ���

				displayDay: !0, //�Ƿ���ʾ����

				displayHour: !0, //�Ƿ���ʾСʱ��

				displayMinute: !0, //�Ƿ���ʾ������

				displaySecond: !0, //�Ƿ���ʾ����

				displayLabel: !0, //�Ƿ���ʾ����ʱ�ײ�label

				onFinish: function() {}

			};

			UCJQ("#b_u_time").jCountdown(config);

		});

	</script>

</div>

<!--{/if}-->