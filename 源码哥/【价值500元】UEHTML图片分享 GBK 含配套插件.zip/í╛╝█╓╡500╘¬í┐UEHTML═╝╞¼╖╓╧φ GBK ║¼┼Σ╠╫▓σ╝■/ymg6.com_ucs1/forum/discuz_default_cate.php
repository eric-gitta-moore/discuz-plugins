<?php echo 'www.ymg6.com';exit;?>

<!--�Ҷ��ĵ�ר��-->

<!--{if !empty($collectiondata['follows'])}-->

	<!--{eval $forumscount = count($collectiondata['follows']);}-->

	<!--{eval $forumcolumns = 4;}-->

	<!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->

	<div class="fl">

		<div class="bm bmw {if $forumcolumns} flg{/if} cl">

			<div class="bm_h cl">

				<span class="o">

					<img id="category_-1_img" src="{IMGDIR}/$collapse['collapseimg_-1']" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_-1');" />

				</span>

				<h2><a href="forum.php?mod=collection&op=my">{lang my_order_collection}</a></h2>

			</div>

			<div id="category_-1" class="bm_c" style="{echo $collapse['category_-1']}">

				<table cellspacing="0" cellpadding="0" class="fl_tb">

					<tr>

					<!--{eval $ctorderid = 0;}-->

					<!--{loop $collectiondata['follows'] $key $colletion}-->

						<!--{if $ctorderid && ($ctorderid % $forumcolumns == 0)}-->

							</tr>

							<!--{if $ctorderid < $forumscount}-->

								<tr class="fl_row">

							<!--{/if}-->

						<!--{/if}-->

						<td class="fl_g"{if $forumcolwidth} width="$forumcolwidth"{/if}>

							<div class="fl_g_inner">

								<div class="fl_icn_g">

								<a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}" target="_blank"><img src="{$_G['style']['styleimgdir']}/img/forum{if $followcollections[$key]['lastvisit'] < $colletion['lastupdate']}_new{/if}.png" alt="$colletion[name]" /></a>

								</div>

								<dl>

									<dt><a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}">$colletion[name]</a></dt>

									<dd><em>{lang forum_threads}: <!--{echo dnumber($colletion[threadnum])}--></em>, <em>{lang collection_commentnum}: <!--{echo dnumber($colletion[commentnum])}--></em></dd>

									<dd>

									<!--{if $colletion['lastpost']}-->

										<!--{if $forumcolumns < 3}-->

											<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($colletion[lastsubject], 30)}--></a> <cite><!--{date($colletion[lastposttime])}--> <!--{if $colletion['lastposter']}-->$colletion['lastposter']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>

										<!--{else}-->

											<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost">{lang forum_lastpost}: <!--{date($colletion[lastposttime])}--></a>

										<!--{/if}-->

									<!--{else}-->

										{lang never}

									<!--{/if}-->

									</dd>

									<!--{hook/index_followcollection_extra $colletion[ctid]}-->

								</dl>

							</div>

						</td>

						<!--{eval $ctorderid++;}-->



					<!--{/loop}-->

					<!--{if ($columnspad = $ctorderid % $forumcolumns) > 0}--><!--{echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);}--><!--{/if}-->

					</tr>

				</table>

			</div>

		</div>

	</div>

<!--{/if}-->

<!--/�Ҷ��ĵ�ר��-->

	

<!--���ղصİ��-->

<!--{if empty($gid) && !empty($forum_favlist)}-->

	<!--{eval $forumscount = count($forum_favlist);}-->

	<!--{eval $forumcolumns = $forumscount > 3 ? ($forumscount == 4 ? 4 : 5) : 1;}-->

	<!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->

	<div class="fl">

		<div class="bm bmw {if $forumcolumns} flg{/if} cl">

			<div class="bm_h cl">

				<span class="o">

					<img id="category_0_img" src="{IMGDIR}/$collapse['collapseimg_0']" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_0');" />

				</span>

				<h2><a href="home.php?mod=space&do=favorite&type=forum">{lang forum_myfav}</a></h2>

			</div>

			<div id="category_0" class="bm_c" style="{echo $collapse['category_0']}">

				<table cellspacing="0" cellpadding="0" class="fl_tb">

					<tr>

					<!--{eval $favorderid = 0;}-->

					<!--{loop $forum_favlist $key $favorite}-->

					<!--{if $favforumlist[$favorite[id]]}-->

					<!--{eval $forum=$favforumlist[$favorite[id]];}-->

					<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->

						<!--{if $forumcolumns>1}-->

							<!--{if $favorderid && ($favorderid % $forumcolumns == 0)}-->

								</tr>

								<!--{if $favorderid < $forumscount}-->

									<tr class="fl_row">

								<!--{/if}-->

							<!--{/if}-->

							<td class="fl_g"{if $forumcolwidth} width="$forumcolwidth"{/if}>

								<div class="fl_g_inner">

									<div class="fl_icn_g"{if !empty($forum[extra][iconwidth]) && !empty($forum[icon])} style="width: {$forum[extra][iconwidth]}px;"{/if}>

										<!--{if $forum[icon]}-->

											$forum[icon]

										<!--{else}-->

											<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{$_G['style']['styleimgdir']}/img/forum{if $forum[folder]}_new{/if}.png" alt="$forum[name]" /></a>

										<!--{/if}-->

									</div>

									<dl{if !empty($forum[extra][iconwidth]) && !empty($forum[icon])} style="margin-left: {$forum[extra][iconwidth]}px;"{/if}>

										<dt><a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a><!--{if $forum[todayposts] && !$forum['redirect']}--><em class="xw0 xi1" title="{lang forum_todayposts}"> ($forum[todayposts])</em><!--{/if}--></dt>

										<dd>

											<!--{if $forum[threadtypes]}-->

												<!--{eval $threadtypes = unserialize($forum[threadtypes]);$ti = 1;}-->

												<!--{loop $threadtypes[types] $key $value}-->

													<!--{if $ti > 3 }-->{eval break;}<!--{/if}-->

													<!--{if $ti !== 1}-->��<!--{/if}-->

													<a href="forum.php?mod=forumdisplay&fid={$forum[fid]}&filter=typeid&typeid={$key}" target="_blank"><u>{$value}</u></a>

													<!--{eval $ti++}-->

												<!--{/loop}-->

											<!--{else}-->

												<!--{if $forum[description]}-->

													<!--{echo cutstr($forum[description], 30)}-->

												<!--{else}-->

													�ð����δ���Ӽ����Ϣ

												<!--{/if}-->

											<!--{/if}-->

										</dd>

										<!--{if empty($forum[redirect])}-->

											<dd>

												<em>{lang index_today}: <!--{echo dnumber($forum[todayposts])}--></em> 

												<em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em> 

												<em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em>

											</dd>

										<!--{/if}-->

										<!--{hook/index_forum_extra $forum[fid]}-->

									</dl>

								</div>

							</td>

							<!--{eval $favorderid++;}-->

						<!--{else}-->

							<td class="fl_icn uc-hover" {if !empty($forum[extra][iconwidth]) && !empty($forum[icon])} style="width: {$forum[extra][iconwidth]}px;"{/if}>

								<!--{if $forum[icon]}-->

									$forum[icon]

								<!--{else}-->

									<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{$_G['style']['styleimgdir']}/img/forum{if $forum[folder]}_new{/if}.png" alt="$forum[name]" /></a>

								<!--{/if}-->

							</td>

							<td class="fl_tit uc-hover">

								<h2><a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a><!--{if $forum[todayposts] && !$forum['redirect']}--><em class="xw0 xi1" title="{lang forum_todayposts}"> ($forum[todayposts])</em><!--{/if}--></h2>

								<!--{if $forum[description]}--><p class="xg2">{eval echo cutstr($forum[description], 80, '');}</p><!--{/if}-->

								<!--{if $forum['subforums']}--><p>{lang forum_subforums}: $forum['subforums']</p><!--{/if}-->

								<!--{if $forum['moderators']}--><p>{lang forum_moderators}: <span class="xi2">$forum[moderators]</span></p><!--{/if}-->

								<!--{hook/index_favforum_extra $forum[fid]}-->

							</td>

							<td class="fl_i uc-hover">

								<!--{if empty($forum[redirect])}--><span class="xi2"><!--{echo dnumber($forum[threads])}--></span><span class="xg1"> / <!--{echo dnumber($forum[posts])}--></span><!--{/if}-->

							</td>

							<td class="fl_by uc-hover">

								<div>

								<!--{if $forum['permission'] == 1}-->

									{lang private_forum}



								<!--{else}-->

									<!--{if $forum['redirect']}-->

										<a href="$forumurl" class="xi2">{lang url_link}</a>

									<!--{elseif is_array($forum['lastpost'])}-->

										<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a> <cite>$forum[lastpost][dateline] <!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>

									<!--{else}-->

										{lang never}

									<!--{/if}-->

								<!--{/if}-->

								</div>

							</td>

						</tr>

						<tr class="fl_row">



						<!--{/if}-->

					<!--{/if}-->

					<!--{/loop}-->

					<!--{if ($columnspad = $favorderid % $forumcolumns) > 0}--><!--{echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);}--><!--{/if}-->

					</tr>

				</table>



			</div>

		</div>

	</div>

	<!--{ad/intercat/bm a_c/-1}-->

<!--{/if}-->

<!--/���ղصİ��-->



<!--��̳���а��-->

<!--{loop $catlist $key $cat}-->

	<!--{hook/index_catlist $cat[fid]}-->

	<div class="fl">

		<div class="bm bmw {if $cat['forumcolumns']} flg{/if} cl">

			<div class="bm_h cl">

				<span class="o">

					<img id="category_$cat[fid]_img" src="{IMGDIR}/$cat[collapseimg]" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_$cat[fid]');" />

				</span>

				<!--{if $cat['moderators']}--><span class="y">{lang forum_category_modedby}: $cat[moderators]</span><!--{/if}-->

				<!--{eval $caturl = !empty($cat['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$cat['domain'].'.'.$_G['setting']['domain']['root']['forum'] : '';}-->

				<h2><a href="{if !empty($caturl)}$caturl{else}forum.php?gid=$cat[fid]{/if}" style="{if $cat[extra][namecolor]}color: {$cat[extra][namecolor]};{/if}">$cat[name]</a></h2>

			</div>

			<div id="category_$cat[fid]" class="bm_c" style="{echo $collapse['category_'.$cat[fid]]}">

				<table cellspacing="0" cellpadding="0" class="fl_tb">

					<tr>

					<!--{loop $cat[forums] $forumid}-->

					<!--{eval $forum=$forumlist[$forumid];}-->

					<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->

					<!--{if $cat['forumcolumns']}-->

						<!--{if $forum['orderid'] && ($forum['orderid'] % $cat['forumcolumns'] == 0)}-->

							</tr>

							<!--{if $forum['orderid'] < $cat['forumscount']}-->

								<tr class="fl_row">

							<!--{/if}-->

						<!--{/if}-->

						<td class="fl_g" width="$cat[forumcolwidth]">

							<div class="fl_g_inner">

								<div class="fl_icn_g">

									<!--{if $forum[icon]}-->

										$forum[icon]

									<!--{else}-->

										<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{$_G['style']['styleimgdir']}/img/forum{if $forum[folder]}_new{/if}.png" alt="$forum[name]" /></a>

									<!--{/if}-->

								</div>

								<dl>

									<dt><a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a><!--{if $forum[todayposts] && !$forum['redirect']}--><em class="xw0 xi1" title="{lang forum_todayposts}"> ($forum[todayposts])</em><!--{/if}--></dt>

									<dd>

										<!--{if $forum[threadtypes]}-->

											<!--{eval $threadtypes = unserialize($forum[threadtypes]);$ti = 1;}-->

											<p>

											<!--{loop $threadtypes[types] $key $value}-->

												<!--{if $ti > 3 }-->{eval break;}<!--{/if}-->

												<!--{if $ti !== 1}-->��<!--{/if}-->

												<a href="forum.php?mod=forumdisplay&fid={$forum[fid]}&filter=typeid&typeid={$key}" target="_blank"><u>{$value}</u></a>

												<!--{eval $ti++}-->

											<!--{/loop}-->

											</p>

										<!--{elseif $forum['subforums']}-->

											<p>{lang forum_subforums}: $forum['subforums']</p>

										<!--{elseif $forum['moderators']}-->

											<p>{lang forum_moderators}: <span class="xi2">$forum[moderators]</span></p>

										<!--{else}-->

											<!--{if $forum[description]}-->

												<p><!--{echo cutstr($forum[description], 30)}--></p>

											<!--{else}-->

												<p>�ð�����޼��</p>

											<!--{/if}-->

										<!--{/if}-->

									</dd>

									<!--{if empty($forum[redirect])}-->

										<dd>

											<em>{lang index_today}: <!--{echo dnumber($forum[todayposts])}--></em> 

											<em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em> 

											<em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em>

										</dd>

									<!--{/if}-->

									<!--{hook/index_forum_extra $forum[fid]}-->

								</dl>

							</div>

						</td>

					<!--{else}-->

						<td class="fl_icn uc-hover" {if !empty($forum[extra][iconwidth]) && !empty($forum[icon])} style="width: {$forum[extra][iconwidth]}px;"{/if}>

							<!--{if $forum[icon]}-->

								$forum[icon]

							<!--{else}-->

								<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{$_G['style']['styleimgdir']}/img/forum{if $forum[folder]}_new{/if}.png" alt="$forum[name]" /></a>

							<!--{/if}-->

						</td>

						<td class="fl_tit uc-hover">

							<h2><a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a><!--{if $forum[todayposts] && !$forum['redirect']}--><em class="xw0 xi1" title="{lang forum_todayposts}"> ($forum[todayposts])</em><!--{/if}--></h2>

							<!--{if $forum[description]}--><p class="xg2">{eval echo cutstr($forum[description], 80, '');}</p><!--{/if}-->

							<!--{if $forum['subforums']}--><p>{lang forum_subforums}: $forum['subforums']</p><!--{/if}-->

							<!--{if $forum['moderators']}--><p>{lang forum_moderators}: <span class="xi2">$forum[moderators]</span></p><!--{/if}-->

							<!--{hook/index_forum_extra $forum[fid]}-->

						</td>

						<td class="fl_i uc-hover">

							<!--{if empty($forum[redirect])}--><span class="xi2"><!--{echo dnumber($forum[threads])}--></span><span class="xg1"> / <!--{echo dnumber($forum[posts])}--></span><!--{/if}-->

						</td>

						<td class="fl_by uc-hover">

							<div>

							<!--{if $forum['permission'] == 1}-->

								{lang private_forum}

							<!--{else}-->

								<!--{if $forum['redirect']}-->

									<a href="$forumurl" class="xi2">{lang url_link}</a>

								<!--{elseif is_array($forum['lastpost'])}-->

									<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a> <cite>$forum[lastpost][dateline] <!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>

								<!--{else}-->

									{lang never}

								<!--{/if}-->

							<!--{/if}-->

							</div>

						</td>

					</tr>

					<tr class="fl_row">

					<!--{/if}-->

					<!--{/loop}-->

					$cat['endrows']

					</tr>

				</table>

			</div>

		</div>

	</div>

	<!--{ad/intercat/bm a_c/$cat[fid]}-->

<!--{/loop}-->

<!--/��̳���а��-->



<!--��ר�����Ƽ�-->

<!--{if !empty($collectiondata['data'])}-->

	<!--{eval $forumscount = count($collectiondata['data']);}-->

	<!--{eval $forumcolumns = 3;}-->

	<!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->

	<div class="fl">

		<div class="bm bmw {if $forumcolumns} flg{/if} cl">

			<div class="bm_h cl">

				<span class="o">

					<img id="category_-2_img" src="{IMGDIR}/$cat[collapseimg]" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_-2');" />

				</span>

				<h2><a href="forum.php?mod=collection">{lang recommend_collection}</a></h2>

			</div>

			<div id="category_-2" class="bm_c" style="{echo $collapse['category_-2']}">

				<table cellspacing="0" cellpadding="0" class="fl_tb">

					<tr>

					<!--{eval $ctorderid = 0;}-->

					<!--{loop $collectiondata['data'] $key $colletion}-->

						<!--{if $ctorderid && ($ctorderid % $forumcolumns == 0)}-->

							</tr>

							<!--{if $ctorderid < $forumscount}-->

								<tr>

							<!--{/if}-->

						<!--{/if}-->

						<td class="fl_g"{if $forumcolwidth} width="$forumcolwidth"{/if}>

							<div class="fl_g_inner">

								<div class="fl_icn_g">

								<a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}" target="_blank"><img src="{$_G['style']['styleimgdir']}/img/forum.png" alt="$colletion[name]" /></a>

								</div>

								<dl>

									<dt><a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}">$colletion[name]</a></dt>

									<dd><em>{lang forum_threads}: <!--{echo dnumber($colletion[threadnum])}--></em> <em>{lang collection_commentnum}: <!--{echo dnumber($colletion[commentnum])}--></em></dd>

									<dd>

									<!--{if $colletion['lastpost']}-->

										<!--{if $forumcolumns < 3}-->

											<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($colletion[lastsubject], 30)}--></a> <cite><!--{date($colletion[lastposttime])}--> <!--{if $colletion['lastposter']}-->$colletion['lastposter']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>

										<!--{else}-->

											<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost">{lang forum_lastpost}: <!--{date($colletion[lastposttime])}--></a>

										<!--{/if}-->

									<!--{else}-->

										{lang never}

									<!--{/if}-->

									</dd>

									<!--{hook/index_followcollection_extra $colletion[ctid]}-->

								</dl>

							</div>

						</td>

						<!--{eval $ctorderid++;}-->

					<!--{/loop}-->

					<!--{if ($columnspad = $ctorderid % $forumcolumns) > 0}--><!--{echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);}--><!--{/if}-->

					</tr>

				</table>

			</div>

		</div>

	</div>

<!--{/if}-->

<!--/��ר�����Ƽ�-->