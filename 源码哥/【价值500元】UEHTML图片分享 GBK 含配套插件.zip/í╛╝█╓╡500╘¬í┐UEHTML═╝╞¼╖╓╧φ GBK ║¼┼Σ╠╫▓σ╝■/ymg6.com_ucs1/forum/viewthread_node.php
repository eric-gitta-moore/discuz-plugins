<?php echo 'www.ymg6.com';exit;?>

<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->

<!--{eval $postshowavatars = !($_G['setting']['bannedmessages'] & 2 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)));}-->



<!--{block authorverifys}-->

<!--{loop $post['verifyicon'] $vid}-->

	<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank">

		<!--{if $_G['setting']['verify'][$vid]['icon']}-->

			<img src="$_G['setting']['verify'][$vid]['icon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" />

		<!--{else}-->

			{$_G['setting']['verify'][$vid]['title']}

		<!--{/if}-->

	</a>

<!--{/loop}-->

<!--{/block}-->

<!--{if $post['first'] && $_G['forum_threadstamp']}-->

	<div id="threadstamp"><img src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" /></div>

<!--{/if}-->

<!--{if empty($post['deleted'])}-->

	<!--{if $post['first']}-->

		<div class="uc-thread" id="pid$post[pid]" summary="pid$post[pid]">

			<div class="uc-thread-header cl" id="uc_first" pid="{$post[pid]}">

				<div class="uc-thread-header-avatar">

					<a href="home.php?mod=space&uid=$_G[forum_thread][authorid]" c="1" title="$_G[forum_thread][author]"><!--{avatar($_G[forum_thread][authorid],small)}--></a>

				</div>

				<div class="uc-thread-header-title">

					<h2>

						<span id="thread_subject">$_G[forum_thread][subject]</span>

						<!--{if $_G['forum_thread']['recommendlevel']}-->&nbsp;<img src="{IMGDIR}/recommend_$_G['forum_thread']['recommendlevel'].gif" alt="" title="{lang thread_recommend} $_G['forum_thread'][recommends]" /><!--{/if}-->

						<!--{if $_G['forum_thread'][heatlevel]}-->&nbsp;<img src="{IMGDIR}/hot_$_G['forum_thread'][heatlevel].gif" alt="" title="{lang heats}: $_G['forum_thread']['heats']" /><!--{/if}-->

						<!--{if $_G['forum_thread']['closed'] == 1}-->&nbsp;<img src="{IMGDIR}/locked.gif" alt="{lang close}" title="{lang close}" class="vm" /><!--{/if}-->

						<a href="forum.php?mod=viewthread&tid=$_G[tid]$fromuid" onclick="return copyThreadUrl(this, '$_G[setting][bbname]')" {if $fromuid}title="{lang share_url_copy_comment}"{/if} style="margin-right:10px;">[{lang share_url_copy}]</a>

						<!--{if $post['invisible'] == 0}-->

						<a href="forum.php?mod=viewthread&action=printable&tid=$_G[tid]" title="{lang thread_printable}" target="_blank"><i class="ico-print ico-hover"></i></a>

						<!--{/if}-->

						<a href="forum.php?mod=redirect&goto=nextoldset&tid=$_G[tid]" title="{lang last_thread}"><i class="ico-circle-arrow-left ico-hover"></i></a>

						<a href="forum.php?mod=redirect&goto=nextnewset&tid=$_G[tid]" title="{lang next_thread}"><i class="ico-circle-arrow-right ico-hover"></i></a>

					</h2>

					<p>

						<!--{if $_G[forum_thread][authorid] && $_G[forum_thread][author]}-->

							<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><span class="z" style="color:#ff4c4c;">{lang thread_stick}</span><!--{/if}-->

							<!--{if $thread['digest'] > 0 && $filter != 'digest'}--><span class="z" style="color:#ff4c4c;">{lang thread_digest}</span><!--{/if}-->

							<span class="z"><i class="ico-user ico-hover"></i><a href="home.php?mod=space&uid=$post[authorid]" c="1" title="�����û��飺{$post[authortitle]}" target="_blank">$post[author]</a>$authorverifys</span>

							<!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->

								<!--{if !IS_ROBOT && ($_G['forum']['threadtypes']['listable'] || $_G['forum']['status'] == 3)}-->

									<span class="z"><i class="ico-list-alt ico-hover"></i><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$_G[forum_thread][typeid]">{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}</a></span>

								<!--{else}-->

									<span class="z"><i class="ico-list-alt ico-gray"></i>{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}</span>

								<!--{/if}-->

							<!--{/if}-->

							<!--{if $threadsorts && $_G['forum_thread']['sortid']}-->

								<span class="z"><i class="ico-list-alt ico-hover"></i><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_G[forum_thread][sortid]">{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}</a></span>

							<!--{/if}-->				

								<span class="z"><i class="ico-time ico-gray"></i>$post[dateline]</span>

							<!--{if $post['status'] & 8}-->

								<span class="z"><i class="ico-star-empty ico-gray"></i><!--{if $_G['setting']['mobile']['mobilecomefrom']}-->{$_G['setting']['mobile']['mobilecomefrom']}<!--{else}-->{lang from_mobile}<!--{/if}--></span>

							<!--{/if}-->

							<!--{if $post['invisible'] == 0}-->

								<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->

									<span class="z"><i class="ico-eye-close ico-hover"></i><a href="forum.php?mod=viewthread&tid=$post[tid]&page=$page&authorid=$post[authorid]" rel="nofollow">ֻ��¥��</a></span>

								<!--{elseif !$_G['forum_thread']['archiveid']}-->

									<span class="z"><i class="ico-eye-open ico-hover"></i><a href="forum.php?mod=viewthread&tid=$post[tid]&page=$page" rel="nofollow">�鿴ȫ��</a></span>

								<!--{/if}-->

							<!--{/if}-->

						<!--{else}-->

							<!--{if $_G['forum']['ismoderator']}-->

								<span class="z"><i class="ico-user ico-hover"></i><a href="home.php?mod=space&uid=$_G[forum_thread][authorid]">{lang anonymous}</a></span>

							<!--{else}-->

								<span class="z"><i class="ico-user ico-gray"></i>{lang anonymous}</span>

							<!--{/if}-->

							<span class="z"><i class="ico-user ico-gray"></i>{lang poston} $post[dateline]</span>

						<!--{/if}-->

						<!--{if !$_G['forum_thread']['archiveid']}-->

							<!--{if $post['invisible'] == 0}-->

								<!--{if $_G['setting']['magicstatus']}-->

									<span class="z"><a href="javascript:;" id="mgc_post_$post[pid]" onmouseover="showMenu(this.id)" class="showmenu">{lang thread_magic}</a></span>

								<!--{/if}-->

		

								<!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->

									<span class="z"><a href="javascript:;" onclick="setanswer($post['pid'], '$_GET[from]')">{lang reward_set_bestanswer}</a></span>

								<!--{/if}-->

		

								<!--{if !$post['first'] && $_G['group']['raterange'] && $post['authorid']}-->

									<span class="z"><a href="javascript:;" onclick="showWindow('rate', 'forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]', 'get', -1);return false;">{lang rate}</a></span>

								<!--{/if}-->

		

								<!--{if !empty($postlist[$post[pid]]['totalrate']) && $_G['forum']['ismoderator']}-->

									<span class="z"><a href="forum.php?mod=misc&action=removerate&tid=$_G[tid]&pid=$post[pid]&page=$page" onclick="showWindow('rate', this.href, 'get', -1)">{lang removerate}</a></span>

								<!--{/if}-->

								<!--{if $post['authorid'] != $_G['uid']}-->

									<span class="z"><a href="javascript:;" onclick="showWindow('miscreport$post[pid]', 'misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]', 'get', -1);return false;">{lang report}</a></span>

								<!--{/if}-->

							<!--{/if}-->

							<!--{if $post['invisible'] == 0}-->

								<!--{if $allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])}-->

									<span class="z"><a href="forum.php?mod=misc&action=comment&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page{if $_G['forum_thread']['special'] == 127}&special=$specialextra{/if}" onclick="showWindow('comment', this.href, 'get', 0)">{lang comments}</a></span>

								<!--{/if}-->

								<!--{if (!$_G['uid'] || $allowpostreply) && !$needhiddenreply}-->

									<!--{if $post['first']}-->

										<span class="z"><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&extra=$_GET[extra]&page=$page" onclick="showWindow('reply', this.href)">{lang reply}</a></span>	

									<!--{else}-->

										<span class="z"><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" onclick="showWindow('reply', this.href)">{lang reply}</a></span>

									<!--{/if}-->

								<!--{/if}-->

							<!--{/if}-->

							<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->

								<span class="z"><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}<!--{/if}--></a></span>

							<!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->

								<span class="z"><a href="forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page" onClick="showWindow('postappend', this.href, 'get', 0)">{lang postappend}</a></span>

							<!--{/if}-->

							<!--{if $post['first'] && $allowblockrecommend}-->

								<span class="z"><a href="javascript:;" onclick="modaction('recommend', '$_G[forum_firstpid]', 'op=recommend&idtype={if $_G[forum_thread][isgroup]}gtid{else}tid{/if}&id=$_G[tid]&pid=$post[pid]', 'portal.php?mod=portalcp&ac=portalblock')">{lang modmenu_blockrecommend}</a></span>

							<!--{/if}-->

							<!--{hook/viewthread_postaction $postcount}-->

						<!--{/if}-->

						<!--{hook/viewthread_postheader $postcount}-->

					</p>

				</div>

				<div class="uc-thread-header-views"></div>

			</div>

			<!--{ad ad_a_pr/thread/a_pr/3/$postcount}-->

			<div class="uc-thread-content">

				<div class="uc-thread-copy"><i class="ico-exclamation-sign ico-gray"></i>��Ȩ��Ϣ��վ�ڻ�Ա������Ʒ������ѧϰ��ο�����ȨΪԭ�������С�</div>

				<!--{ad/thread/a_pt/2/$postcount}-->

				<!--{if empty($ad_a_pr_css)}-->

					<style type="text/css">.pcb{margin-right:0}</style>

					<!--{eval $ad_a_pr_css=1;}-->

				<!--{/if}-->

				<!--{if $post['replycredit'] > 0}-->

					<div class="cm">

						<h3 class="psth xs1"><span class="icon_ring vm"></span>

							{lang replycredit} <span class="xw1 xs2 xi1">+{$post['replycredit']}</span> {$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][unit]}{$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][title]}

						</h3>

					</div>

				<!--{/if}-->

				<!--{subtemplate forum/viewthread_node_body}-->

			</div>

			<!--{if helper_access::check_module('collection') && !$_G['forum']['disablecollect']}-->

				<!--{if $post['relatecollection']}-->

					<div class="cm">

						<h3 class="psth xs1"><span class="icon_ring vm"></span>{lang collection_related}</h3>

						<ul class="mbw xl xl2 cl">

						<!--{loop $post['relatecollection'] $var}-->

							<li>&middot; <a href="forum.php?mod=collection&action=view&ctid=$var[ctid]" title="$var[name]" target="_blank" class="xi2 xw1">$var[name]</a><span class="pipe">|</span><span class="xg1">{lang collection_threadnum}: $var[threadnum], {lang collection_follow}: $var[follownum]</span></li>

						<!--{/loop}-->

						<!--{if $post['releatcollectionmore']}-->

							<li>&middot; <a href="forum.php?mod=collection&tid=$_G[tid]" target="_blank" class="xi2 xw1">{lang more}</a></li>

						<!--{/if}-->

						</ul>

					</div>

					<!--{if $post['sourcecollection']['ctid']}-->

					<div>

						{lang collection_fromctid}

						<form action="forum.php?mod=collection&action=comment&ctid={$ctid}&tid={$_G[tid]}" method="POST" class="ptm pbm cl">

							<input type="hidden" name="ratescore" id="ratescore" />

							<span class="clct_ratestar">

								<span class="btn">

									<a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star',1)" onmouseout="rateStarHover('clct_ratestar_star',0)" onclick="rateStarSet('clct_ratestar_star',1,'ratescore')">1</a>

									<a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star',2)" onmouseout="rateStarHover('clct_ratestar_star',0)" onclick="rateStarSet('clct_ratestar_star',2,'ratescore')">2</a>

									<a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star',3)" onmouseout="rateStarHover('clct_ratestar_star',0)" onclick="rateStarSet('clct_ratestar_star',3,'ratescore')">3</a>

									<a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star',4)" onmouseout="rateStarHover('clct_ratestar_star',0)" onclick="rateStarSet('clct_ratestar_star',4,'ratescore')">4</a>

									<a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star',5)" onmouseout="rateStarHover('clct_ratestar_star',0)" onclick="rateStarSet('clct_ratestar_star',5,'ratescore')">5</a>

								</span>

								<span id="clct_ratestar_star" class="star star$memberrate"></span>

							</span>

							&nbsp;<button type="submit" value="submit" class="pn"><span>{lang collection_rate}</span></button>

						</form>

					</div>

					<!--{/if}-->

				<!--{/if}-->

			<!--{/if}-->

			<!--{if $locations[$post[pid]]}-->

				<div class="mobile-location">$locations[$post[pid]][location]</div>

			<!--{/if}-->

			<!--{if !IS_ROBOT && !$_G['forum_thread']['archiveid']}-->

				<!--{if $post['invisible'] == 0}-->

					<div id="p_btn" class="mtw mbm hm cl">

						<!--{if !empty($_G['setting']['pluginhooks']['viewthread_share_method'])}-->

							<div class="tshare cl">

								<b>{lang viewthread_share_to}:&nbsp;</b>

								<!--{hook/viewthread_share_method}-->

							</div>

						<!--{/if}-->

						<!--{hook/viewthread_useraction}-->

					</div>

				<!--{/if}-->

			<!--{/if}-->

			<!--{hook/viewthread_postsightmlafter $postcount}-->

			<!--{ad/thread/a_pb/1/$postcount}-->

			<div class="uc-thread-footer">

				<!--{if $post['invisible'] == 0}-->

					<a class="uc-thread-footer-like-btn" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', 'recommendupdate({$_G['group']['allowrecommend']})');return false;"{else} onclick="showWindow('login', this.href)"{/if} title="$_G[forum_thread][recommend_add]ϲ��"><i class="ico-heart ico-white"></i>ϲ�� ��$_G[forum_thread][recommend_add]��</a>

				<!--{/if}-->

				<div class="uc-thread-footer-other cl">

					<!--{if $post['first'] && ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->

					<div class="uc-thread-footer-tags">

						<span><i class="ico-tags"></i>��ǩ</span>

						<!--{if $post[tags]}-->

							<!--{loop $post[tags] $var}-->

								<a title="$var[1]" href="misc.php?mod=tag&id=$var[0]" target="_blank">$var[1]</a>

							<!--{/loop}-->

						<!--{/if}-->

						<!--{if $relatedkeywords}--><span>$relatedkeywords</span><!--{/if}-->

					</div>

					<!--{/if}-->

					<div class="uc-thread-footer-share bdsharebuttonbox">

						<span><i class="ico-share ico-gray"></i>������</span>

						<div class="uc-thread-footer-share-box">

							<a href="#" class="bds_qzone" data-cmd="qzone" title="������QQ�ռ�">QQ�ռ�</a>

							<a href="#" class="bds_tsina" data-cmd="tsina" title="����������΢��">����΢��</a>

							<a href="#" class="bds_weixin" data-cmd="weixin" title="������΢��">΢��</a>

							<a href="#" class="bds_tqq" data-cmd="tqq" title="��������Ѷ΢��">��Ѷ΢��</a>

							<a href="#" class="bds_renren" data-cmd="renren" title="������������">������</a>

							<a href="#" class="bds_huaban" data-cmd="huaban" title="����������">������</a>

							<a href="#" class="bds_douban" data-cmd="douban" title="������������">����</a>

							<a href="#" class="bds_diandian" data-cmd="diandian" title="�����������">���</a>

						</div>

					</div>

				</div>

			</div>

		</div>

		<div class="uc-author-works">

			<div class="uc-author-works-title">TA��������Ʒ<span><a href="home.php?mod=space&uid={$post[authorid]}&do=thread&from=space" target="_blank" class="author-all-works">�鿴ȫ��</a></span></div>

			<div class="uc-author-works-content">

				<ul>

					<!--{loop $ucthread $item}-->

						<li>

							<a href="forum.php?mod=viewthread&tid={$item['tid']}" title="$item[subject] by $item[author]" target="_blank">

								<!--{if $item['cover']}-->

									<!--{eval $item['coverpath'] = getthreadcover($item['tid'], 1);}-->

									<span style="background-image:url('{$item['coverpath']}');"></span>

								<!--{else}-->

									<span class="nopic" style="background-size:auto auto;" title="$item[subject] by $item[author]"></span>

								<!--{/if}-->

							</a>

						</li>

					<!--{/loop}-->

				</ul>

			</div>

		</div>

	<!--{else}-->

		<div class="uc-comment-item" id="pid$post[pid]" summary="pid$post[pid]">

			<div class="uc-comment-avatar"><a href="home.php?mod=space&uid=$post[authorid]" c="1" target="_blank">$post[avatar]</a></div>

			<div class="uc-comment-content">

				<p class="item-info">

					<!--{if ($post['authorid'] && !$post['anonymous']) || getstatus($post['status'], 5)}-->

						<a href="home.php?mod=space&uid=$post[authorid]" c="1" target="_blank" class="item-username">$post[author]</a>

						<span class="item-date" id="authorposton$post[pid]"><i class="ico-time ico-gray"></i>$post[dateline]</span>

						<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->

							<a class="item-like" href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', '');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = ($('review_support_$post[pid]').innerHTML ? $('review_support_$post[pid]').innerHTML : 0) + ' {lang activity_member_unit} {lang support_reply}'"><i class="ico-thumbs-up ico-hover"></i>�ޣ�<span id="review_support_$post[pid]">{if $post[postreview][support]==0}0{else}$post[postreview][support]{/if}</span>��</a>

						<!--{/if}-->

					<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous'] || !$post['authorid'] && !$post['username']}-->

						<a class="item-username">$_G[setting][anonymoustext]</a>

						<span class="item-date" id="authorposton$post[pid]"><i class="ico-time ico-gray"></i>$post[dateline]</span>

					<!--{/if}-->	

					<!--{hook/viewthread_postheader $postcount}-->

					<!--{if isset($post[isstick])}-->

						<span style="color:#ff7800">���ö���</span>

					<!--{/if}-->

					<!--{if !$post['first'] && $modmenu['post']}-->

						<span>

						<label for="manage$post[pid]">

						<input type="checkbox" id="manage$post[pid]" class="pc" {if !empty($modclick)}checked="checked" {/if}onclick="pidchecked(this);modclick(this, $post[pid])" value="$post[pid]" autocomplete="off" />

						{lang manage}

						</label>

						</span>

					<!--{/if}-->

					<strong class="y">

						<a href="{if $post[first]}forum.php?mod=viewthread&tid=$_G[tid]$fromuid{else}forum.php?mod=redirect&goto=findpost&ptid=$_G[tid]&pid=$post[pid]$fromuid{/if}"  {if $fromuid}title="{lang share_url_copy_comment}"{/if} id="postnum$post[pid]" onclick="setCopy(this.href, '{lang post_copied}');return false;"<!--{if isset($post[isstick]) && $close_leftinfo}--> class="km2"<!--{elseif $post[number] == -1 && $close_leftinfo}--> class="km1"<!--{elseif $post[number] == 1}--> class="km1"<!--{elseif $post[number] == 2}--> class="km2"<!--{elseif $post[number] == 3}--> class="km3"<!--{elseif $post[number] == 4}--> class="km4"<!--{/if}-->>

							<!--{if isset($post[isstick])}-->

								<!--{if !$close_leftinfo}--><img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="vm" /> <!--{/if}--><!--{if $close_leftinfo}-->{lang replystick} <!--{/if}-->{lang from} {$post[number]}{$postnostick}

							<!--{elseif $post[number] == -1}-->

								{lang recommend}

							<!--{else}-->

								<!--{if !empty($postno[$post[number]])}-->

									$postno[$post[number]]

								<!--{else}-->

									<em>{$post[number]}</em>{$postno[0]}

								<!--{/if}-->

							<!--{/if}-->

						</a>

					</strong>

				</p>

				<!--{subtemplate forum/viewthread_node_body}-->

			</div>

		</div>

	<!--{/if}-->

	<!--{hook/viewthread_postfooter $postcount}-->

	<!--{if !$_G['forum_thread']['archiveid']}-->

		<!--{if $_G['setting']['magicstatus']}-->

			<ul id="mgc_post_$post[pid]_menu" class="p_pop mgcmn" style="display: none;">

			<!--{if $post['first']}-->

				<!--{if !empty($_G['setting']['magics']['bump'])}-->

					<li><a href="home.php?mod=magic&mid=bump&idtype=tid&id=$_G[tid]" id="a_bump" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/bump.small.gif" />$_G['setting']['magics']['bump']</a></li>

				<!--{/if}-->

				<!--{if !empty($_G['setting']['magics']['stick'])}-->

					<li><a href="home.php?mod=magic&mid=stick&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/stick.small.gif" />$_G['setting']['magics']['stick']</a></li>

				<!--{/if}-->

				<!--{if !empty($_G['setting']['magics']['close'])}-->

					<li><a href="home.php?mod=magic&mid=close&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/close.small.gif" />$_G['setting']['magics']['close']</a></li>

				<!--{/if}-->

				<!--{if !empty($_G['setting']['magics']['open'])}-->

					<li><a href="home.php?mod=magic&mid=open&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/open.small.gif" />$_G['setting']['magics']['open']</a></li>

				<!--{/if}-->

				<!--{if !empty($_G['setting']['magics']['highlight'])}-->

					<li><a href="home.php?mod=magic&mid=highlight&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/highlight.small.gif" />$_G['setting']['magics']['highlight']</a></li>

				<!--{/if}-->

				<!--{if !empty($_G['setting']['magics']['sofa'])}-->

					<li><a href="home.php?mod=magic&mid=sofa&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/sofa.small.gif" />$_G['setting']['magics']['sofa']</a></li>

				<!--{/if}-->

				<!--{if !empty($_G['setting']['magics']['jack'])}-->

					<li><a href="home.php?mod=magic&mid=jack&idtype=tid&id=$_G[tid]" id="a_jack" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/jack.small.gif" />$_G['setting']['magics']['jack']</a></li>

				<!--{/if}-->

				<!--{hook/viewthread_magic_thread}-->

			<!--{/if}-->

			<!--{if !empty($_G['setting']['magics']['repent']) && $post['authorid'] == $_G['uid'] && !$rushreply}-->

				<li><a href="home.php?mod=magic&mid=repent&idtype=pid&id=$post[pid]:$_G[tid]" id="a_repent_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/repent.small.gif" />$_G['setting']['magics']['repent']</a></li>

			<!--{/if}-->

			<!--{if !empty($_G['setting']['magics']['anonymouspost']) && $post['authorid'] == $_G['uid']}-->

				<li><a href="home.php?mod=magic&mid=anonymouspost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_anonymouspost_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/anonymouspost.small.gif" />$_G['setting']['magics']['anonymouspost']</a><li>

			<!--{/if}-->

			<!--{if !empty($_G['setting']['magics']['namepost'])}-->

				<li><a href="home.php?mod=magic&mid=namepost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_namepost_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/namepost.small.gif" />$_G['setting']['magics']['namepost']</a><li>

			<!--{/if}-->

			<!--{hook/viewthread_magic_post $postcount}-->

			</ul>

			<script type="text/javascript" reload="1">checkmgcmn('post_$post[pid]')</script>

		<!--{/if}-->

	<!--{/if}-->

	<!--{if $_G['forum_thread']['replies']}--><!--{ad/interthread/a_p/$postcount}--><!--{/if}-->

	<!--{if !empty($aimgs[$post[pid]])}-->

	<script type="text/javascript" reload="1">

		aimgcount[{$post[pid]}] = [<!--{echo dimplode($aimgs[$post[pid]]);}-->];

		attachimggroup($post['pid']);

		<!--{if empty($_G['setting']['lazyload'])}-->

			<!--{if !$post['imagelistthumb']}-->

				attachimgshow($post[pid]);

			<!--{else}-->

				attachimgshow($post[pid], 1);

			<!--{/if}-->

		<!--{/if}-->

		var aimgfid = 0;

		<!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || $_G['uid'] == $_G['thread']['authorid'])}-->

			aimgfid = $_G[fid];

		<!--{/if}-->

		<!--{if $post['imagelistthumb']}-->

			attachimglstshow($post['pid'], <!--{echo intval($_G['setting']['lazyload'])}-->, aimgfid, '{$_G[setting][showexif]}');

		<!--{/if}-->

	</script>

	<!--{/if}-->

<!--{else}-->

	<div class="uc-delete" id="pid$post[pid]" summary="pid$post[pid]">

		<div class="pi"><strong><a><!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}--><em>{$post[number]}</em>{$postno[0]}<!--{/if}--></a></strong></div>

		<div class="pct">{lang post_deleted}</div>

	</div>

<!--{/if}-->

<!--{hook/viewthread_endline $postcount}-->