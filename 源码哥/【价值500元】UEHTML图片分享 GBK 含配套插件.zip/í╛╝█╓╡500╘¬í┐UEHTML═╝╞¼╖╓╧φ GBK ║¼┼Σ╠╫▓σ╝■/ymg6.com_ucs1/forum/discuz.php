<?php echo 'www.ymg6.com';exit;?>

<!--{if ($_GET['ucUpdateMessageType'] || $_GET['ucUpdateMessageID']) && $_G[uid]}-->

	<!--{eval}-->

		$update = array();

		$uid = ' AND '.DB::field('uid', $_G[uid]);

		$ids = $_GET['ucUpdateMessageID'];

		$type = $_GET['ucUpdateMessageType'];

		$update['new'] = 0;

		$where = DB::field('uid', $_G[uid]);

		if($type && $type !== 'other'){

			$where .= ' AND '.DB::field('type', $type);

		}

		if($ids){

			$ids = explode(',',str_replace(' ','',$ids));

			$ids = array_filter($ids);

			$where .= ' AND '.DB::field('id', $ids);

		}

		if($type || $ids){

			DB::update('home_notification', $update, $where);

		}

	<!--{/eval}-->

<!--{else}-->

	<!--{template common/header}-->

	<style id="diy_style" type="text/css"></style>

		<!--{if $uctype !== 0}-->

			<!--{template forum/discuz_data}-->

			<!--{if $uc['topbar']['type'] !== 0}-->

				<!--{template forum/discuz_topbar}-->

			<!--{else}-->

				<!--[diy=diy_ucTop]--><div id="diy_ucTop" class="area"></div><!--[/diy]-->

			<!--{/if}-->

			<div id="wp" class="wp">

			<!--{template forum/discuz_toolbar}-->

			<!--[diy=diy_ucForumTop]--><div id="diy_ucForumTop" class="area"></div><!--[/diy]-->

			<div class="uc-piclist{if $uctype == 3 || $uctype == 4} uc-article{/if}">

				<!--{if $uctype == 1}--><!--{eval $slide_h = $ucth+90;}--><!--{elseif $uctype == 3}--><!--{eval $slide_h = $ucth+268;}--><!--{else}--><!--{eval $slide_h = $ucgth+90;}--><!--{/if}-->

				<style type="text/css">

					body .uc-piclist .uc-slide,body .uc-piclist .uc-slide li,body .uc-piclist .uc-slide li,body .uc-piclist .uc-slide-thumb { width:580px; height:{$slide_h}px; }

				</style>

				<ul id="waterfall" class="cl">

					<li class="uc-slide" id="ucSlide">

						<div class="uc-slide-btn">

							<a href="javascript:void(0)" class="prev"><i class="ico-left ico-white"></i></a>

							<a href="javascript:void(0)" class="next"><i class="ico-right ico-white"></i></a>

						</div>

						<!--[diy=diy_ucSlide]--><div id="diy_ucSlide" class="area"></div><!--[/diy]-->

						<div>

							<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/slide.js"></script>

							<script type="text/javascript" reload="1">

								ucSlide('ucSlide');

							</script>

						</div>

					</li>

					<!--{loop $list $key $thread}-->

						<li style="width:{$uctw}px">

							<div class="uc-piclist-con-top">

								<div class="uc-thumb">

									<a href="forum.php?mod=viewthread&tid={$thread[tid]}&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra={$extra}" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="{$thread[subject]} by {$thread[author]}" class="z">

										<!--{if $thread['cover']}-->

											<img src="{$thread[coverpath]}" alt="{$thread[subject]} by {$thread[author]}" width="{$uctw}" {if $uctype == 1 || $uctype == 3}height="{$ucth}"{/if} />

										<!--{else}-->

											<span class="nopic" style="width:{$uctw}px; height:{$ucth}px;" title="{$thread[subject]} by {$thread[author]}"></span>

										<!--{/if}-->

									</a>

								</div>

								<!--{if $uctype == 1 || $uctype == 2}-->

								<div class="uc-title">

									<a href="forum.php?mod=viewthread&tid={$thread[tid]}&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra={$extra}"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="{$thread[subject]} by {$thread[author]}" class="uc-title-a"><span>{$thread[subject]}</span></a>

									<div class="uc-title-bg"></div>

								</div>

								<!--{/if}-->

							</div>

							<div class="uc-piclist-con-bot">

								<!--{if $uctype == 3 || $uctype == 4}-->

									<div class="uc-title">

										<a href="forum.php?mod=viewthread&tid={$thread[tid]}&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra={$extra}"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="{$thread[subject]} by {$thread[author]}" class="uc-title-a"><span>{$thread[subject]}</span></a>

									</div>

									<div class="uc-author">

										<!--{if $thread['authorid'] && $thread['author']}-->

											<a href="home.php?mod=space&uid={$thread[authorid]}" c="1" title="{$thread[author]}" target="_blank">{$thread[author]}</a>

										<!--{else}-->

											<a href="javascript:void(0)">{$_G[setting][anonymoustext]}</a>

										<!--{/if}-->

										<span><i class="ico-time ico-gray"></i>{eval echo dgmdate($thread['dateline'], 'u', '9999', getglobal('setting/dateformat'))}</span>								

									</div>

									<div class="uc-summary"{if $uctype == 3} style="height:{$ucch}px;overflow:hidden;"{/if}>

									<!--{eval}-->

										$query = DB::fetch_first("SELECT message, tid FROM ".DB::table('forum_post')." WHERE tid = ".$thread['tid']." AND first=1");

										$thread['summary'] = cutstr($query['message'], $uccm, '');

										echo $thread['summary'];

									<!--{/eval}-->

									</div>

									<div class="uc-stat">

										<span title="{lang show}"><i class="ico-eye-open ico-gray"></i>{$thread[views]}</span>

										<span title="{lang reply}"><i class="ico-comment ico-gray"></i>{$thread[replies]}</span>

										<span title="{lang like}"><i class="ico-heart ico-gray"></i><!--{if $thread[recommends]}-->{$thread[recommends]}<!--{else}-->0<!--{/if}--></span>

										<a href="forum.php?mod=forumdisplay&fid=$thread[fid]" class="uc-forumname" target="_blank">$forumname[$thread[fid]]</a>

									</div>

								<!--{else}-->

									<div class="uc-stat">

										<span title="{lang show}"><i class="ico-eye-open ico-gray"></i>{$thread[views]}</span>

										<span title="{lang reply}"><i class="ico-comment ico-gray"></i>{$thread[replies]}</span>

										<span title="{lang like}"><i class="ico-heart ico-gray"></i><!--{if $thread[recommends]}-->{$thread[recommends]}<!--{else}-->0<!--{/if}--></span>

									</div>

									<div class="uc-author">

										<!--{if $thread['authorid'] && $thread['author']}-->

											<a href="home.php?mod=space&uid={$thread[authorid]}" c="1" class="z" title="{$thread[author]}" target="_blank"><!--{avatar($thread[authorid],middle)}--><span>{$thread[author]}</span></a>

										<!--{else}-->

											<a href="javascript:void(0)">{$_G[setting][anonymoustext]}</a>

										<!--{/if}-->

										<a href="forum.php?mod=forumdisplay&fid=$thread[fid]" class="uc-forumname" target="_blank">$forumname[$thread[fid]]</a>

									</div>

								<!--{/if}-->

							</div>

						</li>

					<!--{/loop}-->

				</ul>

				<div class="uc-pagelist cl">{$multipage}</div>

			</div>

			<!--{if $uctype == 2 || $uctype == 4}-->

			<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/masonry.pkgd.min.js"></script>

			<script type="text/javascript" reload="1">

			_attachEvent(window, "load", function () {	

				if($("waterfall")) {

					var ele = $('waterfall');

					new Masonry(ele, {itemSelector:'li',animate:false,columnWidth:$uctw+20});

				}

			});

			</script>

			<!--{/if}-->

		<!--{else}-->

			<div id="pt" class="cl">

				<!--{if empty($gid) && $announcements}-->

				<div class="y">

					<div id="an">

						<dl class="cl">

							<dt class="z xw1">{lang announcements}:&nbsp;</dt>

							<dd>

								<div id="anc"><ul id="ancl">$announcements</ul></div>

							</dd>

						</dl>

					</div>

					<script type="text/javascript">announcement();</script>

				</div>

				<!--{/if}-->

				<div class="z">

					<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a><em>&raquo;</em><a href="forum.php">{$_G[setting][navs][2][navname]}</a>$navigation

				</div>

				<div class="z"><!--{hook/index_status_extra}--></div>

			</div>

			<!--{if empty($gid)}-->

				<!--{ad/text/wp a_t}-->

			<!--{/if}-->

			<!--{if empty($gid)}-->

				<div class="wp">

					<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->

				</div>

			<!--{/if}-->

			<!--{if empty($gid)}-->

				<div class="uc-chart">

					<div class="uc-chart-info">

						<ul>

							<li><strong>$posts</strong><span>վ��������</span></li>

							<li><strong>$postdata[0]</strong><span>���շ�����</span></li>

							<li><strong>$todayposts</strong><span>���շ�����</span></li>

							<li><strong>$_G['cache']['userstats']['totalmembers']</strong><span>վ���Ա����</span></li>

						</ul>

					</div>

				</div>

			<!--{/if}-->

			<div id="ct" class="wp cl{if $_G['setting']['forumallowside']} ct2{/if} uc-catlist">

				<div class="mn">

					<!--{if !empty($_G['setting']['grid']['showgrid'])}-->

						<!--{template forum/discuz_default_grid}-->

					<!--{/if}-->

					<!--{hook/index_top}-->

					<!--{if !empty($_G['cache']['heats']['message'])}-->

						<div class="bm">

							<div class="bm_h cl">

								<h2>{lang hotthreads_forum}</h2>

							</div>

							<div class="bm_c cl">

								<div class="heat z">

									<!--{loop $_G['cache']['heats']['message'] $data}-->

										<dl class="xld">

											<dt><!--{if $_G['adminid'] == 1}--><a class="d" href="forum.php?mod=misc&action=removeindexheats&tid=$data[tid]" onclick="return removeindexheats()">delete</a><!--{/if}-->

											<a href="forum.php?mod=viewthread&tid=$data[tid]" target="_blank" class="xi2">$data[subject]</a></dt>

											<dd>$data[message]</dd>

										</dl>

									<!--{/loop}-->

								</div>

								<ul class="xl xl1 heatl">

								<!--{loop $_G['cache']['heats']['subject'] $data}-->

									<li><!--{if $_G['adminid'] == 1}--><a class="d" href="forum.php?mod=misc&action=removeindexheats&tid=$data[tid]" onclick="return removeindexheats()">delete</a><!--{/if}-->&middot; <a href="forum.php?mod=viewthread&tid=$data[tid]" target="_blank" class="xi2">$data[subject]</a></li>

								<!--{/loop}-->

								</ul>

							</div>

						</div>

					<!--{/if}-->

					<!--{hook/index_catlist_top}-->

					<!--{template forum/discuz_default_cate}-->

					<!--{hook/index_middle}-->

					<div class="wp mtn">

						<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->

					</div>

				</div>

				<!--{if $_G['setting']['forumallowside']}-->

					<div id="sd" class="sd">

						<!--{hook/index_side_top}-->

						<!--[diy=index_side]--><div id="index_side" class="area"></div><!--[/diy]-->

						<!--{hook/index_side_bottom}-->

					</div>

				<!--{/if}-->

			</div>

			<!--{if $_G['group']['radminid'] == 1}-->

				<!--{eval helper_manyou::checkupdate();}-->

			<!--{/if}-->

			<!--{if empty($_G['setting']['disfixednv_forumindex']) }--><script>fixed_top_nv();</script><!--{/if}-->

		<!--{/if}-->

	

		<div class="uc-module cl">

			<div class="uc-item i1"><!--[diy=diy_forum_index_module_1]--><div id="diy_forum_index_module_1" class="area"></div><!--[/diy]--></div>

			<div class="uc-item i2"><!--[diy=diy_forum_index_module_2]--><div id="diy_forum_index_module_2" class="area"></div><!--[/diy]--></div>

			<div class="uc-item i3"><!--[diy=diy_forum_index_module_3]--><div id="diy_forum_index_module_3" class="area"></div><!--[/diy]--></div>

		</div>

		<!--{if empty($gid) && $_G['setting']['whosonlinestatus']}-->

			<div id="online" class="bm oll">

				<div class="bm_h">

				<!--{if $detailstatus}-->

					<span class="o"><a href="forum.php?showoldetails=no#online" title="{lang spread}"><img src="{IMGDIR}/collapsed_no.gif" alt="{lang spread}" /></a></span>

					<h3>

						<strong><a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a></strong>

						<span class="xs1">- <strong>$onlinenum</strong> {lang onlines}

						- <strong>$membercount</strong> {lang index_members}(<strong>$invisiblecount</strong> {lang index_invisibles}),

						<strong>$guestcount</strong> {lang index_guests}

						- {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>

					</h3>

				<!--{else}-->

					<!--{if empty($_G['setting']['sessionclose'])}-->

						<span class="o"><a href="forum.php?showoldetails=yes#online" title="{lang spread}"><img src="{IMGDIR}/collapsed_yes.gif" alt="{lang spread}" /></a></span>

					<!--{/if}-->

					<h3>

						<strong>

							<!--{if !empty($_G['setting']['whosonlinestatus'])}-->

								{lang onlinemember}

							<!--{else}-->

								<a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a>

							<!--{/if}-->

						</strong>

						<span class="xs1">- {lang total} <strong>$onlinenum</strong> {lang onlines}

						<!--{if $membercount}-->- <strong>$membercount</strong> {lang index_members},<strong>$guestcount</strong> {lang index_guests}<!--{/if}-->

						- {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>

					</h3>

				<!--{/if}-->

				</div>

				<!--{if $_G['setting']['whosonlinestatus'] && $detailstatus}-->

					<dl id="onlinelist" class="bm_c">

						<dt class="ptm pbm bbda">$_G[cache][onlinelist][legend]</dt>

						<!--{if $detailstatus}-->

							<dd class="ptm pbm">

							<ul class="cl">

							<!--{if $whosonline}-->

								<!--{loop $whosonline $key $online}-->

									<li title="{lang time}: $online[lastactivity]">

									<img src="{STATICURL}image/common/$online[icon]" alt="icon" />

									<!--{if $online['uid']}-->

										<a href="home.php?mod=space&uid=$online[uid]" c="1">$online[username]</a>

									<!--{else}-->

										$online[username]

									<!--{/if}-->

									</li>

								<!--{/loop}-->

							<!--{else}-->

								<li style="width: auto">{lang online_only_guests}</li>

							<!--{/if}-->

							</ul>

						</dd>

						<!--{/if}-->

					</dl>

				<!--{/if}-->

			</div>

		<!--{/if}-->

	

		<!--{if empty($gid) && ($_G['cache']['forumlinks'][0] || $_G['cache']['forumlinks'][1] || $_G['cache']['forumlinks'][2])}-->

			<div class="bm lk">

				<div class="bm_h cl">

					<h2>��������</h2>

				</div>

				<div id="category_lk" class="bm_c ptm">

					<!--{if $_G['cache']['forumlinks'][0]}-->

						<ul class="m mbn cl">$_G['cache']['forumlinks'][0]</ul>

					<!--{/if}-->

					<!--{if $_G['cache']['forumlinks'][1]}-->

						<div class="mbn cl">

							$_G['cache']['forumlinks'][1]

						</div>

					<!--{/if}-->

					<!--{if $_G['cache']['forumlinks'][2]}-->

						<ul class="x mbm cl">

							$_G['cache']['forumlinks'][2]

						</ul>

					<!--{/if}-->

				</div>

			</div>

		<!--{/if}-->

		<!--{hook/index_bottom}-->

	<!--{template common/footer}-->

<!--{/if}-->