<?php echo 'www.ymg6.com';exit;?>

<!--{template common/header}-->



<!--{eval $ucthread = C::t('forum_thread')->fetch_all_by_authorid($_G['forum_thread']['authorid'], 0,8);}-->

<!--{eval $ucauthor = DB::fetch_first("SELECT `follower`,`threads`,`following` FROM ".DB::table('common_member_count')." WHERE uid = ".$_G['forum_thread']['authorid']);}-->

<script type="text/javascript">var fid = parseInt('$_G[fid]'), tid = parseInt('$_G[tid]');</script>

<!--{if $modmenu['thread'] || $modmenu['post']}-->

	<script type="text/javascript" src="{$_G['setting']['jspath']}forum_moderate.js?{VERHASH}"></script>

<!--{/if}-->



<script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>

<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']);var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}';var aimgcount = new Array();</script>



<style id="diy_style" type="text/css"></style>



<!--{hook/viewthread_top}-->

<!--{ad/text/wp a_t}-->



<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->



<!--{if $modmenu['post']}-->

	<div id="mdly" class="fwinmask" style="display:none;z-index:350;">

		<table cellspacing="0" cellpadding="0" class="fwin">

			<tr>

				<td class="t_l"></td>

				<td class="t_c"></td>

				<td class="t_r"></td>

			</tr>

			<tr>

				<td class="m_l">&nbsp;&nbsp;</td>

				<td class="m_c">

					<div class="f_c">

						<div class="c">

							<h3>{lang admin_select}&nbsp;<strong id="mdct" class="xi1"></strong>&nbsp;{lang piece}: </h3>

							<!--{if $_G['forum']['ismoderator']}-->

								<!--{if $_G['group']['allowwarnpost']}--><a href="javascript:;" onclick="modaction('warn')">{lang modmenu_warn}</a><span class="pipe">|</span><!--{/if}-->

								<!--{if $_G['group']['allowbanpost']}--><a href="javascript:;" onclick="modaction('banpost')">{lang modmenu_banpost}</a><span class="pipe">|</span><!--{/if}-->

								<!--{if $_G['group']['allowdelpost'] && !$rushreply}--><a href="javascript:;" onclick="modaction('delpost')">{lang modmenu_deletepost}</a><span class="pipe">|</span><!--{/if}-->

							<!--{/if}-->

							<!--{if $_G['forum']['ismoderator'] && $_G['group']['allowstickreply'] || $_G['forum_thread']['authorid'] == $_G['uid']}--><a href="javascript:;" onclick="modaction('stickreply')">{lang modmenu_stickpost}</a><span class="pipe">|</span><!--{/if}-->

							<!--{if $_G['forum_thread']['pushedaid'] && $allowpostarticle}--><a href="javascript:;" onclick="modaction('pushplus', '', 'aid=$_G[forum_thread][pushedaid]', 'portal.php?mod=portalcp&ac=article&op=pushplus')">{lang modmenu_pushplus}</a><span class="pipe">|</span><!--{/if}-->

						</div>

					</div>

				</td>

				<td class="m_r"></td>

			</tr>

			<tr>

				<td class="b_l"></td>

				<td class="b_c"></td>

				<td class="b_r"></td>

			</tr>

		</table>

	</div>

<!--{/if}-->





<!--{hook/viewthread_beginline}-->



<div class="uc-postview cl">

	<div class="uc-postview-main z">	

		<div id="postlist" class="uc-post">

			<!--{eval $postcount = 0;}-->

			<!--{eval $ucommentlist = 0;}-->

			<!--{loop $postlist $post}-->

				<!--{if $rushreply && $_GET['checkrush'] && $post['rewardfloor'] != 1}-->

					<!--{eval continue;}-->

				<!--{/if}-->

				<!--{if $post['first']}-->

					<div id="post_$post[pid]" {if $_G['blockedpids'] && $post['inblacklist']}style="display:none;"{/if}>

						<!--{subtemplate forum/viewthread_node}-->

					</div>

					<div class="uc-comment-list" id="comment_list">

						<div class="uc-comment-title cl">

							<h2>

								<!--{if !IS_ROBOT && !$_G['forum_thread']['archiveid'] && !$rushreply}-->

									<div class="y"><a onmouseover="showMenu(this.id)" class="showmenu" href="javascript:;" id="uc_view_orderby"><!--{if $ordertype != 1}-->{lang post_ascview}<!--{else}-->{lang post_descview}<!--{/if}--></a></div>

								<!--{/if}-->

								ȫ������<i>/</i><em>{$_G[forum_thread][allreplies]}&nbsp;��</em>

							</h2>

						</div>

						<!--{if !IS_ROBOT && !$_G['forum_thread']['archiveid'] && !$rushreply && $_G[forum_thread][allreplies]!=0}-->

							<div style="display:none" class="p_pop" id="uc_view_orderby_menu">

								<ul>

									<!--{if $ordertype != 1}-->

										<li><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2#comiis_allreplies">{lang post_ascview}</a></li>

										<li><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1#comiis_allreplies">{lang post_descview}</a></li>

									<!--{else}-->

										<li><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1#comiis_allreplies">{lang post_descview}</a></li>

										<li><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2#comiis_allreplies">{lang post_ascview}</a></li>

									<!--{/if}-->

								</ul>          

							</div>

						<!--{/if}-->

						<!--[diy=diyfastposttop]--><div id="diyfastposttop" class="area"></div><!--[/diy]-->

						<!--{if $fastpost}-->

							<!--{subtemplate forum/viewthread_fastpost}-->

						<!--{/if}-->

						<div id="postend"></div>

						<div id="postlistreply" class="pl"><div id="post_new" class="viewthread_table" style="display: none"></div></div>

						<!--{if $_G['blockedpids']}-->

							<div id='hiddenpoststip'><a href='javascript:display_blocked_post();'>{lang other_reply_hide}</a></div>

							<div id="hiddenposts"></div>

						<!--{/if}-->

				<!--{else}-->

					<!--{if $postcount == 0}-->

						<div class="uc-comment-black cl"><a href="forum.php?mod=viewthread&tid=$_G[tid]">���ز鿴��������</a></div>

						<div class="uc-comment-list" id="comment_list">

							<div class="uc-comment-title cl">

								<h2>

									<!--{if !IS_ROBOT && !$_G['forum_thread']['archiveid'] && !$rushreply}-->

										<div class="y"><a onmouseover="showMenu(this.id)" class="showmenu" href="javascript:;" id="uc_view_orderby"><!--{if $ordertype != 1}-->{lang post_ascview}<!--{else}-->{lang post_descview}<!--{/if}--></a></div>

									<!--{/if}-->

									ȫ������<i>/</i><em>{$_G[forum_thread][allreplies]}&nbsp;��</em>

								</h2>

							</div>

							<!--{if !IS_ROBOT && !$_G['forum_thread']['archiveid'] && !$rushreply && $_G[forum_thread][allreplies]!=0}-->

								<div style="display:none" class="p_pop" id="uc_view_orderby_menu">

									<ul>

										<!--{if $ordertype != 1}-->

											<li><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2#comiis_allreplies">{lang post_ascview}</a></li>

											<li><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1#comiis_allreplies">{lang post_descview}</a></li>

										<!--{else}-->

											<li><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1#comiis_allreplies">{lang post_descview}</a></li>

											<li><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2#comiis_allreplies">{lang post_ascview}</a></li>

										<!--{/if}-->

									</ul>          

								</div>

							<!--{/if}-->

							<!--[diy=diyfastposttop]--><div id="diyfastposttop" class="area"></div><!--[/diy]-->

							<!--{if $fastpost}-->

								<!--{subtemplate forum/viewthread_fastpost}-->

							<!--{/if}-->

							<div id="postend"></div>

							<div id="postlistreply" class="pl"><div id="post_new" class="viewthread_table" style="display: none"></div></div>

							<!--{if $_G['blockedpids']}-->

								<div id='hiddenpoststip'><a href='javascript:display_blocked_post();'>{lang other_reply_hide}</a></div>

								<div id="hiddenposts"></div>

							<!--{/if}-->

							<div id="uc_postbeg"></div>

					<!--{/if}-->

					<div id="post_$post[pid]" {if $_G['blockedpids'] && $post['inblacklist']}style="display:none;"{/if}>

						<!--{subtemplate forum/viewthread_node}-->

					</div>

				<!--{/if}-->

				<!--{eval $postcount++;}-->

			<!--{/loop}-->

			<div id="uc_postend"></div>

			<!--{if $_G['page'] == 1 }-->

				<div id="post-ajax-show"></div> 

				<div class="uc-comment-more"> 

					<div id="post-more">

						<div id="post-ajax-load" style="display:none;"><a>������...</a></div>

						<div id="post-ajax-btn"><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype={if $ordertype != 1}2{else}1{/if}&threads=thread" onclick="return ajaxpage(this.href);">����</a></div>

					</div>

				</div>

				<script type="text/javascript">

				var pages=$_G['page'];

				var allpage={echo $thispage = ceil($_G['forum_thread']['replies'] / $_G['ppp']);};

				$('post-ajax-btn').style.display = allpage > 1 ? 'block' : 'none';

				function ajaxpage(url){

					$("post-ajax-load").style.display='block';

					$("post-ajax-btn").style.display='none';

					var x = new Ajax("HTML");

					pages++;

					url=url+'&page='+pages;

					x.get(url, function (s) {

						s = s.replace(/\\n|\\r/g, "");

						s = s.substring(s.indexOf("<div id=\"uc_postbeg\"></div>"), s.indexOf("<div id=\"uc_postend\"></div>"));

						console.log(s);

						$('post-ajax-show').innerHTML+=s;

						$("post-ajax-load").style.display='none';

						if(pages==allpage){							

							$("post-more").style.display='none';

						}else{

							$("post-ajax-btn").style.display='block';

						}

					});

					return false;

				}

				</script>

			<!--{/if}-->

			</div>

			<!--{if $_G['page'] !== 1}-->

				<div class="uc-pagelist cl">$multipage</div>

			<!--{/if}-->

		</div>

		<form method="post" autocomplete="off" name="modactions" id="modactions">

			<input type="hidden" name="formhash" value="{FORMHASH}" />

			<input type="hidden" name="optgroup" />

			<input type="hidden" name="operation" />

			<input type="hidden" name="listextra" value="$_GET[extra]" />

			<input type="hidden" name="page" value="$page" />

		</form>

		$_G['forum_tagscript']

		<!--{hook/viewthread_middle}-->

		<!--{hook/viewthread_bottom}-->

		<!--{if ($_G['setting']['visitedforums']) && $_G['forum']['status'] != 3}-->

			<div id="visitedforums_menu" class="p_pop blk cl" style="display: none;">

				<table cellspacing="0" cellpadding="0">

					<tr>

						<td id="v_forums">

							<h3 class="mbn pbn bbda xg1">{lang viewed_forums}</h3>

							<ul class="xl xl1">

								$_G['setting']['visitedforums']

							</ul>

						</td>

					</tr>

				</table>

			</div>

		<!--{/if}-->

		<!--{if $_G['medal_list']}-->

		<!--{loop $_G['medal_list'] $medalid $medal}-->

			<div id="md_{$medalid}_menu" class="tip tip_4" style="display: none;">

				<div class="tip_horn"></div>

				<div class="tip_c">

					<h4>$medal[name]</h4>

					<p>$medal[description]</p>

				</div>

			</div>

		<!--{/loop}-->

		<!--{/if}-->

		<!--{if !IS_ROBOT && !empty($_G[setting][lazyload])}-->

			<script type="text/javascript">

			new lazyload();

			</script>

		<!--{/if}-->

		

		<!--{if !IS_ROBOT && $_G['setting']['threadmaxpages'] > 1}-->

			<script type="text/javascript">document.onkeyup = function(e){keyPageScroll(e, <!--{if $page > 1}-->1<!--{else}-->0<!--{/if}-->, <!--{if $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->1<!--{else}-->0<!--{/if}-->, 'forum.php?mod=viewthread&tid=$_G[tid]<!--{if $_GET[authorid]}-->&authorid=$_GET[authorid]<!--{/if}-->', $page);}</script>

		<!--{/if}-->

	</div>

	<div class="uc-postview-side y">

		<!--{if $modmenu['thread']}-->

		<div class="uc-postview-side-manage uc-side-div">

			<a href="javascript:void(0)"><i class="ico-asterisk ico-white"></i>�������</a>

			<div id="modmenu" class="uc-before">

				<ul class="cl">

				<!--{eval $modopt=0;}-->

				<!--{if $_G['forum']['ismoderator']}-->

					<!--{if $_G['group']['allowdelpost']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modthreads(3, 'delete')">{lang modmenu_deletethread}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowbumpthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modthreads(3, 'bump')">{lang modmenu_updown}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modthreads(1, 'stick')">{lang modmenu_stickthread}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowlivethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('live')">{lang modmenu_live}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowhighlightthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modthreads(1, 'highlight')">{lang modmenu_highlight}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modthreads(1, 'digest')">{lang modmenu_digestpost}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowrecommendthread'] && !empty($_G['forum']['modrecommend']['open']) && $_G['forum']['modrecommend']['sort'] != 1 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(1, 'recommend')">{lang modmenu_recommend}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowstampthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('stamp')">{lang modmenu_stamp}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowstamplist'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('stamplist')">{lang modmenu_icon}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowclosethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modthreads(4)"><!--{if !$_G['forum_thread']['closed']}-->{lang modmenu_switch_off}<!--{else}-->{lang modmenu_switch_on}<!--{/if}--></a></li><!--{/if}-->

					<!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modthreads(2, 'move')">{lang modmenu_move}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowedittypethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modthreads(2, 'type')">{lang modmenu_type}</a></li><!--{/if}-->

					<!--{if !$_G['forum_thread']['special'] && !$_G['forum_thread']['is_archived']}-->

						<!--{if $_G['group']['allowcopythread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('copy')">{lang modmenu_copy}</a></li><!--{/if}-->

						<!--{if $_G['group']['allowmergethread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('merge')">{lang modmenu_merge}</a></li><!--{/if}-->

						<!--{if $_G['group']['allowrefund'] && $_G['forum_thread']['price'] > 0}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('refund')">{lang modmenu_restore}</a></li><!--{/if}-->

					<!--{/if}-->

					<!--{if $_G['group']['allowsplitthread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('split')">{lang modmenu_split}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowrepairthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('repair')">{lang modmenu_repair}</a></li><!--{/if}-->

					<!--{if $_G['forum_thread']['is_archived'] && $_G['adminid'] == 1}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('restore', '', 'archiveid={$_G[forum_thread][archiveid]}')">{lang modmenu_archive}</a></li><!--{/if}-->

					<!--{if $_G['forum_firstpid']}-->

						<!--{if $_G['group']['allowwarnpost']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('warn', '$_G[forum_firstpid]')">{lang modmenu_warn}</a></li><!--{/if}-->

						<!--{if $_G['group']['allowbanpost']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('banpost', '$_G[forum_firstpid]')">{lang modmenu_banthread}</a></li><!--{/if}-->

					<!--{/if}-->

					<!--{if $_G['group']['allowremovereward'] && $_G['forum_thread']['special'] == 3 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><li><a href="javascript:;" onclick="modaction('removereward')">{lang modmenu_removereward}</a></li><!--{/if}-->

					<!--{if $_G['forum']['status'] == 3 && in_array($_G['adminid'], array('1','2')) && $_G['forum_thread']['closed'] < 1}--><li><a href="javascript:;" onclick="modthreads(5, 'recommend_group');return false;">{lang modmenu_grouprecommend}</a></li><!--{/if}-->

					<!--{if $_G['group']['allowmanagetag']}--><li><a href="javascript:;" onclick="showWindow('mods', 'forum.php?mod=tag&op=manage&tid=$_G[tid]', 'get', 0)">{lang post_tag}</a></li><!--{/if}-->

					<!--{if $_G['group']['alloweditusertag']}--><li><a href="javascript:;" onclick="showWindow('usertag', 'forum.php?mod=misc&action=usertag&tid=$_G[tid]', 'get', 0)">{lang usertag}</a></li><!--{/if}-->

				<!--{/if}-->

				<!--{if $allowpusharticle && $allowpostarticle}--><!--{eval $modopt++}--><li><a href="portal.php?mod=portalcp&ac=article&from_idtype=tid&from_id=$_G['tid']">{lang modmenu_pusharticle}</a></li><!--{/if}-->

				<!--{hook/viewthread_modoption}-->

				</ul>

			</div>

		</div>

		<!--{/if}-->

		<div class="uc-postview-side-author uc-side-div cl">

			<p class="z"><strong>$ucauthor['following']</strong><span>��ע</span></p>

			<p class="m"><strong>$ucauthor['follower']</strong><span>��˿</span></p>

			<p class="y"><strong>$ucauthor['threads']</strong><span>��Ʒ</span></p>

		</div>

		<div class="uc-postview-side-upload uc-side-div">

			<a title="������Ʒ" onclick="showWindow('nav', this.href, 'get', 0)" href="forum.php?mod=misc&amp;action=nav"><i class="ico-upload ico-white"></i>������Ʒ</a>

			<div class="cl">

				<span class="z"><a id="recommend_add" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', '');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = $('recommendv_add').innerHTML + ' {lang activity_member_unit}$_G[setting][recommendthread][addtext]'" title="{lang maketoponce}"><i class="ico-heart ico-white"></i>�Һ�ϲ��<span id="recommendv_add" style="display:none">$_G[forum_thread][recommend_add]</span></a></span>

				<span class="y"><a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_{$_G[forum_thread][authorid]}&touid={$_G[forum_thread][authorid]}&pmid=0&daterange=2&tid={$_G[tid]}" onclick="showWindow('sendpm', this.href);" title="{lang viewthread_left_sendpm}"><i class="ico-message ico-white"></i>����˽��</a></span>

			</div>

			<div class="cl">

				<span class="z"><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}" id="k_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" onmouseover="this.title = $('favoritenumber').innerHTML + ' {lang activity_member_unit}{lang thread_favorite}'" title="{lang fav_thread}"><i class="ico-star ico-white"></i>�����ղ�<span id="favoritenumber" style="display:none">{$_G['forum_thread']['favtimes']}</span></a></span>

				<span class="y">



					<a{if helper_access::check_module('share')} href="home.php?mod=spacecp&ac=share&type=thread&id=$_G[tid]" onclick="showWindow('sharethread', this.href, 'get', 0);" title="{lang share_digest}"{else} href="javascript:;"{/if}><i class="ico-share ico-white"></i>��Ҫ����</a>

					<div class="uc-postview-side-share uc-before">

						<div class="uc-postview-side-share-top cl">

							<div class="bdsharebuttonbox z">

								<a href="javascript:;" class="bds_qzone" data-cmd="qzone" title="������QQ�ռ�">QQ�ռ�</a>

								<a href="javascript:;" class="bds_tsina" data-cmd="tsina" title="����������΢��">����΢��</a>

								<a href="javascript:;" class="bds_tqq" data-cmd="tqq" title="��������Ѷ΢��">��Ѷ΢��</a>

								<a href="javascript:;" class="bds_renren" data-cmd="renren" title="������������">������</a>

								<a href="javascript:;" class="bds_huaban" data-cmd="huaban" title="����������">������</a>

								<a href="javascript:;" class="bds_douban" data-cmd="douban" title="������������">����</a>

								<a href="javascript:;" class="bds_diandian" data-cmd="diandian" title="�����������">���</a>

							</div>

							<div class="bdsharebuttonbox y">

								<p class="cl"><a href="javascript:;" class="bds_weixin" data-cmd="weixin" title="������΢��">������΢��</a></p>

								<p class="cl"><span id="qrcode" title="��΢��ɨһɨ���ɽ���ҳ������΢��"></span></p>

								<p class="cl" style="margin-bottom:0;">��΢��ɨһɨ���ɽ���ҳ������΢��</p>

							</div>

						</div>

						<div class="uc-postview-side-share-bot cl">

							<div class="z">

								<span>��������̳���߲���</span>

								<p class="bdsharebuttonbox"><input type="text" value="http://$_SERVER['HTTP_HOST']/forum.php?mod=viewthread&tid={$_G[tid]}" id="bdshareinput" readOnly UNSELECTABLE='true'></p>

							</div>

							<a href="forum.php?mod=viewthread&tid=$_G[tid]$fromuid" onclick="return copyThreadUrl(this, '$_G[setting][bbname]')" {if $fromuid}title="{lang share_url_copy_comment}"{/if} class="y">����</a>

						</div>

						<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/jcountdown/jquery.min.js"></script>

						<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/qrcode.js"></script>

						<script type="text/javascript">

							var UCJQ = jQuery.noConflict();

							UCJQ(function(){UCJQ('#qrcode').qrcode({render: "table",width: 99,height: 100,correctLevel: 0,text: '{$_G[setting][siteurl]}/forum.php?mod=viewthread&tid={$_G[tid]}'})});

							window._bd_share_config={"common": {"bdSnsKey": {},"bdText": "","bdMini": "2","bdMiniList": false,"bdPic": "","bdStyle": "0","bdSize": "16"},"share": {}};

							with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];

						</script>

					</div>

				</span>

			</div>

		</div>

		<!--[diy=thread_sidebar]--><div id="thread_sidebar" class="area"></div><!--[/diy]-->

		<div id="uc_side_fixed">

			<div class="uc-postview-side-works uc-side-div cl">

				<div class="tit">���ߵ�������Ʒ<a href="home.php?mod=space&uid={$post[authorid]}&do=thread&from=space" target="_blank">�鿴ȫ��</a></div>

				<div class="con">

					<ul class="cl">

					<!--{loop $ucthread $item}-->

						<li>

							<a href="forum.php?mod=viewthread&tid={$item['tid']}" title="$item[subject] by $item[author]" target="_blank">

								<!--{if $item['cover']}-->

									<!--{eval $item['coverpath'] = getthreadcover($item['tid'], 1);}-->

									<span style="background-image:url('{$item['coverpath']}');"></span>

								<!--{else}-->

									<span class="nopic s" style="background-size:auto auto;" title="$item[subject] by $item[author]"></span>

								<!--{/if}-->

							</a>

						</li>

					<!--{/loop}-->

					</ul>

				</div>

			</div>

			<!--[diy=thread_sidebar_2]--><div id="thread_sidebar_2" class="area"></div><!--[/diy]-->

		</div>

	</div>

</div>



<div class="wp mtn">

	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->

</div>







<!--{if $_G['relatedlinks'] || $_GET['highlight']}-->

	<script type="text/javascript">

		var relatedlink = [];

		<!--{loop $_G['relatedlinks'] $key $link}-->

		relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};

		<!--{/loop}-->

		{eval $highlights = explode(' ', str_replace(array('\'', chr(125)), array('&#039;', '&#125;'), dhtmlspecialchars($_GET['highlight'])));}

		<!--{loop $highlights $word}-->

		{eval $key++;}

		relatedlink[$key] = {'sname':'$word', 'surl':''};

		<!--{/loop}-->

		relatedlinks('postmessage_$_G[forum_firstpid]');

	</script>

<!--{/if}-->



<!--{if !empty($_G['cookie']['clearUserdata']) && $_G['cookie']['clearUserdata'] == 'forum'}-->

	<script type="text/javascript">saveUserdata('forum_'+discuz_uid, '')</script>

<!--{/if}-->



<script type="text/javascript">

<!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || $_G['uid'] == $_G['thread']['authorid'])}-->

function showsetcover(obj) {

	if(obj.parentNode.id == 'postmessage_$_G[forum_firstpid]') {

		var defheight = $_G['setting']['forumpicstyle']['thumbheight'];

		var defwidth = $_G['setting']['forumpicstyle']['thumbwidth'];

		var newimgid = 'showcoverimg';

		var imgsrc = obj.src ? obj.src : obj.file;

		if(!imgsrc) return;



		var tempimg=new Image();

		tempimg.src=imgsrc;

		if(tempimg.complete) {

			if(tempimg.width < defwidth || tempimg.height < defheight) return;

		} else {

			return;

		}

		if($(newimgid) && obj.id != newimgid) {

			$(newimgid).id = 'img'+Math.random();

		}

		if($(newimgid+'_menu')) {

			var menudiv = $(newimgid+'_menu');

		} else {

			var menudiv = document.createElement('div');

			menudiv.className = 'tip tip_4 aimg_tip';

			menudiv.id = newimgid+'_menu';

			menudiv.style.position = 'absolute';

			menudiv.style.display = 'none';

			obj.parentNode.appendChild(menudiv);

		}

		menudiv.innerHTML = '<div class="tip_c xs0"><a onclick="showWindow(\'setcover_'+newimgid+'\', this.href)" href="forum.php?mod=ajax&amp;action=setthreadcover&amp;tid=$_G[tid]&amp;pid=$_G[forum_firstpid]&amp;fid=$_G[fid]&imgurl='+imgsrc+'">{lang set_cover}</a></div>';

		obj.id = newimgid;

		showMenu({'ctrlid':newimgid,'pos':'12'});

	}

	return;

}

<!--{/if}-->

function succeedhandle_followmod(url, msg, values) {

	var fObj = $('followmod_'+values['fuid']);

	if(values['type'] == 'add') {

		fObj.innerHTML = '{lang nofollow}';

		fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];

	} else if(values['type'] == 'del') {

		fObj.innerHTML = '{lang follow}';

		fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];

	}

}

<!--{if $_G['blockedpids']}-->

var blockedPIDs = [<!--{echo implode(',', $_G['blockedpids'])}-->];

<!--{/if}-->

<!--{if $postlist && empty($_G['setting']['disfixedavatar'])}-->

fixed_avatar([<!--{echo implode(',', array_keys($postlist))}-->], {if empty($_G['setting']['disfixednv_viewthread']) }1{else}0{/if});

<!--{elseif empty($_G['setting']['disfixednv_viewthread'])}-->

fixed_top_nv();

<!--{/if}-->

</script>

<!--{template common/footer}-->

