<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require DISCUZ_ROOT . 'source/plugin/e6_box/config.php';
$num_option = "<option value=\"\">{$e6_c['box_16']}</option>";
for ($n=1; $n<=8; $n++) {
	$num_option .= "<option value=\"{$n}\">{$n}{$e6_c['box_17']}</option>";
}
$page = empty($_GET['page']) ? 1 : intval($_GET['page']);
if($page<1) $page = 1;
$perpage = 15;
$start = ($page-1)*$perpage;
$theurl = E6::M()->adminurl();
$multi = '';
$where = ' WHERE 1=1';
E6::M()->getgpc(array('username', 'box', 'num', 'sdate', 'edate'));
if ($username) {
	$uid = E6::M()->get_uid($username);
	$where .= " AND `uid`='{$uid}'";
	$theurl .= '&username=' . $username;	
}
if ($box) {
	$where .= " AND `box`='{$box}'";
	$theurl .= '&box=' . $box;	
}
if ($num) {
	$where .= " AND `num`='{$num}'";
	$theurl .= '&num=' . $num;	
}
if ($sdate) {
	$_POST['sdate'] && $sdate = strtotime($sdate);
	$where .= " AND date>'{$sdate}'";
	$theurl .= '&sdate=' . $sdate;
}
if ($edate) {
	$_POST['edate'] && $edate = strtotime($edate);
	$where .= " AND date<'{$edate}'";
	$theurl .= '&edate=' . $edate;
}
$count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('e6_box_user') . " u $where ");
if ($count) {
	$n = ($page-1)*$perpage+1;
	$query = DB::query("SELECT * FROM " . DB::table('e6_box_user') . " $where ORDER BY `id` DESC  LIMIT $start,$perpage");
	while($rt = DB::fetch($query)) {
		$rt['n'] = $n;
		$rt['box'] = E6::M()->box_types($rt['box']);
		$rt['date'] = dgmdate($rt['date'], 'Y-m-d H:i:s');
		$list[] = $rt;
		$n++;
	}
	$multi = multi($count, $perpage, $page, $theurl);
}
@include template('e6_box:box');
?>