<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . 'source/plugin/e6_box/config.php';
if (empty($_POST['step'])) {
	E6::M()->js('j');
	E6::M()->js('admin');
	E6::M()->prompt($e6_c['prize_1']);
	E6::M()->header();
	foreach(E6::M()->box_type() as $key => $value) {
		E6::M()->type_header("<span style=\"color:red;\">{$value}{$e6_c['prize_2']}</span>", $e6_c['prize_3']);
		for ($n=1; $n<=8; $n++) {
			print "<span style=\"color:blue;\">{$n} {$e6_c['prize_4']}: </span><span> 10000 / </span>";
			E6::M()->text("{$key}_winning_rate{$n}", " &nbsp;({$e6_c['prize_5']})", "style=\"width:50px;\"");
			print "<br /><span>{$n} {$e6_c['prize_6']}: </span>";
			E6::M()->select("{$key}_winning_prize{$n}", E6::M()->prize_type(), false, "onchange=\"show_type('{$key}_winning_prize{$n}',this);\" id=\"{$key}_winning_prize{$n}type\" style=\"width:120px;\"");
			E6::M()->text("{$key}_winning_prize{$n}_money", false, "class=\"{$key}_winning_prize{$n} id1 txt\" style=\"width:80px;display:none;\"");
			E6::M()->select("{$key}_winning_prize{$n}_money_type", E6::M()->money_list(), false, "class=\"{$key}_winning_prize{$n} id1\" style=\"width:120px;display:none;\"");
			$magic_list = E6::M()->magic_list();
			if($magic_list && $_G['setting']['magicstatus']){
				E6::M()->text("{$key}_winning_prize{$n}_magic_num", "<span class=\"{$key}_winning_prize{$n} id2\" style=\"display:none;\">{$e6_c['prize_7']} &nbsp;</span>", "class=\"{$key}_winning_prize{$n} id2 txt\" style=\"width:80px;display:none;\"");
				E6::M()->select("{$key}_winning_prize{$n}_magic", $magic_list, false, "class=\"{$key}_winning_prize{$n} id2\" style=\"width:120px;display:none;\"");
			} else {
				print "<span style=\"display:none;color:red;\" class=\"{$key}_winning_prize{$n} id2\">{$e6_c['prize_8']}(<a href=\"admin.php?action=magics&operation=admin\" style=\"color:blue;\">{$e6_c['prize_9']}</a>)</span>";
			}
			$medal_list = E6::M()->medal_list();
			if ($medal_list) {
				E6::M()->select("{$key}_winning_prize{$n}_medal", $medal_list, false, "class=\"{$key}_winning_prize{$n} id3\" style=\"width:120px;display:none;\"");
			} else {
				print "<span style=\"display:none;color:red;\" class=\"{$key}_winning_prize{$n} id3\">{$e6_c['prize_10']}(<a href=\"admin.php?action=medals\" style=\color:blue;\">{$e6_c['prize_11']}</a>)</span>";
			}
			$group_list = E6::M()->group_list(" WHERE `type`='special' AND `radminid`='0' ");
			if($group_list){
				E6::M()->select("{$key}_winning_prize{$n}_group", $group_list, false, "class=\"{$key}_winning_prize{$n} id4\" style=\"width:120px;display:none;\"");
				E6::M()->text("{$key}_winning_prize{$n}_group_day", "<span style=\"display:none\" class=\"{$key}_winning_prize{$n} id4\">{$e6_c['prize_12']}</span>", "class=\"{$key}_winning_prize{$n} id4\" style=\width:80px;display:none;\"");
			} else {
				print "<span style=\"display:none;color:red;\" class=\"{$key}_winning_prize{$n} id4\">{$e6_c['prize_13']}(<a href=\"admin.php?action=usergroups\" style=\"color:blue;\">{$e6_c['prize_14']}</a>)</span>";
			}
			print "<span style=\"display:none;\" class=\"{$key}_winning_prize{$n} id6\">{$e6_c['prize_15']}: </span>";
			E6::M()->text("{$key}_winning_prize{$n}_custom", false, "class=\"{$key}_winning_prize{$n} id6 txt\" style=\"width:300px;display:none;\"");
			print "<br /><br />";
		}
		E6::M()->type_footer();	
	}
	E6::M()->footer();
} else {
	E6::M()->save();
}
?>