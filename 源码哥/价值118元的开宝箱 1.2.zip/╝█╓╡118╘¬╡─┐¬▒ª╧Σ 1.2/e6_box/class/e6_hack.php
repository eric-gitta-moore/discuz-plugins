<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class hack_e6_box extends e6_class {

	public $log_table = 'e6_box_credit';

	public static function prize_type($key = NULL) {
		$prize_type = array(
			0 => e6_c('function_1'),
			1 => e6_c('function_2'),
			2 => e6_c('function_3'),
			3 => e6_c('function_4'),
			4 => e6_c('function_5'),
			6 => e6_c('function_6')
		);
		return ($key ? $prize_type[$key] : $prize_type);
	}

	public static function box_type($key = NULL) {
		$box_type = array(
			'gold'	=> e6_c('function_7'),
			'silver'=> e6_c('function_8'),
			'copper'=> e6_c('function_9'),
		);
		return ($key ? $box_type[$key] : $box_type);
	}

	public static function box_types($key = NULL) {
		$box_type = array(
			'1'=> e6_c('function_10'),
			'2'=> e6_c('function_11'),
			'3'=> e6_c('function_12')
		);
		return ($key ? $box_type[$key] : $box_type);
	}

	public static function log_type() {
		return array(
			'1' => e6_c('function_13'),
			'2' => e6_c('function_14'),
		);
	}

	public static function log_arr() {
		return array(
			'1'  => e6_c('function_15') . ': {$alternate}' .e6_c('function_16') . ': {$money}{$money_title}',
			'2'  => e6_c('function_15') . ': {$alternate[0]}' .e6_c('function_17') . '{$alternate[1]}',
		);
	}

	public static function magic_list($close = NULL) {
		!$close && $where = " WHERE `available`='1' ";
		$query = DB::query("SELECT * FROM ".DB::table('common_magic')." $where ORDER BY `magicid` ASC");
		while($rt = DB::fetch($query)) {
			$magic_list[$rt['magicid']] = $rt['name'];
		}
		return $magic_list;
	}

	public static function medal_list($close = NULL) {
		!$close && $where = " WHERE `available`='1' ";
		$query = DB::query("SELECT * FROM ".DB::table('forum_medal')." $where ORDER BY `medalid` ASC");
		while($rt = DB::fetch($query)) {
			$medal_list[$rt['medalid']] = $rt['name'];
		}
		return $medal_list;
	}

	public static function send_reward($type, $id) {
		$config = self::config();
		$prize_type = $config[$type . '_winning_prize' . $id];
		$box_type = E6::M()->box_type($type);
		if ($prize_type == 1) {
			$money = $config[$type . '_winning_prize' . $id . '_money'];
			$money_type = $config[$type . '_winning_prize' . $id . '_money_type'];
			$money_list = self::money_list();
			$describe = e6_c('function_18') . $money . $money_list[$money_type];
			self::money(array($money_type => $money), '2', false, array($box_type, $describe));
		} elseif ($prize_type == 2) {
			$magicid = $config[$type .'_winning_prize'. $id .'_magic'];
			$magic_num = $config[$type .'_winning_prize'. $id .'_magic_num'];
			$magic_title = DB::result_first("SELECT `name` FROM ".DB::table('common_magic')." WHERE `magicid`='{$magicid}'");
			$describe = e6_c('function_19') .  $magic_num . e6_c('function_20') . $magic_title;
			self::money(false, '2', false, array($box_type, $describe));
			$uid = $GLOBALS['_G']['uid'];
			self::send_magic($uid, $magicid, $magic_num);
		} elseif ($prize_type == 3) {
			$medalid = $config[$type . '_winning_prize' .$id. '_medal'];
			$medal_title = DB::result_first("SELECT `name` FROM ".DB::table('forum_medal')." WHERE `medalid`='{$medalid}'");
			$describe = e6_c('function_21') .  $medal_title;
			self::money(false, '2', false, array($box_type, $describe));
			$uid = $GLOBALS['_G']['uid'];
			self::send_medal($uid, $medalid);
		} elseif ($prize_type == 4) {
			$groupid = $config[$type . '_winning_prize' .$id. '_group'];
			$group_date = $config[$type . '_winning_prize' .$id. '_group_day'];
			$group_title = DB::result_first("SELECT `grouptitle` FROM ".DB::table('common_usergroup')." WHERE `groupid`='{$groupid}'");
			$group_date_title = $group_date ?  $group_date . e6_c('function_22') : e6_c('function_23');
			$describe  = e6_c('function_24') . " {$group_title} ({$group_date_title})";
			self::money(false, '2', false, array($box_type, $describe));
			$uid = $GLOBALS['_G']['uid'];
			self::send_group($uid, $groupid, $group_date);
		} elseif ($prize_type == 6) {
			$describe = $config[$type .'_winning_prize' . $id .'_custom'];
			self::money(false, '2', false, array($box_type, $describe));
		}
		$message = e6_c('function_25') . $box_type . e6_c('function_26') . $describe;
		E6::M()->msg($GLOBALS['_G']['uid'], e6_c('function_27'), $message);
		$typeid_array = array(
			'gold' => 1,
			'silver' => 2,
			'copper' => 3
		);
		$typeid = $typeid_array[$type];
		DB::query("INSERT INTO ".DB::table('e6_box_user')." SET
			`uid`		=	'{$GLOBALS['_G']['uid']}',
			`username`	=	'{$GLOBALS['_G']['username']}',
			`box`		=	'{$typeid}',
			`num`		=	'{$id}',
			`date`		=	'{$GLOBALS['_G']['timestamp']}',
			`describe`	=	'{$describe}'
		");
		return "alert('$message')";
	}
	
	public static function send_magic($uid, $magicid, $num = 1){
		$Y = DB::result_first("SELECT * FROM ".DB::table('common_member_magic')." WHERE `uid` ='$uid' AND `magicid`='$magicid'");
		if ($Y) {
			DB::query("UPDATE ".DB::table('common_member_magic')." SET `num`=`num`+'$num' WHERE `uid`='$uid' AND `magicid`='$magicid'");
		} else {
			DB::query("INSERT INTO ".DB::table('common_member_magic')." SET `uid`='$uid',`magicid`='$magicid',`num`='$num'");
		}
		DB::query("INSERT INTO ".DB::table('common_magiclog')." SET `uid`='$uid',`magicid`='$magicid',`action`='3',`dateline`='{$GLOBALS['_G']['timestamp']}',`amount`='$num',`price`='',`credit`='',`idtype`='',`targetid`='0',`targetuid`='$uid'");
	}
	
	public static function send_medal($uid, $medalid) {
		$my_medal = DB::result_first("SELECT `medals` FROM ".DB::table('common_member_field_forum')." WHERE uid='$uid'");
		$my_medal_arr = explode("\t", $my_medal);
		if ($my_medal) {
			if(!in_array($medalid, $my_medal_arr)){
				$new_medal = $medalid . "\t" . $my_medal;
			}
		} else {
			$new_medal = $medalid;
		}
		if ($new_medal) {
			DB::query("UPDATE ".DB::table('common_member_field_forum')." SET `medals`='$new_medal' WHERE `uid`='$uid'");
			DB::query("INSERT INTO ".DB::table('forum_medallog')." SET `uid`='$uid' , `medalid`='$medalid' , `type`='0' , `dateline`='{$GLOBALS['_G']['timestamp']}' , `expiration`='0' , `status`='0'");
			if ($GLOBALS['_G']['setting']['version'] != 'X2') {
				DB::query("REPLACE INTO ".DB::table('common_member_medal')." SET `uid`='$uid' , `medalid`='$medalid'");
			}
		}
	}

	public static function send_group($uid, $groupid, $date = NULL) {
 		$user = DB::fetch_first("SELECT `groupid`,`groupexpiry` FROM ".DB::table('common_member')." WHERE `uid`='$uid'");
		if ($user['groupid'] == '1') return FALSE;
		$group_radminid = DB::result_first("SELECT `radminid` FROM ".DB::table('common_usergroup')." WHERE `groupid`='$groupid'");
		!$group_radminid && $group_radminid = '-1';
		if ($date) {
			if ($user['groupid'] == $groupid && $user['groupexpiry'] > $GLOBALS['_G']['timestamp']) {
				$groupexpiry = $user['groupexpiry'] + ($date * 86400);
			} else {
				if ($user['groupid'] == $groupid && !$user['groupexpiry']) return TRUE;
				$groupexpiry = $GLOBALS['_G']['timestamp'] + ($date * 86400);
			}
			$groupterms = array('main'=>array('time' => $groupexpiry), 'ext' => array($groupid => $groupexpiry));
			$groupterms = addslashes(serialize($groupterms));
		} else {
			$groupexpiry = 0;
			$groupterms = 'a:0:{}';
		}
		DB::query("UPDATE ".DB::table('common_member')." SET `groupid`='$groupid',`adminid`='$group_radminid',`groupexpiry`='$groupexpiry' WHERE `uid`='$uid'");
		DB::query("UPDATE  ".DB::table('common_member_field_forum')." SET `groupterms`='$groupterms' WHERE `uid`='$uid'");
	}

	public static function prize_list($type) {
		for ($n=1; $n<=8; $n++) {
			
			if ($box_prize_title = self::box_prize_title($type, $n)) {
				$prize_list[$n] = $box_prize_title;
			}
		}
		return $prize_list;
	}

	public static function box_prize_title($type, $id) {
		$config = self::config();
		$prize_type = $config[$type . '_winning_prize' . $id];
		if ($prize_type == 1) {
			$money = $config[$type . '_winning_prize' . $id . '_money'];
			$money_type = $config[$type . '_winning_prize' . $id . '_money_type'];
			$money_list = self::money_list();
			return $money .' '. $money_list[$money_type];
		} elseif ($prize_type == 2) {
			$magicid = $config[$type .'_winning_prize'. $id .'_magic'];
			$magic_num = $config[$type .'_winning_prize'. $id .'_magic_num'];
			$magic_title = DB::result_first("SELECT `name` FROM ".DB::table('common_magic')." WHERE `magicid`='{$magicid}'");
			return   $magic_num . e6_c('function_28') . $magic_title ;
		} elseif ($prize_type == 3) {
			$medalid = $config[$type . '_winning_prize' .$id. '_medal'];
			$medal_title = DB::result_first("SELECT `name` FROM ".DB::table('forum_medal')." WHERE `medalid`='{$medalid}'");
			return    $medal_title  . e6_c('function_29');
		} elseif ($prize_type == 4) {
			$groupid = $config[$type . '_winning_prize' .$id. '_group'];
			$group_date = $config[$type . '_winning_prize' .$id. '_group_day'];
			$group_title = DB::result_first("SELECT `grouptitle` FROM ".DB::table('common_usergroup')." WHERE `groupid`='{$groupid}'");
			$group_date_title = $group_date ?  $group_date . e6_c('function_30') : e6_c('function_31');
			return e6_c('function_32') . " {$group_title} ({$group_date_title})";
		} elseif ($prize_type == 6) {
			return $config[$type .'_winning_prize' . $id .'_custom'];
		} else {
			return false;
		}
	}
}
$GLOBALS['hack_'.$e6_name] = ${'hack_'.$e6_name} = 1;
?>