e6(function(){
	var admin_arr = new Array("gold", "silver", "copper");
	for(n in admin_arr) {
		for (var i=1; i<=8; i++){
			e6("." + admin_arr[n] + "_winning_prize" + i).hide();
			var typeid = e6("#" + admin_arr[n] + "_winning_prize" + i + "type").val();
			e6("." + admin_arr[n] + "_winning_prize" + i + ".id"+ typeid).show();
		}
	}
});

function show_type(str, id) {
	var typeid = e6(id).val();
	e6("." + str).hide();
	e6("." + str + ".id" + typeid).show();
}