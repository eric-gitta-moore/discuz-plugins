function open_box(type) {
	e6.post("plugin.php?id=e6_box",{step:"2", type:type},function(data){
		eval(data);
	});
}