<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . 'source/plugin/e6_box/config.php';
if (empty($_POST['step'])) {
	E6::M()->prompt($e6_c['edit_1']);
	E6::M()->header();
	E6::M()->type('radio', array('open', $e6_c['edit_2'], '<a href="http://www.6ie6.com/hack.php?name=discuz_e6_box" target="_blank" style="color:blue;">' . $e6_c['edit_3'] . '</a>'));
	E6::M()->type('checkbox', array('group', $e6_c['edit_4'], $e6_c['edit_5'], E6::M()->group_list()));
	E6::M()->type_header($e6_c['edit_6']);
	E6::M()->text('gold_money', false, 'style="width:50px;"');
	E6::M()->select('gold_type', E6::M()->money_list());
	E6::M()->type_footer();
	E6::M()->type_header($e6_c['edit_7']);
	E6::M()->text('silver_money', false, 'style="width:50px;"');
	E6::M()->select('silver_type', E6::M()->money_list());
	E6::M()->type_footer();	
	E6::M()->type_header($e6_c['edit_8']);
	E6::M()->text('copper_money', false, 'style="width:50px;"');
	E6::M()->select('copper_type', E6::M()->money_list());
	E6::M()->type_footer();	
	E6::M()->type_header($e6_c['edit_9'], $e6_c['edit_10']);
	echo "<span>{$e6_c['edit_11']}: </span>";
	E6::M()->text('nav_text1', false, 'style="width:100px;"');
	echo "<br /><span>{$e6_c['edit_12']}: </span>";
	E6::M()->text('nav_url1', false, 'style="width:280px;"');
	E6::M()->type_footer();
	E6::M()->type_header($e6_c['edit_13'], $e6_c['edit_14']);
	echo "<span>{$e6_c['edit_11']}: </span>";
	E6::M()->text('nav_text2', false, 'style="width:150px;"');
	echo "<br /><span>{$e6_c['edit_12']}: </span>";
	E6::M()->text('nav_url2', false, 'style="width:300px;"');
	E6::M()->type_footer();
	E6::M()->type('textarea', array('play', $e6_c['edit_15'], $e6_c['edit_16']));
	E6::M()->type('text', array('ann_title', $e6_c['edit_17'], $e6_c['edit_18'], false, 'style="width:150px;"'));
	E6::M()->type('textarea', array('ann_content', $e6_c['edit_19'], $e6_c['edit_20']));
	E6::M()->footer();
} else {
	!$_POST[$e6_name]['group'] && $_POST[$e6_name]['group'] = null;
	E6::M()->save();
}
?>