<?php
/*
 *Դ����Ʒ��������Ʒ
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *Դ���99%����Դ���ǻظ���ֱ��������صģ�����ĳ��վ��Ҫ���VIP���Ǹ�VIP
 */if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require DISCUZ_ROOT.'source/plugin/e6_box/config.php';
$navtitle = e6_c('e6_box_1');
!$e6_box['open'] && Showmessage(e6_c('e6_box_2'));
$money_list = E6::M()->money_list();
E6::M()->getgpc(array('step', 'type'));
if ($step == 2) {
	if (empty($_G['uid'])) {
		$str = "showWindow('login', 'member.php?mod=logging&action=login');";
	} else {
		if (!in_array($type, array('gold', 'silver', 'copper'))) {
			$str = "alert('" . e6_c('e6_box_3') . "')";
		} else {
			if ($e6_box['group'] && !in_array($_G['groupid'], $e6_box['group'])) {
				echo "alert('" . e6_c('e6_box_4') . "')";
				exit;
			}
			$box_money = $e6_box[$type . '_money'];
			$box_type = $e6_box[$type . '_type'];
			if ($box_money) {
				if ($box_money > E6::M()->get_usermoney($_G['uid'], $box_type)) {
					$str = "alert('" . e6_c('e6_box_5') . $money_list[$box_type] . e6_c('e6_box_6') . "')";
				} else {
					E6::M()->money(array($box_type => -$box_money), 1, false, E6::M()->box_type($type));
					$M1 = $e6_box[$type . '_winning_rate1'];
					for ($n=1; $n<=8; $n++) {
						$rate = $e6_box[$type . '_winning_rate' . $n];
						$M += intval($rate);
						if ($n != 1) {
							$i = $n-1;
							${'M'.$n} = ${'M' . $i} + $rate;
						}
					}
					$Y = rand(1, 10000);
					if ($Y > $M) {
						$str = "alert('" . e6_c('e6_box_7') . "')";
					} else {
						for ($n=1; $n<=8; $n++) {
							$rate = $e6_box[$type . '_winning_rate' . $n];
							if ($n == 1) {
								if ($Y <= $M1) {
									if ($rate) {
										$str = E6::M()->send_reward($type, $n);
										break;
									} else {
										continue;
									}
								}
							} else {
								$i = $n-1;
								if ($Y > ${'M' . $i} && $Y <= ${'M' . $n}) {
									if ($rate) {
										$str = E6::M()->send_reward($type, $n);
										break;
									} else {
										continue;
									}
								}		
							}
						}
					}
				}
			} else {
				$str = "alert('" . e6_c('e6_box_8'). "')";
			}
		}
	}
	json_encode($str);
	echo $str;
	exit;
}
if (empty($_GET['nav'])) {
	$gold_list = E6::M()->prize_list('gold');
	$silver_list = E6::M()->prize_list('silver');
	$copper_list = E6::M()->prize_list('copper');
} elseif($_GET['nav'] == 'box'){
	$page = empty($_GET['page']) ? 1 : intval($_GET['page']);
	if($page<1) $page=1;
	$perpage = 18;
	$start = ($page-1)*$perpage;
	$multi = '';
	$theurl = 'plugin.php?id=e6_box&nav=box';
	$count = DB::result_first("SELECT count(*) AS sum FROM " . DB::table('e6_box_user') . " WHERE `uid`='$_G[uid]'");
	if($count) {
		$box_type = E6::M()->box_types();
		$query = DB::query("SELECT * FROM " . DB::table('e6_box_user') . "  WHERE `uid`='{$_G['uid']}' ORDER BY `id` DESC LIMIT $start,$perpage");
		while ($rt = DB::fetch($query)) {
			$rt['date'] = dgmdate($rt['date'], 'Y-m-d H:i:s');
			$rt['box'] = $box_type[$rt['box']];
			$list[]=$rt;
		}
		$multi = multi($count, $perpage, $page, $theurl);
	}
}
$query = DB::query("SELECT * FROM " . DB::table('e6_box_user') . "  WHERE `num` < 2 ORDER BY `id` DESC LIMIT 12");	
while ($rt = DB::fetch($query)) {
	$list_right[]=$rt;
}
@include template("e6_box:index");
?>