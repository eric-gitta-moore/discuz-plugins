<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$lang = array_merge($lang, $scriptlang[$plugin['identifier']]);
require_once libfile('function/home');

loadcache('plugin');
if(!$_G['cache']['plugin']['dzapp_wechat']) {
	cpmsg('app_wechat_nonexistence', '', 'error');
}

if(empty($_GET['ac'])) {

	if(!submitcheck('listsubmit')) {

		showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod=admincp_app');
		showtableheader();
		showsubtitle(array('app_order', 'app_func', 'app_keyword', 'app_statement', 'app_num', 'app_available', 'app_op'));
		$dir = DISCUZ_ROOT.'./source/plugin/'.$plugin['identifier'].'/app';
		$directory = @opendir($dir);
		while($entry = @readdir($directory)) {
			if($entry == '.' || $entry == '..') continue;
			@include_once $dir.'/'.$entry;
			if(!$module['name']) continue;
			$module['func'] = str_replace('.php', '', $entry);
			$list[$module['func']] = $module;
			$func[] = $module['name'];
		}
		$keyword = C::t('#dzapp_wechat#dzapp_wechat_keyword')->fetch_all_by_func($func);
		foreach($keyword as $value) {
			$func = str_replace($plugin['identifier'].'/app/', '', $value['func']);
			$param = unserialize($value['param']);
			showtablerow('', array('class="td25"'), array(
				'<input type="text" class="txt" name="displayorder['.$value['id'].']" value="'.$value['displayorder'].'" />',
				$func,
				$value['keyword'],
				$param['statement'],
				$value['num'],
				'<input type="checkbox" class="checkbox" name="close['.$value['id'].']" value="1"'.(!$value['close'] ? 'checked="checked"' : '').' />',
				'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod=admincp_app&ac=edit&id='.$func.'" class="act">'.cplang('app_edit').'</a><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod=admincp_app&ac=uninstall&id='.$func.'" class="act">'.cplang('app_uninstall').'</a>',
			));
			unset($list[$func]);
		}
		if($list) {
			showtitle('app_new');
		}
		foreach($list as $module) {
			$module['name'] = str_replace($plugin['identifier'].'/app/', '', $module['name']);
			showtablerow('', array('class="td25"'), array(
				'',
				$module['name'],
				$module['keyword'],
				$module['statement'],
				'-',
				'',
				'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod=admincp_app&ac=install&id='.$module['func'].'" class="act bold">'.cplang('app_install').'</a>',
			));
		}
		showsubmit('listsubmit', 'submit');
		showtablefooter();
		showformfooter();

	} else {

		if(is_array($_GET['displayorder'])) {
			foreach($_GET['displayorder'] as $key => $value) {
				C::t('#dzapp_wechat#dzapp_wechat_keyword')->update($key, array(
					'close' => !$_GET['close'][$key],
					'displayorder' => $_GET['displayorder'][$key],
				));
			}
		}

		cpmsg('app_update_succeed', 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod=admincp_app', 'succeed');

	}

} elseif($_GET['ac'] == 'edit') {
	
	@include_once DISCUZ_ROOT.'./source/plugin/'.$plugin['identifier'].'/app/'.$_GET['id'].'.php';
	$app = C::t('#dzapp_wechat#dzapp_wechat_keyword')->fetch_by_func($module['name']);
	if(!$app) {
		cpmsg('app_nonexistence', '', 'error');
	}
	$param = dunserialize($app['param']);

	if(!submitcheck('editsubmit')) {

		showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod=admincp_app&ac=edit&id='.$_GET['id'], 'enctype');
		showtableheader('app_edit');
		showsetting('app_keyword', 'keyword', $app['keyword'], 'text');
		foreach($module['field'] as $value) {
			showsetting($value['name'], 'param['.$value['name'].']', $param[$value['name']], $value['type']);
		}
		showsubmit('editsubmit');
		showtablefooter();
		showformfooter();

	} else {

		if(!$_GET['keyword']) {
			cpmsg('app_invalid', '', 'error');
		}

		if($_GET['keyword'] != $app['keyword']) {
			$new = explode(',', $_GET['keyword']);
			$old = explode(',', $app['keyword']);
			$id = $app['id'];
			$add = array_diff($new, $old);
			$del = array_diff($old, $new);
			$keyword = C::t('#dzapp_wechat#dzapp_wechat_multikeyword')->fetch_all($add);
			if($keyword) {
				cpmsg('app_keyword_invalid', '', 'error');
			}
			C::t('#dzapp_wechat#dzapp_wechat_keyword')->update($id, array('keyword' => $_GET['keyword']));
			foreach($add as $value) {
				C::t('#dzapp_wechat#dzapp_wechat_multikeyword')->insert(array(
					'keyword' => $value,
					'id' => $id,
				));
			}
			if($del) {
				C::t('#dzapp_wechat#dzapp_wechat_multikeyword')->delete($del);
			}
		}

		foreach($_FILES['param'] as $key => $value) {
			foreach($value as $k => $v) {
				$file[$k][$key] = $v;
			}
		}
		$attachurl = 'data/attachment/portal/';
		foreach($file as $key => $value) {
			if($pic = pic_upload($value, 'portal')) $_GET['param'][$key] = $attachurl.$pic['pic'];
			if($pic && $param[$key]) pic_delete(str_replace($attachurl, '', $param[$key]), 'portal');
		}

		$data = array(
			'keyword' => $_GET['keyword'],
			'param' => serialize($_GET['param']),
		);
		C::t('#dzapp_wechat#dzapp_wechat_keyword')->update_by_func($module['name'], $data);

		cpmsg('app_edit_success', 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod=admincp_app', 'succeed');
	}

} elseif($_GET['ac'] == 'install') {

	@include_once DISCUZ_ROOT.'./source/plugin/'.$plugin['identifier'].'/app/'.$_GET['id'].'.php';

	if(!submitcheck('installsubmit')) {

		showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod=admincp_app&ac=install&id='.$_GET['id'], 'enctype');
		showtableheader('app_install');
		showsetting('app_keyword', 'keyword', $module['keyword'], 'text');
		showsetting('app_statement', 'param[statement]', $module['statement'], 'text');
		foreach($module['field'] as $value) {
			showsetting($value['name'], 'param['.$value['name'].']', $value['default'], $value['type']);
		}
		showsubmit('installsubmit');
		showtablefooter();
		showformfooter();

	} else {

		if(!$_GET['keyword']) {
			cpmsg('app_invalid', '', 'error');
		}

		$keyword = C::t('#dzapp_wechat#dzapp_wechat_multikeyword')->fetch_all(explode(',', $_GET['keyword']));
		if($keyword) {
			cpmsg('app_keyword_invalid', '', 'error');
		}

		if(C::t('#dzapp_wechat#dzapp_wechat_keyword')->fetch_by_func($module['name'])) {
			cpmsg('app_func_invalid', '', 'error');
		}

		foreach($_FILES['param'] as $key => $value) {
			foreach($value as $k => $v) {
				$file[$k][$key] = $v;
			}
		}
		$attachurl = 'data/attachment/portal/';
		foreach($file as $key => $value) {
			if($pic = pic_upload($value, 'portal')) $_GET['param'][$key] = $attachurl.$pic['pic'];
		}

		$data = array(
			'func' => $module['name'],
			'keyword' => $_GET['keyword'],
			'param' => serialize($_GET['param']),
		);
		$id = C::t('#dzapp_wechat#dzapp_wechat_keyword')->insert($data, true);
		foreach(explode(',', $_GET['keyword']) as $value) {
			C::t('#dzapp_wechat#dzapp_wechat_multikeyword')->insert(array(
				'keyword' => $value,
				'id' => $id,
			));
		}

		cpmsg('app_install_success', 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod=admincp_app', 'succeed');
	}

} elseif($_GET['ac'] == 'uninstall') {

	@include_once DISCUZ_ROOT.'./source/plugin/'.$plugin['identifier'].'/app/'.$_GET['id'].'.php';
	$app = C::t('#dzapp_wechat#dzapp_wechat_keyword')->fetch_by_func($module['name']);
	if(!$app) {
		cpmsg('app_nonexistence', '', 'error');
	}
	$param = dunserialize($app['param']);

	$attachurl = 'data/attachment/portal/';
	foreach($module['field'] as $value) {
		if($value['type'] == 'filetext') {
			pic_delete(str_replace($attachurl, '', $param[$value['name']]), 'portal');
		}
	}

	C::t('#dzapp_wechat#dzapp_wechat_keyword')->delete_by_func($module['name']);
	C::t('#dzapp_wechat#dzapp_wechat_multikeyword')->delete_by_id($app['id']);

	cpmsg('app_uninstall_success', 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod=admincp_app', 'succeed');
}

?>