<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$lang = array_merge($lang, $scriptlang['dzapp_sort']);
$lang['threadtype_edit_vars_type_identity'] = cplang('built_sorce');
$lang['threadtype_edit_vars_type_price'] = cplang('built_price');

if(empty($_GET['ac'])) {

	if(!submitcheck('listsubmit')) {

		showformheader('plugins&operation=config&identifier=dzapp_sort&pmod=admincp_module');
		showtableheader();
		showsubtitle(array('del', 'displayorder', 'name', 'description', ''));
		$query = C::t('#dzapp_sort#dzapp_sort_module')->fetch_all_by_displayorder();
		foreach($query as $value) {
			showtablerow('', array('class="td25"', 'class="td25"', '', 'class="td29"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$value['moduleid'].'" />',
				'<input type="text" class="txt" name="displayorder['.$value['moduleid'].']" value="'.$value['displayorder'].'" />',
				'<input type="text" class="txt" name="name['.$value['moduleid'].']" value="'.$value['name'].'" />',
				'<input type="text" class="txt" name="description['.$value['moduleid'].']" value="'.$value['description'].'" />',
				"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_module&ac=edit&id=$value[moduleid]\">".cplang('detail')."</a>"
			));
		}
		echo '<tr><td></td><td colspan="20"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.cplang('add_module').'</a></div></td></tr>';
		showsubmit('listsubmit', 'submit', 'del');
		showtablefooter();
		showformfooter();
		echo '<script type="text/javascript">var rowtypedata = [[[1, \'\', \'td25\'], [1, \'<input type="text" class="txt" name="newdisplayorder[]" />\', \'td25\'], [1, \'<input type="text" class="txt" name="newname[]" />\', \'\'], [1, \'<input type="text" class="txt" name="newdescription[]" />\', \'td29\']]];</script>';

	} else {

		if(is_array($_GET['delete'])) {
			C::t('#dzapp_sort#dzapp_sort_module')->delete($_GET['delete']);
		}

		if(is_array($_GET['name'])) {
			foreach($_GET['name'] as $key => $value) {
				C::t('#dzapp_sort#dzapp_sort_module')->update($key, array(
					'displayorder' => $_GET['displayorder'][$key],
					'name' => $_GET['name'][$key],
					'description' => $_GET['description'][$key],
				));
			}
		}

		if(is_array($_GET['newname'])) {
			foreach($_GET['newname'] as $key => $value) {
				if(empty($value)) continue;
				C::t('#dzapp_sort#dzapp_sort_module')->insert(array(
					'displayorder' => $_GET['newdisplayorder'][$key],
					'name' => $_GET['newname'][$key],
					'description' => $_GET['newdescription'][$key],
				));
			}
		}

		update_cache_dzapp_sort_module();
		cpmsg('module_update_succeed', 'action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_module', 'succeed');
	}

} elseif($_GET['ac'] == 'edit' && $_GET['id']) {

	$module = DB::fetch_first("SELECT * FROM ".DB::table('dzapp_sort_module')." WHERE moduleid='{$_GET['id']}'");
	if(!$module) {
		cpmsg('not_existence', '', 'error');
	}

	if(!submitcheck('editsubmit')) {

		showformheader('plugins&operation=config&identifier=dzapp_sort&pmod=admincp_module&ac=edit&id='.$_GET['id']);
		showtableheader();
		showtitle('base_info');
		showsetting('name', 'name', $module['name'], 'text');
		showsetting('description', 'description', $module['description'], 'text');
		showtitle('field_info');
		showtablefooter();
		showtableheader();
		showsubtitle(array('del', 'order', 'name', 'type', 'unit', 'required', 'search', 'conbime', 'list', ''));
		$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_option')." WHERE moduleid='$module[moduleid]' ORDER BY displayorder");
		while($option = DB::fetch($query)) {
			showtablerow('', array('class="td25"', 'class="td28"', '', '', 'class="td28"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$option[optionid]\">",
				"<input type=\"text\" class=\"txt\" name=\"displayorder[$option[optionid]]\" value=\"$option[displayorder]\">",
				"<input type=\"text\" class=\"txt\" name=\"title[$option[optionid]]\" value=\"$option[title]\">",
				$lang['threadtype_edit_vars_type_'. $option['type']],
				"<input type=\"text\" class=\"txt\" name=\"unit[$option[optionid]]\" value=\"$option[unit]\">",
				"<input class=\"checkbox\" type=\"checkbox\" name=\"required[$option[optionid]]\" value=\"1\"".($option['required'] ? ' checked' : '').">",
				"<input class=\"checkbox\" type=\"checkbox\" name=\"search[$option[optionid]]\" value=\"1\"".($option['search'] ? ' checked' : '').">",
				"<input class=\"checkbox\" type=\"checkbox\" name=\"colspan[$option[optionid]]\" value=\"1\"".($option['colspan'] ? ' checked' : '').">",
				"<input class=\"checkbox\" type=\"checkbox\" name=\"listshow[$option[optionid]]\" value=\"1\"".($option['listshow'] ? ' checked' : '').">",
				"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_module&ac=option&id=$option[optionid]\">".cplang('detail')."</a>"
			));
		}
		echo '<tr><td></td><td colspan="7"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.cplang('add_field').'</a></div></td></tr>';

		showsubmit('editsubmit');
		showtablefooter();
		showformfooter();

		echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
[
	[1,'', 'td25'],
	[1,'<input type="text" class="txt" name="newdisplayorder[]">', 'td28'],
	[1,'<input type="text" class="txt" name="newtitle[]">'],
	[6, '<select name="newtype[]"><option value="number">$lang[threadtype_edit_vars_type_number]</option><option value="text" selected>$lang[threadtype_edit_vars_type_text]</option><option value="textarea">$lang[threadtype_edit_vars_type_textarea]</option><option value="radio">$lang[threadtype_edit_vars_type_radio]</option><option value="checkbox">$lang[threadtype_edit_vars_type_checkbox]</option><option value="select">$lang[threadtype_edit_vars_type_select]</option><option value="calendar">$lang[threadtype_edit_vars_type_calendar]</option><option value="email">$lang[threadtype_edit_vars_type_email]</option><option value="url">$lang[threadtype_edit_vars_type_url]</option><option value="range">$lang[threadtype_edit_vars_type_range]</option><option value="identity">$lang[threadtype_edit_vars_type_identity]</option><option value="price">$lang[threadtype_edit_vars_type_price]</option></select>'],
]
];
</script>
EOT;

	} else {

		if(!$_GET['name']) {
			cpmsg('write_all_required', '', 'error');
		}

		$data = array(
			'name' => $_GET['name'],
			'description' => $_GET['description'],
		);
		DB::update('dzapp_sort_module', $data, "moduleid='{$_GET['id']}'");

		if($ids = dimplode($_GET['delete'])) {
			DB::query("DELETE FROM ".DB::table('dzapp_sort_option')." WHERE optionid IN ($ids)");
		}

		if(is_array($_GET['title'])) {
			foreach($_GET['title'] as $key => $value) {
				$data = array(
					'title' => $value,
					'displayorder' => $_GET['displayorder'][$key],
					'unit' => $_GET['unit'][$key],
					'required' => $_GET['required'][$key],
					'search' => $_GET['search'][$key],
					'colspan' => $_GET['colspan'][$key],
					'listshow' => $_GET['listshow'][$key],
				);
				DB::update('dzapp_sort_option', $data, array('optionid' => $key));
			}
		}

		if(is_array($_GET['newtitle'])) {
			foreach($_GET['newtitle'] as $key => $value) {
				if(empty($value)) continue;
				$data = array(
					'title' => $value,
					'moduleid' => $module['moduleid'],
					'displayorder' => $_GET['newdisplayorder'][$key],
					'type' => $_GET['newtype'][$key],
					'system' => in_array($_GET['newtype'][$key], array('identity', 'price')) ? 1 : 0,
				);
				DB::insert('dzapp_sort_option', $data);
			}
		}

		$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_option')." WHERE moduleid='$module[moduleid]' AND system='0'");
		while($option = DB::fetch($query)) {
			$insertoption[$option['optionid']] = $option;
		}

		$query = DB::query("SHOW TABLES LIKE '".DB::table('dzapp_sort_module_')."{$module['moduleid']}'");
		if(DB::num_rows($query) != 1) {
			$create_table_sql = "CREATE TABLE ".DB::table('dzapp_sort_module_')."{$module['moduleid']} (\r\ninfoid mediumint(8) UNSIGNED NOT NULL DEFAULT '0',\r\ncatid smallint(6) UNSIGNED NOT NULL DEFAULT '0',\r\ndateline int(10) UNSIGNED NOT NULL DEFAULT '0',\r\nexpiration int(10) UNSIGNED NOT NULL DEFAULT '0',\r\n";
			foreach($insertoption as $optionid => $option) {
				$identifier = 'field_'.$optionid;
				if(in_array($option['type'], array('radio'))) {
					$create_table_sql .= "$identifier smallint(6) UNSIGNED NOT NULL DEFAULT '0',\r\n";
				} elseif(in_array($option['type'], array('number', 'range'))) {
					$create_table_sql .= "$identifier int(10) UNSIGNED NOT NULL DEFAULT '0',\r\n";
				} elseif($option['type'] == 'select') {
					$create_table_sql .= "$identifier varchar(50) NOT NULL,\r\n";
				} else {
					$create_table_sql .= "$identifier mediumtext NOT NULL,\r\n";
				}
				$separator = ' ,';
				if(in_array($option['type'], array('radio', 'select', 'number'))) {
					$indexoption[] = $identifier;
				}
			}
			$create_table_sql .= "KEY (catid), KEY(dateline)";
			if($indexoption) {
				foreach($indexoption as $index) {
					$create_table_sql .= "$separator KEY $index ($index)\r\n";
					$separator = ' ,';
				}
			}
			$create_table_sql .= ") TYPE=MyISAM;";
			$dbcharset = empty($dbcharset) ? str_replace('-','',CHARSET) : $dbcharset;
			$db = DB::object();
			$create_table_sql = syntablestruct($create_table_sql, $db->version() > '4.1', $dbcharset);
			DB::query($create_table_sql);
		} else {
			$tables = array();
			$db = DB::object();
			if($db->version() > '4.1') {
				$query = DB::query("SHOW FULL COLUMNS FROM ".DB::table('dzapp_sort_module_')."{$module['moduleid']}", 'SILENT');
			} else {
				$query = DB::query("SHOW COLUMNS FROM ".DB::table('dzapp_sort_module_')."{$module['moduleid']}", 'SILENT');
			}
			while($field = @DB::fetch($query)) {
				$tables[$field['Field']] = 1;
			}
			foreach($insertoption as $optionid => $option) {
				$identifier = 'field_'.$optionid;
				if(!$tables[$identifier]) {
					if(in_array($option['type'], array('radio'))) {
						$fieldtype = "smallint(6) UNSIGNED NOT NULL DEFAULT '0'";
					} elseif(in_array($option['type'], array('number', 'range'))) {
						$fieldtype = "int(10) UNSIGNED NOT NULL DEFAULT '0'";
					} elseif($option['type'] == 'select') {
						$fieldtype = "varchar(50) NOT NULL";
					} else {
						$fieldtype = "mediumtext NOT NULL";
					}
					DB::query("ALTER TABLE ".DB::table('dzapp_sort_module_')."{$module['moduleid']} ADD $identifier $fieldtype");
					if(in_array($option['type'], array('radio', 'select', 'number'))) {
						DB::query("ALTER TABLE ".DB::table('dzapp_sort_module_')."{$module['moduleid']} ADD INDEX ($identifier)");
					}
				}
			}
		}

		update_cache_dzapp_sort_module();
		cpmsg('succeed_edit_module', 'action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_module&ac=edit&id='.$module['moduleid'], 'succeed');

	}

} elseif($_GET['ac'] == 'option' && $_GET['id']) {

	$option = DB::fetch_first("SELECT * FROM ".DB::table('dzapp_sort_option')." WHERE optionid='{$_GET['id']}'");
	if(!$option) {
		cpmsg('not_existence', '', 'error');
	}

	if(!submitcheck('optionsubmit')) {

		$typeselect = '<select name="type">';
		foreach(array('number', 'text', 'radio', 'checkbox', 'textarea', 'select', 'calendar', 'email', 'url', 'range', 'identity', 'price') as $type) {
			$typeselect .= '<option value="'.$type.'" '.($option['type'] == $type ? 'selected' : '').'>'.$lang['threadtype_edit_vars_type_'.$type].'</option>';
		}
		$typeselect .= '</select>';

		showformheader('plugins&operation=config&identifier=dzapp_sort&pmod=admincp_module&ac=option&id='.$_GET['id']);
		showtableheader();
		showsetting('title', 'title', $option['title'], 'text');
		showsetting('type', '', '', $typeselect);
		showsetting('description', 'description', $option['description'], 'text');
		showsetting('separator', 'separator', $option['separator'], 'text');
		showsetting('unit', 'unit', $option['unit'], 'text');
		showsetting('choice', 'choice', $option['choice'], 'textarea');
		showsetting('width', 'width', $option['width'], 'text');
		showsetting('extra', 'extra', $option['extra'], 'textarea');
		showsetting('case', 'case', $option['case'], 'text');
		showsetting('range', 'range', $option['range'], 'text');
		showsubmit('optionsubmit');
		showtablefooter();
		showformfooter();

	} else {

		if(!$_GET['title']) {
			cpmsg('write_all_required', '', 'error');
		}

		$data = array(
			'title' => $_GET['title'],
			'type' => $_GET['type'],
			'description' => $_GET['description'],
			'separator' => $_GET['separator'],
			'unit' => $_GET['unit'],
			'choice' => $_GET['choice'],
			'width' => $_GET['width'],
			'extra' => $_GET['extra'],
			'case' => $_GET['case'],
			'range' => $_GET['range'],
		);
		DB::update('dzapp_sort_option', $data, "optionid='{$_GET['id']}'");

		update_cache_dzapp_sort_module();
		cpmsg('field_edit_succeed', 'action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_module&ac=edit&id='.$option['moduleid'], 'succeed');

	}
}

function syntablestruct($sql, $version, $dbcharset) {

	if(strpos(trim(substr($sql, 0, 18)), 'CREATE TABLE') === FALSE) {
		return $sql;
	}

	$sqlversion = strpos($sql, 'ENGINE=') === FALSE ? FALSE : TRUE;

	if($sqlversion === $version) {

		return $sqlversion && $dbcharset ? preg_replace(array('/ character set \w+/i', '/ collate \w+/i', "/DEFAULT CHARSET=\w+/is"), array('', '', "DEFAULT CHARSET=$dbcharset"), $sql) : $sql;
	}

	if($version) {
		return preg_replace(array('/TYPE=HEAP/i', '/TYPE=(\w+)/is'), array("ENGINE=MEMORY DEFAULT CHARSET=$dbcharset", "ENGINE=\\1 DEFAULT CHARSET=$dbcharset"), $sql);

	} else {
		return preg_replace(array('/character set \w+/i', '/collate \w+/i', '/ENGINE=MEMORY/i', '/\s*DEFAULT CHARSET=\w+/is', '/\s*COLLATE=\w+/is', '/ENGINE=(\w+)(.*)/is'), array('', '', 'ENGINE=HEAP', '', '', 'TYPE=\\1\\2'), $sql);
	}
}

function update_cache_dzapp_sort_module() {
	$data = array();

	$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_module')." ORDER BY displayorder");
	while($value = DB::fetch($query)) {
		$data[$value['moduleid']] = $value;
	}

	$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_option')." ORDER BY displayorder");
	while($option = DB::fetch($query)) {
		if($option['choice']) {
			$choices = array();
			foreach(explode("\n", $option['choice']) as $item) {
				list($index, $choice) = explode('=', $item);
				$choices[trim($index)] = trim($choice);
			}
			$option['choice'] = $choices;
		}
		if($option['range']) {
			$ranges = array();
			$prevs = '';
			foreach(explode(',', $option['range']) as $item) {
				$index = $prevs.'_'.$item;
				$ranges[$index] = !$prevs ? $item.$option['unit'].cplang('under') : $prevs.'-'.$item.$option['unit'];
				$prevs = $item;
			}
			$ranges[$item.'_'] = $prevs.$option['unit'].cplang('above');
			$option['choice'] = $ranges;
		}
		$option['w'] = $option['width'] ? ' style="width: '.$option['width'].'px"' : '';
		$data[$option['moduleid']]['option'][$option['optionid']] = $option;
	}

	savecache('dzapp_sort_module', $data);
}

?>