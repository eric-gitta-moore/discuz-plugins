<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class dzapp_sort_api {

	function forumdisplay_topBar() {
		return $this->wsq_push('forumdisplay_topBar');
	}

	function forumdisplay_sideBar() {
		return $this->wsq_push('forumdisplay_sideBar');
	}

	function viewthread_topBar() {
		return $this->wsq_push('viewthread_topBar');
	}

	function viewthread_sideBar() {
		return $this->wsq_push('viewthread_sideBar');
	}

	function wsq_push($hook) {
		global $_G;

		loadcache('dzapp_wsq_push');
		require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';

		foreach($_G['cache']['dzapp_wsq_push'][$hook] as $value) {
			if($value['plugin'] != 'sort') continue;
			if($_G['cache']['plugin']['dzapp_wsq']['url']) {
				$value['url'] = $_G['siteurl'].'plugin.php?id=dzapp_sort&mod=view&infoid='.$value['id'];
			} else {
				$value['url'] = WeChatHook::getPluginUrl('dzapp_sort', array('mod' => 'view', 'infoid' => $value['id']));
			}
			$value['content'] = '<a href="'.$value['url'].'"><img src="'.$value['pic'].'" /></a>';
			if($hook == 'forumdisplay_topBar') {
				$return[] = array('name' => $value['title'], 'html' => $value['content'], 'more' => $value['url']);
			} else {
				$return .= $value['content'];
			}
		}
		return $return;
	}
}

?>
