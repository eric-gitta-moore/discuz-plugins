<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$lang = array_merge($lang, $scriptlang['dzapp_sort']);

if(empty($_GET['ac'])) {

	if(!submitcheck('seosubmit')) {

		echo '<script type="text/javascript">
		function insertContent(obj, text) {
			var obj = obj.parentNode.parentNode.firstChild.lastChild;
			selection = document.selection;
			obj.focus();
			if(!isUndefined(obj.selectionStart)) {
				var opn = obj.selectionStart + 0;
				obj.value = obj.value.substr(0, obj.selectionStart) + text + obj.value.substr(obj.selectionEnd);
			} else if(selection && selection.createRange) {
				var sel = selection.createRange();
				sel.text = text;
				sel.moveStart(\'character\', -strlen(text));
			} else {
				obj.value += text;
			}
		}
		</script>';

		$sort_seo = dunserialize($_G['setting']['sort_seo']);
		$page = array(
			'index' => array('bbname'),
			'list' => array('bbname', 'cat'),
			'view' => array('bbname', 'subject', 'message'),
			'memcp' => array('bbname'),
			'post' => array('bbname'),
			'search' => array('bbname'),
		);
		showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier=dzapp_sort&pmod=admincp_seo');
		showtableheader();
		foreach($page as $key => $value) {
			$code = cplang('code');
			foreach($value as $v) {
				$code .= '<a onclick="insertContent(this, \'{'.$v.'}\');return false;" href="javascript:;" title="'.cplang($v).'">{'.cplang($v).'}</a>';
			}
			showtitle('page_'.$key);
			showsetting('seotitle', 'sort_seo['.$key.'][seotitle]', $sort_seo[$key]['seotitle'], 'text', '', 0, $code);
			showsetting('seokeywords', 'sort_seo['.$key.'][seokeywords]', $sort_seo[$key]['seokeywords'], 'text', '', 0, $code);
			showsetting('seodescription', 'sort_seo['.$key.'][seodescription]', $sort_seo[$key]['seodescription'], 'text', '', 0, $code);
		}
		showsubmit('seosubmit');
		showtablefooter();
		showformfooter();
		
	} else {
		
		$sort_seo = serialize($_GET['sort_seo']);
		DB::query("REPLACE INTO ".DB::table('common_setting')." (skey, svalue) VALUES ('sort_seo', '$sort_seo')");
		updatecache('setting');

		cpmsg('seo_update_succeed', 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier=dzapp_sort&pmod=admincp_seo', 'succeed');
	}
}

?>