/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/
(function (win,T,undefined){
if(win[T]===undefined){win[T]={};}
T=win[T];
T.version=0.1;
T.author="Loong";
T.ie = !-[1,];
T.ie6 = !-[1,]&&!window.XMLHttpRequest;
T.add=function (n,f){if(T[n]===undefined){T[n]=f;}};
})(window,"TUI");
(function (T,undefined){
function get(){
var doc=(typeof(arguments[0])==="string")?document.getElementById(arguments[0]):arguments[0];
if(doc===null || typeof(doc) !== "object"){return null;}
if(arguments[1]===undefined){
return doc;
}else if(typeof(arguments[1])==="string"){
if(doc===null){return false;}
var Tags=doc.getElementsByTagName(arguments[1]);
switch (typeof arguments[2]){
case "undefined":
return Tags;
break;
case "boolean":
var childNodes=[];
for (var i=0,len=Tags.length;i<len;i++){
if(Tags[i].parentNode==doc){
childNodes.push(Tags[i]);
}
}
return childNodes;
break;
case "string":
var ret=[];
for (var j=0,jlen=Tags.length;j<jlen;j++){
if(T.UI.hasclass(Tags[j],arguments[2])){
ret.push(Tags[j]);
}
}
return ret;
break;
}
}
}
TUI.add("get",get);
if(window.$===undefined){window.$=get;}
})(TUI);
(function (T,undefined){
function deldom(_Tag){
if(typeof(_Tag)==="string"){_Tag=T.get(_Tag);}
if(_Tag===null){return _Tag;}
var _TagParent=_Tag.parentNode;
_TagParent.removeChild(_Tag);
return _TagParent;
}
TUI.add("deldom",deldom);

function node(_TagName,_TagAttribute){
var NewTag=document.createElement(_TagName);
if(_TagAttribute===undefined){ return NewTag;}
for (var AttributeName in _TagAttribute){
switch (AttributeName){
case "style":
NewTag.style.cssText=_TagAttribute[AttributeName];
break;
case "class":
NewTag.className=_TagAttribute[AttributeName];
break;
case "html":
NewTag.innerHTML = _TagAttribute[AttributeName];
break;
default:
NewTag.setAttribute(AttributeName,_TagAttribute[AttributeName]);
break;
}
}
return NewTag;
}
TUI.add("node",node);
})(TUI);
(function (T,undefined){
function xcookie(name,value,seconds){
if(value===undefined){
var start=document.cookie.indexOf(name);
var end=document.cookie.indexOf(";",start);
return start==-1?null:unescape(document.cookie.substring(start+name.length+1,(end>start?end:document.cookie.length)));
}
expires=new Date();
seconds=seconds || (86400 * 365);
expires.setTime(expires.getTime()+seconds);
document.cookie=name+"="+escape(value)+";expires="+expires.toGMTString()+";path=/";
}
TUI.add("cookie",xcookie);
})(TUI);
(function (T,undefined){
function addEvent(i,h,g){
if(typeof(i)==="string"){i=T.get(i);}
if(!i || !h || typeof(g) != "function"){
return;
}
if( typeof(i)==="object" && i.length>0 && i.nodeName===undefined ){
for (var n=0,nlen=i.length;n<nlen;n++){
T.on(i[n],h,g);
}
return i;
}
if(i.addEventListener){
if(h==='mouseenter'){
i.addEventListener('mouseover',withoutChild(g),false);
}else if(h==='mouseleave'){
i.addEventListener('mouseout',withoutChild(g),false);
}else{
i.addEventListener(h,g,false);
}
}else if(i.attachEvent){
i.attachEvent("on"+h,function(){return g.call(i);});
}else{
if(h==='mouseenter'){
i.onmouseover=withoutChild(g);
}else if(h==='mouseleave'){
i.onmouseout=withoutChild(g);
}else{
i['on'+h]=g;
}
}
if(i.nodeName && i.nodeName.toLowerCase() !== 'form'){
return i;
}
};
TUI.add("on",addEvent);
function withoutChild(func){
return function(e){
var relatedNode=e.relatedTarget;
while(relatedNode && relatedNode !== this){
try{ relatedNode=relatedNode.parentNode;}catch(e){ break;}
}
if(relatedNode===this){ return;}
func.call(this,e);
}
}
})(TUI);
(function (T,undefined){
var UI={
'trim':function(g){
return g.replace(/^\s+|\s+$/g,"")
},
'hasclass':function(h,g){
h=typeof(h)==="string"?T.get(h):h;
if(!h || !g || !h.className){return false;}
return h.className.indexOf(g)>-1;
},
'addclass':function(h,g){
h=typeof(h)==="string"?T.get(h):h;
if(!h || !g){return;}
if(this.hasclass(h,g)){return;}
h.className+=" "+g;
},
'removeclass':function(h,g){
if( typeof(h)==="object" && h.length>0 && h.nodeName===undefined ){
for (var n=0,nlen=h.length;n<nlen;n++){
TUI.UI.removeclass(h[n],g);
}
return h;
}
h=typeof(h)==="string"?T.get(h):h;
if(!this.hasclass(h,g)){return;}
h.className=h.className.replace(new RegExp(g,"g"),"");
if(!this.trim(h.className)){
h.removeAttribute(T.isIE?"className": "class")
}
},
'toggleclass':function (element,className){
if(typeof(element)==="string"){element=T.get(element);}
if(element===null){return;}
return UI[this.hasclass(element,className)?'removeclass':'addclass'](element,className);
},
'css':function (elem,name,val){
elem=T.get(elem);
if(elem===null){return;}
if(val===undefined){
if(elem.style[name]){
return elem.style[name];
}else if(elem.currentStyle){
return elem.currentStyle[name];
}else if(document.defaultView && document.defaultView.getComputedStyle){
try{name=name.replace(/([A-Z])/g,"-$1");} catch (e){name=name.toString().replace(/([A-Z])/g,"-$1");}
name=name.toLowerCase();
var s=document.defaultView.getComputedStyle(elem,"");
return s && s.getPropertyValue(name);
}else{return null;}
}else{
val=typeof(val)==="number"?val+"px":val;
elem.style[name]=val;
}
}
};
TUI.add("UI",UI);
})(TUI);
(function (T,undefined){
function tuse(_ModeName,_CallBack){
if(T[_ModeName]===undefined){
getfile('source/plugin/dzapp_sort/static/'+_ModeName+'.js',_CallBack);
}else{
try{_CallBack();}catch(r){}
}
}
function getfile(_FileUrl,_FunctionName){
if(typeof(_FileUrl) !== "string" || _FileUrl.length<4){return;}
var _FileType=_FileUrl.substring(_FileUrl.lastIndexOf('.')+1,_FileUrl.length);
var head=document.getElementsByTagName("head")[0];
var fileref='';
switch (_FileType){
case "js":
fileref=T.node("script",{"type": "text/javascript","src": _FileUrl});
break;
case "css":
fileref=T.node("link",{"rel": "stylesheet","type": "text/css","href": _FileUrl});
break;
default:
return;
}
head.appendChild(fileref);
fileref.onload=fileref.onreadystatechange=function (){
var r=this.readyState;
if((!r || r==="loaded" || r==="complete")){
if(typeof(_FunctionName)==="function"){_FunctionName();}
fileref.onload=fileref.onreadystatechange=null;
try{if(head===fileref.parentNode && _FileType=="js"){head.removeChild(fileref);}} catch (e){}
}
};
}
TUI.add("getfile",getfile);
TUI.add("use",tuse);
})(TUI);
(function(){
String.prototype.replaceAll=function (sSearch,sReplace){
var ssRegExp=new RegExp(sSearch,"g");
return this.replace(ssRegExp,sReplace);
};
})();