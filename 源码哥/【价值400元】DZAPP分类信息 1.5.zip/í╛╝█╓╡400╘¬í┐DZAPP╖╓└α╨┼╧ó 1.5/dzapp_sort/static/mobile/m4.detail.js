/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/
var dianping = "";  
var sore_arr = {"sore6":"����", "sore5":"�Ϻ�", "sore4":"һ��", "sore2":"����", "sore0":"�ܲ�"};
var job_page_num = 0;
var max_25num = 25;

Date.prototype.format = function(format) // author: meizz
{ 
  var o = { 
    "M+" : this.getMonth()+1, // month
    "d+" : this.getDate(),    // day
    "h+" : this.getHours(),   // hour
    "m+" : this.getMinutes(), // minute
    "s+" : this.getSeconds(), // second
    "q+" : Math.floor((this.getMonth()+3)/3),  // quarter
    "S" : this.getMilliseconds() // millisecond
  }; 
  if(/(y+)/.test(format)) format=format.replace(RegExp.$1, 
    (this.getFullYear()+"").substr(4 - RegExp.$1.length)); 
  for(var k in o)if(new RegExp("("+ k +")").test(format)) 
    format = format.replace(RegExp.$1, 
      RegExp.$1.length==1 ? o[k] : 
        ("00"+ o[k]).substr((""+ o[k]).length)); 
  return format; 
};



//dom ������ɺ�ִ��
document.addEventListener("DOMContentLoaded", function () {
    detailAttrStyle();
});

//����ҳ������Ϣ���Զ���
var detailAttrStyle = function () {
    if (!$(".attr_info").length) {
        return;
    }
    $(".attr_info").find(".attrName").each(function () {
        if ($(this).text().length < 4) {
            var strs = $(this).text().substr(0, 1);
            var stre = $(this).text().substr(1);
            $(this).html(strs + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + stre);
        }
    });
};

//�ղسɹ���ʾ
var FavoriteMsg = function (txt) {
    if (!$(".FavoriteMsg").length) {
        var msgLayer = "<div class='FavoriteMsg'></div>";
    }
    $(".status_bar").append(msgLayer);
    var msgLayer = $(".FavoriteMsg");
    if (txt) {
        msgLayer.html(txt);
    } else {
        msgLayer.html("�ղسɹ������ڡ��ҵ��ղء��в鿴");
    }
    msgLayer.show();
    setTimeout(function () {
        msgLayer.hide();
    }, 2000);
};

function imageInit() {
    if ($(".image_area").length && $(".bigimg_box").length) {
        $(".image_area").carousel({
            imgType:"thumb"
        });
        var thumbImg = $(".image_area").find("img");
        thumbImg.each(function (i) {
            $(this).bind("click", function () {
                if ($(".bigimg_box").find("img").size() == 0) {
                    thumbImg.each(function () {
                        var _bigSrc = $(this).attr("ref").replace("tiny", "big");
                        var _bigImg = document.createElement("img");
                        var _li = document.createElement("li");
                        _bigImg.src = "imglogo_gray.png";
                        _bigImg.setAttribute("ref", _bigSrc);
                        _li.appendChild(_bigImg);
                        document.querySelector(".bigimg_box ul").appendChild(_li);
                    });
                }
                setTimeout(function () {
                    window.scrollTo(0, 1);
                    $(".bigimg_box").carousel({
                        imgType:"big",
                        scrollTo:i
                    });
                }, 0);
                $("#viewBigImagebg").show().css("height", document.body.clientHeight + "px");
                $("#viewBigImage").show();
                //ͳ�ƴ���
                var path = "/" + ____json4fe.locallist[0].listname + "/" + ____json4fe.rootcatentry.listname + "/" + ____json4fe.catentry.listname + "/detail/click/photo/";
                googleAnalytices(path, document.referer);
            });
        });
        $(".btn_back").bind("click", function () {
            $("#viewBigImagebg").hide();
            $("#viewBigImage").hide();
        });
    }
}

//�첽����js��ִ�ж�Ӧģ�鹦��
loadJS(_jsRootPath + "/m.base.js", function () {
    basefun();
});

$(function () {
	loadJS(_jsRootPath + "/m4.slide.js", function () {
		return;
		imageInit();
		if ($(".compic").length) {
			job_img();
		}
	});
});

loadJS(_jsRootPath + "/m.ucenter.js", function () {
    $.my.addHistory();
});



loadJS(_jsRootPath + "/m.googleAnalytices.js");


////// ��Ƹ����ְ ////////


$(function () {
    if ($(".job_nav").length) {
        $(".job_nav span").bind("click", function (i) {
            var $this = $(this);
            var $id = $this.attr("id").substring(4);
            $this.siblings().removeClass("select");
            $this.addClass("select");
            $(".detail_w").hide();
            $("#" + $id).show();
            //job_onscroll();
            //if ($id == "nav3") {
            norate_init();
            //}
        })
    }

    if ($(".compic").length) {
        $(".compic").attr("src", $(".compic").attr("ref"));
    }

});


function createPL(o) {
    $.ajax({type:"JSONP",
        url:"http://" + dianping + "/m_listenterprisecomment/" + _companyUserId + "/" + o + "/?callback=?",
        success:function (data) {
            if (data.total > 0) {
                var reason_html = "";
                if (!$(".pinfolst").length) {
                    var reason_html = "<ul class=\"pinfolst\">";
                }
                for (var j = 0; j < data.entity.length; j++) {
                    var new_score = parseInt(data.entity[j].score) + 4;
                    var score_zh = eval("sore_arr.sore" + new_score);
                    reason_html += "<li class='padding10'>";
                    reason_html += "<span class=\"shrank\">" + data.entity[j].name + "&nbsp;&nbsp;<span class=\"xyimg" + new_score + "\"></span>" + score_zh + "</span>";
                    reason_html += "<span class=\"fr\">" + data.entity[j].time + "</span><br>";
                    reason_html += "<p class=\"preason\">" + data.entity[j].reason + "</p>";
                    reason_html += "<p>" + data.entity[j].comment + "</p>";
                    reason_html += "</li>";
                }
                if (!$(".pinfolst").length) {
                    reason_html += "</ul>";
                }
                if (data.total > 10 && !$(".butmore").length) {
                    reason_html += "<div class=\"butmore padding10\"><a href=\"javascript:void(0)\" class=\"url\">����鿴����</a></div>";
                }
                if (data.page * 10 >= data.total) {
                    $(".butmore").html("û�и���������");
                }
                if (o == 1) {
                    $("#nav3").append(reason_html);
                } else {
                    $(".pinfolst").append(reason_html);
                }

            }
            /*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

            $(".butmore a.url").unbind("click");
            $(".butmore a.url").bind("click", function () {
                if (data.page * 10 < data.total) {
                    createPL(parseInt(data.page) + 1);
                    //��һҳ
                }
//                else{
//                    $(".butmore").html("û�и���������");
//                    //û�и���������
//                }
            });

        },
        timeout:30000,
        error:function () {
        }
    });

}

//��˾���ۣ�footer�õ׺�δ���۾���
function norate_init() {
    var body_height = parseInt($("body").css("height"));
    var win_height = window.innerHeight;
    if (body_height < win_height - 4) {
        if ($(".rank_no_txt").length) {
            var chj = (win_height - body_height - 2 ) / 2;
            $(".rank_no_txt").css("padding", "" + parseInt(40 + chj) + "px 10px " + chj + "px");
        } else {
            var top_margin = win_height - body_height - 2;
            $(".footer").css("margin-top", top_margin + "px");
        }
    }
    if (body_height > win_height) {
        $(".footer").css("margin-top", "0px");
    }
}


$(function () {
    //���ŷ�Դ����ҳ
    if ($("#pinj_main").length) {
        var get_infoid = ____json4fe.infoid;
        getRoomPLNumd(get_infoid);
        getRoomPLMesd(get_infoid);
    }
});

$(function() {
	// �绰
	$('.call').bind('click', function() {
		var phoneNo = $(this).attr('phoneNo');
		location.href = 'tel:' + phoneNo;
	});

	/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

	// ����
	$('.sms').bind('click', function() {
		var phoneNo = $(this).attr('phoneNo');
		location.href = 'sms:' + phoneNo;// + '?body=' + encodeURIComponent('���Զ�������');
	});
});

//������ϵ�ˣ�����ID �� ���������¼
function add_caller(o, p) {
    var msg_uid = "uid" + o;
    if (typeof(localStorage.myjson_ls) == 'undefined') {
        var myjson_init = {"caller":[
            {"callerid":o, "infoid":p}
        ], "messages":{}};
        myjson_init.messages[msg_uid] = [];
        localStorage.myjson_ls = JSON.stringify(myjson_init);
    } else {
        var myjson = JSON.parse(localStorage.myjson_ls);
        var addcall = true;
        $.each(myjson.caller, function (idx, item) {
            if (o == item.callerid) {
                item.infoid = p;
                localStorage.myjson_ls = JSON.stringify(myjson);
                addcall = false;
                return;
            }
        });
        if (addcall) {
            if (myjson.caller.length >= max_25num) {
                var last_id = myjson.caller[max_25num - 1].callerid;
                delete myjson.messages["uid" + last_id];
                myjson.caller.pop();
            }
            myjson.caller.unshift({"callerid":o, "infoid":p});
            myjson.messages[msg_uid] = [];
            localStorage.myjson_ls = JSON.stringify(myjson);
        }
    }
}

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/
$(function () {
	$('.banner_down a').bind('click', function (e) {
		if ($.os.ios) {
			googleAnalytices("/clickdetail/detailbanner/iphone/", document.referer);
		} else if ($.os.android) {
			googleAnalytices("/clickdetail/detailbanner/android/", document.referer);
		} else {
			googleAnalytices("/clickdetail/detailbanner/other/", document.referer);
		}
	});
});

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/
$(function () {
	if (typeof tongyongCode !== 'undefined') {
		(new Image()).src = tongyongCode;
	}
});

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/
$(function () {
	if ($.cookie.get('mtg')) {
		$('.banner_down').hide();
	}
});


function googleStatistics(para, referer) {
	if (typeof googleAnalytices === 'function') {
		googleAnalytices(para, referer);
	}
}

function scrollpic() {
	var slideX = (function() {
		var _slide = function(div_id, panel_id, duration) {
			var	_divId, _div, _ul, _panel, _eleX, _li_margin, _ul_width, _ul_margin,
			_startx = _index = 0, _duration = duration,autoScroll = true,
			_bindEvents = function() {
				_ul.bind("touchstart", _touchstart, false);
				_ul.bind("touchmove", _touchmove, false);
				_ul.bind("touchend", _touchend, false);
			},
			_click = function(e) {
				var img = e.target;
			},
			_move = function(e, sx, ex) {
				var max = _ul.children().length;
				if (ex > sx) {
					if (_index > 0) {
						_index --;
					}
				} else if (ex < sx){
					if (_index < max-1) {
						_index ++;
					}
				} else {
					_click(e);
					return;
				}
				var movex = (_index==0)?_ul_margin:-(_index * (_ul_width+_li_margin*2))+_ul_margin;
				_ul.css("-webkit-transition-duration", _duration);
				_ul.css("-webkit-transform", "translate3d("+movex+"px,0,0)");
				_panel.children("span").removeClass("curr").get(_index).className = "curr";
				
			};
			_touchstart = function(e) {
				autoScroll = false;
				e.stopPropagation();
				var finger0 = e.targetTouches[0];
				_startx = finger0.pageX;
				var transform = $(this).css("-webkit-transform");
				var translateX = parseInt(transform.split(/[(]|[,]|[)]/)[1]);
				_eleX = translateX || _ul_margin;
			},
			_touchmove = function(e) {
				e.preventDefault();
				e.stopPropagation();
				var finger0 = e.targetTouches[0];
				var moveX = finger0.pageX - _startx + _eleX;
				_ul.css({"-webkit-transition-duration": "0", "-webkit-transform": "translate3d("+moveX+"px, 0, 0)"});
			};
			_touchend = function(e) {
				var finger0 = e.changedTouches[0];
				_move(e, _startx, finger0.pageX);
				autoScroll = true;
				if (_index > 0) {
					googleStatistics( "/clicklocal/finger/banner1/", document.referer );
				} else {
					googleStatistics( "/clicklocal/finger/banner2/", document.referer );
				}
			};
			
			setInterval(function(){
				if (!autoScroll) {
					return;
				}
				if (_index > 0) {
					_index --;
					 $("#datu").css({"-webkit-transform" : "translate3d(0px, 0, 0)", "-webkit-transition": "300ms","transition":"300ms" });
					$(".panel_num").children("span").removeClass("curr").get(_index).className = "curr";
				} else {
					_index ++;
					var x = -1 * document.body.offsetWidth;
					 $("#datu").css({"-webkit-transform" : "translate3d(" + x + "px, 0, 0)", "-webkit-transition": "300ms","transition":"300ms" });
					$(".panel_num").children("span").removeClass("curr").get(_index).className = "curr";
				}
				
			},4000);
			

			this.init = function() {
				_divId = div_id || "";
				if ("" != _divId) {
					_div = $("#"+_divId);
					_ul = _div.children("ul");
					var div_width = document.body.clientWidth;//parseInt(_div.css("width").replace("px", ""));
					var li1 = $(_ul.children("li").get(0));
					_li_margin = li1.css('margin-left') ? parseInt(li1.css("margin-left").replace("px", "")) : 0;
					_ul_width = parseInt(li1.css("width").replace("px", ""));
					_ul_margin = (div_width - _ul_width) / 2 - _li_margin;
					_ul.css("-webkit-transform", "translate3d("+_ul_margin+"px, 0, 0)");
					_panel = (/^\./.test(panel_id)) ? $(panel_id) : $(("#"+panel_id).replace(/##/, "#"));
					var spans = '';
					for (var i=0, len=_ul.children("li").length; i<len; ++i) {
						spans += (0==i)?'<span class="curr"></span>':'<span></span>';
					}
					_panel.html(spans);
					_bindEvents();
				}
			};
		};
		_slide.bind = function(div_id, panel_id, duration) {
			var obj = new m58.slideX(div_id, panel_id, duration);
			obj.init();
		};
		return _slide;
	}) ();
	window.m58 = window.m58 || {};
	window.m58.slideX = slideX;	
		//��
		m58.slideX.bind("pics", ".panel_num", "300ms");
}

$(function () {
	if ($.os.ios) {
		return;
	}
	// ���ѿ��
	var text = '3���˶��õ��ֻ����ִ�ȫ';
	var href = 'http://dl.wandoujia.com/files/phoenix/latest/wandoujia-58tongcheng_hl.apk';
	var onclick = ' onclick="clickLog(\'from=localwordads1\')"';
	var ul = $('<ul class="fanqie" style="background: #FFF; border-top: 1px solid #FF6C00; list-style-type: square; padding-left: 28px;"><li style="font-size: 12px; padding: 16px 0; text-indent: -5px; "><a href="' + href + '"' + onclick + ' style="color:#374565;">' + text + '</a></li></ul>')[0];
	var div = document.createElement('div');
	div.className = 'fanqie';
	var a = document.createElement('a');
	a.href = href;
	a.innerHTML = text;
	div.appendChild(a);
	$('.body_div')[0].insertBefore(ul, $('.dl_nav')[0]);
	$('.fanqie a').bind('click', function () {
		if (typeof googleAnalytices !== 'undefined') {
			googleAnalytices('/clicklocal/wordads/fanqie/', document.referer);
		}
	});

	$('.dl_nav').css('border-top-color', '#E3E3E3');

	function insertAfter(newEl, targetEl) { 
		var parentEl = targetEl.parentNode; 
		if(parentEl.lastChild == targetEl) { 
			parentEl.appendChild(newEl); 
		} else { 
			parentEl.insertBefore(newEl,targetEl.nextSibling); 
		} 
	} 
});
