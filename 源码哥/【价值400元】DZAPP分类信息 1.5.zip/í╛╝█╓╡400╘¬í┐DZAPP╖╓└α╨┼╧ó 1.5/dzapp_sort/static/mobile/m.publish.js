_rootDomain = 'http://m.58.com';

function googleAnalytices(d, e, f, g) {
    var h = _rootDomain + "/ga/url/?path=" + d + "&referer=" + (typeof(e) == 'undefined' ? "" : e) + (typeof(f) == 'undefined' ? "" : f) + "&callback=?";
    var i = true;
    if (g == false) i = g;
    $.ajax({
        type: "JSONP",
        url: h,
        async: i,
        success: function(a) {
            var b = _rootDomain + a.url;
            var c = document.createElement("img");
            c.src = b;
            c.className = "googleanalyze";
            document.body.appendChild(c)
        },
        timeout: 30000,
        error: function(a) {}
    })
}

function alertShow(a, b, c, d, f, g) {
    if (!$("#alert_bg").length) {
        var h = "<div id='alert_bg' style=\" width: 100%; position: absolute; top:0px; left: 0px; z-index: 1000; background: rgba(0, 0, 0, 0.1)\"></div>" + "<div id=\"alert_box\">" + "<div id=\"show_mes\">信息</div>" + "<div id=\"but_div\">" + "</div></div>";
        $("body").append(h);
        var i = $(document.body).css("height");
        $("#alert_bg").css("height", i)
    } else {
        $("#but_div").empty()
    }
    $("#show_mes").text(a);
    if (b == "1") {
        $("#but_div").show();
        var j = "<div id=\"but01\">" + c + "</div>";
        $("#but_div").append(j);
        $("#but01").css("width", "100%");
        $("#but01").bind("click", function() {
            f()
        })
    }
    if (b == "2") {
        $("#but_div").show();
        var k = "<div id=\"but01\">" + c + "</div><div id=\"but02\">" + d + "</div>";
        $("#but_div").append(k);
        $("#but01").bind("click", function() {
            f()
        });
        $("#but02").bind("click", function() {
            g()
        })
    }
    if (typeof b == "undefined") {
        $("#but_div").hide()
    }
    $("#alert_bg").show();
    $("#alert_box").show();
    var y = parseInt($("#alert_box").get().clientHeight) / 2;
    $("#alert_box").css("margin-top", -y + "px");
    $("#but_div > div").bind("touchstart", function() {
        $(this).addClass("but_hover")
    });
    $("#but_div > div").bind("touchmove", function() {
        $(this).removeClass("but_hover")
    });
    $("#but_div > div").bind("touchend", function() {
        $(this).removeClass("but_hover")
    });
    $("#alert_bg").bind("touchmove", function(e) {
        e.preventDefault()
    });
    $("#alert_box").bind("touchmove", function(e) {
        e.preventDefault()
    })
}

function cancel_but() {
    $("#alert_bg").hide();
    $("#alert_box").hide()
}(function() {
    if (typeof myInfo === 'undefined') {
        var c = document.createElement('div');
        var d = document.createElement('img');
        c.className = 'banner_top';
        d.src = 'publish1120.png';
        document.body.insertBefore(c, $('header')[0]);
        c.appendChild(d);
    } else {
        var c = document.createElement('div');
        var d = document.createElement('img');
        c.className = 'banner_bottom';
        d.src = 'publish1120.png';
        c.appendChild(d);
        $('.post').parent()[0].appendChild(c);
        $(c).bind('click', function() {
            googleAnalytices('/post/clickindex/banner1/' + myInfo.currentCateName, document.referer);
            window.location = 'http://api.wireless.58.com/api/redirect/down/507'
        });
        googleAnalytices('/post/showindex/banner1/' + myInfo.currentCateName, document.referer)
    }
    $('.business dt').bind('click', function() {
        var a = $(this).parent();
        if (a.hasClass('exp')) {
            a.removeClass('exp')
        } else {
            var b = document.body.scrollTop;
            a.addClass('exp');
            window.scrollTo(0, b)
        }
    });
    $('.item .title').append('<div class="placeholder"></div>');
    $('.business a').bind('click', function() {
        if (typeof window.localStorage !== 'undefined') {
            var a = $(this);
            if (!a.hasClass('cate')) {
                localStorage.setItem('userselcate', a.text() + '|||' + a.attr('href'))
            }
        }
    });
    var e = $('.category');
    if (e.length > 0) {
        if (typeof window.localStorage !== 'undefined') {
            var f = localStorage.getItem('publishedok');
            if (f) {
                var g = f.split(',');
                var h = [];
                for (var i = 0, leni = g.length; i < leni; i += 1) {
                    var p = g[i].split('|||');
                    var j = p[0];
                    var k = p[1];
                    p = '<a href="' + k + '">' + j + '</a>';
                    h.push(p)
                }
                e.html(h.join(' | '));
                $('.history').show();
                $('hr').show()
            }
        }
    }
}());
(function() {
    if (typeof datasrc === 'object') {
        $('select').each(function() {
            var a = $(this);
            var b = a.html();
            b = b.replace('selected', 'selected2');
            a.attr('options', b).html('')
        });
        var q = $('.input');
        q.each(function() {
            var b = $(this);
            var c = b.html();
            var d = /(<select[^>]*>)/g;
            b.html(c.replace(d, function(a) {
                a = a.replace('</select>', '');
                return '<div class="select"><label class="psu">请选择</label>' + a + '</select></div>'
            }))
        });
        var r = $('select');
        $('select').each(function() {
            var a = $(this);
            var b = a.attr('id');
            var c = datasrc[b];
            var d = a.parent().parent();
            var e = $('<div class="select"><label class="psu">请选择</label></div>');
            var f = '';
            var g = false;
            if (Object.prototype.toString.call(c) === '[object Object]') {
                if (c.option) {
                    for (var j = 0, lenj = c.option.length; j < lenj; j += 1) {
                        if (typeof c.option[j].value !== 'undefined') {
                            f += '<option value="' + c.option[j].value + '">' + c.option[j].text + '</option>';
                            if (typeof c.option[j].option !== 'undefined') {
                                g = true
                            }
                        }
                    }
                }
            }
            if (Object.prototype.toString.call(c) === '[object Array]') {
                g = true;
                a.attr('array', '1');
                for (var j = 0, lenj = c.length; j < lenj; j += 1) {
                    f += '<option value="' + c[j].id + '">' + c[j].name + '</option>'
                }
            }
            var h = $(this).attr('options') || '';
            a.html('<option value="">请选择</option>' + h + f);
            if (g) {
                d.append('<div class="select" style="visibility: hidden;" type="subcate"><label class="psu">请选择</label></div>')
            }
        });
        $('select').bind('change', function() {
            var c = $(this);
            var d = c.val();
            var e = datasrc[c.attr('id')];
            var f = $(c[0].options[c[0].selectedIndex]).text();
            var g = c.attr('msg');
            var h = c.attr('pattern2');
            c.parent().children('label').text(f);
            if (e && typeof e.option !== 'undefined') {
                var i = c.parent().parent().children('[type=subcate]');
                if (i.length > 0) {
                    i.find('select').remove();
                    i.children('label').text('请选择').parent().css('visibility', 'hidden');
                    if (d !== '') {
                        var j = e.option[c[0].selectedIndex - 1];
                        var k = j.paramname;
                        var l = '<select id="' + k + '" name="' + k + '" class="decorate" msg="' + g + '" pattern2="' + h + '"><option value="">请选择</option>';
                        var m = '';
                        $(j.option).each(function() {
                            var a = this;
                            m += '<option value="' + a.value + '">' + a.text + '</option>'
                        });
                        l += m + '</select>';
                        var n = $(l);
                        var i = c.parent().parent().children('[type=subcate]');
                        if (m !== '') {
                            i.append(l).css('visibility', 'visible');
                            i.children('select').bind('change', function() {
                                var a = $(this);
                                var b = $(a[0].options[a[0].selectedIndex]).text();
                                a.parent().children('label').text(b)
                            })
                        }
                    }
                }
            } else if (c.attr('array') === '1') {
                var i = c.parent().parent().children('[type=subcate]');
                i.find('select').remove();
                i.children('label').text('请选择').parent().css('visibility', 'hidden');
                if (d !== '') {
                    var j = e[c[0].selectedIndex - 1];
                    var k = j.paramname;
                    var l = '<select id="' + k + '" name="' + k + '" class="decorate" msg="' + g + '" pattern2="' + h + '"><option value="">请选择</option>';
                    var o = 0;
                    $(j.option).each(function() {
                        var a = this;
                        l += '<option value="' + a.id + '">' + a.name + '</option>';
                        o++
                    });
                    if (o > 0) {
                        l += '</select>';
                        var n = $(l);
                        var i = c.parent().parent().children('[type=subcate]');
                        i.append(l).css('visibility', 'visible');
                        i.children('select').bind('change', function() {
                            var a = $(this);
                            var b = $(a[0].options[a[0].selectedIndex]).text();
                            a.parent().children('label').text(b)
                        })
                    }
                }
            } else {
                var i = c.parent().parent().children('[type=subcate]');
                var p = i.find('select');
                if (p) {
                    p.remove()
                }
                if (i.length > 0) {
                    i.children('label').text('请选择').parent().css('visibility', 'hidden')
                }
            }
        })
    }
}());
(function() {
    $('#pubFail .btn').bind('click', function() {
        $('#pubFail').hide();
        $('header').css({
            display: '-webkit-box',
            display: 'flex'
        });
        $('aside').show();
        $('body>dl').show();
        $('nav').show();
        $('hr').show();
        $('footer').show();
        $('#mpostForm').show()
    });
    $('.d3 a').bind('click', function() {
        m58.PostX.showLogonWindow();
        scroll(0, document.body.scrollHeight)
    });
    $('.d4 a').bind('click', function() {
        m58.PostX.showLogonWindow()
    })
}());
(function() {}());
(function() {
    var h = {
        continueProcess: false,
        getNodeById: function(a) {
            return document.getElementById(a)
        },
        getNodeByFor: function(a) {
            return document.querySelector('[forid=qy]')
        },
        getCookie: function(a) {
            var b = [],
                reg = new RegExp("(^| )" + a + "=([^;]*)(;|$)");
            if (b = document.cookie.match(reg)) {
                return unescape(b[2])
            }
            return ''
        },
        make5461: function() {
            var d = [];
            $('form select').each(function() {
                var a = $(this);
                var b = a.attr('name');
                var c = $(a[0].options[a[0].selectedIndex]).text();
                if (c !== '' && c !== '请选择') {
                    d.push(b + '=' + encodeURIComponent(c.replace(/\s*$/, '')))
                }
            });
            console.log(d.join('&'));
            return d.join('&')
        },
        getQuery: function() {
            var a = '';
            var b = $('input[type=text], input[type=number], input[type=date], input[type=hidden], input[type=radio]:checked, select, textarea');
            for (var i = 0, leni = b.length; i < leni; i += 1) {
                var c = b[i];
                var d = c.getAttribute('name');
                if (d == "codeText") {
                    if ($("#code-bg").length > 0 && $("#code-bg").css("display") == "none") {
                        continue
                    }
                }
                a += d + '=' + encodeURIComponent(c.value) + '&'
            }
            a = a.replace(/&$/, '');
            return a
        },
        getUserInfo: function() {
            var a = h.getCookie('PPU');
            if (a) {
                var b = (a.match(/UID=(\d*)&/)) ? RegExp.$1 : '';
                var c = (a.match(/UN=([^&]*)&/)) ? RegExp.$1 : '';
                return {
                    "uid": b,
                    "un": c
                }
            } else {
                return false
            }
        },
        validate: function() {
            var a = true,
                nodes = $('[pattern2]'),
                firsttime = false;
            for (var i = 0, leni = nodes.length; i < leni; i += 1) {
                var b = $(nodes[i]),
                    patterns = b.attr('pattern2'),
                    msgs = b.attr('msg');
                if (b.parent().parent().parent()[0].tagName.toLowerCase() === 'div') {
                    if (b.parent().parent().parent().css('display') === 'none') {
                        continue
                    }
                }
                if (b.parent().parent().parent().parent()[0].tagName.toLowerCase() === 'div') {
                    if (b.parent().parent().parent().parent().css('display') === 'none') {
                        continue
                    }
                }
                if (patterns && msgs) {
                    patterns = patterns.split('#');
                    msgs = msgs.split('#');
                    var c = true;
                    for (var j = 0, lenj = patterns.length; j < lenj && c; j += 1) {
                        var d = patterns[j],
                            msg = msgs[j],
                            regexp = new RegExp(d),
                            value = b.val();
                        if (!regexp.test(value)) {
                            h.showTip(b, msg);
                            a = false;
                            c = false;
                            if (!firsttime) {
                                b[0].focus();
                                firsttime = true
                            }
                        } else {
                            h.hideTip(b)
                        }
                    }
                }
            }
            return a
        },
        validate2: function() {
            var a = $('#zonglouceng');
            var b = $('#Floor');
            if (a.length > 0 && b.length > 0) {
                if (+b.val() > +a.val()) {
                    h.showTip(a, '总楼层不能小于所在楼层');
                    a[0].focus();
                    return false
                }
            }
            var c = $('#Time');
            if (c.length > 0) {
                if (c.attr('msg').indexOf('有效期') >= 0) {
                    var d = c.val().replace(/[-/]/g, '');
                    var e = new Date();
                    var f = e.getFullYear() + '';
                    f += (e.getMonth() >= 9) ? e.getMonth() + 1 + '' : '0' + e.getMonth();
                    f += (e.getDate() >= 10) ? e.getDate() + '' : '0' + e.getDate();
                    if (d < f) {
                        h.showTip(c, '有效期不能早于今天');
                        c[0].focus();
                        return false
                    }
                }
            }
            return true
        },
        validate3: function() {
            var a = document.getElementById('codeText');
            if (a && ($("#code-bg").length > 0 && $("#code-bg").css("display") != "none")) {
                var b = $('#codeText');
                var c = b.val().replace(/(^\s*)|(\s*$)/g, "");
                if (c.length == 0 || c == "验证码") {
                    h.showTip(b, '请输入验证码');
                    return false
                } else if (!c.match(/^[A-Za-z0-9]{4,10}$/g)) {
                    h.showTip(b, '验证码错误，请重新输入');
                    return false
                } else {
                    $('#code-pop').find('.tip').css("display", 'none');
                    return true
                }
            } else {
                return true
            }
        },
        loadScript: function(a, b) {
            var c = document.head || document.getElementsByTagName('head')[0] || document.documentElement,
                script, options, s;
            if (typeof a === 'object') {
                options = a;
                a = undefined
            }
            s = options || {};
            a = a || s.url;
            b = b || s.success;
            script = document.createElement('script');
            script.async = s.async || false;
            script.type = 'text/javascript';
            if (s.charset) {
                script.charset = s.charset
            }
            if (s.cache === false) {
                a = a + (/\?/.test(a) ? '&' : '?') + '_=' + (new Date()).getTime()
            }
            script.src = a;
            c.insertBefore(script, c.firstChild);
            if (b) {
                document.addEventListener ? script.addEventListener('load', b, false) : script.onreadystatechange = function() {
                    if (/loaded|complete/.test(script.readyState)) {
                        script.onreadystatechange = null;
                        b()
                    }
                }
            }
        },
        prepare: function() {
            var b = this.getCookie('PPU');
            if (b) {
                this.onLogonOK()
            }
            var c = '';
            $(document.body).append(c);
            $('#winLogon .logonTab').delegate('li', 'click', function() {
                var a = $(this);
                if (a.hasClass('logonTabHid')) {
                    $('.logonTabSel').removeClass('logonTabSel').addClass('logonTabHid');
                    a.removeClass('logonTabHid').addClass('logonTabSel');
                    if (a.text() === '账号登录') {
                        $('#pptLoginForm').show();
                        $('#pptMobileLoginForm').hide()
                    } else {
                        $('#pptLoginForm').hide();
                        $('#pptMobileLoginForm').show()
                    }
                }
            })
        },
        showTip: function(a, b) {
            var c = a.parent().parent();
            if (!c.hasClass('item')) {
                c = c.parent()
            }
            a = c.children('.tip');
            a.html(b);
            a.show();
            c.find('.placeholder').show()
        },
        hideTip: function(a) {
            var b = a.parent().parent();
            if (!b.hasClass('item')) {
                b = b.parent()
            }
            a = b.children('.tip');
            a.hide();
            b.find('.placeholder').hide()
        },
        showLogonWindow: function() {
            $('header').hide();
            $('aside').hide();
            $('body>dl').hide();
            $('nav').hide();
            $('hr').hide();
            $('footer').hide();
            $('#mpostForm').hide();
            $('#winLogon').show()
        },
        hideLogonWindow: function() {
            $('header, nav, hr, #mpostForm, footer,aside,body>dl').show();
            $('#winLogon').css('display', 'none');
            h.continueProcess = false
        },
        send: function(a, b) {
            var c = $('#mpostForm').attr('action');
            $('#btnPost').attr('disabled', true);
            $.ajax({
                type: 'POST',
                url: c,
                data: b,
                success: h.onSubmitOK
            })
        },
        onSubmit: function(e) {
            var a = document.querySelectorAll('.tip'),
                userInfo = h.getUserInfo(),
                query = '';
            for (var i = 0, leni = a.length; i < leni; i += 1) {
                var b = a[i];
                b.style.display = 'none'
            }
            var c = h.validate();
            c &= h.validate2();
            c &= h.validate3();
            if (c) {
                if (userInfo) {
                    $('#gobquzhi').val(h.make5461());
                    query = h.getQuery();
                    h.send(userInfo, query)
                } else {
                    myInfo.userid = 0;
                    myInfo.loginstate = '';
                    h.continueProcess = true;
                    h.showLogonWindow()
                }
            }
            if (typeof e !== 'undefined') {
                e.preventDefault()
            }
            return false
        },
        onSubmitOK: function(a) {
            if (a) {
                if (a.indexOf('|') > 0) {
                    var a = a.split('|');
                    var b = a[0];
                    var c = a[1];
                    if (b == 0) {
                        var d = document.getElementById('code-bg');
                        if (d) {
                            $("#code-bg").hide();
                            $("#code-pop").hide()
                        }
                        alertShow('发布成功，您可以在“我的58-我的发布”中查看和操作该信息。', 2, '我的发布', '关闭', function() {
                            window.location = 'http://m.m.58.com/'
                        }, function() {
                            window.location = 'http://p.m.58.com/'
                        });
                        if (typeof window.localStorage !== 'undefined') {
                            var e = localStorage.getItem('userselcate');
                            var f = localStorage.getItem('publishedok') || [];
                            if (e && f.indexOf(e) < 0) {
                                if (Object.prototype.toString.call(f) !== '[object Array]') {
                                    f = f.split(',')
                                }
                                f.unshift(e);
                                if (f.length > 2) {
                                    f.pop()
                                }
                                localStorage.setItem('publishedok', f.join(','));
                                localStorage.removeItem('userselcate')
                            }
                        }
                    } else if (b == 4) {
                        var d = document.getElementById('codeText');
                        if (d) {
                            var g = $('#codeText');
                            h.showTip(g, '验证码错误，请重新输入');
                            nextCode();
                            $('#btnPost').removeAttr('disabled');
                            $('#codeText').one('focus', function() {
                                $('#codeText').val('')
                            });
                            return false
                        }
                    } else if (b == 5) {
                        popCode()
                    } else {
                        var d = document.getElementById('code-bg');
                        if (d) {
                            $("#code-bg").hide();
                            $("#code-pop").hide()
                        }
                        alertShow('信息发布失败。<br>' + c, 1, '关闭', '', cancel_but);
                        $('#btnPost').removeAttr('disabled')
                    }
                }
            }
            return
        },
        onPassportLoad: function() {
            if ($('#pptMobileLoginForm').length > 0) {
                $('#winLogon').append('<div class="logonsep"></div><p>二、注册新账户登录发布</p>');
            }
        },
        onRegLoad: function() {
            $('#pptMobileRegForm').append('<input id="btnCancel" type="button" value="取消" />');
            $('#btnCancel').bind('click', function() {
                h.hideLogonWindow()
            })
        },
        onLogonOK: function(e) {
            var a = h.continueProcess;
            $('header .d3').hide();
            h.hideLogonWindow();
            if (a) {
                h.onSubmit()
            }
        },
        init: function() {
            var a = document.getElementById('mpostForm');
            if (a) {
                a.addEventListener('submit', m58.PostX.onSubmit, false)
            }
            this.prepare();
        }
    };
    window.m58 = window.m58 || {};
    window.m58.PostX = h;
    m58.PostX.init();
    document.write = function(a) {
        $('#winLogon').append(a)
    };
    if (typeof window.myInfo !== 'undefined') {
        var k = myInfo.curDiscateid;
        var l = {
            autoFill: true,
            fill: function(a) {
                if (a && l.autoFill) {
                    $('#Title').val(a.substring(0, 30))
                }
            },
            zhengzu: function() {
                $('#xiaoqu, #huxingshi, #huxingting, #huxingwei, #area').bind('blur', function() {
                    var a = $('#xiaoqu').val(),
                        huxingshi = $('#huxingshi').val(),
                        huxingting = $('#huxingting').val(),
                        huxingwei = $('#huxingwei').val(),
                        area = $('#area').val();
                    var b = (a != '' ? a + ' ' : '') + (huxingshi != '' ? huxingshi + '室' : '') + (huxingting != '' ? huxingting + '厅' : '') + (huxingwei != '' ? huxingwei + '卫' : '') + (area != '' ? ' ' + area + '㎡' : '');
                    l.fill(b)
                })
            },
            hezu: function() {
                $('#xiaoqu, #huxingshi, #huxingting, #huxingwei, #xianzhi').bind('blur', function() {
                    var a = $('#xiaoqu').val(),
                        huxingshi = $('#huxingshi').val(),
                        huxingting = $('#huxingting').val(),
                        huxingwei = $('#huxingwei').val(),
                        xianzhi = $($('#xianzhi')[0].options[$('#xianzhi')[0].selectedIndex]).text();
                    var b = (a != '' ? a + ' ' : '') + (huxingshi != '' ? huxingshi + '室' : '') + (huxingting != '' ? huxingting + '厅' : '') + (huxingwei != '' ? huxingwei + '卫' : '') + (xianzhi != '请选择' ? ' ' + xianzhi : '');
                    l.fill(b)
                })
            },
            xiezilou: function() {
                $('#localDiduan, #loupan, #ObjectType, #area').bind('blur', function() {
                    var a = $($('#localDiduan')[0].options[$('#localDiduan')[0].selectedIndex]).text(),
                        loupan = $('#loupan').val(),
                        leixing = $($('#ObjectType')[0].options[$('#ObjectType')[0].selectedIndex]).text();
                    area = $('#area').val();
                    var b = (a != '请选择' ? a + ' ' : '') + (loupan != '' ? loupan : '') + (leixing != '请选择' ? leixing : '') + (area != '' ? ' ' + area + '㎡' : '');
                    l.fill(b)
                })
            },
            shangpu: function() {
                $('#localDiduan, #diduan, #ObjectType, #area').bind('blur', function() {
                    var a = $('#localDiduan').length > 0 ? $($('#localDiduan')[0].options[$('#localDiduan')[0].selectedIndex]).text() : '',
                        diduan = $('#diduan').length > 0 ? $('#diduan').val() : '',
                        leixing = $($('#ObjectType')[0].options[$('#ObjectType')[0].selectedIndex]).text(),
                        area = $('#area').val();
                    var b = (a != '请选择' ? a : '') + (diduan != '' ? ' ' + diduan : '') + (leixing != '请选择' ? ' ' + leixing : '') + (area != '' ? ' ' + area + '㎡' : '');
                    l.fill(b)
                })
            },
            changfang: function() {
                $('#localDiduan, #diduan, #ObjectType, #area').bind('blur', function() {
                    var a = $($('#localDiduan')[0].options[$('#localDiduan')[0].selectedIndex]).text(),
                        diduan = $('#diduan').val(),
                        leixing = $($('#ObjectType')[0].options[$('#ObjectType')[0].selectedIndex]).text();
                    area = $('#area').val();
                    var b = (a != '请选择' ? a : '') + (diduan != '' ? ' ' + diduan : '') + (leixing != '请选择' ? ' ' + leixing : '') + (area != '' ? ' ' + area + '㎡' : '');
                    l.fill(b)
                })
            }
        };
        $('#Title').bind('keyup', function() {
            if ($(this).val() != '') {
                l.autoFill = false
            } else {
                l.autoFill = true
            }
        });
        switch (k) {
            case 8:
                l.zhengzu();
                break;
            case 12:
                l.zhengzu();
                break;
            case 10:
                l.hezu();
                break;
            case 13:
                l.xiezilou();
                break;
            case 14:
                l.shangpu();
                break;
            case 15:
                l.changfang();
                break;
            default:
                break
        }
    }
}());
$(function() {
    var a = document.getElementById('codeText');
    if (a) {
        $('#mpostForm').find('.nextCode').bind('click', function() {
            $($('.nextCode').get(0).parentNode.parentNode).find('.tip').hide();
            nextCode();
            $('#codeText').val('')
        })
    }
});

function nextCode() {
    var a = $('#codeImg').attr('src');
    if (a.indexOf('&') != -1) {
        $('#codeImg').attr('src', a.substring(0, a.indexOf('&')) + '&random=' + Math.random())
    } else {
        $('#codeImg').attr('src', a + '&random=' + Math.random())
    }
}

function popCode() {
    var H = $(document.body).css("height");
    if ($("#code-bg").length) {
        $('#code-bg').show();
        $('#code-pop').show();
        return
    } else {
        $(document.body).append('<div id="code-bg" style="display:block;position:fixed;left:0;top:0;z-index:1005;width:100%;height:' + H + ';background:rgba(0,0,0,0.5);"></div>' + '');
        $("#code-bg").bind("touchmove", function(e) {
            e.preventDefault()
        });
        $("#code-pop").bind("touchmove", function(e) {
            e.preventDefault()
        })
    }
    $('#codeText').bind('focus', function() {
        if ($(this).val() == '验证码') {
            $(this).val('')
        }
    });
    $('.nextCode').bind('click', function() {
        $($('.nextCode').get(0).parentNode.parentNode).find('.tip').hide();
        nextCode();
        $('#codeText').val('验证码')
    });
    $('#code-pop').find('.pop_cancel').bind('click', function() {
        $('#code-pop').hide();
        $('#code-bg').hide();
        $('#btnPost').removeAttr('disabled')
    });
    $('#code-pop').find('.pop_sub').bind('click', function() {
        window.m58.PostX.onSubmit();
        return true
    })
}