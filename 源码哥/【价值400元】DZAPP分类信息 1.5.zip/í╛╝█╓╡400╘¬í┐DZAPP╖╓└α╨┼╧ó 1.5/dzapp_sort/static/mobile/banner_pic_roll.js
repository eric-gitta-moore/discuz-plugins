

function googleStatistics(para, referer) {
	if (typeof googleAnalytices === 'function') {
		googleAnalytices(para, referer);
	}
}

function scrollpic() {
	var slideX = (function() {
		var _slide = function(div_id, panel_id, duration) {
			var	_divId, _div, _ul, _panel, _eleX, _li_margin, _ul_width, _ul_margin,
			_startx = _index = 0, _duration = duration,autoScroll = true,
			_bindEvents = function() {
				_ul.bind("touchstart", _touchstart, false);
				_ul.bind("touchmove", _touchmove, false);
				_ul.bind("touchend", _touchend, false);
			},
			_click = function(e) {
				var img = e.target;
			},
			_move = function(e, sx, ex) {
				var max = _ul.children().length;
				if (ex > sx) {
					if (_index > 0) {
						_index --;
					}
				} else if (ex < sx){
					if (_index < max-1) {
						_index ++;
					}
				} else {
					_click(e);
					return;
				}
				var movex = (_index==0)?_ul_margin:-(_index * (_ul_width+_li_margin*2))+_ul_margin;
				_ul.css("-webkit-transition-duration", _duration);
				_ul.css("-webkit-transform", "translate3d("+movex+"px,0,0)");
				_panel.children("span").removeClass("curr").get(_index).className = "curr";
				
			};
			_touchstart = function(e) {
				autoScroll = false;
				e.stopPropagation();
				var finger0 = e.targetTouches[0];
				_startx = finger0.pageX;
				var transform = $(this).css("-webkit-transform");
				var translateX = parseInt(transform.split(/[(]|[,]|[)]/)[1]);
				_eleX = translateX || _ul_margin;
			},
			_touchmove = function(e) {
				e.preventDefault();
				e.stopPropagation();
				var finger0 = e.targetTouches[0];
				var moveX = finger0.pageX - _startx + _eleX;
				_ul.css({"-webkit-transition-duration": "0", "-webkit-transform": "translate3d("+moveX+"px, 0, 0)"});
			};
			_touchend = function(e) {
				var finger0 = e.changedTouches[0];
				_move(e, _startx, finger0.pageX);
				autoScroll = true;
				if (_index > 0) {
					googleStatistics( "/clicklocal/finger/banner1/", document.referer );
				} else {
					googleStatistics( "/clicklocal/finger/banner2/", document.referer );
				}
			};
			
			setInterval(function(){
				if (!autoScroll) {
					return;
				}
				if (_index > 0) {
					_index --;
					 $("#datu").css({"-webkit-transform" : "translate3d(0px, 0, 0)", "-webkit-transition": "300ms","transition":"300ms" });
					$(".panel_num").children("span").removeClass("curr").get(_index).className = "curr";
				} else {
					_index ++;
					 $("#datu").css({"-webkit-transform" : "translate3d(-320px, 0, 0)", "-webkit-transition": "300ms","transition":"300ms" });
					$(".panel_num").children("span").removeClass("curr").get(_index).className = "curr";
				}
				
			},4000);
			

			this.init = function() {
				_divId = div_id || "";
				if ("" != _divId) {
					_div = $("#"+_divId);
					_ul = _div.children("ul");
					var div_width = document.body.clientWidth;//parseInt(_div.css("width").replace("px", ""));
					var li1 = $(_ul.children("li").get(0));
					_li_margin = li1.css('margin-left') ? parseInt(li1.css("margin-left").replace("px", "")) : 0;
					_ul_width = parseInt(li1.css("width").replace("px", ""));
					_ul_margin = (div_width - _ul_width) / 2 - _li_margin;console.log(_ul_margin);
					_ul.css("-webkit-transform", "translate3d("+_ul_margin+"px, 0, 0)");
					_panel = (/^\./.test(panel_id)) ? $(panel_id) : $(("#"+panel_id).replace(/##/, "#"));
					var spans = '';
					for (var i=0, len=_ul.children("li").length; i<len; ++i) {
						spans += (0==i)?'<span class="curr"></span>':'<span></span>';
					}
					_panel.html(spans);
					_bindEvents();
				}
			};
		};
		_slide.bind = function(div_id, panel_id, duration) {
			var obj = new m58.slideX(div_id, panel_id, duration);
			obj.init();
		};
		return _slide;
	}) ();
	window.m58 = window.m58 || {};
	window.m58.slideX = slideX;	
	$(function() {
		//��
		m58.slideX.bind("pics", ".panel_num", "300ms");
	});
}



/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/
$(function () {
	if ($.cookie.get('mtg')) {
		$('#pics').parent().hide();
	}
});
