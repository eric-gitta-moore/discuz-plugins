

    setTimeout(function(){ window.scrollTo(0, 1); }, 1);

    //TOP
    var scr_time;
    window.onscroll=function(){
        var docH = window.innerHeight;
        var scrT = document.body.scrollTop;
        if($(".top_div").get(0)) $(".top_div").hide();
        clearInterval(scr_time);
        if(scrT > docH*3){
            if(!$(".top_div").get(0)){
                var top_html = "<div class=\"top_div\"><a href=\"javascript:document.body.scrollTop = 0\">&nbsp;</a></div>";
                $("body").append(top_html);
            }
            scr_time = setInterval(show_top,100);
        }
    };
    function show_top(){
        $(".top_div").show();
        clearInterval(scr_time);
    };

    //�б�����
    if($(".selist_div .selist_more")){
        $(".selist_div .selist_more").bind("click",function(){
            var maxH = Math.max(window.innerHeight,document.body.clientHeight);
            $("#selectorMask").show().css("height",maxH+"px");
            $("#selectorWrap").show().css("height",maxH+"px");
            $("#selectorBox").css("height",maxH+"px").show();
            setTimeout(function(){
                window.scrollTo(0,1);
                $("#selectorBox").css("-webkit-transform","translate3d(0,0,0)");
            },0);
        });
    };
    if($("#selectorMask")){
        $("#selectorMask").bind("click",function(){
            $("#selectorBox").css("-webkit-transform","translate3d(280px,0,0)");
            $("#selectorMask").hide();
            setTimeout(function(){
                $("#selectorBox").hide();
            },300);
        });
    };
    if($("#selectorBox ul#selectorCon li")){
        $("#selectorBox ul#selectorCon li").bind("click",function(){
            window.location.href = $(this).attr("url");
        });
    };

    //iphone
    if(____json4fe.catentry.name == "sou" && $(".index_div")&& window.location.href.indexOf("local")>0){
        if ((/iphone|ipad/gi).test(navigator.appVersion)) {
            if(window.localStorage){
                if(typeof(localStorage.addLayer)=='undefined'){
                    $(".index_div").append('<div id="addMscreen"><b class="ico_close"></b><p>�밴�·�"<strong>+</strong>"����"<strong>@</strong>"<br>Ȼ��ѡ�� "���ӵ�����Ļ"<br>���ɿ��������������!</p><div class="addThree"></div></div>');
                    $('#addMscreen').css("display","block");
                    localStorage.setItem('addLayer','addMscreen');
                }
                $('.ico_close').bind('click',function(){
                    $('#addMscreen').css("display","none");
                });
                $('#addMscreen').bind('click',function(){
                    $(this).css("display","none");
                });
            }
        }
    };

//    $(".nav_a ul li").bind("touchstart",function(){
//        $(this).find(".nav_img_sh").show();
//    });
//    $(".nav_a ul li").bind("touchmove",function(){
//        $(this).find(".nav_img_sh").hide();
//    });
//    $(".nav_a ul li").bind("touchend",function(){
//        $(this).find(".nav_img_sh").hide();
//    });
//    $(".nav_a ul li").bind("touchcancel",function(){
//        $(this).find(".nav_img_sh").hide();
//    });

//��������
	if($(".nav_a ul li a.nav_aurl").length){
		$(".nav_a ul li a.nav_aurl").bind("touchstart",function(){
			$(this).css("opacity","1");
		});
		$(".nav_a ul li a.nav_aurl").bind("touchmove",function(){
			$(this).css("opacity","0");
		});
		$(".nav_a ul li a.nav_aurl").bind("touchend",function(){
			$(this).css("opacity","0");
		});
		$(".nav_a ul li a.nav_aurl").bind("touchcancel",function(){
			$(this).css("opacity","0");
		});
	}

    a_init();

//��ҳ��ť��Ч
	if($(".index_nav_main ul li a").length){
		$(".index_nav_main ul li a").bind("touchstart",function(){
			$(this).addClass("hover2");
			var url = $(this).attr("rel");
			setTimeout(function(){ window.location.href = url },900);
		});
	}

    if($(".selist_half a span font div")){
        selist_half_num = $(".selist_half a span font div").length-1;
        $(".selist_half a span font div").each(function(i){
            var str_width =  parseInt($(this).css("width"));
            var str_nums = parseInt(str_width/14);  //һ����ʾ��������
            var old_str = $(this).text();
            var ghr = old_str.lastIndexOf(")");
            var ghl = old_str.lastIndexOf("(");
            var num_str = old_str.substr(ghl,ghr); //ȡ��ǰ������
            var num_strs = Math.ceil((ghr-ghl+1)/2);    // ���������
            var show_num  = str_nums - num_strs;   //ǰ��������������
            var old_show = old_str.substr(0,ghl);   //��ǰ������
            var old_show_le = old_show.length;      //��ǰ���ָ���
            if(old_show_le > show_num ){
                var wzi = old_show.substr(0,show_num-1)+"��";
                $(this).text(wzi+num_str);
            }
            if(selist_half_num == i){
                $(".selist_div").css("height","auto");
            }
        });

    }

    //����ҳ��ת
    if($("#gotodownload").length){
        if($.os.ios){
            $("#gotodownload").attr("href","http://itunes.apple.com/cn/app/id404612543?mt=8");
            if($("#detailgotodownload").length){
                $("#detailgotodownload").attr("href","http://itunes.apple.com/cn/app/id404612543?mt=8");
            }
        }
    }
    
    if($(".m311").length){
        $("input").bind({
            focus:function () {
                $(this).css("color", "#3e3e3e");
            },
            blur:function () {
                $(this).css("color", "#B6B6B6");
            }
        });
    }
    if($(".detail_w").length){
        $.my.addHistory();
    }
    $.my.delPubInfo();
    $.my.delFavorite();
    $.my.delHistory();

    if($(".city_box").length){
        lettersIndex();
    }
    //��Ļ��תʱ�����б�ҳ���� and android��֧��orientationchange �Ĵ���
    window.addEventListener("orientationchange",function(){
        infoListIconStyle();
    });
    if(jq.os.android){
        window.addEventListener("resize",function(){
            infoListIconStyle();
        });
    }

    //��δ����Ϣ��
    if($("#bangbang").length){
        if ($.m3login.checklogin()){
            if($.cookie.get("m58offline") != null && $.cookie.get("m58offline") != 0){
                if(parseInt($.cookie.get("m58offline")) > 99 ){
                    $("#bangbang").html("99+").css("display","inline-block");
                    $(".bbmes").html("99+").css("display","inline-block");
                }else{
                    $("#bangbang").html($.cookie.get("m58offline")).css("display","inline-block");
                    $(".bbmes").html($.cookie.get("m58offline")).css("display","inline-block");
                }
            }
        }else{
            if($.cookie.get("m58outoffline") != null && $.cookie.get("m58outoffline") != 0){
                if(parseInt($.cookie.get("m58outoffline")) > 99 ){
                    $("#bangbang").html("99+").css("display","inline-block");
                    $(".bbmes").html("99+").css("display","inline-block");
                }else{
                    $("#bangbang").html($.cookie.get("m58outoffline")).css("display","inline-block");
                    $(".bbmes").html($.cookie.get("m58outoffline")).css("display","inline-block");
                }
            }
        }
    }


});


function a_init(){
    $("a").bind("touchstart",function(){
        if(!$(this).hasClass("disabled")){
            if($(this).parent().hasClass("nav_tt") || $(this).parent().hasClass("other_title") || $(this).parent().hasClass("menu_title") ){
                if(!$(this).parent().hasClass("nav_tta")){
                    $(this).addClass("hover1");
                }
            }else{
                if($(this).attr("class") != "nav_aurl"){
                    $(this).addClass("hover");
                }
            }
        }
    });
    $("a").bind("touchmove",function(){
        $(this).removeClass("hover");
        $(this).removeClass("hover1");
    });
    $("a").bind("touchend",function(){
        $(this).removeClass("hover");
        $(this).removeClass("hover1");
    });
    $("a").bind("touchcancel",function(){
        $(this).removeClass("hover");
        $(this).removeClass("hover1");
    });
}


function body_init(){
    var body_height = parseInt($(".body_div").css("height"));
    var win_height = window.innerHeight;
    if(body_height < win_height){
        var top_margin = win_height-body_height-2;
        $(".footer").css("margin-top",top_margin+"px");
    }
}

//dom ������ɺ�ִ��
document.addEventListener("DOMContentLoaded",function(){
    detailAttrStyle();
});

//�б�ҳ����ͼƬ����
var infoListIconStyle=function(){
    if(!$(".infolst").length){return}
    var currUl = $(".infolst");
    var currUlIndex = currUl.length-1;
    $(currUl.get(currUlIndex)).find("li").each(function(){
        var tagi = $(this).find("dt i");
        if(tagi.length==1){
            $(this).find("strong").css("padding-right","40px");
        }else if(tagi.length==2){
            $(this).find("strong").css("padding-right","55px");
            $(this).find(".biz").css("right","20px");
            $(this).find(".qiandai").css("right","20px");
        }
    });
};

//����ҳ������Ϣ���Զ���
var detailAttrStyle=function(){
    if(!$(".attr_info").length){return}
    $(".attr_info").find(".attrName").each(function(){
        if($(this).text().length<4){
            var strs = $(this).text().substr(0,1);
            var stre = $(this).text().substr(1);
            $(this).html(strs+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+stre);
        }
    });
};

//�ղسɹ���ʾ
var FavoriteMsg=function(txt){
    if(!$(".FavoriteMsg").length){
        var msgLayer = "<div class='FavoriteMsg'></div>";
    }
    $(".status_bar").append(msgLayer);
    var msgLayer =$(".FavoriteMsg");
    if(txt){
        msgLayer.html(txt);
    }else{
        msgLayer.html("�ղسɹ������ڡ��ҵ��ղء��в鿴");
    }
    msgLayer.show();
    setTimeout(function(){
        msgLayer.hide();
    },2000);
};

//����ĸ��λ�����б�
function lettersIndex(){
    var scrTop;
    $(window).bind("scroll",function(){
        scrTop =  document.body.scrollTop;
    });
    $(".letters_lst li").each(function(i){
        $(this).bind("click",function(){
            var thatTop = $(".city_box h4").get(i).getBoundingClientRect().top;
            document.body.scrollTop= scrTop + thatTop;
        });
    });
}

//��������
function citySearch(keywordCity,autoTipsCity){
    this.keywordCity=keywordCity;
    this.autoTipsCity=autoTipsCity;
    this.cityData = null;
    this.focus=function(){
        var val = $("#"+this.keywordCity).val();
        if(val=="�������������"){
            $("#"+this.keywordCity).val("");
        }
    };
    this.blur=function(){
        var val = $("#"+this.keywordCity).val();
        if(val==""){
            $("#"+this.keywordCity).val("�������������");
        }
    };
    this.getData=function(){
        var _this = this;
        var val = $("#"+_this.keywordCity).val();
        var url = "http://"+_rootDomainNoProtocol+"/city/search?cityName="+val+"&backfun=";
        $.get(url,function(data){
              _this.cityData = eval(data);
              var url = "http://"+_rootDomainNoProtocol+"/";
              if(typeof _this.cityData =="object"&& _this.cityData.data.length){
                  var cityList = "<ul>";
                  $.each(_this.cityData.data,function(i,sub){
                      cityList+="<li><a href='"+ url+sub.localName+"'>"+sub.listName+"</a></li>";
                  });
                  cityList+="<li id='closeTips'>��&nbsp;&nbsp;��</li></ul>";
                  $("#"+_this.autoTipsCity).html(cityList);
                  $("#"+_this.autoTipsCity).show();
                  $("#closeTips").bind("click",function(){
                      $("#"+_this.autoTipsCity).hide();
                  });
              }else{
                  $("#"+_this.autoTipsCity).empty();
                  $("#"+_this.autoTipsCity).hide();
              }
        });

    };
    this.submit=function(){
        var val = $("#"+this.keywordCity).val();
        var url = "http://"+_rootDomainNoProtocol+"/";
        var gotoStatus=false;
        if(val=="�������������"){
           return;
        }
        if(typeof this.cityData =="object"&& this.cityData.data.length){
            $.each(this.cityData.data,function(i,sub){
                 if(sub.listName==val){
                     gotoStatus=true;
                     window.location.href=url+ sub.localName;
                 }else{
                     gotoStatus=false;
                 }
            });
            if(!gotoStatus){
                alert("��������ȷ�ĳ�������");
            }
        }else{
            alert("��������ȷ�ĳ�������");
        }
    };
}

//���ж�λ
(function($){
    $.location={
        //��ȡ��ǰλ��
        getCurrPos:function(){
            if(navigator.geolocation){
                if($(".city_page").length){
                    $(".curr_city").html("���ڶ�λ��,���Ժ�...");
                }else if($(".index_page").length){
                    $.location.createTips("���ڻ�ȡλ����Ϣ...");
                }else if($(".getpos_page").length){
                    $.location.createTips("���ж�λ��...");
                }
                navigator.geolocation.getCurrentPosition(this.getPosSuccess,this.getPosError,{
                    timeout:10000,
                    maximumAge:60000,
                    enableHighAccuracy:true
                });
                //gaͳ��
                googleAnalytices("/location/city/click/" ,document.referrer);
            }else{
                alert("�����������֧��GPS��λ����");
            }
        },
        //�ɹ��󴢴�λ������,ִ����ת����ʾ
        getPosSuccess:function(pos){
            // �˴� thisָ���window����
            var lat = pos.coords.latitude;
            var lon = pos.coords.longitude;
            var service_url = "http://"+_rootDomainNoProtocol+"/location/?l=" + lat + "&d=" + lon;
            $.ajax({url:service_url,success:function(data){
                var citydata = eval('(' + data + ')');
                if(typeof citydata =="object" && citydata.listname.length){
                    if(window.localStorage){
                        var saveDate = new Date();
                        localStorage.setItem("locationDate",saveDate.getDate());
                        localStorage.setItem("myLat",lat);
                        localStorage.setItem("myLon",lon);
                        localStorage.setItem("myCity",citydata.listname);
                        localStorage.setItem("myCityName",citydata.cityname);
                    }
                    //alert("�����ڵĳ����ǣ�"+citydata.cityname);
                    var gotoUrl = "http://"+_rootDomainNoProtocol+"/"+citydata.listname;
                    if($(".index_page").length){
                        $.location.createTips("��ǰ��λ���У�"+citydata.cityname);
                        setTimeout(function(){
                            $("#tipsDiv").hide();
                        },3000);
                        window.location.href=gotoUrl;
                    }else if($(".city_page").length){
                        $(".curr_city").html("��ǰ��λ����: "+"<a href="+gotoUrl+">"+citydata.cityname+"</a>");
                    }else if($(".getpos_page").length){
                        $.location.createTips("��ǰ��λ���У�"+citydata.cityname);
                        setTimeout(function(){
                            $("#tipsDiv").hide();
                        },3000);
                        window.location.href="http://"+_rootDomainNoProtocol+"/"+citydata.listname+"/pinche/?from=qq_pinche&channel=qq";
                    }
                }
                //gaͳ��
                var oldcity = ____json4fe.locallist[0].listname ;
                var eq = "eq" ;
                if(oldcity != citydata.listname){eq = "ne";}
                googleAnalytices("/location/"+ oldcity +"/locate/"+ citydata.listname +"/"+ eq +"/success/" ,document.referrer);

            },timeout:10000,error:function(){
                $.location.createTips("��λʧ�ܣ����ֶ�ѡ����С�");
                setTimeout(function(){
                    $("#tipsDiv").hide();
                },3000);
            }});
        },
        //ʧ�ܺ���ʾ������Ϣ
        getPosError:function(err){
            // �˴� thisָ���window����ֱ��this.createTips�ᱨ����
            var oldcity = ____json4fe.locallist[0].listname;
            switch(err.code){
                case err.PERMISSION_DENIED:
                    if($(".getpos_page").length){
                        $.location.createTips("��λʧ�ܣ�Ϊ����ת������ƴ��ҳ��...");
                        window.location.href="http://"+_rootDomainNoProtocol+"/bj/pinche/?from=qq_pinche&channel=qq";
                    }else{
                        $.location.createTips("���ܾ��˹���λ�ã����ֶ�ѡ����С�");
                    }
                    setTimeout(function(){
                        $("#tipsDiv").hide();
                    },3000);
                    googleAnalytices("/location/"+ oldcity +"/locate/"+ oldcity+"/eq/fail/denied/" ,document.referrer);
                    console.log("�û��ܾ�����λ��");
                    break;
                case err.POSITION_UNAVAILABLE:
                    $.location.getCityIp();
                    googleAnalytices("/location/"+ oldcity +"/locate/"+ oldcity+"/eq/fail/unavailable/" ,document.referrer);
                    console.log("�޷���ȡ��ǰλ��");
                    break;
                case err.TIMEOUT:
                    $.location.getCityIp();
                    googleAnalytices("/location/"+ oldcity +"/locate/"+ oldcity+"/eq/fail/timeout/" ,document.referrer);
                    console.log("��ȡλ�ó�ʱ");
                    break;
                default:
                    $.location.getCityIp();
                    googleAnalytices("/location/"+ oldcity +"/locate/"+ oldcity+"/eq/fail/unknownerror/" ,document.referrer);
                    console.log("δ֪����");
                    break;
            }
        },
        getCityIp:function(){
            var ipserverurl = "http://"+_rootDomainNoProtocol+"/ipservice/?callback=?";
            $.ajax({url:ipserverurl,success:function(data){
                var ipCityData = data;
                if(typeof ipCityData=="object"){
                    //��������֧�ֱ��ش��棬�������ݴ��뱾��
                    if(window.localStorage){
                        var saveDate = new Date();
                        localStorage.setItem("locationDate",saveDate.getDate());
                        localStorage.setItem("myCity",ipCityData.listname);
                        localStorage.setItem("myCityName",ipCityData.localname);
                    }
                    var gotoUrl= "http://"+_rootDomainNoProtocol+"/"+ipCityData.listname;
                    if($(".index_page").length ){
                        $.location.createTips("��ǰ��λ���У�"+ipCityData.localname);
                        setTimeout(function(){
                            $("#tipsDiv").hide();
                        },3000);
                        window.location.href=gotoUrl;
                    }else if($(".city_page").length){
                        $(".curr_city").html("��ǰ��λ����: "+"<a href="+gotoUrl+">"+ipCityData.localname+"</a>");
                    }else if($(".getpos_page").length){
                        $.location.createTips("��ǰ��λ���У�"+ipCityData.localname);
                        setTimeout(function(){
                            $("#tipsDiv").hide();
                        },3000);
                        window.location.href="http://"+_rootDomainNoProtocol+"/"+ipCityData.listname+"/pinche/?from=qq_pinche&channel=qq";
                    }
                }else{
                    $.location.getCityIpError();
                }
            },timeout:10000,error:function(){
                $.location.getCityIpError();
            }});
        },
        getCityIpError:function(){
            //gaͳ��
            var oldcity = ____json4fe.locallist[0].listname;
            googleAnalytices("/location/"+ oldcity +"/locate/"+ oldcity+"/eq/fail/iperror/" ,document.referrer);
            if($(".index_page").length){
                $.location.createTips("��λʧ�ܣ�����ǰ������ѡ��ҳ��...");
                window.location.href="http://"+_rootDomainNoProtocol+"/city.html?from=iperror";
            }else if($(".city_page").length){
                $(".curr_city").html("<span class='ico'></span>��ѽ����λ���ɹ����� <a href='javascript:;' onclick='$.location.getCurrPos()'>���¶�λ</a>");
            }else if($(".getpos_page").length){
                $.location.createTips("��λʧ�ܣ�Ϊ����ת������ƴ��ҳ��...");
                setTimeout(function(){
                    $("#tipsDiv").hide();
                },3000);
                window.location.href="http://"+_rootDomainNoProtocol+"/bj/pinche/?from=qq_pinche&channel=qq";
            }
        },
        //��ʼ����ִ�ж�λ����
        posInit:function(){
            if(typeof localStorage.locationDate=="undefined"){
                this.getCurrPos();
            }else{
                var nowDate = new Date();
                if(nowDate.getDate()==localStorage.locationDate && localStorage.myCity.length){
                    //alert("һ����ֻ��λһ��,�����ڵĳ����ǣ�"+localStorage.myCityName);
                    var gotoUrl = "http://"+_rootDomainNoProtocol+"/"+localStorage.myCity;
                    if($(".index_page").length){
                        window.location.href=gotoUrl;
                    }else if($(".city_page").length){
                        $(".curr_city").html("��ǰ��λ����: "+"<a href="+gotoUrl+">"+localStorage.myCityName+"</a>");
                    }else if($(".getpos_page").length){
                        $.location.createTips("����ǰ��"+localStorage.myCityName+"ƴ��ҳ��...");
                        setTimeout(function(){
                            $("#tipsDiv").hide();
                        },3000);
                        window.location.href="http://"+_rootDomainNoProtocol+"/"+localStorage.myCity+"/pinche/?from=qq_pinche&channel=qq";
                    }
                }else{
                    this.getCurrPos();
                }
            }
        },
        //����������Ϣ��
        createTips:function(txt){
            if(!$("#tipsDiv").length){
                var tipsDiv = "<div id='tipsDiv'>"+txt+"</div>";
                $("body").append(tipsDiv);
            }else{
                $("#tipsDiv").text(txt);
            }
            $("#tipsDiv").show();
        }
    };
})(jq);
/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/
function clearFootmark() {
	var footmark = localStorage.getItem('footmark');
	if (footmark) {
		footmark = JSON.parse(footmark);
		var esc = footmark['29'];
		localStorage.removeItem('footmark');
		if (typeof esc !== 'undefined') {
			footmark = {};
			footmark['29'] = esc;
			localStorage.setItem('footmark', JSON.stringify(footmark));
		}
	}
}


function bzt_getUserId(cookie){
    if(cookie){
        var arr = cookie.split('&');
        var username = "";
        $.each(arr,function(idx,obj){
            var arr1 = obj.split('=');
            if(arr1[0] == "UserID"){
                username = decodeURI(arr1[1]);
            }
        });
    }
    return username;
}

function GetCookieValue(b) {
    var a=document.cookie.match(new RegExp(b+"=([^;]+)"));
    return a==null?"":decodeURI(a[1]);
}
(function($){
    $.m3login = function(){};
    $.m3login.checklogin = function(){
        var cookievalue = GetCookieValue("www58com");
        if(cookievalue!=null&&cookievalue!=''){
            return true;
        }
        return false;
    }
    $.m3login.initlogin = function(){
        $.m3login.islogin = $.m3login.checklogin() ;
        var userid = 1;
        if($.m3login.islogin){
            //$(".login_txt").html("�ѵ�¼")
            var cookievalue = GetCookieValue("www58com");
            userid = bzt_getUserId(cookievalue);
            $(".login_txt").css("display","none");
            $(".login_in").css("display","inline-block");
        }
        //$(".login_in").html(username);
        var rel_url = $(".release").attr("path")+"/"+userid+"/?path="+window.location.href;
        $(".release").attr("href",rel_url);
    }
})(jq);

// cookie�洢
(function($){
    $.cookie = {
        get: function (name, encode) {
            var arg = name + "=";
            var alen = arg.length;
            var clen = document.cookie.length;
            var i = 0;
            var j = 0;
            while (i < clen) {
                j = i + alen;
                if (document.cookie.substring(i, j) == arg)
                    return this.getCookieVal(j, encode);
                i = document.cookie.indexOf(" ", i) + 1;
                if (i == 0)
                    break;
            }
            return null;
        },
        //ȡcookie���µ�ĳ������ֵ
        getname:function(cookie_name,name){
            var cookie_val = this.get(cookie_name);
            var regex = new RegExp("[?&]" + encodeURIComponent(name) + "\\=([^&#]+)");
            var value = (cookie_val.match(regex)||["",""])[1];
            return decodeURIComponent(value);
        },
        set: function (name, value, expires, path, domain, secure) {
            var argv = arguments;
            var argc = arguments.length;
            //        var expires = (argc > 2) ? argv[2] : null;
            var now = new Date();
            var expires = (argc > 2) ? argv[2] : new Date(now.getFullYear(), now.getMonth() + 1, now.getUTCDate());
            var path = (argc > 3) ? argv[3] : '/';
            var domain = (argc > 4) ? argv[4] : '..com';
            var secure = (argc > 5) ? argv[5] : false;
            document.cookie = name + "=" + escape(value) + ((expires == null) ? "" : ("; expires=" + expires.toGMTString())) + ((path == null) ? "" : ("; path=" + path)) + ((domain == null) ? "" : ("; domain=" + domain)) + ((secure == true) ? "; secure" : "");
        },
        remove: function (name) {
            if (this.get(name)) this.set(name, "", new Date(1970, 1, 1));
        },

        getCookieVal : function(offset, encode){
            var endstr = document.cookie.indexOf(";", offset);
            if (endstr == -1) {
                endstr = document.cookie.length;
            }
            if (encode == false) return document.cookie.substring(offset, endstr);
            else return unescape(document.cookie.substring(offset, endstr));
        }
    };
})(jq);

//��������
(function($){
    $.my=function(){}
    //���������¼
    $.my.addHistory=function(){
        var infoid = ____json4fe.infoid;
        if(typeof infoid=="undefined"){
            return;
        }
        var addurl = "http://m."+_rootDomainNoProtocol+"/history/save/"+infoid+"?callback=?";
        $.ajax({
            type:"JSONP",
            url:addurl,
            success:function(data){
                if(data.state=="true"){
                    console.log("��������ʷ��¼");
                }
            },
            timeout:30000,
            error:function(){
                console.log("�����쳣.");
            }
        });
    }
    //��װ��post����
    $.my.post_data=function(url,data,succall){
        var opts={
            type:"POST",
            url:url,
            data:data,
            success:succall,
            error:function(){
                alertShow("�����쳣,���Ժ����ԡ�");
                setTimeout(function(){
                    cancel_but(); //���ص�����
                },3000);
            }
        }
        $.ajax(opts);
    }
    //ɾ���ѷ�����Ϣ
    $.my.delPubInfo=function(){
        $(".del").bind("click",function(){
            var _this=$(this);
            alertShow("��ȷ��ɾ����Ϣ��?",2,"ȷ��","ȡ��",submit_del,cancel_but);
            function submit_del(){
                alertShow("ɾ����...");
                var key = _this.parent().parent().attr("key");
                var url = "http://m."+_rootDomainNoProtocol+"/info/delete/?";
                $.my.post_data(url,{"infoId":key},function(status){
                    if(status==1){
                        _this.parent().parent().parent().addClass("disabled");
                        _this.parent().parent().find(".status").text("��ɾ��");
                        _this.parent().parent().attr("href","javascript:;");
                        _this.hide();
                    }
                    cancel_but();//���ص�����
                });
            }
            return false;
        });
    }
    //����ղؼ�
    $.my.delFavorite=function(){
        $(".btn_clear").bind("click",function(){
            alertShow("��ȷ�����ȫ����Ϣ��?",2,"ȷ��","ȡ��",submit_del,cancel_but);
            function submit_del(){
                alertShow("�������ȫ����Ϣ...");
                var url = "http://m."+_rootDomainNoProtocol+"/favoriteclear";
                $.my.post_data(url,"",function(status){
                    if(status==1){
                        $("#userFav").html("<li class=\"no_info\"\">����û���ղ���ϢŶ~</li>");
                        $(".u_paging").hide();
                        body_init();//����ҳ��߶�
                    }
                    cancel_but();//���ص�����
                });
            }
        });
    }
    //��������¼
    $.my.delHistory=function(){
        $(".btn_clearhistory").bind("click",function(){
            alertShow("��ȷ����������¼��?",2,"ȷ��","ȡ��",submit_del,cancel_but);
            function submit_del(){
                alertShow("�������ȫ����Ϣ...");
                var url = "http://m."+_rootDomainNoProtocol+"/history/delete?callback=?";
                $.my.post_data(url,"",function(data){
                    if(data.state=="true"){
                        $("#userHistory").html("<li class=\"no_info\"\">����û�������ϢŶ~</li>");
                        $(".btn_clearhistory").hide();
                        body_init();//����ҳ��߶�
                    }
                    cancel_but();//���ص�����
                });
            }
        });
    }
})(jq);


//alertShow(��ʾ���֣���ť��������ť����1����ť����2����ť1��������ť2����)
function alertShow(meg, but_num, but_left, but_right, left_fn, right_fn) {
    if(!$("#alert_bg").length){
        var alertHtml = "<div id='alert_bg' style=\" width: 100%; position: absolute; top:0px; left: 0px; z-index: 1000; background: rgba(0, 0, 0, 0.1)\"></div>" +
            "<div id=\"alert_box\">" +
            "<div id=\"show_mes\">��Ϣ</div>" +
            "<div id=\"but_div\">" +
            //"<div id=\"but01\" onclick=\"mes(1)\">��ť1</div>" +
            //"<div id=\"but02\" onclick=\"mes(2)\">��ť2</div>" +
            "</div></div>";
        $("body").append(alertHtml);
        var body_height = $(".body_div").css("height");
        $("#alert_bg").css("height", body_height);
    }else{
        $("#but_div").empty();
    }
    $("#show_mes").text(meg);
    if (but_num == "1") {
        $("#but_div").show();
        var lebut = "<div id=\"but01\">" + but_left + "</div>";
        $("#but_div").append(lebut);
        $("#but01").css("width","100%");
        $("#but01").bind("click", function () {
            left_fn();
        });
    }
    if (but_num == "2") {
        $("#but_div").show();
        var ttbut = "<div id=\"but01\">" + but_left + "</div><div id=\"but02\">" + but_right + "</div>";
        $("#but_div").append(ttbut);
        $("#but01").bind("click", function () {
            left_fn();
        });
        $("#but02").bind("click", function () {
            right_fn();
        });
    }
    if(typeof but_num=="undefined"){
        $("#but_div").hide();
    }
    $("#alert_bg").show();
    $("#alert_box").show();
    var y= parseInt($("#alert_box").get().clientHeight)/2;
    $("#alert_box").css("margin-top",-y+"px");

    $("#but_div > div").bind("touchstart",function(){
        $(this).addClass("but_hover");
    });
    $("#but_div > div").bind("touchmove",function(){
        $(this).removeClass("but_hover");
    });
    $("#but_div > div").bind("touchend",function(){
        $(this).removeClass("but_hover");
    });
    $("#alert_bg").bind("touchmove",function(e){
        e.preventDefault();
    });
    $("#alert_box").bind("touchmove",function(e){
        e.preventDefault();
    });
}

function exit_58(){
    window.location.href = "/logout/";
}

function cancel_but() {
    $("#alert_bg").hide();
    $("#alert_box").hide();
}
