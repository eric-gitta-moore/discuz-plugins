/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/
var loadJS = function(url,callback){
    var head = document.getElementsByTagName('head');
    if(head&&head.length){
        head = head[0];
    }else{
        head = document.body;
    }
    var script = document.createElement('script');
    script.src = url;
    script.type = "text/javascript";
    head.appendChild(script);
    if(arguments.length == 2){
        //document.addEventListener("DOMContentLoaded", function () {
			//console.log('DOMContentLoaded');
            script.onload = function(){
				callback();
                script.onload=null;
            }
        //});
    }
};

function GetCookieValue(b) {
    var a=document.cookie.match(new RegExp(b+"=([^;]+)"));
    return a==null?"":decodeURI(a[1]);
}

(function ($) {
    $.m3login = function () {
    };
    $.m3login.checklogin = function () {
        var cookievalue = GetCookieValue("www58com");
        if (cookievalue != null && cookievalue != '') {
            return true;
        }
        return false;
    }
    $.m3login.initlogin = function () {
        $.m3login.islogin = $.m3login.checklogin();
        var userid = 1;
        if ($.m3login.islogin) {
            //$(".login_txt").html("�ѵ�¼")
            var cookievalue = GetCookieValue("www58com");
            userid = bzt_getUserId(cookievalue);
            $(".login_txt").css("display", "none");
            $(".login_in").css("display", "inline-block");
        }
        //$(".login_in").html(username);
        var rel_url = $(".release").attr("path") + "/" + userid + "/?path=" + window.location.href;
        $(".release").attr("href", rel_url);
    }

    // cookie�洢
    $.cookie = {
        //ȡcookie��
        get:function (name, encode) {
            var arg = name + "=";
            var alen = arg.length;
            var clen = document.cookie.length;
            var i = 0;
            var j = 0;
            while (i < clen) {
                j = i + alen;
                if (document.cookie.substring(i, j) == arg)
                    return this.getCookieVal(j, encode);
                i = document.cookie.indexOf(" ", i) + 1;
                if (i == 0)
                    break;
            }
            return null;
        },
        //ȡcookie���µ�ĳ������ֵ
        getname:function(cookie_name,name){
            var cookie_val = this.get(cookie_name);
            var regex = new RegExp("[?&]" + encodeURIComponent(name) + "\\=([^&#]+)");
            var value = (cookie_val.match(regex)||["",""])[1];
            return decodeURIComponent(value);
        },
        set:function (name, value, expires, path, domain, secure) {
            var argv = arguments;
            var argc = arguments.length;
            //        var expires = (argc > 2) ? argv[2] : null;
            var now = new Date();
            var expires = (argc > 2) ? argv[2] : new Date(now.getFullYear(), now.getMonth() + 1, now.getUTCDate());
            var path = (argc > 3) ? argv[3] : '/';
            var domain = (argc > 4) ? argv[4] : '';
            var secure = (argc > 5) ? argv[5] : false;
            document.cookie = name + "=" + escape(value) + ((expires == null) ? "" : ("; expires=" + expires.toGMTString())) + ((path == null) ? "" : ("; path=" + path)) + ((domain == null) ? "" : ("; domain=" + domain)) + ((secure == true) ? "; secure" : "");
        },
        remove:function (name) {
            if (this.get(name)) this.set(name, "", new Date(1970, 1, 1));
        },

        getCookieVal:function (offset, encode) {
            var endstr = document.cookie.indexOf(";", offset);
            if (endstr == -1) {
                endstr = document.cookie.length;
            }
            if (encode == false) return document.cookie.substring(offset, endstr);
            else return unescape(document.cookie.substring(offset, endstr));
        }
    };
})(jq);



















