/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/



$(function(){
    //���ఴť
    if($("#selist_more").length){
        $("#selist_more").bind("click",function(){
            var div_height = Math.ceil($("#selist_div a").length / 2) * 43+"px";
            var selist_div_height = $("#selist_div").css("height");
            if(selist_div_height == div_height){
                $("#selist_div").css("height","129px");
                $("#moretxt").html("����&nbsp;");
                $(".arrow_more").css("-webkit-transform","rotate(0deg)");
            }else{
                $("#selist_div").css("height",div_height);
                $("#moretxt").html("����&nbsp;");
                $(".arrow_more").css("-webkit-transform","rotate(180deg)");
            }
        })

    }



    //�б�ҳ��Ŀ��������
    if($(".selist_half a span font div")){
        selist_half_num = $(".selist_half a span font div").length-1;
        $(".selist_half a span font div").each(function(i){
            var str_width =  parseInt($(this).css("width"));
            var str_nums = parseInt(str_width/14);  //һ����ʾ��������
            var old_str = $(this).text();
            var ghr = old_str.lastIndexOf(")");
            var ghl = old_str.lastIndexOf("(");
            var num_str = old_str.substr(ghl,ghr); //ȡ��ǰ������
            var num_strs = Math.ceil((ghr-ghl+1)/2);    // ���������
            var show_num  = str_nums - num_strs;   //ǰ��������������
            var old_show = old_str.substr(0,ghl);   //��ǰ������
            var old_show_le = old_show.length;      //��ǰ���ָ���
            if(old_show_le > show_num ){
                var wzi = old_show.substr(0,show_num-1)+"��";
                $(this).text(wzi+num_str);
            }
            if(selist_half_num == i){
                $(".selist_div").css("height","auto");
            }
        });
    }

    //��Ļ��תʱ�����б�ҳ���� and android��֧��orientationchange �Ĵ���
    window.addEventListener("orientationchange",function(){
        infoListIconStyle();
    });
    if(jq.os.android){
        window.addEventListener("resize",function(){
            infoListIconStyle();
        });
    }
    infoListIconStyle();

    //�ж�js�Ƿ񻺴���ִ�ж�Ӧģ��Ĺ���
    if(typeof filter=="function"){
		/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/
    }
    if(typeof TipWindow=="function"){
        win = new TipWindow("search_ajax", "keyWords1", "", "4", "������ؼ���", true, false, "������ؼ���");
    }
    if(typeof basefun=="function"){
        basefun();
    }

});

//�б�ҳ����ͼƬ����
var infoListIconStyle=function(){
    if(!$(".infolst").length){return}
    var currUl = $(".infolst");
    var currUlIndex = currUl.length-1;
    $(currUl.get(currUlIndex)).find("li").each(function(){
        var tagi = $(this).find("dt i");
        if(tagi.length==1){
            $(this).find("strong").css("padding-right","40px");
        }else if(tagi.length==2){
            $(this).find("strong").css("padding-right","55px");
            $(this).find(".biz").css("right","20px");
            $(this).find(".qiandai").css("right","20px");
        }
    });
};

//�첽����js��ִ�ж�Ӧģ�鹦��
loadJS(_jsRootPath+"/m.base.js",function(){
    basefun();
});

loadJS(_jsRootPath+"/m.filter.js",function(){
    if($(".filter").length){
        var myfilter = new filter(filter_data);
        myfilter.drawList();
    }
});
var footmark2 = {
	add: function () {
		var _this = this;
		var json4fe = ____json4fe;
		var catentry = json4fe.catentry;
		var dispid = (Object.prototype.toString.call(catentry) === '[object Array]') ? catentry[1].dispid : catentry.dispid;
		//var dispid = (Object.prototype.toString.call(catentry) === '[object Array]') ? catentry[catentry.length - 1].dispid : catentry.dispid;
		var history = localStorage.getItem('footmark') || {};
		if (!history) {
			return;
		} else {
			if (typeof history === 'string') {
				history = JSON.parse(history);
			}
		}
		if (typeof history[dispid] === 'undefined') {
			return;
		} else {
			if (Object.prototype.toString.call(history) === '[object Array]') {
				localStorage.removeItem('footmark');
				return;
			} else {
				history = history[dispid];
			}
		}
		if (!history) {
			return;
		}
		var filter = $('.filter');
		var html = '<dl class="filter_item" type="footmark"><dt>��ʷ</dt><dd>';
		for (var i = history.length - 1, n = 0; i >= 0 && n !== 3; i--) {
			if (typeof history[i].text !== 'undefined') {
				html += '<a href="' + history[i].url + '">' + history[i].text + '</a>';
				n++;
			}
		}
		html += '<div class="ico_more" style="top: -6px;"></div></dd></dl>';
		var html = $(html);
		filter[0].insertBefore(html[0], filter.children('dl').get(0));

		// ��������ʷ֮��Ҫ���������ĸ߶ȼ�45���أ��������ɸѡ�����İ�ť���޷���ʾ�ˡ�
		console.log(filter.css('height'));
		filter.css('height', (+filter.css('height').replace('px', '') + 45) + 'px');

		var ico_more = html.find('.ico_more');
		if (ico_more.length > 0) {
			ico_more.bind('click', function () {
				var $this = $(this);
				if (!$this.hasClass('up')) {
					$this.addClass('up');
					var height = 28 * $this.parent().children('a').length;
					$this.parent().css('height', height + 'px');
					if (height > 28) {
						filter.css('height', (+filter.css('height').replace('px', '') + (height - 28)) + 'px');
					}
				} else {
					$this.removeClass('up');
					$this.parent().css('height', '28px');
					var height = 28 * $this.parent().children('a').length;
					filter.css('height', (+filter.css('height').replace('px', '') - (height - 28)) + 'px');
				}
			});
		}
	},

	compareTwoWords: function (wordA, wordB) {
		if (!wordA || !wordB) {
			return false;
		}
		var arrA = wordA.split(' ');
		var arrB = wordB.split(' ');
		var count = 0;
		for (var i = 0, leni = arrA.length; i < leni; ++i) {
			var wA = arrA[i];
			for (var j = 0, lenj = arrB.length; j < lenj; ++j) {
				var wB = arrB[j];
				if (wA === wB) {
					count++;
					continue;
				}
			}
		}
		var maxlength = arrA.length > arrB.length ? arrA.length : arrB.length;
		if (maxlength - count > 1) {
			return false;
		} else {
			return true;
		}
	}	
};

// iOS�û�����б�ҳ����ͼƬ��ʱ�򣬵�ȡ�ͻ��ˡ�
$(function () {
	var logo_a = $('.banner_down a');
	if (__device === 'iphone') {
		logo_a.bind('click', function(e) {
			e.preventDefault();
			if (e.layerX <= 32 && e.layerY <= 32) {
				$('.banner_down').hide();
				return;
			}
			if (e.layerY > 20 && e.layerY < 55 && e.layerX > 265 && e.layerX < 315) {
				googleAnalytices('/clicklist/checkiosdownload/', document.referer);
				window.location = 'wbmain://';
				setTimeout(function() {
					googleAnalytices('/clicklist/isodownload/', document.referer);
					window.location = 'http://itunes.apple.com/cn/app/id404612543?mt=8';
				}, 300);
			}
		});
	} else {
		logo_a.bind('click', function(e) {
			var width = e.srcElement.offsetWidth,
				height = e.srcElement.offsetHeight,
				layerX = e.layerX,
				layerY = e.layerY;
			var x1 = Math.floor(412 * width / 640);
			var x2 = Math.floor(574 * height / 100);
			var y1 = Math.floor(22 * height / 100);
			var y2 = Math.ceil(78 * height / 100);
			if (layerY > y1 && layerY < y2 && layerX > x1 && layerX < x2) {
				googleAnalytices('/clicklist/androiddownload/', document.referer);
			} else {
				e.preventDefault();
			}
		});
	}
});

//����ȫ�ֱ���
var win;
loadJS( _jsRootPath+"/m3.search.js",function(){
    win = new TipWindow("search_ajax", "keyWords1", "", "4", "������ؼ���", true, false, "������ؼ���");
});

loadJS( _jsRootPath+"/m.googleAnalytices.js");

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/
$(function () {
	if ($.cookie.get('mtg')) {
		$('.banner_down').hide();
	}
});



function googleStatistics(para, referer) {
	if (typeof googleAnalytices === 'function') {
		googleAnalytices(para, referer);
	}
}

function scrollpic() {
	var slideX = (function() {
		var _slide = function(div_id, panel_id, duration) {
			var	_divId, _div, _ul, _panel, _eleX, _li_margin, _ul_width, _ul_margin,
			_startx = _index = 0, _duration = duration,autoScroll = true,
			_bindEvents = function() {
				_ul.bind("touchstart", _touchstart, false);
				_ul.bind("touchmove", _touchmove, false);
				_ul.bind("touchend", _touchend, false);
			},
			_click = function(e) {
				var img = e.target;
			},
			_move = function(e, sx, ex) {
				var max = _ul.children().length;
				if (ex > sx) {
					if (_index > 0) {
						_index --;
					}
				} else if (ex < sx){
					if (_index < max-1) {
						_index ++;
					}
				} else {
					_click(e);
					return;
				}
				var movex = (_index==0)?_ul_margin:-(_index * (_ul_width+_li_margin*2))+_ul_margin;
				_ul.css("-webkit-transition-duration", _duration);
				_ul.css("-webkit-transform", "translate3d("+movex+"px,0,0)");
				_panel.children("span").removeClass("curr").get(_index).className = "curr";
				
			};
			_touchstart = function(e) {
				autoScroll = false;
				e.stopPropagation();
				var finger0 = e.targetTouches[0];
				_startx = finger0.pageX;
				var transform = $(this).css("-webkit-transform");
				var translateX = parseInt(transform.split(/[(]|[,]|[)]/)[1]);
				_eleX = translateX || _ul_margin;
			},
			_touchmove = function(e) {
				e.preventDefault();
				e.stopPropagation();
				var finger0 = e.targetTouches[0];
				var moveX = finger0.pageX - _startx + _eleX;
				_ul.css({"-webkit-transition-duration": "0", "-webkit-transform": "translate3d("+moveX+"px, 0, 0)"});
			};
			_touchend = function(e) {
				var finger0 = e.changedTouches[0];
				_move(e, _startx, finger0.pageX);
				autoScroll = true;
				if (_index > 0) {
					googleStatistics( "/clicklocal/finger/banner1/", document.referer );
				} else {
					googleStatistics( "/clicklocal/finger/banner2/", document.referer );
				}
			};
			
			setInterval(function(){
				if (!autoScroll) {
					return;
				}
				if (_index > 0) {
					_index --;
					 $("#datu").css({"-webkit-transform" : "translate3d(0px, 0, 0)", "-webkit-transition": "300ms","transition":"300ms" });
					$(".panel_num").children("span").removeClass("curr").get(_index).className = "curr";
				} else {
					_index ++;
					var x = -1 * document.body.offsetWidth;
					 $("#datu").css({"-webkit-transform" : "translate3d(" + x + "px, 0, 0)", "-webkit-transition": "300ms","transition":"300ms" });
					$(".panel_num").children("span").removeClass("curr").get(_index).className = "curr";
				}
				
			},4000);
			

			this.init = function() {
				_divId = div_id || "";
				if ("" != _divId) {
					_div = $("#"+_divId);
					_ul = _div.children("ul");
					var div_width = document.body.clientWidth;//parseInt(_div.css("width").replace("px", ""));
					var li1 = $(_ul.children("li").get(0));
					_li_margin = li1.css('margin-left') ? parseInt(li1.css("margin-left").replace("px", "")) : 0;
					_ul_width = parseInt(li1.css("width").replace("px", ""));
					_ul_margin = (div_width - _ul_width) / 2 - _li_margin;
					_ul.css("-webkit-transform", "translate3d("+_ul_margin+"px, 0, 0)");
					_panel = (/^\./.test(panel_id)) ? $(panel_id) : $(("#"+panel_id).replace(/##/, "#"));
					var spans = '';
					for (var i=0, len=_ul.children("li").length; i<len; ++i) {
						spans += (0==i)?'<span class="curr"></span>':'<span></span>';
					}
					_panel.html(spans);
					_bindEvents();
				}
			};
		};
		_slide.bind = function(div_id, panel_id, duration) {
			var obj = new m58.slideX(div_id, panel_id, duration);
			obj.init();
		};
		return _slide;
	}) ();
	window.m58 = window.m58 || {};
	window.m58.slideX = slideX;	
		//��
		m58.slideX.bind("pics", ".panel_num", "300ms");
}





//�����ĵ���¼�
$(function(){
    $($('.relation2').get(0)).css({'borderTop':'1px solid #cdcdcd'});
	$('.relation2 .title').bind('click',function(){
		$(this).siblings('.list').toggle();
		if($(this).hasClass('show')){
			$(this).removeClass('show');
			$(this).parent().css({'borderBottom':'1px solid #E0E1E2'});
		}else{
			$(this).addClass('show');
			$(this).parent().css({'borderBottom':'1px solid #cdcdcd'});
		}
	});
});
