<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$lang = array_merge($lang, $scriptlang['dzapp_sort']);
loadcache(array('dzapp_sort_category', 'dzapp_sort_module', 'plugin'));
$category = $_G['cache']['dzapp_sort_category'];

echo <<<EOT
<style type="text/css">
.forthboard, .lastforthboard { padding-left: 165px; background: url(source/plugin/dzapp_sort/static/bg_repno.gif) no-repeat; }
.forthboard { background-position: -130px -550px; }
.lastforthboard { background-position: -130px -600px; }
</style>
EOT;

if(empty($_GET['ac'])) {

	if(!submitcheck('listsubmit')) {

		showformheader('plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category');
		showtableheader();
		showsubtitle(array('displayorder', 'cate', 'module', 'news_num', 'operation'));
		foreach ($category as $key=>$value) {
			if($value['level'] == 0) {
				echo showcategoryrow($key, 0, '');
			}
		}
		echo '<tr><td class="td25">&nbsp;</td><td colspan="3"><div><a class="addtr" onclick="addrow(this, 0, 0)" href="###">'.cplang('add_cate').'</a></div></td></tr>';
		showsubmit('listsubmit');
		showtablefooter();
		showformfooter();
		echo '
<script type="text/JavaScript">
var rowtypedata = [
	[[1,\'<input type="text" class="txt" name="neworder[{1}][]" value="0" />\', \'td25\'], [3, \'<div class="parentboard"><input type="text" class="txt" value="'.cplang('add_cate').'" name="newname[{1}][]"/></div>\']],
	[[1,\'<input type="text" class="txt" name="neworder[{1}][]" value="0" />\', \'td25\'], [3, \'<div class="board"><input type="text" class="txt" value="'.cplang('add_subclass').'" name="newname[{1}][]"/></div>\']],
	[[1,\'<input type="text" class="txt" name="neworder[{1}][]" value="0" />\', \'td25\'], [3, \'<div class="childboard"><input type="text" class="txt" value="'.cplang('add_third_cate').'" name="newname[{1}][]"/></div>\']],
	[[1,\'<input type="text" class="txt" name="neworder[{1}][]" value="0" />\', \'td25\'], [3, \'<div class="forthboard"><input type="text" class="txt" value="'.cplang('add_fouth_cate').'" name="newname[{1}][]"/></div>\']],
];
</script>';

	} else {


		if(is_array($_GET['name'])) {
			foreach($_GET['name'] as $key => $value) {
				$data = array(
					'catname' => $value,
					'displayorder' => $_GET['order'][$key],
					'moduleid' => $_GET['moduleid'][$key],
				);
				DB::update('dzapp_sort_category', $data, array('catid' => $key));
			}
		}

		if($_GET['newname']) {
			foreach($_GET['newname'] as $upid=>$names) {
				foreach($names as $nameid=>$name) {
					$data = array(
						'catname' => $name,
						'upid' => $upid,
						'displayorder' => $_GET['neworder'][$upid][$nameid],
					);
					DB::insert('dzapp_sort_category', $data);
				}
			}
		}

		updatecache('dzapp_sort_category');
		cpmsg('cate_update_succeed', 'action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category', 'succeed');
	}

} elseif($_GET['ac'] == 'edit') {

	$category = DB::fetch_first("SELECT * FROM ".DB::table('dzapp_sort_category')." WHERE catid='{$_GET['catid']}'");
	if(!$category) {
		cpmsg('selected_module_not_existence', '', 'error');
	}

	$sortkeys = C::t('common_setting')->fetch('sortkeys', true);

	if(!submitcheck('editsubmit')) {

		showformheader('plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category&ac=edit&catid='.$_GET['catid'], 'enctype');
		showtableheader();
		showtitle('base_info');
		showsetting('catname', 'catname', $category['catname'], 'text');
		showsetting('icon', 'icon', $category['icon'], 'filetext');
		showsetting('moduleid', array('moduleid', module_select()), $category['moduleid'], 'select');
		showsetting('keys', 'keys', $sortkeys[$_GET['catid']], 'text');
		showsetting('listtpl', array('listtpl', array(array('sort_list', $lang['sort_list']), array('list_trade', $lang['list_trade']), array('list_house', $lang['list_house']), array('list_job', $lang['list_job']), array('list_life', $lang['list_life']), array('list_love', $lang['list_love']), array('list_pet',  $lang['list_pet']), array('list_friend', $lang['list_friend']))), $category['listtpl'], 'select');
		showsetting('showpic', 'showpic', $category['showpic'], 'radio');
		showsetting('seotitle', 'seotitle', $category['seotitle'], 'text');
		showsetting('keyword', 'keyword', $category['keyword'], 'text');
		showsetting('description', 'description', $category['description'], 'textarea');
		showsetting('rule', 'rule', $category['rule'], 'text');
		showsetting('mobile_style', 'mobile_style', $category['mobile_style'], 'text');
		showsetting('weixin', 'weixin', $category['weixin'], 'text');
		showsetting('list_url', 'list_url', $category['list_url'], 'text');
		showsetting('post_url', 'post_url', $category['post_url'], 'text');
		showsubmit('editsubmit');
		showtablefooter();
		showformfooter();

	} else {

		if(!$_GET['catname']) {
			cpmsg('write_all_required', '', 'error');
		}

		if($_GET['weixin'] && $_GET['weixin'] != $category['weixin'] && $_G['cache']['plugin']['dzapp_wechat']) {
			if(C::t('#dzapp_wechat#dzapp_wechat_multikeyword')->fetch_all(explode(',', $_GET['weixin']))) {
				cpmsg('app_keyword_invalid', '', 'error');
			}

			C::t('#dzapp_wechat#dzapp_wechat_keyword')->delete_by_keyword($category['weixin']);
			C::t('#dzapp_wechat#dzapp_wechat_multikeyword')->delete($category['weixin']);
			$id = C::t('#dzapp_wechat#dzapp_wechat_keyword')->insert(
				$data = array(
					'func' => 'dzapp_sort/app/category',
					'keyword' => $_GET['weixin'],
					'param' => serialize(array('catid' => $_GET['catid'])),
			), true);
			C::t('#dzapp_wechat#dzapp_wechat_multikeyword')->insert(array('keyword' => $_GET['weixin'], 'id' => $id));
		}

		require_once libfile('function/home');
		if($pic = pic_upload($_FILES['icon'], 'portal')) $_GET['icon'] = $pic['pic'];
		if($pic && $category['icon']) pic_delete($category['icon'], 'portal');

		$data = array(
			'catname' => $_GET['catname'],
			'icon' => $_GET['icon'],
			'moduleid' => $_GET['moduleid'],
			'listtpl' => $_GET['listtpl'],
			'showpic' => $_GET['showpic'],
			'seotitle' => $_GET['seotitle'],
			'keyword' => $_GET['keyword'],
			'description' => $_GET['description'],
			'rule' => $_GET['rule'],
			'mobile_style' => $_GET['mobile_style'],
			'weixin' => $_GET['weixin'],
			'list_url' => $_GET['list_url'],
			'post_url' => $_GET['post_url'],
		);
		DB::update('dzapp_sort_category', $data, "catid='{$_GET['catid']}'");

		if($sortkeys[$_GET['catid']] != $_GET['keys'] && preg_match('/^\w*$/', $_GET['keys']) && !preg_match('/^\d+$/', $_GET['keys'])) {
			$sortkeys[$_GET['catid']] = $_GET['keys'];
			C::t('common_setting')->update('sortkeys', $sortkeys);
		}

		updatecache('dzapp_sort_category');
		cpmsg('succeed_edit_cate', 'action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category', 'succeed');

	}

} elseif($_GET['ac'] == 'delete') {

	$catid = intval($_GET['catid']);
	if($category[$catid]['children']) {
		cpmsg('stop_del_subclass', '', 'error');
	}
	DB::query("DELETE FROM ".DB::table('dzapp_sort_category')." WHERE catid='$catid'");

	updatecache('dzapp_sort_category');
	cpmsg('del_cate_succeed', 'action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category', 'succeed');
}

function showcategoryrow($key, $level = 0, $last = '') {
	global $_G;

	$value = $_G['cache']['dzapp_sort_category'][$key];
	$return = '';

	$moduleselect = '<select name="moduleid['.$key.']">';
	$moduleselect .= '<option value="0"></option>';
	foreach($_G['cache']['dzapp_sort_module'] as $moduleid => $module) {
		$moduleselect .= '<option value="'.$moduleid.'"'.($moduleid == $value['moduleid'] ? ' selected="selected"' : '').'>'.$module['name'].'</option>';
	}
	$moduleselect .= '</select>';

	if($level == 3) {
		$class = $last ? 'lastforthboard' : 'forthboard';
		$return = '<tr class="hover"><td class="td25"><input type="text" class="txt" name="order['.$value['catid'].']" value="'.$value['displayorder'].'" /></td><td><div class="'.$class.'">'.
		'<input type="text" name="name['.$value['catid'].']" value="'.$value['catname'].'" class="txt" />'.
		'</div>'.
		'</td><td></td><td></td><td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category&ac=edit&catid='.$value['catid'].'">'.cplang('edit').'</a> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category&ac=delete&catid='.$value['catid'].'">'.cplang('delete').'</a></td></tr>';
	} elseif($level == 2) {
		$class = $last ? 'lastchildboard' : 'childboard';
		$return = '<tr class="hover"><td class="td25"><input type="text" class="txt" name="order['.$value['catid'].']" value="'.$value['displayorder'].'" /></td><td><div class="'.$class.'">'.
		'<input type="text" name="name['.$value['catid'].']" value="'.$value['catname'].'" class="txt" />'.
		'<a class="addchildboard" onclick="addrowdirect = 1;addrow(this, 3, '.$value['catid'].')" href="###">'.cplang('add_fouth_cate').'</a></div>'.
		'</div>'.
		'</td><td></td><td></td><td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category&ac=edit&catid='.$value['catid'].'">'.cplang('edit').'</a> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category&ac=delete&catid='.$value['catid'].'">'.cplang('delete').'</a></td></tr>';
		for($i=0,$L=count($value['children']); $i<$L; $i++) {
			$return .= showcategoryrow($value['children'][$i], 3, $i==$L-1);
		}
	} elseif($level == 1) {
		$return = '<tr class="hover"><td class="td25"><input type="text" class="txt" name="order['.$value['catid'].']" value="'.$value['displayorder'].'" /></td><td><div class="board">'.
		'<input type="text" name="name['.$value['catid'].']" value="'.$value['catname'].'" class="txt" />'.
		'<a class="addchildboard" onclick="addrowdirect = 1;addrow(this, 2, '.$value['catid'].')" href="###">'.cplang('add_third_cate').'</a></div>'.
		'</td><td>'.$moduleselect.'</td><td>'.$value['post'].'</td><td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category&ac=edit&catid='.$value['catid'].'">'.cplang('edit').'</a><!--{/if}--> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category&ac=delete&catid='.$value['catid'].'">'.cplang('delete').'</a></td></tr>';
		for($i=0,$L=count($value['children']); $i<$L; $i++) {
			$return .= showcategoryrow($value['children'][$i], 2, $i==$L-1);
		}
	} else {
		$return = '<tr class="hover"><td class="td25"><input type="text" class="txt" name="order['.$value['catid'].']" value="'.$value['displayorder'].'" /></td><td><div class="parentboard">'.
		'<input type="text" name="name['.$value['catid'].']" value="'.$value['catname'].'" class="txt" />'.
		'</div>'.
		'</td><td></td><td></td><td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category&ac=edit&catid='.$value['catid'].'">'.cplang('edit').'</a> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_category&ac=delete&catid='.$value['catid'].'">'.cplang('delete').'</a></td></tr>';
		for($i=0,$L=count($value['children']); $i<$L; $i++) {
			$return .= showcategoryrow($value['children'][$i], 1, '');
		}
		$return .= '<tr><td class="td25"></td><td colspan="3"><div class="lastboard"><a class="addtr" onclick="addrow(this, 1, '.$value['catid'].')" href="###">'.cplang('add_subclass').'</a></div>';
	}
	return $return;
}

function module_select() {
	global $_G;

	loadcache('dzapp_sort_module');
	$select[] = array(0, '');
	foreach($_G['cache']['dzapp_sort_module'] as $module) {
		$select[] = array($module['moduleid'], $module['name']);
	}

	return $select;
}

?>