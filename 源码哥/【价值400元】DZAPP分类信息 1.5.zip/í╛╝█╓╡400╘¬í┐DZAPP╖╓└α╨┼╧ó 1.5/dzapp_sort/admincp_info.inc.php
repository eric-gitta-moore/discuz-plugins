<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$lang = array_merge($lang, $scriptlang['dzapp_sort']);
loadcache('dzapp_sort_category');

if(empty($_GET['ac'])) {

	if(!submitcheck('listsubmit')) {

		showformheader('plugins&operation=config&identifier=dzapp_sort&pmod=admincp_info');
		showtableheader();
		showsubtitle(array('del', 'subject', 'category', 'username', 'realname', 'mobile', 'dateline', ''));
		$perpage = 20;
		$start = ($page - 1) * $perpage;
		$mpurl = ADMINSCRIPT."?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_info";
		$param = array();
		$count = C::t('#dzapp_sort#dzapp_sort_info')->count_by_search($param);
		if($count) {
			$query = C::t('#dzapp_sort#dzapp_sort_info')->fetch_all_by_search($param, $start, $perpage);
			foreach($query as $value) {
				$status = '';
				if($value['displayorder'] == '-1') {
					$status = cplang('check');
				} elseif($value['displayorder'] == '-2') {
					$status = cplang('modify');
				} elseif($value['displayorder'] == '-3') {
					$status = cplang('deleted');
				} elseif($value['displayorder'] == '1') {
					$status = cplang('stick');
				}
				showtablerow('', array('class="td25"'), array(
					'<input type="checkbox" class="checkbox" name="ids[]" value="'.$value['infoid'].'" />',
					'<a href="plugin.php?id=dzapp_sort&mod=view&infoid='.$value['infoid'].'" target="_blank">'.$value['subject'].'</a> '.$status,
					$_G['cache']['dzapp_sort_category'][$value['catid']]['catname'],
					'<a href="home.php?mod=space&uid='.$value['uid'].'" target="_blank">'.$value['username'].'</a>',
					$value['realname'],
					$value['mobile'],
					dgmdate($value['dateline']),
					'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_info&ac=edit&id='.$value['infoid'].'">'.cplang('edit').'</a>'
				));
			}
			$multipage = multi($count, $perpage, $page, $mpurl);
		}
		showsubmit('listsubmit', 'submit', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" /><label for="chkall">'.cplang('select_all').'</label><input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.cplang('delete').'</label><input type="radio" name="optype" id="moderate" value="moderate" class="radio" /><label for="moderate" class="vmiddle">'.cplang('moderate').'</label><input type="radio" name="optype" id="stick" value="stick" class="radio" /><label for="stick" class="vmiddle">'.cplang('stick').'</label>', '', $multipage);
		showtablefooter();
		showformfooter();

	} else {


		if(is_array($_GET['ids'])) {
			if($_GET['optype'] == 'delete') {
				C::t('#dzapp_sort#dzapp_sort_info')->delete($_GET['ids']);
			} elseif($_GET['optype'] == 'moderate') {
				C::t('#dzapp_sort#dzapp_sort_info')->update($_GET['ids'], array('displayorder' => 0));
			} elseif($_GET['optype'] == 'stick') {
				C::t('#dzapp_sort#dzapp_sort_info')->update($_GET['ids'], array('displayorder' => 1));
			}
		}

		if(is_array($_GET['delete'])) {
			C::t('#dzapp_sort#dzapp_sort_info')->delete($_GET['delete']);
		}

		cpmsg('info_update_succeed', 'action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_info', 'succeed');
	}

} elseif($_GET['ac'] == 'edit') {

	$info = C::t('#dzapp_sort#dzapp_sort_info')->fetch($_GET['id']);
	if(empty($info)) {
		cpmsg('info_nonexistence', '', 'error');
	}
	
	if(!submitcheck('editsubmit')) {

		showformheader('plugins&operation=config&identifier=dzapp_sort&pmod=admincp_info&ac=edit&id='.$info['infoid']);
		showtableheader();
		showsetting('subject', 'subject', $info['subject'], 'text');
		showsetting('message', 'message', $info['message'], 'textarea');
		showsetting('realname', 'realname', $info['realname'], 'text');
		showsetting('mobile', 'mobile', $info['mobile'], 'text');
		showsetting('qq', 'qq', $info['qq'], 'text');
		showsetting('status', array('displayorder', array(array(0, cplang('normal')), array(1, cplang('stick')), array(-1, cplang('check')), array(-2, cplang('modify')), array(-3, cplang('deleted')))), $info['displayorder'], 'mradio');
		showsubmit('editsubmit', 'submit'); 
		showtablefooter();
		showformfooter();

	} else {

		if(!$_GET['subject'] || !$_GET['realname'] || !$_GET['mobile']) {
			cpmsg('info_invalid', '', 'error');
		}
		
		$data = array(
			'subject' => $_GET['subject'],
			'message' => $_GET['message'],
			'realname' => $_GET['realname'],
			'mobile' => $_GET['mobile'],
			'qq' => $_GET['qq'],
			'displayorder' => $_GET['displayorder'],
		);
		C::t('#dzapp_sort#dzapp_sort_info')->update($info['infoid'], $data);

		cpmsg('info_edit_succeed', 'action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_info', 'succeed');
	}
}

?>