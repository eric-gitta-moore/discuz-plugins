<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

require_once libfile('function/home');
loadcache(array('dzapp_sort_category', 'dzapp_sort_district', 'dzapp_sort_module'));
$var = $_G['cache']['plugin']['dzapp_sort'];

$sort_seo = dunserialize($_G['setting']['sort_seo']);
$nobbname = true;
$domain = str_replace('www.', '', $_SERVER['HTTP_HOST']);

$modarray = array('index', 'list', 'view', 'post', 'search', 'attachment', 'swfupload', 'favorite', 'memcp', 'misc', 'shortcut');
$mod = !in_array($_G['mod'], $modarray) ? 'index' : $_G['mod'];

if(!$_G['mobile']) {
	hookscriptoutput();
}

require DISCUZ_ROOT.'./source/plugin/dzapp_sort/module/sort_'.$mod.'.php';

?>