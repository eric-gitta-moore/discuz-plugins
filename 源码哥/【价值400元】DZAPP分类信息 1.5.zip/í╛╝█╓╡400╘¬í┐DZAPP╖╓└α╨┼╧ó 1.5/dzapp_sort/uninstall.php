<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_dzapp_sort_attachment`;
DROP TABLE IF EXISTS `pre_dzapp_sort_category`;
DROP TABLE IF EXISTS `pre_dzapp_sort_district`;
DROP TABLE IF EXISTS `pre_dzapp_sort_favorite`;
DROP TABLE IF EXISTS `pre_dzapp_sort_info`;
DROP TABLE IF EXISTS `pre_dzapp_sort_mod`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_1`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_10`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_11`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_12`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_13`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_14`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_15`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_16`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_17`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_2`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_3`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_4`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_5`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_6`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_7`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_8`;
DROP TABLE IF EXISTS `pre_dzapp_sort_module_9`;
DROP TABLE IF EXISTS `pre_dzapp_sort_option`;
EOF;

runquery($sql);

if(file_exists(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')) {
	require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
	WeChatHook::delAPIHook('dzapp_sort');
}

$finish = TRUE;