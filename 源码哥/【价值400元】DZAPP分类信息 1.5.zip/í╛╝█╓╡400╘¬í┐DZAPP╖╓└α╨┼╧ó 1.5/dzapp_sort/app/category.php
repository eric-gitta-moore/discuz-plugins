<?php

$module = array('name' => '', 'keyword' => '', 'statement' => '');

class category {

	function run() {
		global $_G, $param, $wechatdata, $wechatuser;

		loadcache('dzapp_sort_category');
		$cat = $_G['cache']['dzapp_sort_category'][$param['catid']];
		if($cat['children']) {
			$cat_id = $cat['children'];
		}
		$cat_id[] = $param['catid'];

		$result[] = array(
			'title' => $cat['catname'],
			'url' => $_G['siteurl'].'plugin.php?id=dzapp_sort&mod=list&catid='.$param['catid'],
			'picurl' => $_G['siteurl'].'source/plugin/dzapp_sort/static/sort.png',
		);
		$query = C::t('#dzapp_sort#dzapp_sort_info')->fetch_all_by_search(array(array('catid', $cat_id)), 0, 9);
		foreach($query as $value) {
			$row['title'] = $value['subject'];
			$row['url'] = $_G['siteurl'].'plugin.php?id=dzapp_sort&mod=view&infoid='.$value['infoid'];
			$row['picurl'] = $value['pic'] ? $_G['siteurl'].'data/attachment/portal/'.$value['pic'] : $_G['siteurl'].'source/plugin/dzapp_sort/static/nopic_2.gif';
			$row['contents'] = cutstr($value['message'], 100);
			$result[] = $row;
		}
		out($result);
	}
}

?>