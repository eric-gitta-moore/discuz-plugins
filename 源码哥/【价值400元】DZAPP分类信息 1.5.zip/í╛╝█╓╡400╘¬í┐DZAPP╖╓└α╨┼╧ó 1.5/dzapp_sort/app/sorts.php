<?php

$module = array(
	'name' => 'dzapp_sort/app/sorts', 
	'keyword' => lang('plugin/dzapp_sort', 'sort'), 
	'statement' => lang('plugin/dzapp_sort', 'sort_app'),
	'field' => array(
		array('name' => 'title', type => 'text', 'default' => lang('plugin/dzapp_sort','sort')),
		array('name' => 'url', type => 'text', 'default' => 'plugin.php?id=dzapp_sort'),
		array('name' => 'picurl', type => 'filetext', 'default' => 'source/plugin/dzapp_sort/static/sort.png'),
		array('name' => 'description', type => 'textarea', 'default' => lang('plugin/dzapp_sort','sort_app')),
	)
);

class sorts {

	function run() {
		global $_G, $param, $wechatdata, $wechatuser;

		$result[0]['title'] = $param['title'];
		$result[0]['description'] = $param['description'];
		$result[0]['url'] = $_G['siteurl'].$param['url'];
		$result[0]['picurl'] = $_G['siteurl'].$param['picurl'];
		out($result);
	}
}

?>