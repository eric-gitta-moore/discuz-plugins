<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$lang = array_merge($lang, $scriptlang['dzapp_sort']);
loadcache('dzapp_sort_district');

if(empty($_GET['ac'])) {

	if(!submitcheck('listsubmit')) {

		showformheader('plugins&operation=config&identifier=dzapp_sort&pmod=admincp_district');
		showtableheader();
		showsubtitle(array('del', 'displayorder', 'name', ''));
		foreach($_G['cache']['dzapp_sort_district'] as $key => $value) {
			$parent = $value['upid'] ? '' : 'parent';
			if(!$value['upid'] && $lastkey) {
				$upid = $_G['cache']['dzapp_sort_district'][$lastkey]['upid'] ? $_G['cache']['dzapp_sort_district'][$lastkey]['upid'] : $lastkey;
				echo '<tr><td></td><td></td><td colspan="20"><div class="lastboard"><a href="###" onclick="addrow(this, 1, '.$upid.')" class="addtr">'.cplang('add_subdistrict').'</a></div></td></tr>';
			}
			showtablerow('', array('class="td25"', 'class="td25"', ''), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$value['districtid'].'" />',
				'<input type="text" class="txt" name="displayorder['.$value['districtid'].']" value="'.$value['displayorder'].'" />',
				'<div class="'.$parent.'board"><input type="text" class="txt" name="name['.$value['districtid'].']" value="'.$value['name'].'" /></div>',
				'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_district&ac=edit&id='.$key.'" class="act">'.cplang('edit').'</a>'
			));
			$lastkey = $key;
		}
		if($lastkey) {
			$upid = $_G['cache']['dzapp_sort_district'][$lastkey]['upid'] ? $_G['cache']['dzapp_sort_district'][$lastkey]['upid'] : $lastkey;
		}
		if($upid) {
			echo '<tr><td></td><td></td><td colspan="20"><div class="lastboard"><a href="###" onclick="addrow(this, 1, '.$upid.')" class="addtr">'.cplang('add_subdistrict').'</a></div></td></tr>';
		}
		echo '<tr><td></td><td></td><td colspan="20"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.cplang('add_district').'</a></div></td></tr>';
		showsubmit('listsubmit', 'submit', 'del');
		showtablefooter();
		showformfooter();
		echo '<script type="text/javascript">
		var rowtypedata = [
			[[1, \'\', \'td25\'], [1, \'<input type="text" class="txt" name="newdisplayorder[]" />\', \'td25\'], [1, \'<input type="text" class="txt" name="newname[]" />\', \'\'], [1, \'<input type="hidden" name="upid[]" value="0" />\']],
			[[1, \'\', \'td25\'], [1, \'<input type="text" class="txt" name="newdisplayorder[]" />\', \'td25\'], [1, \'<div class="board"><input type="text" class="txt" name="newname[]" /></div>\', \'\'], [1, \'<input type="hidden" name="upid[]" value="{1}" />\']],
		];
		</script>';

	} else {

		if(is_array($_GET['delete'])) {
			C::t('#dzapp_sort#dzapp_sort_district')->delete($_GET['delete']);
		}

		if(is_array($_GET['name'])) {
			foreach($_GET['name'] as $key => $value) {
				C::t('#dzapp_sort#dzapp_sort_district')->update($key, array(
					'displayorder' => $_GET['displayorder'][$key],
					'name' => $_GET['name'][$key],
				));
			}
		}

		if(is_array($_GET['newname'])) {
			foreach($_GET['newname'] as $key => $value) {
				if(empty($value)) continue;
				C::t('#dzapp_sort#dzapp_sort_district')->insert(array(
					'displayorder' => $_GET['newdisplayorder'][$key],
					'name' => $_GET['newname'][$key],
					'upid' => $_GET['upid'][$key],
				));
			}
		}

		update_cache_dzapp_sort_district();
		cpmsg('district_update_succeed', 'action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_district', 'succeed');
	}

} elseif($_GET['ac'] == 'edit') {

	$district = C::t('#dzapp_sort#dzapp_sort_district')->fetch($_GET['id']);
	if(!$district) {
		cpmsg('district_nonexistence', '', 'error');
	}

	if(!submitcheck('editsubmit')) {
			
		showformheader('plugins&operation=config&identifier=dzapp_sort&pmod=admincp_district&ac=edit&id='.$district['districtid']);
		showtableheader();
		showsetting('name', 'name', $district['name'], 'text');
		showsubmit('editsubmit');
		showtablefooter();
		showformfooter();

	} else {

		if(!$_GET['name']) { 
			cpmsg('district_invalid', '', 'error');
		}
		
		$data = array(
			'name' => $_GET['name'],
		);
		C::t('#dzapp_sort#dzapp_sort_district')->update($district['districtid'], $data);

		update_cache_dzapp_sort_district();
		cpmsg('district_edit_succeed', 'action=plugins&operation=config&identifier=dzapp_sort&pmod=admincp_district', 'succeed');
	}
}

function update_cache_dzapp_sort_district() {
	$query = C::t('#dzapp_sort#dzapp_sort_district')->fetch_all_by_displayorder();
	foreach($query as $key => $value) {
		if($value['upid']) {
			$query[$value['upid']]['children'][] = $key;
		}
	}
	foreach($query as $key => $value) {
		if($value['upid'] == 0) {
			$dzapp_sort_district[$key] = $value;
			foreach($value['children'] as $children) {
				$dzapp_sort_district[$children] = $query[$children];
			}
		}
	}
	savecache('dzapp_sort_district', $dzapp_sort_district);
}

?>