<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql['1.3'] = <<<EOF
ALTER TABLE `pre_dzapp_sort_district`
ADD COLUMN `upid`  smallint(6) NOT NULL AFTER `districtid`;
EOF;

foreach($sql as $key => $value) {
	if($_GET['fromversion'] < $key) runquery($value);
}

if($_GET['fromversion'] < 1.2) {
	copy(DISCUZ_ROOT.'./source/plugin/dzapp_sort/cache/cache_dzapp_sort_category.php', DISCUZ_ROOT.'./source/function/cache/cache_dzapp_sort_category.php');
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')) {
	$pluginid = 'dzapp_sort';
	$Hooks = array('forumdisplay_topBar', 'forumdisplay_sideBar', 'viewthread_topBar', 'viewthread_sideBar');
	$data = array();
	foreach($Hooks as $Hook) {
		$data[] = array($Hook => array('plugin' => $pluginid, 'include' => 'api.class.php', 'class' => $pluginid.'_api', 'method' => $Hook));
	}
	require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
	WeChatHook::updateAPIHook($data);
}

$finish = true;