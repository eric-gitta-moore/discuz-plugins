<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dzapp_sort_mod extends discuz_table {

	public function __construct() {
		$this->_table = 'dzapp_sort_mod';
		$this->_pk    = '';

		parent::__construct();
	}
		
	public function fetch_all_by_expiration_status($expiration, $status = 1) {
		return DB::fetch_all('SELECT * FROM %t WHERE expiration>0 AND expiration<%d AND status=%d', array($this->_table, $expiration, $status));
	}

	public function update_by_infoid_action($infoid, $action, $data) {
		return DB::update($this->_table, $data, DB::field('infoid', $infoid).' AND '.DB::field('action', $action));
	}
}

?>