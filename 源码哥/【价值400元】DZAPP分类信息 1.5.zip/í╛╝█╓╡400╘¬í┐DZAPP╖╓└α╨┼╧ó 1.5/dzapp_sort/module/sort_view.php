<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$id = intval($_GET['infoid']);
$info = DB::fetch_first("SELECT * FROM ".DB::table('dzapp_sort_info')." WHERE infoid='$id'");
if(empty($info)) {
	showmessage("dzapp_sort:view_null");
}
if($info['displayorder'] == '-1' && $info['uid'] != $_G['uid']) {
	showmessage("dzapp_sort:info_moderating");
}
DB::query("UPDATE ".DB::table('dzapp_sort_info')." SET views=views+1 WHERE infoid='$id'");

$catid = $info['catid'];
$type = $info['type'];
$subtype = $info['subtype'];
$cats = $_G['cache']['dzapp_sort_category'];
$modules = $_G['cache']['dzapp_sort_module'];
$cat = $cats[$catid];
$module = $modules[$cat['moduleid']];
if($cat['moduleid']) {
	$options = DB::fetch_first("SELECT * FROM ".DB::table('dzapp_sort_module_')."$module[moduleid] WHERE infoid='$id'");
}

$info['dateline'] = dgmdate($info['dateline']);
$info['lastupdate'] = dgmdate($info['lastupdate']);
$info['price'] = floatval($info['price']);
$info['message'] = nl2br($info['message']);
$info['url'] = $_G['siteurl'].'plugin.php?id=dzapp_sort&mod=view&infoid='.$id;
if($var['sort_protect'] && !$_G['mobile']) {
	$info['mobile'] = '<img src="'.makevaluepic($info['mobile']).'" style="margin-top: 4px;" />';
}

if($info['pic']) {
	require_once libfile('function/home');
	$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_attachment')." WHERE infoid='$id' ORDER BY attachid");
	while($attach = DB::fetch($query)) {
		$attach['pic'] = pic_get($attach['attachment'], 'portal');
		$attach['thumb'] = pic_get($attach['attachment'], 'portal', $attach['thumb'], $attach['remote']);
		$attachs[] = $attach;
	}
	$pics = count($attachs);
}

$member = array_merge(
	C::t('common_member')->fetch($info['uid']),
	C::t('common_member_count')->fetch($info['uid']),
	C::t('common_member_status')->fetch($info['uid'])
);
$member['avatar'] = avatar($member['uid']);

$seodata = array('bbname' => $_G['setting']['bbname'], 'subject' => $info['subject'], 'message' => $info['message']);
list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $sort_seo['view']);

$cat['icon'] = $cat['icon'] ? $cat['icon'] : $cats[$cat['upid']]['icon'];
$weixin = array(
	'img_url' => $_G['siteurl'].($cat['icon'] ? 'data/attachment/portal/'.$cat['icon'] : 'source/plugin/dzapp_sort/static/icon.png'),
	'link' => $_G['siteurl'].'plugin.php?id=dzapp_sort&mod=view&infoid='.$id,
	'desc' => $metadescription,
	'title' => $navtitle,
);

if($_G['mobile']) {
	include template('dzapp_sort:sort_view');
} else {
	include template('diy:sort_view', 0, $var['style']);
}

function checkcase($case, $options) {
	if(!$case) {
		return true;
	} else {
		$case = explode('=', $case);
		$case[1] = explode(',', $case[1]);
		if(in_array($options[$case[0]], $case[1])) {
			return true;
		} else {
			return false;
		}
	}
}

function makevaluepic($value) {
	$basedir = !getglobal('setting/attachdir') ? './data/attachment' : getglobal('setting/attachdir');
	$url = !getglobal('setting/attachurl') ? './data/attachment/' : getglobal('setting/attachurl');
	$subdir1 = substr(md5($value), 0, 2);
	$subdir2 = substr(md5($value), 2, 2);
	$target = 'temp/'.$subdir1.'/'.$subdir2.'/';
	$targetname = substr(md5($value), 8, 16).'.png';
	discuz_upload::check_dir_exists('temp', $subdir1, $subdir2);
	if(file_exists($basedir.'/'.$target.$targetname)) {
		return $url.$target.$targetname;
	}
	$value = str_replace("\n", '', $value);
	$fontfile = $fontname = '';
	$ttfenabled = false;
	$size = 20;
	$w = 130;
	$rowh = 30;
	if(function_exists('imagettftext')) {
		$fontroot = DISCUZ_ROOT.'./static/image/seccode/font/ch/';
		$dirs = opendir($fontroot);
		while($entry = readdir($dirs)) {
			if($entry != '.' && $entry != '..' && in_array(strtolower(fileext($entry)), array('ttf', 'ttc'))) {
				$fontname = $entry;
				break;
			}
		}
		if(!empty($fontname)) {
			$fontfile = DISCUZ_ROOT.'./static/image/seccode/font/ch/'.$fontname;
		}
		if($fontfile) {
			if(strtoupper(CHARSET) != 'UTF-8') {
				include DISCUZ_ROOT.'./source/class/class_chinese.php';
				$cvt = new Chinese(CHARSET, 'utf8');
				$value = $cvt->Convert($value);
			}
			$size = 9;
			$ttfenabled = true;
		}
	}
	$value = explode("\r", $value);
	foreach($value as $str) {
		if($ttfenabled) {
			$box = imagettfbbox($size, 0, $fontfile, $str);
			$height = max($box[1], $box[3]) - min($box[5], $box[7]);
			$len = (max($box[2], $box[4]) - min($box[0], $box[6]));
			$rowh = max(array($height, $strh));
		} else {
			$len = strlen($str) * 9;
		}
		$w = max(array($len, $w));
	}
	$h = $rowh * count($value) + count($value) * 2;
	$im = @imagecreate($w, $h);
	$background_color = imagecolorallocate($im, 255, 255, 255);
	$text_color = imagecolorallocate($im, 255, 60, 0);
	$h = $ttfenabled ? $rowh : 4;
	foreach($value as $str) {
		if($ttfenabled) {
			imagettftext($im, $size, 0, 0, $h, $text_color, $fontfile, $str);
			$h += 2;
		} else {
			imagestring($im, $size, 0, $h, $str, $text_color);
		}
		$h += $rowh;
	}
	imagepng($im, $basedir.'/'.$target.$targetname);
	imagedestroy($im);
	return $url.$target.$targetname;
}

?>