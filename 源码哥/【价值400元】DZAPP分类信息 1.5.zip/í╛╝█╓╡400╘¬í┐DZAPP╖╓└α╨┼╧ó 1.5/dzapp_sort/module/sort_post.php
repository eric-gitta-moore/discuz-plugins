<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

if($infoid = intval($_GET['infoid'])) {
	$info = DB::fetch_first("SELECT * FROM ".DB::table('dzapp_sort_info')." WHERE infoid='$infoid'");
}

if($info && $info['uid'] != $_G['uid'] && $_G['adminid'] != 1) {
	showmessage('dzapp_sort:no_grant_act');
}

$credit = $_G['setting']['extcredits'][$var['sort_credit']];
$credit['num'] = getuserprofile('extcredits'.$var['sort_credit']);

if($_GET['ac'] == 'update' || $_GET['ac'] == 'stick') {
	include_once template('dzapp_sort:sort_misc');
	exit;
}

if(submitcheck('updatesubmit')) {

	if($credit['num'] < $var['sort_update']) {
		showmessage('dzapp_sort:credit_not_enough');
	}
	DB::query('UPDATE '.DB::table('dzapp_sort_info')." SET lastupdate='$_G[timestamp]' WHERE infoid='$infoid'");
	updatemembercount($_G['uid'], array($var['sort_credit'] => '-'.$var['sort_update']), true, 'UIF', $infoid);
	showmessage('operation_done', "plugin.php?id=dzapp_sort&mod=memcp");

}

if(submitcheck('sticksubmit')) {

	$day = intval($_GET['day']);
	$cost = $day * $var['sort_stick'];
	if(empty($day)) {
		showmessage('dzapp_sort:select_datetime');
	}
	if($credit['num'] < $cost) {
		showmessage('dzapp_sort:credit_not_enough');
	}
	DB::query('UPDATE '.DB::table('dzapp_sort_info')." SET displayorder='1' WHERE infoid='$infoid'");
	$setarr = array(
			'infoid' => $infoid,
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'dateline' => $_G['timestamp'],
			'expiration' => $_G['timestamp'] + $day * 86400,
			'action' => 'SIF',
			'status' => '1',
			'value' => '1'
	);
	DB::insert("dzapp_sort_mod", $setarr);
	updatemembercount($_G['uid'], array($var['sort_credit'] => '-'.$cost), true, 'SIF', $infoid);
	showmessage('operation_done', "plugin.php?id=dzapp_sort&mod=memcp");

}

$catid = $info ? $info['catid'] : intval($_GET['catid']);
$type = $info ? $info['type'] : intval($_GET['type']);
$subtype = $info ? $info['subtype'] : intval($_GET['subtype']);
$cats = $_G['cache']['dzapp_sort_category'];
$modules = $_G['cache']['dzapp_sort_module'];
$cat = $cats[$catid];
$cat['upname'] = $cat['level'] ? $cats[$cat['upid']]['catname'] : $cat['catname'];
$cat['rule'] = $cat['level'] ? $cats[$cat['upid']]['rule'] : $cat['rule'];
$module = $modules[$cat['moduleid']];
$attach_ids = 0;
if($info) {
	$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_attachment')." WHERE infoid='$infoid' ORDER BY attachid");
	while($attach = DB::fetch($query)) {
		$attachs[] = $attach;
		$attach_ids .= ','.$attach['attachid'];
	}
	$info['attachs'] = get_upload_content($attachs, $info['pic']);
	if($cat['moduleid']) {
		$options = DB::fetch_first("SELECT * FROM ".DB::table('dzapp_sort_module_')."$cat[moduleid] WHERE infoid='$infoid'");
	}
}

if(submitcheck("sortsubmit")) {

	if(empty($_GET['subject']) || empty($_GET['message']) || empty($_GET['realname']) || empty($_GET['mobile'])) {
		showmessage('dzapp_sort:required_null');
	}

	$attach_ids = array();
	foreach(explode(',', $_GET['attach_ids']) as $attach_id) {
		if(intval($attach_id)) {
			$attach_ids[] = $attach_id;
		}
	}
	$picnum = count($attach_ids);

	$setarr = array(
		'type' => intval($_GET['type']),
		'subtype' => intval($_GET['subtype']),
		'districtid' => intval($_GET['districtid']),
		'subject' => dhtmlspecialchars($_GET['subject']),
		'pic' => dhtmlspecialchars($_GET['pic']),
		'picnum' => $picnum,
		'identity' => intval($_GET['identity']),
		'price' => floatval($_GET['price']),
		'message' => dhtmlspecialchars($_GET['message']),
		'realname' => dhtmlspecialchars($_GET['realname']),
		'realname' => dhtmlspecialchars($_GET['realname']),
		'mobile' => dhtmlspecialchars($_GET['mobile']),
		'qq' => dhtmlspecialchars($_GET['qq']),
	);

	foreach($_GET['option'] as $optionid => $value) {
		if($module['option'][$optionid]['type'] == 'checkbox') {
			$value = implode("\t", $value);
		} elseif($module['option'][$optionid]['type'] == 'calendar') {
			$value = strtotime($value);
		} elseif(in_array($module['option'][$optionid]['type'], array('radio', 'number', 'range'))) {
			$value = intval($value);
		} else {
			$value = dhtmlspecialchars($value);
		}
		$option['field_'.$optionid] = $value;
	}

	if($info['infoid']) {
		DB::update('dzapp_sort_info', $setarr, array('infoid' => $infoid));
		if($cat['moduleid']) {
			DB::update('dzapp_sort_module_'.$cat['moduleid'], $option, array('infoid' => $infoid));
		}
	} else {
		$setarr['uid'] = $_G['uid'];
		$setarr['username'] = $_G['username'];
		$setarr['dateline'] = $_G['timestamp'];
		$setarr['lastupdate'] = $_G['timestamp'];
		$setarr['ip'] = $_G['clientip'];
		$setarr['catid'] = $catid;
		$setarr['moduleid'] = $cat['moduleid'];
		$setarr['displayorder'] = $var['moderate'] ? -1 : 0;
		$infoid = DB::insert('dzapp_sort_info', $setarr, true);
		$option['infoid'] = $infoid;
		$option['catid'] = $catid;
		$option['dateline'] = $_G['timestamp'];
		if($cat['moduleid']) {
			DB::insert('dzapp_sort_module_'.$cat['moduleid'], $option);
		}
		DB::query("UPDATE ".DB::table('dzapp_sort_category')." SET post=post+1, todaypost=todaypost+1 WHERE catid IN ('$catid', '$type')");
	}

	if($attach_ids) {
		DB::update('dzapp_sort_attachment', array('infoid' => $infoid), 'attachid IN ('.dimplode($attach_ids).')');
	}

	require_once libfile('function/cache');
	updatecache('dzapp_sort_category');

	showmessage('operation_done', 'plugin.php?id=dzapp_sort&mod=view&infoid='.$infoid);

}

require_once libfile('function/upload');
$swfconfig = getuploadconfig($_G['uid'], 0, false);

$exts = explode(',', $var['sort_attachextensions']);
$swfconfig['max'] = $var['sort_attachsize'];
$swfconfig['imageexts']['ext'] = '*.'.implode(';*.', $exts);
$swfconfig['imageexts']['depict'] = 'Image File';


$datasrc['districtid'] = array(
	'paramname' => 'districtid',
	'title' => 'region',
);
foreach($_G['cache']['dzapp_sort_district'] as $value) {
	$datasrc['districtid']['option'][] = array('text' => diconv($value['name'], CHARSET, 'UTF-8'), 'value' => $value['districtid']);
}
foreach($module['option'] as $key => $value) {
	if($value['type'] == 'select') {
		$datasrc['field_'.$key] = array('paramname' => 'field_'.$key, 'title' => $value['title']);
		foreach($value['choice'] as $k => $v) {
			$datasrc['field_'.$key]['option'][] = array('text' => diconv($v, CHARSET, 'UTF-8'), 'value' => $k);
		}
	}
}
$datasrc = json_encode($datasrc);

$seodata = array('bbname' => $_G['setting']['bbname']);
list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $sort_seo['post']);

include template('diy:sort_post', 0, $var['style']);

function get_upload_content($attachs, $cover) {
	require_once libfile('function/home');

	$html = '';
	$i = 0;
	foreach($attachs as $key => $attach) {
		$type = 'portal';
		$html .= '<td id="attach_list_'.$attach['attachid'].'">';
		if($attach['isimage']) {
			$pic = pic_get($attach['attachment'], $type, $attach['thumb'], $attach['remote'], 0);
			$small_pic = $attach['thumb'] ? getimgthumbname($pic) : '';
			$check = $cover == $attach['attachment'] ? 'checked' : '';
			$aid = $check ? $attach['aid'] : '';

			$html .= '<a href="javascript:;" class="opattach">';
			$html .= '<img src="'.($small_pic ? $small_pic : $pic).'" class="cur1" /></a>';
			$html .= '<label for="setcover'.$attach['attachid'].'" class="cur1 xi2"><input type="radio" name="setcover" id="setcover'.$attach['attachid'].'" class="pr" value="1" onclick=setCover(\''.$attach['attachment'].'\') '.$check.'>set_face</label>';
			$html .= '<span class="pipe">|</span><span class="cur1 xi2" onclick="deleteAttach(\''.$attach['attachid'].'\', \'plugin.php?id=dzapp_sort&mod=attachment&attachid='.$attach['attachid'].'&aid='.$aid.'&op=delete\');">delete</span>';
		}
		$html .= '</td>';
		$i++;

		if($i % 6 == 0 && isset($attachs[$i])) {
			$html .= '</tr><tr>';
		}
	}
	if(!empty($html)) {
		if(($imgpad = $i % 6) > 0) {
			$html .= str_repeat('<td width="16%"></td>', 6 - $imgpad);
		}

		$html = '<table class="imgl"><tr>'.$html.'</tr></table>';
	}
	return $html;
}

?>