<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$id = empty($_GET['infoid']) ? 0 : intval($_GET['infoid']);
if($id) {
	$info = DB::fetch_first("SELECT * FROM ".DB::table('dzapp_sort_info')." WHERE infoid='$id'");
}

if($info) {
	if($info['uid'] != $_G['uid'] && !$_G['adminid']) {
		showmessage('dzapp_sort:no_grant_act');
	}
}

if($_GET['op'] == 'recyle') {
	if($info['displayorder'] == '-1') {
		showmessage('dzapp_sort:can_not_delete_moderate');
	}
	DB::update("dzapp_sort_info", array('displayorder' => -3), array('infoid' => $id));

	showmessage('operation_done', "plugin.php?id=dzapp_sort&mod=memcp");
}

if($_GET['op'] == 'recovery') {

	DB::update("dzapp_sort_info", array('displayorder' => 0), array('infoid' => $id));

	showmessage('operation_done', "plugin.php?id=dzapp_sort&mod=memcp");
}

if($_GET['op'] == 'delete') {

	DB::query('DELETE FROM '.DB::table('dzapp_sort_info')." WHERE infoid='$id'");
	DB::query('DELETE FROM '.DB::table('dzapp_sort_module_')."$info[moduleid] WHERE infoid='$id'");

	showmessage('operation_done', "plugin.php?id=dzapp_sort&mod=memcp");
}

$type = $_GET['type'];
$typearr = array('common' => 0, 'stick' => 1, 'aduit' => -1, 'close' => -2, 'recyle' => -3);

$perpage = 20;
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $perpage;
if($start < 0) $start = 0;

$gets = array(
	'id' => 'dzapp_sort',
	'mod' => 'memcp',
	'type' => $type,
);
$theurl = 'plugin.php?'.url_implode($gets);

$wheresql = "uid='$_G[uid]'";
$wheresql .= $type ? " AND displayorder='$typearr[$type]'" : '';

$list = array();
$multi = '';
$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('dzapp_sort_info')." WHERE $wheresql");
if($count) {
	$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_info')." WHERE $wheresql ORDER BY dateline DESC LIMIT $start,$perpage");
	while ($value = DB::fetch($query)) {
		$value['cat'] = $_G['cache']['dzapp_sort_category'][$value['catid']]['catname'];
		$value['lastupdate'] = dgmdate($value['lastupdate']);
		$list[] = $value;
	}
	$multi = multi($count, $perpage, $page, $theurl);
}

$seodata = array('bbname' => $_G['setting']['bbname']);
list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $sort_seo['memcp']);

include template('dzapp_sort:sort_memcp');

?>