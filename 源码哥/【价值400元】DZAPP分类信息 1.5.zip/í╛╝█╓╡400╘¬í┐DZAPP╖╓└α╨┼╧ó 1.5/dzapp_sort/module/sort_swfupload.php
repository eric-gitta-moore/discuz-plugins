<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$_G['uid'] = intval($_GET['uid']);

if((empty($_G['uid']) && $_GET['operation'] != 'upload') || $_GET['hash'] != md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])) {
	exit();
} else {
	if($_G['uid']) {
		$_G['member'] = getuserbyuid($_G['uid']);
	}
	$_G['groupid'] = $_G['member']['groupid'];
	loadcache('usergroup_'.$_G['member']['groupid']);
	$_G['group'] = $_G['cache']['usergroup_'.$_G['member']['groupid']];
}

if($_GET['operation'] == 'upload') {

	if(empty($_GET['simple'])) {
		$_FILES['Filedata']['name'] = diconv(urldecode($_FILES['Filedata']['name']), 'UTF-8');
		$_FILES['Filedata']['type'] = $_GET['filetype'];
	}
	$forumattachextensions = '';
	$fid = intval($_GET['fid']);
	if($fid) {
		$forum = $fid != $_G['fid'] ? C::t('forum_forum')->fetch_info_by_fid($fid) : $_G['forum'];
		if($forum['status'] == 3 && $forum['level']) {
			$levelinfo = C::t('forum_grouplevel')->fetch($forum['level']);
			if($postpolicy = $levelinfo['postpolicy']) {
				$postpolicy = dunserialize($postpolicy);
				$forumattachextensions = $postpolicy['attachextensions'];
			}
		} else {
			$forumattachextensions = $forum['attachextensions'];
		}
		if($forumattachextensions) {
			$_G['group']['attachextensions'] = $forumattachextensions;
		}
	}
	$upload = new forum_upload();

} elseif($_GET['operation'] == 'sort') {

	$infoid = intval($_GET['infoid']);
	$msg = '';
	$errorcode = 0;
	$upload = new discuz_upload();
	$_FILES["Filedata"]['name'] = addslashes(diconv(urldecode($_FILES["Filedata"]['name']), 'UTF-8'));
	$upload->init($_FILES['Filedata'], 'portal');
	$attach = $upload->attach;
	if(!$upload->error()) {
		$upload->save();
	}
	if($upload->error()) {
		$errorcode = 4;
	}
	if(!$errorcode) {
		if($attach['isimage']) {
			require_once libfile('class/image');
			$image = new image();
			$thumbimgwidth = 400;
			$thumbimgheight = 300;
			$attach['thumb'] = $image->Thumb($attach['target'], '', $thumbimgwidth, $thumbimgheight, 2);
			$image->Watermark($attach['target'], '', 'portal');
		}
		$setarr = array(
			'uid' => $_G['uid'],
			'filename' => $attach['name'],
			'attachment' => $attach['attachment'],
			'filesize' => $attach['size'],
			'isimage' => $attach['isimage'],
			'thumb' => $attach['thumb'],
			'remote' => $attach['remote'],
			'filetype' => $attach['extension'],
			'dateline' => $_G['timestamp'],
			'infoid' => $infoid
		);
		$setarr['attachid'] = DB::insert("dzapp_sort_attachment", $setarr, true);
		if($attach['isimage']) {
			require_once libfile('function/home');
			$smallimg = pic_get($attach['attachment'], 'portal', $attach['thumb'], $attach['remote']);
			$bigimg = pic_get($attach['attachment'], 'portal', 0, $attach['remote']);
			$coverstr = $attach['attachment'];
			echo "{\"aid\":$setarr[attachid], \"isimage\":$attach[isimage], \"smallimg\":\"$smallimg\", \"bigimg\":\"$bigimg\", \"errorcode\":$errorcode, \"cover\":\"$coverstr\"}";
			exit();
		}
	}
}

?>