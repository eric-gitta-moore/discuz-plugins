<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$id = empty($_GET['infoid']) ? 0 : intval($_GET['infoid']);
$idtype = 'infoid';
$info = DB::fetch_first("SELECT * FROM ".DB::table('dzapp_sort_info')." WHERE infoid='$id'");
$title = $info['subject'];
$icon = '<img src="source/plugin/dzapp_sort/static/info.gif" alt="thread" class="vm" /> ';

if(empty($idtype) || empty($title)) {
	showmessage('favorite_cannot_favorite');
}

$fav = C::t('#dzapp_sort#dzapp_sort_favorite')->fetch_by_id_idtype($id, $idtype, $_G['uid']);
if($fav) {
	showmessage('favorite_repeat');
}

$fav_count = C::t('#dzapp_sort#dzapp_sort_favorite')->count_by_id_idtype($id, $idtype);
$arr = array(
	'uid' => intval($_G['uid']),
	'idtype' => $idtype,
	'id' => $id,
	'spaceuid' => $spaceuid,
	'title' => getstr($title, 255),
	'description' => getstr($_GET['description'], '', 0, 0, 1),
	'dateline' => TIMESTAMP
);
$favid = C::t('#dzapp_sort#dzapp_sort_favorite')->insert($arr, true);

DB::query("UPDATE ".DB::table('dzapp_sort_info')." SET favtimes=favtimes+1 WHERE infoid='$id'");

showmessage('favorite_do_success', dreferer(), array('id' => $id), array('showdialog' => true, 'closetime' => true));

?>