<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$operation = $_GET['op'] ? $_GET['op'] : '';

$id = empty($_GET['attachid']) ? 0 : intval($_GET['attachid']);
$infoid = empty($_GET['infoid']) ? '' : intval($_GET['infoid']);
$attach = DB::fetch_first("SELECT * FROM ".DB::table('dzapp_sort_attachment')." WHERE attachid='$id'");
if(empty($attach)) {
	showmessage('dzapp_sort:portal_attachment_noexist');
}

if($operation == 'delete') {

	DB::query("DELETE FROM ".DB::table('dzapp_sort_attachment')." WHERE attachid='$id'");
	pic_delete($attach['attachment'], 'portal', $attach['thumb'], $attach['remote']);
	showmessage('dzapp_sort:portal_image_noexist');

} elseif($operation == 'getattach') {

	if($attach['isimage']) {
		$smallimg = pic_get($attach['attachment'], 'portal', $attach['thumb'], $attach['remote']);
		$bigimg = pic_get($attach['attachment'], 'portal', 0, $attach['remote']);
		$coverstr = $attach['attachment'];
	}
	include template('dzapp_sort:sort_attachment');
	exit;

}

?>