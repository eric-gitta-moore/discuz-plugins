<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$perpage = 30;
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $perpage;
if($start < 0) $start = 0;

$_GET['keyword'] = $_GET['srchtxt'] ? $_GET['srchtxt'] : $_GET['keyword'];
$keyword = stripsearchkey($_GET['keyword']);
$keyword = $keyword == lang('plugin/dzapp_sort', 'input_what_you_want') ? '' : $keyword;
$keyword = $_G['mobile'] ? diconv($keyword, 'utf-8', CHARSET) : $keyword;

$wheresql = "displayorder>='0'";
$wheresql .= $keyword ? " AND (subject LIKE '%$keyword%' OR message LIKE '%$keyword%' OR mobile LIKE '%$keyword%')" : '';

include_once libfile('function/home');
$gets = array(
	'id' => 'dzapp_sort',
	'mod' => 'search',
	'keyword' => $_GET['keyword'],
);
$theurl = 'plugin.php?'.url_implode($gets);

$list = array();
$multi = '';
$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('dzapp_sort_info')." WHERE $wheresql");
if($count) {
	$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_info')." WHERE $wheresql ORDER BY lastupdate DESC LIMIT $start,$perpage");
	while ($value = DB::fetch($query)) {
		$value['pic'] = $value['pic'] ? pic_get($value['pic'], 'portal', 1) : 'source/plugin/dzapp_sort/static/nopic_2.gif';
		$value['district'] = $_G['cache']['dzapp_sort_district'][$value['districtid']]['name'];
		$value['catname'] = $_G['cache']['dzapp_sort_category'][$value['catid']]['catname'];
		$value['upid'] = $_G['cache']['dzapp_sort_category'][$value['catid']]['upid'];
		$value['upname'] = $_G['cache']['dzapp_sort_category'][$value['upid']]['catname'];
		$value['lastupdate'] = dgmdate($value['lastupdate']);
		$value['message'] = cutstr($value['message'], 300);
		$list[] = $value;
	}
	$multi = multi($count, $perpage, $page, $theurl);
}

$seodata = array('bbname' => $_G['setting']['bbname']);
list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $sort_seo['search']);

$weixin = array(
	'img_url' => $_G['siteurl'].'source/plugin/dzapp_sort/static/icon.png',
	'link' => $_G['siteurl'].'plugin.php?id=dzapp_sort&mod=search',
	'desc' => $metadescription,
	'title' => $navtitle,
);

if($_G['mobile']) {
	include template('dzapp_sort:sort_search');
} else {
	include template('diy:sort_search', 0, $var['style']);
}

?>