<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$catid = intval($_GET['catid']);
$type = intval($_GET['type']);
$subtype = intval($_GET['subtype']);
$districtid = intval($_GET['districtid']);
$dateline = intval($_GET['dateline']);
$cats = $_G['cache']['dzapp_sort_category'];
$modules = $_G['cache']['dzapp_sort_module'];
$cat = $cats[$catid];
$moduleid = $cat['moduleid'] ? $cat['moduleid'] : $cats[$cat['children'][0]]['moduleid'];
$module = $modules[$moduleid];

$area = $_G['cache']['dzapp_sort_district'][$_GET['districtid']];
$child['area'] = $area['children'] ? $area['children'] : $_G['cache']['dzapp_sort_district'][$area['upid']]['children'];
if($area['children']) {
	$districtid = array_merge($area['children'], array($_GET['districtid']));
}

$root = $cat['upid'] ? $cats[$cat['upid']] : $cat;
foreach($root['children'] as $value) {
	$root['post'] += $cats[$value]['post'];
}

$perpage = 40;
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $perpage;
if($start < 0) $start = 0;

$wheresql = "displayorder>='0'";
$wheresql .= $catid ? ($cat['level'] ? " AND catid='$catid'" : " AND catid IN (".dimplode($cat[children]).")") : '';
$wheresql .= $type ? " AND type='$type'" : '';
$wheresql .= $subtype ? " AND subtype='$subtype'" : '';
$wheresql .= $districtid ? (is_array($districtid) ? " AND districtid IN (".implode(',', $districtid).")" : " AND districtid='$districtid'") : '';
$wheresql .= $dateline ? " AND dateline >= '".($_G['timestamp'] - $dateline)."'" : '';
$wheresql .= $_GET['pic'] ? " AND picnum>'0'" : '';

$gets = array(
	'id' => 'dzapp_sort',
	'mod' => 'list',
	'catid' => $catid,
	'type' => $type,
	'subtype' => $subtype,
	'districtid' => $_GET['districtid'],
);
foreach($module['option'] as $optionid => $option) {
	if($option['search'] == 1) {
		$field = $option['system'] == 1 ? $option['type'] : 'field_'.$optionid;
		if($option['range'] && $_GET[$field]) {
			$fieldstr = explode('_', $_GET[$field]);
			if(!$fieldstr[0]) {
				$sql = " AND $field<'$fieldstr[1]'";
			} elseif(!$fieldstr[1]) {
				$sql = " AND $field>'$fieldstr[0]'";
			} else {
				$sql = " AND ($field BETWEEN ".intval($fieldstr[0])." AND ".intval($fieldstr[1]).")";
			}
		} else {
			$sql = " AND $field='$_GET[$field]'";
		}
		if($option['system'] == 1) {
			$wheresql .= $_GET[$field] ? $sql : '';
		} else {
			$optionsql .= $_GET[$field] ? $sql : '';
		}
		$gets[$field] = $_GET[$field];
	}
}
$theurl = 'plugin.php?'.url_implode($gets);

if($optionsql) {
	$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_module_')."$module[moduleid] WHERE catid='$catid' $optionsql");
	while ($value = DB::fetch($query)) {
		$infoids[] = $value['infoid'];
	}
	if($infoids) {
		$wheresql .= " AND infoid IN (".dimplode($infoids).")";
	}
}

$list = array();
$multi = '';
$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('dzapp_sort_info')." WHERE $wheresql");
$count = $optionsql ? min($count, count($infoids)) : $count;
if($count) {
	$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_info')." WHERE $wheresql ORDER BY displayorder DESC, lastupdate DESC LIMIT $start,$perpage");
	while ($value = DB::fetch($query)) {
		$value['pic'] = $value['pic'] ? pic_get($value['pic'], 'portal', 1) : 'source/plugin/dzapp_sort/static/nopic_2.gif';
		$value['district'] = $_G['cache']['dzapp_sort_district'][$value['districtid']]['name'];
		$value['lastupdate'] = dgmdate($value['lastupdate'], "Y-m-d");
		$value['price'] = round($value['price'], 2);
		$value['message'] = cutstr($value['message'], 100);
		$list[] = $value;
		$ids[] = $value['infoid'];
	}
	$multi = multi($count, $perpage, $page, $theurl);
}

if($module) {
	$query = DB::query("SELECT * FROM ".DB::table('dzapp_sort_module_')."$module[moduleid] WHERE infoid IN (".dimplode($ids).")");
	while($value = DB::fetch($query)) {
		$options[$value['infoid']] = $value;
	}
}

foreach($cat['children'] as $value) {
	$post += $cats[$value]['post'];
	$todaypost += $cats[$value]['todaypost'];
}

if($cat['seotitle']) {
	list($navtitle, $metadescription, $metakeywords) = array($cat['seotitle'], $cat['description'], $cat['keyword']);
} else {
	$seodata = array('bbname' => $_G['setting']['bbname'], 'cat' => $cat['catname']);
	list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $sort_seo['list']);
}

$cat['icon'] = $cat['icon'] ? $cat['icon'] : $cats[$cat['upid']]['icon'];
$weixin = array(
	'img_url' => $_G['siteurl'].($cat['icon'] ? 'data/attachment/portal/'.$cat['icon'] : 'source/plugin/dzapp_sort/static/icon.png'),
	'link' => $_G['siteurl'].'plugin.php?id=dzapp_sort&mod=list&catid='.$catid,
	'desc' => $metadescription,
	'title' => $navtitle,
);

$template = $cat['listtpl'] ? $cat['listtpl'] : 'sort_list';
if($_G['mobile']) {
	include template('dzapp_sort:sort_list');
} else {
	include template('diy:'.$template.':'.$_GET['catid'], 0, $var['style']);
}

function price_unit($module_id) {
	global $_G;

	$module = $_G['cache']['dzapp_sort_module'][$module_id];
	foreach($module['option'] as $value) {
		if($value['type'] == 'price') $unit = $value['unit'];
	}

	return $unit;
}

?>