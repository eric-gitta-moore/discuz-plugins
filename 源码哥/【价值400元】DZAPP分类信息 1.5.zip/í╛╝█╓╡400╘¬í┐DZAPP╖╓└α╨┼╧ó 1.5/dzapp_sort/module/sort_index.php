<?php

/*
From��Դ��磨www.ymg6.com��
��עԴ��磬��ʱ��ȡ����dz��Դ���ƽ���ģ��
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cat = $_G['cache']['dzapp_sort_category'];
foreach($cat as $value) {
	if(in_array($value['upid'], array(1, 2, 3, 4, 5, 6))) {
		$count[$value['upid']] += $value['post'];
	}
	$list[] = $value;
}

$seodata = array('bbname' => $_G['setting']['bbname']);
list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $sort_seo['index']);

$weixin = array(
	'img_url' => $_G['siteurl'].'source/plugin/dzapp_sort/static/icon.png',
	'link' => $_G['siteurl'].'plugin.php?id=dzapp_sort',
	'desc' => $metadescription,
	'title' => $navtitle,
);

if($_G['mobile']) {
	include template('dzapp_sort:sort_index');
} else {
	include template('diy:sort_index', 0, $var['style']);
}

?>