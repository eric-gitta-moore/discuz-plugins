<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
?>
<script type="text/javascript">location.href="http://addon.discuz.com/?@838.developer";</script>