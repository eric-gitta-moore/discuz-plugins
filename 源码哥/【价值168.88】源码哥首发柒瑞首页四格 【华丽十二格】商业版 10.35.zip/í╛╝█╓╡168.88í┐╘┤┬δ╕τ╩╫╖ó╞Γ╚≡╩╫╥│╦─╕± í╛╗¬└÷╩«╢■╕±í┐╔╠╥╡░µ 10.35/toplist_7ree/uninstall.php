<?php

/*
	ID: toplist_7ree 
	(C)2007-2014 [www.7ree.com]
	This is NOT a freeware, use is subject to license terms
	update 21:09 2014/7/5
	Agreement: http://www.ymg6.com/gg/addon.php?/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://www.ymg6.com/gg/addon.php?/?@7ree
*/




if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	$pluginid_7ree = 'toplist_7ree';
	$langdir_7ree = 'plugin/'.$pluginid_7ree;
	$pic_cachename	= 'showpic_7ree';
	$cachename_toplist	= "toplist_7ree";
	$vars_7ree = $_G['cache']['plugin'][$pluginid_7ree];
	@require_once(DISCUZ_ROOT.'./source/discuz_version.php');
	$cahcedir_7ree = DISCUZ_VERSION == "X2" ? './data/cache/cache_' : './data/sysdata/cache_';

	
	$picfile_path = DISCUZ_ROOT.$cahcedir_7ree.$pic_cachename.'.php';
	$postfile_path = DISCUZ_ROOT.$cahcedir_7ree.$cachename_toplist.'.php';
	
	if(file_exists($picfile_path)) unlink($picfile_path);
    if(file_exists($postfile_path)) unlink($postfile_path);
    
	$sql = <<<EOF
			DROP TABLE IF EXISTS `pre_toplist_push_7ree`;
	EOF;

	runquery($sql);    
	    
	$finish = TRUE;


?>


