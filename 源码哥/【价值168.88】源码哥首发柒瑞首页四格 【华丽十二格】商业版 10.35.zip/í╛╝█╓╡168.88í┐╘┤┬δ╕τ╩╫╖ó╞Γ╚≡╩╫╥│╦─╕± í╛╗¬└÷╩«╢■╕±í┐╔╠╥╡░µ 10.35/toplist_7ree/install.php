<?php
/*
	ID: toplist_7ree 
	(C)2007-2014 [www.7ree.com]
	This is NOT a freeware, use is subject to license terms
	update 21:09 2014/7/5
	Agreement: http://www.ymg6.com/gg/addon.php?/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://www.ymg6.com/gg/addon.php?/?@7ree
 */

(!defined('IN_DISCUZ') || !IN_ADMIN) && exit('Access Denied');





$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_toplist_push_7ree` (
  `id_7ree` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_7ree` mediumint(8) unsigned NOT NULL,
  `tid_7ree` mediumint(8) unsigned NOT NULL,
  `fid_7ree` mediumint(8) unsigned NOT NULL,
  `subject_7ree` char(80) NOT NULL,
  `fname_7ree` char(80) NOT NULL,
  `author_7ree` char(15) NOT NULL,
  `uid_7ree` mediumint(8) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `highlight_7ree` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_7ree`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;

?>
