<?php

/*
	ID: toplist_7ree 
	(C)2006-2016 [www.7ree.com]
	Update: 2016/10/3 11:09
	This is NOT a freeware, use is subject to license terms
	Agreement: http://www.ymg6.com/gg/addon.php?/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://www.ymg6.com/gg/addon.php?/?@7ree
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_toplist_7ree_forum {

	function viewthread_useraction() {
		global $_G;
		$vars_7ree = $_G['cache']['plugin']['toplist_7ree'];
		$adminuid_7ree = explode(',',$vars_7ree['adminuid_7ree']);
		$isadmin_7ree = ($_G['uid'] && in_array($_G['uid'],$adminuid_7ree)) || $_G['adminid']==1;
		if($isadmin_7ree && $vars_7ree['tui_title_7ree']){
			
		if($_G['tid']) $already_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('toplist_push_7ree')." WHERE tid_7ree = ".$_G['tid']);
	
		if($already_7ree){
			$return_7ree = "<a href='javascript:;'><i><img src='static/image/common/push.png'>".lang('plugin/toplist_7ree', 'php_lang_tuisong2_7ree')."</i></a>";
		}else{
			$return_7ree = "<a href='javascript:;' onclick='showWindow(&quot;pushwin_7ree&quot;, &quot;plugin.php?id=toplist_7ree:push_action_7ree&tid_7ree={$_G[tid]}&quot;)'><i><img src='static/image/common/push.png'>".lang('plugin/toplist_7ree', 'php_lang_tuisong_7ree')."</i></a>";
		}
		return $return_7ree;
		}else{
		return '';
		}	
	}
	
	function index_top() {
		global $_G;
		require_once libfile('function/cache');
		
		$vars_7ree = $_G['cache']['plugin']['toplist_7ree'];
		$attachurl = $_G['setting']['attachurl'];
        $agreement_7ree = $vars_7ree['agreement_7ree'];
        $onoff_7ree = $vars_7ree['onoff_7ree'];
        $width_7ree = $vars_7ree['width_7ree'];
        $height_7ree = $vars_7ree['height_7ree'];
        $cell_height_7ree = $height_7ree + 7;
        $highlight_7ree = $vars_7ree['highlight_7ree'];
        $cutstr_7ree = $vars_7ree['cutstr_7ree']; 
        $blank_7ree = $vars_7ree['blank_7ree']; 
        
        $forums_7ree = array_filter(unserialize($vars_7ree['forums_7ree']));
        $fid_7ree = implode($forums_7ree,",");
        $not_fid_7ree = $fid_7ree ? "AND t.fid NOT IN ($fid_7ree)" : "";

        $forums2_7ree = array_filter(unserialize($vars_7ree['forums2_7ree']));
        $fid2_7ree = implode($forums2_7ree,",");
        $not_fid2_7ree = $fid2_7ree ? "AND t.fid NOT IN ($fid2_7ree)" : "";

        $blank_7ree = $blank_7ree ? "target='_blank'" : "target='_self'";
        $hottime_7ree = $vars_7ree['hottime_7ree'];
        $newtime_7ree = $vars_7ree['newtime_7ree'];
        $reptime_7ree = $vars_7ree['reptime_7ree'];        
        $digtime_7ree = $vars_7ree['digtime_7ree'];        
        $right_show_7ree = $vars_7ree['right_show_7ree'];
        $headertitleshow_7ree = $vars_7ree['headertitleshow_7ree']; 
		$linetitle_style_7ree =  $vars_7ree['linetitle_style_7ree'];
	    $tiptime_7ree = $vars_7ree['tiptime_7ree'] * 1000;	
        $shownum_7ree = min(intval($vars_7ree[shownum_7ree]) ? intval($vars_7ree[shownum_7ree]) : 9, 50);
        $newbienum_7ree = min(intval($vars_7ree[newbienum_7ree]),100);
        $membercycle_7ree = max(intval($vars_7ree[membercycle_7ree]),1);        
        $cachecycle_7ree = intval($vars_7ree[cachecycle_7ree]);
        $vars_7ree['fid1title_7ree'] = trim($vars_7ree['fid1title_7ree']);
        $vars_7ree['fid2title_7ree'] = trim($vars_7ree['fid2title_7ree']);
        
        $fotobtnbg_7ree = $vars_7ree['fotobtnbg_7ree'] ? str_replace("#","0x",$vars_7ree['fotobtnbg_7ree']) : "0x0099ff";


		$fid1_7ree = $vars_7ree['fid1_7ree'] ? array_filter(unserialize($vars_7ree['fid1_7ree'])) : array();
 		$fid2_7ree = $vars_7ree['fid2_7ree'] ? array_filter(unserialize($vars_7ree['fid2_7ree'])) : array(); 
 		$fid1_where_7ree =  COUNT($fid1_7ree) ? "AND t.fid IN (".implode($fid1_7ree,",").")" : "";
 		$fid2_where_7ree =  COUNT($fid2_7ree) ? "AND t.fid IN (".implode($fid2_7ree,",").")" : "";	
 		
 		$vars_7ree['tplmode_7ree'] = $vars_7ree['tplmode_7ree'] ? $vars_7ree['tplmode_7ree']: 1;
 			
 		$tpl_4ge_title_7ree =  array(
	 			                    'xt'=>trim($vars_7ree['newpic_title_7ree']),
	 			                    'jt'=>trim($vars_7ree['digpic_title_7ree']),	
	 			                    'gt'=>trim($vars_7ree['adspic_title_7ree']),
	 			                    'xz'=>trim($vars_7ree['new_title_7ree']),
	 			                    'xh'=>trim($vars_7ree['rep_title_7ree']),
	 			                    'jz'=>trim($vars_7ree['dig_title_7ree']),
	 			                    'rz'=>trim($vars_7ree['hot_title_7ree']),
	 			                    'd1'=>trim($vars_7ree['diy1_title_7ree']),
	 			                    'd2'=>trim($vars_7ree['diy2_title_7ree']),
	 			                    'tj'=>trim($vars_7ree['tui_title_7ree']),
	 			                    'hy'=>trim($vars_7ree['acvrank_title_7ree']),
	 			                    'jf'=>trim($vars_7ree['extrank_title_7ree']),
	 			                    'xm'=>trim($vars_7ree['newrank_title_7ree']),
	 								);

 
		$thread_tagnum_7ree = 7;
		$pic_tagnum_7ree = 3;
		$pic_order_7ree = explode("-",trim($vars_7ree[pic_order_7ree]));		
		$thread_order_7ree = explode("-",trim($vars_7ree[thread_order_7ree]));
		$rank_order_7ree = explode("-",trim($vars_7ree[rank_order_7ree]));	
		$toplist_4georder_7ree = explode("-",trim($vars_7ree[toplist_4georder_7ree]));
		
		$ranknum_7ree = $threadnum_7ree = 0;
		foreach($toplist_4georder_7ree as $gevalue_7ree){
		   $toplist_4ge_url_7ree[$gevalue_7ree] = $this->getgurl_7ree($gevalue_7ree,4);
		   if(in_array($gevalue_7ree,array('hy','jf','xm'))){
		   	$ranknum_7ree += 1;
		   }else{
		   	$threadnum_7ree += 1;
		   }
		}
		
		$gz2_width_7ree = 100/($ranknum_7ree+$threadnum_7ree*1.5);
		$gz_width_7ree = $gz2_width_7ree*1.5;	
	
		$pic_title1_7ree = $pic_title2_7ree = $pic_title3_7ree = '';  
		$thread_title1_7ree = $thread_title2_7ree = $thread_title3_7ree = $thread_title5_7ree =  $thread_title5_7ree =  $thread_title6_7ree =  $thread_title7_7ree = '';		
		$rank_title1_7ree = $rank_title2_7ree = $rank_title3_7ree = '';	
		
		$pickey_7ree = array('1','2','3');
		$threadkey_7ree = array('1','2','3','4','5','6','7');
		$rankkey_7ree = array('1','2','3');
		
		for($i1_7ree=0;$i1_7ree<3;$i1_7ree++){
			$pic_title_var[$i1_7ree] = $pic_order_7ree[$i1_7ree]."pic_title_7ree";
			$pic_title_7ree[$i1_7ree] = $vars_7ree[$pic_title_var[$i1_7ree]];
			$pic_url_7ree[$i1_7ree] = $this->getgurl_7ree($pic_order_7ree[$i1_7ree],1);
		}
		
		for($i2_7ree=0;$i2_7ree<7;$i2_7ree++){
			$thread_title_var[$i2_7ree] = $thread_order_7ree[$i2_7ree]."_title_7ree";
			$thread_title_7ree[$i2_7ree] = $vars_7ree[$thread_title_var[$i2_7ree]];
			$thread_url_7ree[$i2_7ree] = $this->getgurl_7ree($thread_order_7ree[$i2_7ree],2);
		}
		
		for($i3_7ree=0;$i3_7ree<3;$i3_7ree++){
			$rank_title_var[$i3_7ree] = $rank_order_7ree[$i3_7ree]."rank_title_7ree";
			$rank_title_7ree[$i3_7ree] = $vars_7ree[$rank_title_var[$i3_7ree]];
			$rank_url_7ree[$i3_7ree] = $this->getgurl_7ree($rank_order_7ree[$i3_7ree],3);
		}		
		
        if (!$agreement_7ree) return "<div class='tbms mtm mbm'>".lang('plugin/toplist_7ree', 'php_lang_agree_7ree')."</div>";
        
        $bangid_7ree = $vars_7ree['bangid_7ree'] ? unserialize($vars_7ree['bangid_7ree']) : array();
		if(in_array($_G['groupid'] , $bangid_7ree)) return '';
        
        
        if (!$onoff_7ree ||(!$vars_7ree[gidshow_7ree] && $_GET[gid])) return "";

		$weekarray=array(lang('plugin/toplist_7ree', 'php_lang_week0_7ree'),
					     lang('plugin/toplist_7ree', 'php_lang_week1_7ree'),
					  	 lang('plugin/toplist_7ree', 'php_lang_week2_7ree'),
						 lang('plugin/toplist_7ree', 'php_lang_week3_7ree'),
						 lang('plugin/toplist_7ree', 'php_lang_week4_7ree'),
				 		 lang('plugin/toplist_7ree', 'php_lang_week5_7ree'),
						 lang('plugin/toplist_7ree', 'php_lang_week6_7ree')
		);
        $date_7ree = gmdate(lang('plugin/toplist_7ree', 'php_lang_date_7ree'), $_G[timestamp] + $_G[setting][timeoffset] * 3600); 
        $week_7ree = $weekarray[gmdate("w", $_G[timestamp] + $_G[setting][timeoffset] * 3600)]; 
        $time_7ree = gmdate(lang('plugin/toplist_7ree', 'php_lang_time_7ree'), $_G[timestamp] + $_G[setting][timeoffset] * 3600); 

@require_once(DISCUZ_ROOT.'./source/discuz_version.php');
$cahcedir_7ree = DISCUZ_VERSION == "X2" ? './data/cache/cache_' : './data/sysdata/cache_';
///////////////////////////////�õ�ͼ///////////////
//�õ�ͼ��ȡ
//---����---start
$shownums	= min(intval($vars_7ree[picnum_7ree]) ? intval($vars_7ree[picnum_7ree]) : 5 , 20);
$searchnums	= $shownums;//��������.
$pic_cachename	= 'showpic_7ree';//������.����β����ͻ���޸�,ֻҪ����ͻ����Ӱ��ʹ��.

//---����---end
@include($cahcedir_7ree.$pic_cachename.'.php');

if($_G['uid'] && (!$cachetime_7ree || $_G['timestamp'] - $cachetime_7ree > $cachecycle_7ree * 60)) {

		$datapic = array();
	
		$cacheArray .= "\$cachetime_7ree=".$_G['timestamp'].";\n";

if($vars_7ree[newpic_title_7ree]){ //�Ƿ�������ͼƬ��Ŀ
	
	$query = DB::query("SELECT a.attachment,t.tid, t.fid, t.subject FROM ".DB::table('forum_threadimage')." a, ".DB::table('forum_thread')." t  WHERE t.tid=a.tid AND t.isgroup=0 AND t.displayorder>=0 AND t.dateline<{$_G[timestamp]} $not_fid_7ree GROUP BY a.tid ORDER BY a.tid DESC LIMIT $searchnums");
 				while($pic = DB::fetch($query)) {
					$pics['picpics'] = $_G['setting']['attachurl'].'forum/'.$pic['attachment'];
					$pics['attachment'] =$pic['attachment'];
					$pics['piclinks'] = 'forum.php?mod=viewthread%26tid='.$pic['tid'];
					$pics['pictexts'] = str_replace('\'', ' ',$pic['subject']);
					$pics['pictexts'] = cutstr($pics['pictexts'],$vars_7ree['piccutstr_7ree'],'');
					$pics['tid'] = $pic['tid'];
					$datapic[] = $pics;
				}
				$cacheArray .= "\$pic_7ree=".arrayeval($datapic).";\n";
	DB::free_result($query);
}

if($vars_7ree[digpic_title_7ree]){ //�Ƿ����þ���ͼƬ��Ŀ
	$query = DB::query("SELECT a.attachment,t.tid, t.fid, t.subject FROM ".DB::table('forum_threadimage')." a, ".DB::table('forum_thread')." t WHERE t.tid=a.tid AND t.digest>0 AND t.isgroup=0 AND t.displayorder>=0 AND t.dateline<{$_G[timestamp]} $not_fid_7ree GROUP BY a.tid ORDER BY a.tid DESC LIMIT $searchnums");
                 

				while($pic = DB::fetch($query)) {
					$pics['picpics'] = $_G['setting']['attachurl'].'forum/'.$pic['attachment'];
					$pics['attachment'] = $pic['attachment'];
					$pics['piclinks'] = 'forum.php?mod=viewthread%26tid='.$pic['tid'];
					$pics['pictexts'] = str_replace('\'', ' ',$pic['subject']);
					$pics['pictexts'] = cutstr($pics['pictexts'],$vars_7ree['piccutstr_7ree'],'');
					$pics['tid'] = $pic['tid'];
					$digdatapic[] = $pics;
				}
				$cacheArray .= "\$digpic_7ree=".arrayeval($digdatapic).";\n";
	DB::free_result($query);
}
				
	writetocache($pic_cachename, $cacheArray);
	@include(DISCUZ_ROOT.$cahcedir_7ree.$pic_cachename.'.php');

}


if(is_array($pic_7ree) && PHP_VERSION > 4.3 && $vars_7ree['picsorder_7ree']) shuffle($pic_7ree);
if(is_array($digpic_7ree) && PHP_VERSION > 4.3 && $vars_7ree['picsorder_7ree']) shuffle($digpic_7ree);

$i = 0;
$j = 0;
while ($j < $shownums && isset($pic_7ree[$i])) {
	if(is_readable($pic_7ree[$i]['picpics'])) {
		if($vars_7ree['thumbimg_7ree']) $pic_7ree[$i]['picpics'] = $this->getthumb_7ree($pic_7ree[$i]['picpics']);
		$showpicpics .= $comma.$pic_7ree[$i]['picpics'];
		$showpiclinks .= $comma.$pic_7ree[$i]['piclinks'];
		$showpictexts .= $comma.$pic_7ree[$i]['pictexts'];
		$comma = '|';
		$j++;
	}elseif($_G['setting']['ftp']['on']){
		if($vars_7ree['thumbimg_7ree']) $pic_7ree[$i]['attachment'] = $this->getthumb_7ree($pic_7ree[$i]['attachment']);
		$pic_7ree[$i]['picpics'] = $_G['setting']['ftp']['attachurl']."forum/".$pic_7ree[$i]['attachment'];
		$showpicpics .= $comma.$_G['setting']['ftp']['attachurl']."forum/".$pic_7ree[$i]['attachment'];
		$showpiclinks .= $comma.$pic_7ree[$i]['piclinks'];
		$showpictexts .= $comma.$pic_7ree[$i]['pictexts'];
		$j++;
	}
		$comma = '|';
		$i++;

	}
	
	
$i = 0;
$j = 0;
$comma = "";
while ($j < $shownums && isset($digpic_7ree[$i])) {
	if(is_readable($digpic_7ree[$i]['picpics'])) {
		if($vars_7ree['thumbimg_7ree']) $digpic_7ree[$i]['picpics'] = $this->getthumb_7ree($digpic_7ree[$i]['picpics']);
		$showdigpics .= $comma.$digpic_7ree[$i]['picpics'];
		$showdiglinks .= $comma.$digpic_7ree[$i]['piclinks'];
		$showdigtexts .= $comma.$digpic_7ree[$i]['pictexts'];
		$comma = '|';
		$j++;
	}elseif($_G['setting']['ftp']['on']){
		if($vars_7ree['thumbimg_7ree']) $digpic_7ree[$i]['attachment'] = $this->getthumb_7ree($digpic_7ree[$i]['attachment']);
	  	$digpic_7ree[$i]['picpics'] = $_G['setting']['ftp']['attachurl']."forum/".$digpic_7ree[$i]['attachment'];

	  	$showdigpics .= $comma.$_G['setting']['ftp']['attachurl']."forum/".$digpic_7ree[$i]['attachment'];
	    $showdiglinks .= $comma.$digpic_7ree[$i]['piclinks'];
	    $showdigtexts .= $comma.$digpic_7ree[$i]['pictexts'];
		$j++;
	}
	    $comma = '|';
	    $i++;

	}	




//////////////////�������ݵ���
        
        //��ȡ�������ֶ��趨
        $thread_column_7ree = "tid, fid, author, authorid, subject, dateline, lastpost, lastposter, views, replies, highlight";
        
        $cachename_toplist	= "toplist_7ree";//������.����β����ͻ���޸�,ֻҪ����ͻ����Ӱ��ʹ��.

		@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_toplist.'.php';

        if($_G['uid'] && (!$cachetime2_7ree || $_G['timestamp'] - $cachetime2_7ree > $cachecycle_7ree * 60)) {

		$colorarray = array('', '#EE1B2E', '#EE5023', '#996600', '#3C9D40', '#2897C5', '#2B65B7', '#8F2A90', '#EC1282');
		$curdata = "\$cachetime2_7ree=".$_G['timestamp'].";\n\n";
		
		
	
        if(!$vars_7ree['showgroup_7ree']){
        	$query = DB::query("SELECT fid FROM ".DB::table('forum_forum')." WHERE status = 3");
        	while($querylist = DB::fetch($query)) {
        	      $groupid_7ree[] = $querylist[fid];
        	}     
        	$banfid_7ree = array_merge($groupid_7ree,$forums2_7ree);
            $not_fid2_7ree = count($banfid_7ree) ? "AND t.fid NOT IN (".implode($banfid_7ree,",").")" : "";
        }	  		


		
		if($vars_7ree['showfidname_7ree']){
				$forumlist_7ree = $this->getforum_7ree();	
		}
//����
if($vars_7ree[new_title_7ree]){ //�Ƿ�����������Ŀ
        $hack_cut_str = $cutstr_7ree; //��������
        $hack_cut_strauthor = 9;
        $new_post_threadlist = array();
        $nthread = array();
        $query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE closed NOT LIKE 'moved|%' AND displayorder >=0 AND dateline + $newtime_7ree * 86400 > $_G[timestamp] AND dateline<{$_G[timestamp]} {$not_fid2_7ree} ORDER BY dateline DESC LIMIT 0, $shownum_7ree");
        
        while($nthread = DB::fetch($query)) {
        if($vars_7ree['showfidname_7ree']) $nthread['forumname'] = ereg_replace('<[^>]*>','',$forumlist_7ree[$nthread[fid]]);
        $nthread['view_subject'] = ereg_replace('&lt;|&gt;|<|>|\'','',cutstr($nthread['subject'],$hack_cut_str));
        $nthread['view_author'] = cutstr($nthread['author'],$hack_cut_strauthor);
        $nthread['date']= gmdate("Y-m-d H:i:s", $nthread['dateline'] + $_G[setting][timeoffset] * 3600);
        $nthread['date2']= gmdate("m-d H:i", $nthread['dateline'] + $_G[setting][timeoffset] * 3600);
        $nthread['lastreplytime']= gmdate("Y-m-d H:i:s", $nthread[lastpost] + ($_G[setting][timeoffset] * 3600));
        if($nthread['highlight'] && $highlight_7ree) {
                $string = sprintf('%02d', $nthread['highlight']);
                $stylestr = sprintf('%03b', $string[0]);
                $nthread['highlight'] = 'style="';
                $nthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
                $nthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
                $nthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
                $nthread['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
                $nthread['highlight'] .= '"';
        } else {
                $nthread['highlight'] = '';
        }
        $newpost_threadlist[] = $nthread;
}
        $curdata .= "\$new_post_threadlist = ".arrayeval($newpost_threadlist).";\n\n";
       	DB::free_result($query);
}       
        //�»ظ�
if($vars_7ree[rep_title_7ree]){ //�Ƿ�����������Ŀ
        $hack_cut_str = $cutstr_7ree; //��������
        $hack_cut_strauthor = 9;
        $new_reply_threadlist = array();
        $rthread = array();
        
        $query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE closed NOT LIKE 'moved|%' AND displayorder >=0 AND replies !=0 AND dateline + $reptime_7ree * 86400 > $_G[timestamp] AND dateline<{$_G[timestamp]} {$not_fid2_7ree} ORDER BY lastpost DESC LIMIT 0, $shownum_7ree");
        
        while($rthread = DB::fetch($query)) {
        if($vars_7ree['showfidname_7ree']) $rthread['forumname'] = ereg_replace('<[^>]*>','',$forumlist_7ree[$rthread[fid]]);
        $rthread['view_subject'] = ereg_replace('&lt;|&gt;|<|>|\'','',cutstr($rthread['subject'],$hack_cut_str));
        $rthread['view_lastposter'] = cutstr($rthread['lastposter'],$hack_cut_strauthor);
		$rthread['date']= gmdate("Y-m-d H:i:s", $rthread['dateline'] + $_G[setting][timeoffset] * 3600);
        $rthread['date2']= gmdate("m-d H:i", $rthread['dateline'] + $_G[setting][timeoffset] * 3600);
        $rthread['lastreplytime']= gmdate("Y-m-d H:i:s", $rthread[lastpost] + ($_G[setting][timeoffset] * 3600));
        if($rthread['highlight'] && $highlight_7ree) {
                $string = sprintf('%02d', $rthread['highlight']);
                $stylestr = sprintf('%03b', $string[0]);
                $rthread['highlight'] = 'style="';
                $rthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
                $rthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
                $rthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
                $rthread['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
                $rthread['highlight'] .= '"';
        } else {
                $rthread['highlight'] = '';
        }
        $replypost_threadlist[] = $rthread;
}
$curdata .= "\$reply_post_threadlist = ".arrayeval($replypost_threadlist).";\n\n";
		DB::free_result($query);
}
		
        //������
if($vars_7ree[dig_title_7ree]){ //�Ƿ����þ�������Ŀ   
        $hack_cut_str = $cutstr_7ree; //��������
        $hack_cut_strauthor = 9;
        $new_digest_threadlist = array();
        $dthread = array();
        
        $query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE closed NOT LIKE 'moved|%' AND displayorder >=0 AND digest in (1,2,3) AND displayorder >=0 AND dateline + $digtime_7ree * 86400 > $_G[timestamp] AND dateline<{$_G[timestamp]} {$not_fid2_7ree} ORDER BY dateline DESC LIMIT $shownum_7ree");
        
        while($dthread = DB::fetch($query)) {
        if($vars_7ree['showfidname_7ree']) $dthread['forumname'] = ereg_replace('<[^>]*>','',$forumlist_7ree[$dthread[fid]]);
        $dthread['view_subject'] = ereg_replace('&lt;|&gt;|<|>|\'','',cutstr($dthread['subject'],$hack_cut_str));
        $dthread['view_lastposter'] = cutstr($dthread['lastposter'],$hack_cut_strauthor);
		$dthread['date']= gmdate("Y-m-d H:i:s", $dthread['dateline'] + $_G[setting][timeoffset] * 3600);
	    $dthread['date2']= gmdate("m-d H:i", $dthread['dateline'] + $_G[setting][timeoffset] * 3600);
        $dthread['lastreplytime']= gmdate("Y-m-d H:i:s", $dthread[lastpost] + ($_G[setting][timeoffset] * 3600));
        if($dthread['highlight'] && $highlight_7ree) {
                $string = sprintf('%02d', $dthread['highlight']);
                $stylestr = sprintf('%03b', $string[0]);
                $dthread['highlight'] = 'style="';
                $dthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
                $dthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
                $dthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
                $dthread['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
                $dthread['highlight'] .= '"';
        } else {
                $dthread['highlight'] = '';
        }
        $digestpost_threadlist[] = $dthread;
}
$curdata .= "\$digest_post_threadlist = ".arrayeval($digestpost_threadlist).";\n\n";
		DB::free_result($query);
}

//����
if($vars_7ree[hot_title_7ree]){ //�Ƿ����þ�������Ŀ
        $hack_cut_str = $cutstr_7ree; //��������
        $hack_cut_strauthor = 9;
        $hot_post_threadlist = array();
        $hthread = array();
        
        if($vars_7ree['hotorder_7ree']=='view'){
        	$hotorderby_7ree = ' ORDER BY views ';
        }elseif($vars_7ree['hotorder_7ree']=='reply'){
            $hotorderby_7ree = ' ORDER BY replies ';
        }else{
        	$hotorderby_7ree = ' ORDER BY views ';
        }
        
        $query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE closed NOT LIKE 'moved|%' AND displayorder >=0 AND dateline + $hottime_7ree * 86400 > $_G[timestamp] AND dateline<{$_G[timestamp]} {$not_fid2_7ree} {$hotorderby_7ree} DESC LIMIT 0, $shownum_7ree");
        
        while($hthread = DB::fetch($query)) {
        if($vars_7ree['showfidname_7ree']) $hthread['forumname'] = ereg_replace('<[^>]*>','',$forumlist_7ree[$hthread[fid]]);
        $hthread['view_subject'] = ereg_replace('&lt;|&gt;|<|>|\'','',cutstr($hthread['subject'],$hack_cut_str));
        $hthread['view_author'] = cutstr($hthread['author'],$hack_cut_strauthor);
        $hthread['date']= gmdate("Y-m-d H:i:s", $hthread['dateline'] + $_G[setting][timeoffset] * 3600);
        $hthread['lastreplytime']= gmdate("Y-m-d H:i:s", $hthread[lastpost] + ($_G[setting][timeoffset] * 3600));
        $hthread['date2']= gmdate("m-d H:i", $hthread['lastpost'] + $_G[setting][timeoffset] * 3600);
        if($hthread['highlight'] && $highlight_7ree) {
                $string = sprintf('%02d', $hthread['highlight']);
                $stylestr = sprintf('%03b', $string[0]);
                $hthread['highlight'] = 'style="';
                $hthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
                $hthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
                $hthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
                $hthread['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
                $hthread['highlight'] .= '"';
        } else {
                $hthread['highlight'] = '';
        }
        $hotpost_threadlist[] = $hthread;
}
        $curdata .= "\$hot_post_threadlist = ".arrayeval($hotpost_threadlist).";\n\n";
        
        	DB::free_result($query);
}   
        
        
        //����fid1
if($vars_7ree[diy1_title_7ree]){ //�Ƿ�����DIY1����Ŀ
        $hack_cut_str = $cutstr_7ree; //��������
        $hack_cut_strauthor = 9;
        $new_post1_threadlist = array();
        $nthread1 = array();
         $query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE displayorder >=0 AND dateline<{$_G[timestamp]} {$fid1_where_7ree} ORDER BY dateline DESC LIMIT 0, $shownum_7ree");
        
        while($nthread1 = DB::fetch($query)) {
        if($vars_7ree['showfidname_7ree']) $nthread1['forumname'] = ereg_replace('<[^>]*>','',$forumlist_7ree[$nthread1[fid]]);
        $nthread1['view_subject'] = ereg_replace('&lt;|&gt;|<|>|\'','',cutstr($nthread1['subject'],$hack_cut_str));
        $nthread1['view_author'] = cutstr($nthread1['author'],$hack_cut_strauthor);
        $nthread1['date']= gmdate("Y-m-d H:i:s", $nthread1['dateline'] + $_G[setting][timeoffset] * 3600);
        $nthread1['date2']= gmdate("m-d H:i", $nthread1['dateline'] + $_G[setting][timeoffset] * 3600);
        $nthread1['lastreplytime']= gmdate("Y-m-d H:i:s", $nthread1[lastpost] + ($_G[setting][timeoffset] * 3600));
        if($nthread1['highlight'] && $highlight_7ree) {
                $string = sprintf('%02d', $nthread1['highlight']);
                $stylestr = sprintf('%03b', $string[0]);
                $nthread1['highlight'] = 'style="';
                $nthread1['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
                $nthread1['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
                $nthread1['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
                $nthread1['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
                $nthread1['highlight'] .= '"';
        } else {
                $nthread1['highlight'] = '';
        }
        $newpost1_threadlist[] = $nthread1;
}
        $curdata .= "\$new_post1_threadlist = ".arrayeval($newpost1_threadlist).";\n\n";
        
        DB::free_result($query);
}


        //����fid2
if($vars_7ree[diy2_title_7ree]){ //�Ƿ�����DIY2����Ŀ
        $hack_cut_str = $cutstr_7ree; //��������
        $hack_cut_strauthor = 9;
        $new_post2_threadlist = array();
        $nthread2 = array();
        
        $query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE displayorder >=0 AND dateline<{$_G[timestamp]} {$fid2_where_7ree} ORDER BY dateline DESC LIMIT 0, $shownum_7ree");        
        while($nthread2 = DB::fetch($query)) {
        if($vars_7ree['showfidname_7ree']) $nthread2['forumname'] = ereg_replace('<[^>]*>','',$forumlist_7ree[$nthread2[fid]]);
        $nthread2['view_subject'] = ereg_replace('&lt;|&gt;|<|>|\'','',cutstr($nthread2['subject'],$hack_cut_str));
        $nthread2['view_author'] = cutstr($nthread2['author'],$hack_cut_strauthor);
        $nthread2['date']= gmdate("Y-m-d H:i:s", $nthread2['dateline'] + $_G[setting][timeoffset] * 3600);
        $nthread2['date2']= gmdate("m-d H:i", $nthread2['dateline'] + $_G[setting][timeoffset] * 3600);
        $nthread2['lastreplytime']= gmdate("Y-m-d H:i:s", $nthread2[lastpost] + ($_G[setting][timeoffset] * 3600));
        if($nthread2['highlight'] && $highlight_7ree) {
                $string = sprintf('%02d', $nthread2['highlight']);
                $stylestr = sprintf('%03b', $string[0]);
                $nthread2['highlight'] = 'style="';
                $nthread2['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
                $nthread2['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
                $nthread2['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
                $nthread2['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
                $nthread2['highlight'] .= '"';
        } else {
                $nthread2['highlight'] = '';
        }
        $newpost2_threadlist[] = $nthread2;
		}
        $curdata .= "\$new_post2_threadlist = ".arrayeval($newpost2_threadlist).";\n\n";
        DB::free_result($query);
}   
        
if($vars_7ree['tui_title_7ree']){ //�Ƿ������Ƽ���Ŀ

        $tuijian = array();
        
        $query = DB::query("SELECT * FROM ".DB::table('toplist_push_7ree')." ORDER BY id_7ree DESC LIMIT 0, $shownum_7ree");        
        while($tuijian = DB::fetch($query)) {
        if($vars_7ree['showfidname_7ree']) $tuijian['forumname'] = ereg_replace('<[^>]*>','',$tuijian['fname_7ree']);
        $tuijian['view_subject'] = ereg_replace('&lt;|&gt;|<|>|\'','',cutstr($tuijian['subject_7ree'],$hack_cut_str));
        $tuijian['view_author'] = cutstr($tuijian['author_7ree'],$hack_cut_strauthor);
        $tuijian['date']= gmdate("Y-m-d H:i:s", $tuijian['time_7ree'] + $_G[setting][timeoffset] * 3600);
        $tuijian['date2']= gmdate("m-d H:i", $tuijian['time_7ree'] + $_G[setting][timeoffset] * 3600);
        $tuijian['lastreplytime']= gmdate("Y-m-d H:i:s", $tuijian[lastpost] + ($_G[setting][timeoffset] * 3600));
        if($tuijian['highlight_7ree'] && $highlight_7ree) {
                $string = sprintf('%02d', $tuijian['highlight_7ree']);
                $stylestr = sprintf('%03b', $string[0]);
                $tuijian['highlight'] = 'style="';
                $tuijian['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
                $tuijian['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
                $tuijian['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
                $tuijian['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
                $tuijian['highlight'] .= '"';
        } else {
                $tuijian['highlight'] = '';
        }
        $tuijian_7ree_threadlist[] = $tuijian;
		}
        $curdata .= "\$tuijian_threadlist_7ree = ".arrayeval($tuijian_7ree_threadlist).";\n\n";
        DB::free_result($query);
        
}  



	writetocache("$cachename_toplist", $curdata);
		@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_toplist.'.php';
}        


$cachename_ranklist	= "ranklist_7ree";//������.����β����ͻ���޸�,ֻҪ����ͻ����Ӱ��ʹ��.

@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_ranklist.'.php';

if($_G['uid'] && (!$cachetime3_7ree || $_G['timestamp'] - $cachetime3_7ree > $cachecycle_7ree * 60)) {

$curdata = "\$cachetime3_7ree=".$_G['timestamp'].";\n\n";

	
//��Ա��Ծ��
	$ranktime_7ree = $this->gettime_7ree($membercycle_7ree);

if($vars_7ree[acvrank_title_7ree]){ //�Ƿ����û�Ծ����Ŀ

$query = DB::query("SELECT author, authorid, COUNT(*) AS postnum_7ree FROM ".DB::table('forum_post')." WHERE dateline > {$ranktime_7ree} AND authorid <> '' GROUP BY authorid ORDER BY postnum_7ree DESC LIMIT $newbienum_7ree");
        while($postmember_7ree = DB::fetch($query)) {
           		if($vars_7ree['onoffavatar_7ree']){
                	$postmember_7ree[avatar_7ree] = avatar($postmember_7ree[authorid], small, TRUE, FALSE, TRUE);
         	     	if($this->imgexist_7ree($postmember_7ree[avatar_7ree])){              	
        				$postmember_7ree[avatar_7ree] = $postmember_7ree[avatar_7ree];
        			}else{
        				$postmember_7ree[avatar_7ree] = $_G['setting']['ucenterurl'].'/images/noavatar_small.gif';;
        			}        			
        		}
                $post_memberlist_7ree[] = $postmember_7ree;
        }      	
        
		$curdata .= "\$postmember_list_7ree = ".arrayeval($post_memberlist_7ree).";\n\n";
        DB::free_result($query);
}   
        		
//�»�Ա

if($vars_7ree[newrank_title_7ree]){ //�Ƿ������»�Ա��Ŀ	
		$query = DB::query("SELECT username, uid, regdate FROM ".DB::table('common_member')." WHERE uid <> '' ORDER BY uid DESC LIMIT $newbienum_7ree");
        while($member_7ree = DB::fetch($query)) {
           		$member_7ree['regdate'] = gmdate("m-d H:i", $member_7ree[regdate] + ($_G[setting][timeoffset] * 3600));
           		if($vars_7ree['onoffavatar_7ree']){
           		    $member_7ree[avatar_7ree] = avatar($member_7ree[uid], small, TRUE, FALSE, TRUE);
                	if($this->imgexist_7ree($member_7ree[avatar_7ree])){
        				$member_7ree[avatar_7ree] = $member_7ree[avatar_7ree];
        			}else{
        				$member_7ree[avatar_7ree] = $_G['setting']['ucenterurl'].'/images/noavatar_small.gif';;
        			}
        		}
                $newbielist_7ree[] = $member_7ree;
        }      	
        
		$curdata .= "\$newbie_list_7ree = ".arrayeval($newbielist_7ree).";\n\n";
        DB::free_result($query);
}   
        		


//���ְ�

if($vars_7ree[extrank_title_7ree]){ //�Ƿ����û��ְ���Ŀ

		if(!$vars_7ree['rankext_7ree']){
			$ranktitle_7ree = lang('plugin/toplist_7ree','php_lang_fen_7ree');
			$member_query_7ree = "SELECT username, uid, credits FROM ".DB::table('common_member')." WHERE uid >0 ORDER BY credits DESC LIMIT $newbienum_7ree";		    
		}else{
			$ranktitle_7ree = $_G['setting']['extcredits'][$vars_7ree['rankext_7ree']]['title'];
			$thisextcredits_7ree = 'extcredits'.$vars_7ree['rankext_7ree'];
		    $member_query_7ree = "SELECT uid, $thisextcredits_7ree AS credits FROM ".DB::table('common_member_count')." WHERE uid >0 ORDER BY {$thisextcredits_7ree} DESC LIMIT $newbienum_7ree";
		}
	
		$query = DB::query($member_query_7ree);

        while($creditarray_7ree = DB::fetch($query)) {
        		if(!$creditarray_7ree['username']) $creditarray_7ree['username'] = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid = '$creditarray_7ree[uid]'");
                if($vars_7ree['onoffavatar_7ree']){
                	$creditarray_7ree[avatar_7ree] = avatar($creditarray_7ree[uid], small, TRUE, FALSE, TRUE);
                	if($this->imgexist_7ree($creditarray_7ree[avatar_7ree])){
        				$creditarray_7ree[avatar_7ree] = $creditarray_7ree[avatar_7ree];
        			}else{
        				$creditarray_7ree[avatar_7ree] = $_G['setting']['ucenterurl'].'/images/noavatar_small.gif';
        			}
        		}
        		$creditarray_7ree['credits']=$creditarray_7ree['credits'].$ranktitle_7ree;
                $credit_7ree[] = $creditarray_7ree;
        }      	
		$curdata .= "\$credit_list_7ree = ".arrayeval($credit_7ree).";\n\n";
        DB::free_result($query);
}  



		writetocache("$cachename_ranklist", $curdata);
		@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_ranklist.'.php';
}    


		include template('toplist_7ree:toplist_7ree');

		return $return;
}

function gettime_7ree($format_7ree){
		global $_G;
		$return_7ree = 0;

		switch ($format_7ree){
		case 1://����
		  	$return_7ree = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	break;
		case 2://����
		  	$return_7ree = mktime(0, 0, 0, gmdate("m",strtotime("last Monday") + $_G[setting][timeoffset] * 3600),date("d",strtotime("last Monday") + $_G[setting][timeoffset] * 3600),date("Y",strtotime("last Monday") + $_G[setting][timeoffset] * 3600));
		  	break;
		case 3://����
  			$return_7ree = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),1,gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
  			break;
		case 4://������
			$season = ceil((gmdate("n",$_G[timestamp] + $_G[setting][timeoffset] * 3600))/3);
			$return_7ree = mktime(0, 0, 0,$season*3-3+1,1,date('Y'));
		  	break;
		case 5://�����
		  	$return_7ree = mktime(0,0,0,1,1,gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
 		 	break;
		default:
 		 	$return_7ree = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		}

		return $return_7ree;

}


function getthumb_7ree($imgname_7ree){
	
	$thumb_name_array = array();
	$thumb_name_num = 0;
	$return_7ree = '';
	$thumb_name_array = explode('.',$imgname_7ree);
    $thumb_name = ".thumb.jpg";
	$return_7ree = is_readable($imgname_7ree.$thumb_name) ? $imgname_7ree.$thumb_name : $imgname_7ree;
	return $return_7ree;

}

function getforum_7ree(){
	$return_7ree = array();
	global $_G;
	if(!isset($_G['cache']['forums'])) {
        loadcache('forums');
    }
	if(!isset($_G['cache']['groupindex'])){
        loadcache('groupindex');
    } 
    $allfid_7ree = $_G['cache']['forums'] + $_G['cache']['groupindex']['randgroupdata'];
    foreach($allfid_7ree as $fid => $forum) {
		$return_7ree[$fid]=$forum['name'];
	}
 	return $return_7ree;
}

function imgexist_7ree($url){
	global $_G;
	$vars_7ree = $_G['cache']['plugin']['toplist_7ree'];
    $found = FALSE;
    if ($vars_7ree['avaexit_7ree']){
		$url = str_replace($_G['setting']['siteurl'],'./',$url);
		$found = file_exists($url);     
    }else{
        $found = TRUE;
    }
    return $found;
}     

/**/
function getgurl_7ree($ggid_7ree,$gtype_7ree){
	global $_G;
	$vars_7ree = $_G['cache']['plugin']['toplist_7ree'];
	$return_7ree = '';
	
	if($gtype_7ree==1){//ʮ����ͼƬ��Ŀ
				if($ggid_7ree=='new'){
						$return_7ree = $vars_7ree['newpic_url_7ree'];
				}elseif($ggid_7ree=='dig'){
						$return_7ree = $vars_7ree['digpic_url_7ree'];
				}elseif($ggid_7ree=='ads'){
						$return_7ree = $vars_7ree['adspic_url_7ree'];
				}else{
						$return_7ree = '';
				}
	}elseif($gtype_7ree==2){//ʮ����������Ŀ
				if($ggid_7ree=='new'){
						$return_7ree = $vars_7ree['newpost_url_7ree'];
				}elseif($ggid_7ree=='rep'){
						$return_7ree = $vars_7ree['newreply_url_7ree'];
				}elseif($ggid_7ree=='dig'){
						$return_7ree = $vars_7ree['digpost_url_7ree'];
				}elseif($ggid_7ree=='hot'){
						$return_7ree = $vars_7ree['hotpost_url_7ree'];
				}elseif($ggid_7ree=='diy1'){
						$return_7ree = $vars_7ree['diy1_url_7ree'];
				}elseif($ggid_7ree=='diy2'){
						$return_7ree = $vars_7ree['diy2_url_7ree'];
				}elseif($ggid_7ree=='tui'){
						$return_7ree = $vars_7ree['tuijian_url_7ree'];
				}else{
						$return_7ree = $vars_7ree[''];
				}
	}elseif($gtype_7ree==3){//ʮ�����Ա��Ŀ
				if($ggid_7ree=='acv'){
						$return_7ree = $vars_7ree['huoyue_url_7ree'];
				}elseif($ggid_7ree=='ext'){
						$return_7ree = $vars_7ree['jifen_url_7ree'];
				}elseif($ggid_7ree=='new'){
						$return_7ree = $vars_7ree['newbie_url_7ree'];
				}else{
						$return_7ree = '';
				}
	}elseif($gtype_7ree==4){//�ĸ�ģ��
				if($ggid_7ree=='xt'){
						$return_7ree = $vars_7ree['newpic_url_7ree'];
				}elseif($ggid_7ree=='jt'){
						$return_7ree = $vars_7ree['digpic_url_7ree'];
				}elseif($ggid_7ree=='gt'){
						$return_7ree = $vars_7ree['adspic_url_7ree'];
				}elseif($ggid_7ree=='xz'){
						$return_7ree = $vars_7ree['newpost_url_7ree'];
				}elseif($ggid_7ree=='xh'){
						$return_7ree = $vars_7ree['newreply_url_7ree'];
				}elseif($ggid_7ree=='jz'){
						$return_7ree = $vars_7ree['digpost_url_7ree'];
				}elseif($ggid_7ree=='rz'){
						$return_7ree = $vars_7ree['hotpost_url_7ree'];
				}elseif($ggid_7ree=='d1'){
						$return_7ree = $vars_7ree['diy1_url_7ree'];
				}elseif($ggid_7ree=='d2'){
						$return_7ree = $vars_7ree['diy2_url_7ree'];
				}elseif($ggid_7ree=='tj'){
						$return_7ree = $vars_7ree['tuijian_url_7ree'];
				}elseif($ggid_7ree=='hy'){
						$return_7ree = $vars_7ree['huoyue_url_7ree'];
				}elseif($ggid_7ree=='jf'){
						$return_7ree = $vars_7ree['jifen_url_7ree'];
				}elseif($ggid_7ree=='xm'){
						$return_7ree = $vars_7ree['newbie_url_7ree'];
				}else{
						$return_7ree = '';
				}
	
	}
	$return_7ree = trim($return_7ree) ? trim($return_7ree) : "javascript:void(0);";
	

 	return $return_7ree;
}


}




?>
