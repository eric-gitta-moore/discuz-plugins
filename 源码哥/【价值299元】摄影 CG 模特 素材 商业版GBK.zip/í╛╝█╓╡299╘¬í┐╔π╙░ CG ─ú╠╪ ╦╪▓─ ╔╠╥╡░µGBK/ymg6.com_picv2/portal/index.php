<?php echo 'Դ��磨YMG6.COM������Ȩ���У�����ؾ������� www.ymg6.com';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<div class="bus_w100 bus_columall bus_img">
	<div class="l_colum bus_colum bus_slider">
	  <!--[diy=diy_bus_l_colum]--><div id="diy_bus_l_colum" class="area"></div><!--[/diy]-->
	</div>
	<div class="r_colum">
	  <!--[diy=diy_bus_r_colum]--><div id="diy_bus_r_colum" class="area"></div><!--[/diy]-->
	</div>
</div>
<div class="clear"></div>
<div class="bus_index_box">
	<div class="tit"><h3>�����Ƽ�-����</h3><a class="more" target="_blank" href="#">ԭ�����</a><a class="more" target="_blank" href="#">����psd</a><a class="more" target="_blank" href="#">��������</a></div>
	<div class="bushr_h"></div>
	<div class="busbox_bd">
	<!--[diy=diy_busbox_bd]--><div id="diy_busbox_bd" class="area"></div><!--[/diy]-->
	</div>
	
</div>

<script type="text/javascript" src="template/mobanbus_picv2/mobanbus_st/js/mobanbus.js"></script>
<script id="jsID" type="text/javascript">jQuery("#slideBox_top").slide({mainCell:".bd ul",effect:"left",autoPlay:true,easing:"easeInOutQuart",delayTime:500});</script>
<!--{template common/footer}-->
