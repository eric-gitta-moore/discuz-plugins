<?php echo 'Դ��磨YMG6.COM������Ȩ���У�����ؾ������� www.ymg6.com';exit;?>
        	<dl>
            	<dt>
				$_G['forum']['name']
				</dt>
                <dd>
                    <div class="bus_w100 bus_fl">
                        <p class="bus_benban">�������⣺<em class="bus_num">$_G[forum][threads]</em>, ���ո��£�<em class="bus_num">$_G[forum][todayposts]</em></p>
                   	</div>
					<div class="clear"></div>
						<span class="bus_rules bus_fl">
						<!--{if $_G['forum'][description]}-->$_G['forum'][description]<!--{/if}-->
						<!--{if $_G['page'] == 1 && $_G['forum']['rules']}--><br />$_G['forum'][rules]<!--{/if}-->
						</span>
					<!--{if $_G['forum']['ismoderator']}-->
					<div class="bus_w100 bus_fl">
						<p class="recycle">
					
						<!--{if $_G['forum']['recyclebin']}-->
							<a href="{if $_G['adminid'] == 1}admin.php?mod=forum&action=recyclebin&frames=yes{elseif $_G['forum']['ismoderator']}forum.php?mod=modcp&action=recyclebin&fid=$_G[fid]{/if}" target="_blank">{lang forum_recyclebin}</a>
						<!--{/if}-->
						<!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->
						<!--{if $_G['forum']['status'] != 3}-->
								| <a href="forum.php?mod=modcp&fid=$_G[fid]">{lang modcp}</a>
							<!--{else}-->
								| <a href="forum.php?mod=group&action=manage&fid=$_G[fid]">{lang modcp}</a>
							<!--{/if}-->
						<!--{/if}-->
						</p>
					</div>
					<!--{/if}-->
					
                	<div class="bus_w100 tit">
                        <p>
                        <!--{eval $fav = C::t('home_favorite')->fetch_by_id_idtype($_G[fid], 'fid', $_G['uid']);}-->
						<!--{if $_G['uid']}-->
							<!--{if $fav }-->
							<a href="home.php?mod=spacecp&ac=favorite&op=delete&favid={eval echo $fav['favid']}" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" title="ȡ����ע">�ѹ�ע <strong class="xi1" id="number_favorite" {if !$_G[forum][favtimes]} style="display:none;"{/if}>(<span id="number_favorite_num">$_G[forum][favtimes]</span>)</strong></a>
							<!--{else}--> 
							<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);">+ ��ע <strong class="xi1" id="number_favorite" {if !$_G[forum][favtimes]} style="display:none;"{/if}>(<span id="number_favorite_num">$_G[forum][favtimes]</span>)</strong></a>
							<!--{/if}-->
						<!--{else}-->
							<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);">+ ��ע <strong class="xi1" id="number_favorite" {if !$_G[forum][favtimes]} style="display:none;"{/if}>(<span id="number_favorite_num">$_G[forum][favtimes]</span>)</strong></a>
						<!--{/if}-->
						<!--{if !$_G['forum_thread']['is_archived']}--><a class="view_post" {if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} href="javascript:;" title="{lang send_posts}">����������</a><!--{/if}-->
                        </p>
                   	</div>
			   
			    </dd>
            </dl>
