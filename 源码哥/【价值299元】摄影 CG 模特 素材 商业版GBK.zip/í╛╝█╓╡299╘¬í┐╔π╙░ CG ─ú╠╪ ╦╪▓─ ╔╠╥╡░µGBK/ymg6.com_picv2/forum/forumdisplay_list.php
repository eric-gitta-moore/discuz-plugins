<?php echo '源码哥（YMG6.COM），版权所有，盗版必究，官网 www.ymg6.com';exit;?>
