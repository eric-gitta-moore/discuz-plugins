<?php


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$pluginName = 'svipzan_tixians';
$formhash=daddslashes($_GET['formhash']);
if(daddslashes($_GET['do'])=='update' && $formhash==formhash()){
		$id = intval($_GET['id']);
	DB::query("UPDATE ".DB::table('svipzan_tixian_log')." SET biaoji = 1 WHERE id ='$id'");
	cpmsg(lang('plugin/'.$pluginName, 'shenheokinfo'), 'action=plugins&operation=config&identifier='.$pluginName.'&pmod=admin_tixian', 'succeed',dreferer());
}

showformheader('plugins&operation=config&identifier='.$pluginName.'&pmod=details');
showtableheader(lang('plugin/'.$pluginName, 'stxjl'));

showsubtitle(array('',lang('plugin/'.$pluginName, 'stixiandate'),'ID',lang('plugin/'.$pluginName, 'stxfs'),lang('plugin/'.$pluginName, 'stxzh'),lang('plugin/'.$pluginName, 'stixianjine'),lang('plugin/'.$pluginName, 'sstatus'),lang('plugin/'.$pluginName, 'sdo')));

$query = DB::query("SELECT * FROM ".DB::table('svipzan_tixian_log')." WHERE biaoji = 2");
$hash=formhash();
while ($result = DB::fetch($query)){

	showtablerow('','', array(
		'',
		$result['tixian_time'],
		$id=$result['id'],
		$result['tixian_name']=='alipay' ? lang('plugin/'.$pluginName, 'salipay'): lang('plugin/'.$pluginName, 'swxpay'),
		$result['tixian_num'],
		"<b><span style='color:#f98c16;'>".$result['jine'].lang('plugin/'.$pluginName, 'yuan')."</span></b>",
		$result['biaoji']=='2' ? "<span style='color:red;'>".lang('plugin/'.$pluginName, 'sdaishenhe')."</span>": lang('plugin/'.$pluginName, 'sunknowerror'),
		$result['biaoji'] == '2' ? "<a href=\"admin.php?action=plugins&operation=config&identifier=svipzan_tixians&pmod=admin_tixian&formhash=".($hash)."&do=update&id=".($id)."\">".lang('plugin/'.$pluginName, 'shenheok')."</a>": lang('plugin/'.$pluginName, 'sunknowerror')
	));
}

showtablefooter();
showformfooter();

?>