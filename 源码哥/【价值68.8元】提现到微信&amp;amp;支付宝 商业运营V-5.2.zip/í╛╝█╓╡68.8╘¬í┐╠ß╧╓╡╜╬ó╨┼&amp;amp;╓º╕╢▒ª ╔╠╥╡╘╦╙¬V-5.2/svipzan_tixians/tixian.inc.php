<?php

/**

 * 	   QQ：1245941148

 *	   time：2016-11-16 16:30:57

 */



if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if(!$_G['uid']) {
    showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
global $_G;
$config = $_G['cache']['plugin']['svipzan_tixians'];
$kaiguan = $config['kaiguan'];
$jifenlist= $config['jifenlist'];
$minjine= $config['minjine'];
$bili= $config['bili'];
$shuoming= $config['shuoming'];
$nav_name=$config['nav_name'];
$copyright=$config['copyright'];
$root='source/plugin/svipzan_tixians/template/';
$extcredits = 'extcredits'.$jifenlist;
$userinfo = DB::query("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$_G[uid]'");
while($rowinfo = DB::fetch($userinfo)){
	$yue = $rowinfo[$extcredits];
}
$yushu=$yue % $bili;
$jine=($yue - $yushu) / $bili;


if($kaiguan == '0'){
	showmessage('svipzan_tixians:noopen');
};
if($jifenlist == ''){
	showmessage('svipzan_tixians:extcrediterror');
	$jine="0";
};


include template('svipzan_tixians:tixian');