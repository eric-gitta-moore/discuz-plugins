<?php


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

?>
<script language="javascript">
document.write('<if' + 'rame src="http://www.ymg6.com/gg/addon.php?/?@25839.developer" width="100%" height="1000" scrolling="yes" frameborder="0"></if' + 'rame>');		  
</script>