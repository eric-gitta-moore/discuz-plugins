<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_svipzan_tixians {

 function global_footerlink(){	

		global $_G;
        $date= $_G['cache']['plugin']['svipzan_tixians'];
        $kaiguan= $date['kaiguan'];
        $nav_name=$date['nav_name'];
		$root='source/plugin/svipzan_tixians/template/';
		 $result="<a href=\"javascript:;\" onclick=\"showWindow('svipzan_tixians','plugin.php?id=svipzan_tixians:tixian')\"><font color='red'><strong>".$nav_name."</strong></font> </a>";
		

		return $result;
}
 function global_cpnav_extra1(){	

		global $_G;
        $date= $_G['cache']['plugin']['svipzan_tixians'];
        $kaiguan= $date['kaiguan'];
        $nav_name=$date['nav_name'];
		$root='source/plugin/svipzan_tixians/template/';
		 $result="<a href=\"javascript:;\" onclick=\"showWindow('svipzan_tixians','plugin.php?id=svipzan_tixians:tixian')\"><font color='red'><strong>".$nav_name."</strong></font> </a>";
		

		return $result;
}
}
class plugin_svipzan_tixians_home extends plugin_svipzan_tixians  {
	
 function spacecp_credit_extra(){	

			global $_G;
        $date= $_G['cache']['plugin']['svipzan_tixians'];
        $kaiguan= $date['kaiguan'];
        $nav_name=$date['nav_name'];
		$root='source/plugin/svipzan_tixians/template/';
		 $result="<a href=\"javascript:;\" onclick=\"showWindow('svipzan_tixians','plugin.php?id=svipzan_tixians:tixian')\"><font color='red'><strong>".$nav_name."</strong></font> </a>";
		

		return $result;
}


}
?>