<?php
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_svipzan_tixian_log`;
CREATE TABLE IF NOT EXISTS `pre_svipzan_tixian_log` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(5) unsigned NOT NULL,
  `biaoji` int(5) unsigned NOT NULL,
  `jine` bigint(50) unsigned NOT NULL,
  `tixian_time` datetime NOT NULL,
  `daozhang_time` datetime NOT NULL,
  `beizhu` text NOT NULL,
  `people` text NOT NULL,
  `tixian_name` text NOT NULL,
  `tixian_num` text NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT AUTO_INCREMENT=1 ;


EOF;

runquery($sql);

$finish = TRUE;

?>