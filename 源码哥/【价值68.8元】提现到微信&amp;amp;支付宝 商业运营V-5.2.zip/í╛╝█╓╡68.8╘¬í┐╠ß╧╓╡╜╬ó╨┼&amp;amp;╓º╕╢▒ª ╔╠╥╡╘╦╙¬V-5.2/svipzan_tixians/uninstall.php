<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE pre_svipzan_tixian_log;
EOF;


$finish = TRUE;
?>