<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if(!$_G['uid']) {
    showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
global $_G;
$config = $_G['cache']['plugin']['svipzan_tixians'];
$kaiguan = $config['kaiguan'];
$jifenlist= $config['jifenlist'];
$minjine= $config['minjine'];
$bili= $config['bili'];
$shuoming= $config['shuoming'];
$nav_name=$config['nav_name'];
$copyright=$config['copyright'];
$root='source/plugin/svipzan_tixians/template/';
$time=date("Y-m-d h:i:s");
$extcredits = 'extcredits'.$jifenlist;
$userinfo = DB::query("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$_G[uid]'");
while($rowinfo = DB::fetch($userinfo)){
	$yue = $rowinfo[$extcredits];
}
$yushu=$yue % $bili;
$jine=($yue - $yushu) / $bili;



$formhash = daddslashes(htmlspecialchars(stripslashes($_POST['formhash'])));
$tixiantype = daddslashes(htmlspecialchars(stripslashes($_POST['tixiantype'])));
$tixianjine = daddslashes(htmlspecialchars(stripslashes($_POST['tixianjine'])));
$tixianzhanghao = daddslashes(htmlspecialchars(stripslashes($_POST['tixianzhanghao'])));

$tixianjifen=$tixianjine * $bili;

$jianjifen=$yue-$tixianjifen;
if($formhash != $_G['formhash']){
	showmessage('svipzan_tixians:formhasherror');
};

if($tixianjine == ''){
	showmessage('svipzan_tixians:tixianjineerror');
};
if($tixianjine < $minjine){
	showmessage('svipzan_tixians:tixianjineerror');
};
if($tixianzhanghao == ''){
	showmessage('svipzan_tixians:tixianzhanghaoerror');
};
if($jine < $tixianjine){
	showmessage('svipzan_tixians:yuebuzu');
};
if($tixianjine == '0'){
	showmessage('svipzan_tixians:lingyue');
};
if($formhash == $_G['formhash']){
$beizhu=lang('plugin/svipzan_tixians', 'beizhu');
$tixian=DB::query("REPLACE INTO ".DB::table('svipzan_tixian_log')." (id,uid,biaoji,jine,tixian_time,daozhang_time,beizhu,people,tixian_name,tixian_num,name) VALUES ('','$_G[uid]','2','$tixianjine','$time','','--','','$tixiantype','$tixianzhanghao','')");
$tixian1=DB::query("UPDATE ".DB::table('common_member_count')." SET {$extcredits} = '$jianjifen' WHERE uid = '$_G[uid]'");
showmessage('svipzan_tixians:tixian_ok',dreferer());
}