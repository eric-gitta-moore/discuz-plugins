<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/micxp_down/setting.class.php';
MicxpDownSetting::menu();

$Mlang = $scriptlang['micxp_down'];
$op = preg_replace('/[^\[A-Za-z0-9_\]]/', '', getgpc('op'));
if(!$op) {
	if(!submitcheck('submit')) {
		showformheader('plugins&operation=config&identifier=micxp_down&pmod=huandeng');
		showtableheader();
		showsubtitle(array('', 'display_order', 'name', 'url',  'available', ''));
		showtagheader('tbody', '', true);
		$hdlist =  array();

		foreach(C::t('#micxp_down#micxp_down_huandeng')->fetch_all_sort() as $nav) {
			$hdlist[$nav['id']] = $nav;
		}

		foreach($hdlist as $nav) {
			if($nav['available'] < 0) {
				continue;
			}
			showtablerow('', array('class="td25"', 'class="td25"', '', '', '',''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$nav[id]\">",
			"<input type=\"text\" class=\"txt\" size=\"2\" name=\"displayordernew[$nav[id]]\" value=\"$nav[displayorder]\">",
			"<div><input type=\"text\" class=\"txt\" size=\"15\" name=\"namenew[$nav[id]]\" value=\"".dhtmlspecialchars($nav['name'])."\">",

			"<input type=\"text\" class=\"txt\" size=\"15\" name=\"urlnew[$nav[id]]\" value=\"".dhtmlspecialchars($nav['url'])."\">",
			"<input class=\"checkbox\" type=\"checkbox\" name=\"availablenew[$nav[id]]\" value=\"1\" ".($nav['available'] > 0 ? 'checked' : '').">",
			"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=micxp_down&pmod=huandeng&op=edit&sid=$nav[id]\" class=\"act\">$lang[edit]</a>"
			));
				
				
		}
		showtagfooter('tbody');

		echo '<tr><td colspan="1"></td><td colspan="5"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">'.$Mlang['huandeng_add_menu'].'</a></div></td></tr>';
		showsubmit('submit', 'submit', 'del');
		showtablefooter();
		showformfooter();

		echo <<<EOT
<script type="text/JavaScript">
	var rowtypedata = [
		[[1, '', 'td25'], [1,'<input name="newdisplayorder[]" value="" size="3" type="text" class="txt">', 'td25'], [1, '<input name="newname[]" value="" size="15" type="text" class="txt">'],[5, '<input name="newurl[]" value="" size="15" type="text" class="txt"> $applist <input type="hidden" name="newparentid[]" value="0" />']],
	];
</script>
EOT;
	}else {
		if($ids = $_GET['delete']) {
			
			$dellist = C::t('#micxp_down#micxp_down_huandeng')->fetch_all($ids);
			
			foreach ($dellist as $v){
				if(!empty($v['logo'])){
					@unlink($_G['setting']['attachurl'].'common/'.$v['logo']);
				}
			}
			
			C::t('#micxp_down#micxp_down_huandeng')->delete($ids);
		}

		if(is_array($_GET['namenew'])) {
			foreach($_GET['namenew'] as $id => $name) {
				$name = trim(dhtmlspecialchars($name));
				$urlnew = str_replace(array('&amp;'), array('&'), dhtmlspecialchars($_GET['urlnew'][$id]));
				$urladd = !empty($_GET['urlnew'][$id]) ? ", url='$urlnew'" : '';
				$availablenew[$id] = $name && (!isset($_GET['urlnew'][$id]) || $_GET['urlnew'][$id]) && $_GET['availablenew'][$id];
				$displayordernew[$id] = intval($_GET['displayordernew'][$id]);
				$data = array(
						'displayorder' => $displayordernew[$id],
						'available' => $availablenew[$id],
				);
				if(!empty($_GET['urlnew'][$id])) {
					$data['url'] = $urlnew;
				}
				if(!empty($name)) {
					$data['name'] = $name;
				}

				C::t('#micxp_down#micxp_down_huandeng')->update($id, $data);
			}
		}

		if(is_array($_GET['newname'])) {
			foreach($_GET['newname'] as $k => $v) {
				$v = dhtmlspecialchars(trim($v));
				if(!empty($v)) {
					$newavailable = $v && $_GET['newurl'][$k];
					$newdisplayorder[$k] = intval($_GET['newdisplayorder'][$k]);
					$newurl[$k] = str_replace('&amp;', '&', dhtmlspecialchars($_GET['newurl'][$k]));
					$data = array(
							'name' => $v,
							'displayorder' => $newdisplayorder[$k],
							'url' => $newurl[$k],
							'available' => $newavailable,
								
					);
					C::t('#micxp_down#micxp_down_huandeng')->insert($data);
				}
			}
		}

		cpmsg($Mlang['huandeng_add_succeed'],ADMINSCRIPT."?frames=yes&action=plugins&operation=config&do=$pluginid&identifier=micxp_down&pmod=huandeng", 'succeed');


	}
} elseif($op == 'edit' && ($sid = $_GET['sid'])) {
	$huandeng = C::t('#micxp_down#micxp_down_huandeng')->fetch($sid);
	if(!$huandeng) {
		cpmsg($Mlang['huandeng_not_found'], '', 'error');
	}

	if(!submitcheck('editsubmit')) {
		
		if($huandeng['logo']) {
			$huandenglogo = $_G['setting']['attachurl'].'common/'.$huandeng['logo'].'?'.random(6);
			$logohtml = '<br /><label><input type="checkbox" class="checkbox" name="deletelogo" value="yes" /> '.$lang['delete'].'</label><br /><img src="'.$huandenglogo.'" />';
		}
		showformheader("plugins&operation=config&identifier=micxp_down&pmod=huandeng&op=edit&sid=$sid", 'enctype');
		showtableheader();
		showsetting($Mlang['huandeng_name'], 'namenew', $huandeng['name'], 'text');
		showsetting($Mlang['huandeng_url'], 'urlnew', $huandeng['url'], 'text');

		showsetting($Mlang['huandeng_url_open'], array('targetnew', array(
		array(0, $Mlang['url_open_default']),
		array(1, $Mlang['url_open_blank'])
		), TRUE), $huandeng['target'], 'mradio');

		showsetting($Mlang['huandeng_logo'], 'logonew', $huandeng['logo'], 'filetext', '', 0,$logohtml);

		showsubmit('editsubmit');
		showtablefooter();
		showformfooter();



	}else{
		$namenew = trim(dhtmlspecialchars($_GET['namenew']));
		$titlenew = trim(dhtmlspecialchars($_GET['titlenew']));
		$urlnew = str_replace(array('&amp;'), array('&'), dhtmlspecialchars($_GET['urlnew']));
		
		$targetnew = intval($_GET['targetnew']) ? 1 : 0;
		$urladd = ", url='".$urlnew."'";
		$logonew = addslashes($huandeng['logo']);

		if($_FILES['logonew']) {
			$upload = new discuz_upload();
			if($upload->init($_FILES['logonew'], 'common') && $upload->save()) {
				$logonew = $upload->attach['attachment'];
			}
		} else {
			$logonew = $_GET['logonew'];
		}
		if($_GET['deletelogo'] && $huandeng['logo']) {
			$valueparse = parse_url($huandeng['logo']);
			@unlink($_G['setting']['attachurl'].'common/'.$huandeng['logo']);
			$logonew = '';
		}
		$logoadd = ", logo='$logonew'";

		$_GET['sidnew']= intval($_GET['sidnew']);
		$data = array(
				'name' => $namenew,
				'target' => $targetnew,
				'logo' => $logonew,
				'url'=>$urlnew,
		);

			
		C::t('#micxp_down#micxp_down_huandeng')->update($sid, $data);
		cpmsg($Mlang['huandeng_add_succeed'],ADMINSCRIPT."?frames=yes&action=plugins&operation=config&do=$pluginid&identifier=micxp_down&pmod=huandeng", 'succeed');
	}


}


?>