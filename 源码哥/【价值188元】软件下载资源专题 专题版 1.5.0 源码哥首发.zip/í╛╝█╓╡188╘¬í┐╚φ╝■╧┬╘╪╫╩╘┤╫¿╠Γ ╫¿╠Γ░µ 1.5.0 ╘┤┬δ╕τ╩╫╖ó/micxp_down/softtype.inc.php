<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/micxp_down/setting.class.php';
MicxpDownSetting::menu();


$Mlang = $scriptlang['micxp_down'];

//��������
if(!empty($_GET['softtype']) && submitcheck('softtypesubmit')){
	$softtype = daddslashes(strip_tags($_GET['softtype']));
	$softtypeid = C::t("#micxp_down#micxp_down_softtype")->fetch_id_by_softtype($softtype);
	if(!empty($softtypeid)){
		cpmsg($Mlang['exists'],"","error",'','',FALSE);
	}else{
		$softtypeid = DB::query("INSERT INTO ".DB::table('micxp_down_softtype')."(softtype) VALUES ('".$softtype."')");
	}
}

//���²���
if(!empty($_GET['softtype'])  && submitcheck('softtypeupdate')){

	$softtypearray = daddslashes($_GET['softtype']);

	$ids = implode(',', array_keys($softtypearray));
	$sql = "UPDATE ".DB::table('micxp_down_softtype')." SET softtype = CASE softtypeid ";
	foreach ($softtypearray as $id => $softtype) {

		$sql .= sprintf("WHEN %d THEN '%s' ", $id, $softtype);
	}
	$sql .= "END,";
	$sql .= "lencord = CASE softtypeid ";
	
	$lencordarray = daddslashes($_GET['lencord']);
	foreach ($lencordarray as $id => $lencord) {
		$sql .= sprintf("WHEN %d THEN %d ", $id, $lencord);
	}
	
	
	$sql .= "END WHERE softtypeid IN ($ids)";
	DB::query($sql);
}


//�������
if($_GET['op'] == 'delete' && submitcheck('formhash',1)) {
	$id = intval($_GET['id']);
	if(!empty($id)) {
		C::t("#micxp_down#micxp_down_softtype")->delete($id);
	}
}

//����Ĭ��
if($_GET['op'] == 'setdefault' && submitcheck('formhash',1)) {
	$id = intval($_GET['id']);
	if(!empty($id)) {
		DB::query("UPDATE ".DB::table('micxp_down_softtype')." SET isdefault=0");
		C::t("#micxp_down#micxp_down_softtype")->update($id,array('isdefault'=>1));
	}
}


showtableheader();
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softtype', 'softtypesubmit');
showsubmit('softtypesubmit', $Mlang['add'], $Mlang['softtype_name'].': <input name="softtype" value="" class="txt" />');
showformfooter();


showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softtype', 'softtypeupdate');
echo '<tr class="header"><th>ID</th><th>'.$Mlang['softtype_name'].'</th><th>'.$Mlang['lencord'].'</th><th>'.$Mlang['isdefault'].'</th><th>'.$Mlang['opration'].'</th></tr>';

$softtypelist = C::t("#micxp_down#micxp_down_softtype")->range();

//д��������
$cacheArray ='';
$cacheArray .= "\$softtypelist=".arrayeval($softtypelist).";\n";
writetocache("micxp_down_softtype", $cacheArray);

foreach ($softtypelist as $key=>$val){

	if($val['isdefault']){
		$isdefault=$Mlang['yes'];
	}else{
		$isdefault=$Mlang['no'];
	}

	echo '<tr><td class="td25">'.$val['softtypeid'].'</td><td><input name="softtype['.$val['softtypeid'].']" value="'.$val['softtype'].'" class="txt" type="text"></td><td><input name="lencord['.$val['softtypeid'].']" value="'.$val['lencord'].'" class="txt" type="text"></td><td>'.$isdefault.'</td><td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softtype&id='.$val['softtypeid'].'&op=setdefault&formhash='.FORMHASH.'">'.$Mlang['setdefault'].'</a>&nbsp;&nbsp;<a id="d'.$val['softtypeid'].'"  href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softtype&id='.$val['softtypeid'].'&op=delete&formhash='.FORMHASH.'" >'.$Mlang['delete'].'</a></td></tr>';

}
showsubmit('softtypeupdate', $Mlang['update']);

showtablefooter();





?>