<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function build_cache_plugin_downcategory(){
	global $_G;
	
	$data = C::t('#micxp_down#micxp_down_category')->range();
	foreach($data as $key => $value) {
		$upid = $value['upid'];
		$data[$key]['level'] = 0;
		if($upid && isset($data[$upid])) {
			$data[$upid]['children'][] = $key;
			while($upid && isset($data[$upid])) {
				$data[$key]['level'] += 1;
				$upid = $data[$upid]['upid'];
			}
		}
	}
	
	foreach($data as $key => &$value){
		$url = $topid = '';
		$foldername = $value['foldername'];
		if($value['level']) {
			$topid = $key;
			$foldername = '';
			while($data[$topid]['upid']) {
				if($data[$topid]['foldername'] && $data[$key]['foldername']) {
					$foldername = $data[$topid]['foldername'].'/'.$foldername;
				}
				$topid = $data[$topid]['upid'];
			}
			if($foldername) $foldername = $data[$topid]['foldername'].'/'.$foldername;
		} else {
			$topid = $key;
		}
		$value['topid'] = $topid;
	
		if ($foldername) {
			$url = $foldername;
			if(substr($url, -1, 1) != '/') $url.= '/';
		} else {
			$url = 'plugin.php?id=micxp_down:micxp_down&mod=list&catid='.$key;
		}
		$value['caturl'] = $url;
	
		$value['fullfoldername'] = trim($foldername, '/');
	
		
	}
	savecache('downcategory', $data);
	
}