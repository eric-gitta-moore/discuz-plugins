<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
define('MICXP_DOWN_NAME', lang('plugin/micxp_down', 'name'));
define('MICXP_DOWN_BUTTONTEXT', lang('plugin/micxp_down', 'buttontext'));
define('MICXP_DOWN_ICON', 'static/images/down.jpg');
loadcache('plugin');

class threadplugin_micxp_down {
	
	var $name = MICXP_DOWN_NAME;
	var $iconfile = MICXP_DOWN_ICON;
	var $buttontext = MICXP_DOWN_BUTTONTEXT;
	var $down;
	
	function newthread($fid) {
		global $_G;
		
		include_once libfile("function/downcp","plugin/micxp_down");
		$categoryselect = down_category_showselect('down', 'catid', true);
		$languageselect = language_showselect();
		$softtypeselect	= softtype_showselect();
		$sqselect		= sq_showselect();
		$djselect		= dj_showselect();
		
		$hj_list		= get_hjlist();
	
		include template('micxp_down:down_newthread');
		return $return;

	}
	
	function newthread_submit($fid) {
		global $_G,$modnewthreads,$displayorder,$down;
		
		$down = $this->check_gpc();
		if(empty($down['downaid'])) {
			micxpshowmessage('m_no_pic');
		}
	}
	function newthread_submit_end($fid, $tid) {
		global $_G,$pid,$down;
		if($down['downaid']) {
			if($down['logoaid']){
				$attachtable = DB::result_first("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE aid='$down[logoaid]'");
				!$attachtable && $attachment = DB::fetch_first("SELECT * FROM ".DB::table('forum_attachment_unused')." WHERE aid='$down[logoaid]' AND uid='$_G[uid]' AND isimage='1'");
				$attachtable = $attachtable == 127 ? 'unused' : $attachtable;
				($attachtable && empty($attachment)) && $attachment = DB::fetch_first("SELECT * FROM ".DB::table('forum_attachment_'.$attachtable)." WHERE aid='$down[logoaid]' AND uid='$_G[uid]' AND isimage='1'");
				if(!empty($attachment)){
					if($attachtable == 'unused') {
						convertunusedattach($down['logoaid'], $tid, $pid);
					}
					
					$tableid = DB::result_first("SELECT posttableid FROM ".DB::table('forum_thread')." WHERE tid='$tid'");
					if(!$tableid) {
						$tablename = 'forum_post';
					} else {
						$tablename = "forum_post_$tableid";
					}
					DB::query("UPDATE ".DB::table('forum_thread')." SET attachment=2 WHERE tid='$tid'");
					DB::query("UPDATE ".DB::table($tablename)." SET attachment=2 WHERE pid='$pid'");
					$logoaid = 1;
				}
				$attachtable = $attachment =$tableid =$tablename ='';
			}
			
			
			$attachtable = DB::result_first("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE aid='$down[downaid]'");
			!$attachtable && $attachment = DB::fetch_first("SELECT * FROM ".DB::table('forum_attachment_unused')." WHERE aid='$down[downaid]' AND uid='$_G[uid]' AND isimage='1'");
			$attachtable = $attachtable == 127 ? 'unused' : $attachtable;
			($attachtable && empty($attachment)) && $attachment = DB::fetch_first("SELECT * FROM ".DB::table('forum_attachment_'.$attachtable)." WHERE aid='$down[downaid]' AND uid='$_G[uid]' AND isimage='1'");
			if(empty($attachment)) {
				micxpshowmessage('m_no_pic');
			}
			if($attachtable == 'unused') {
				convertunusedattach($down['downaid'], $tid, $pid);
			}
			$tableid = DB::result_first("SELECT posttableid FROM ".DB::table('forum_thread')." WHERE tid='$tid'");
			if(!$tableid) {
				$tablename = 'forum_post';
			} else {
				$tablename = "forum_post_$tableid";
			}
			DB::query("UPDATE ".DB::table('forum_thread')." SET attachment=2 WHERE tid='$tid'");
			DB::query("UPDATE ".DB::table($tablename)." SET attachment=2 WHERE pid='$pid'");
			
			$downaid = 1;

			$threadimage = DB::fetch_first("SELECT tid, pid, attachment, remote FROM ".DB::table(getattachtablebyaid($down[downaid]))." WHERE aid='$down[downaid]'");
			if(setthreadcover(0, 0, $down['downaid'])) {
				$threadimage = daddslashes($threadimage);
				DB::delete('forum_threadimage', "tid='$threadimage[tid]'");
				DB::insert('forum_threadimage', array(
				'tid' => $threadimage['tid'],
				'attachment' => $threadimage['attachment'],
				'remote' => $threadimage['remote'],
				));
			}
			

			DB::insert('micxp_down_soft', array(
			'tid' => $tid,
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'aid' => ($downaid ? $down['downaid'] : 0),
			'logoaid' => ($logoaid ? $down['logoaid'] : 0),
			'catid' => $down['catid'],
			'softurl'=>$down['softurl'],
			'softdj'=>$down['softdj'],
			'tag'=>'',
			'logo'=>$down['logoaid_url'],
			'thumb'=>$down['downaid_url'],
			'summary'=>$down['summary'],
			'updatetime'=>$down['updatetime'],
			'softsize'=>$down['softsize'],
			'softtypeid'=>$down['softtypeid'],
			'sqid'=>$down['sqid'],
			'languageid'=>$down['languageid'],
			'softhj'=>$down['softhj'],
			'softname'=>$down['softname'],
			));
			
			
		}else{
			micxpshowmessage('m_no_pic');
		}
		
		
	}
	
	function viewthread($tid) {
		global $_G,$skipaids,$thread;
		loadcache('downcategory');
		if(DB::result_first("SELECT COUNT(*) FROM ".DB::table('micxp_down_soft')." WHERE tid='$tid'")){
			$soft = DB::fetch_first("SELECT * FROM ".DB::table('micxp_down_soft')." WHERE tid='$tid'");
			$soft['updatetime']= dgmdate($soft['updatetime'], 'Y-m-d');
			
			$soft['catname']=$_G['cache']['downcategory'][$soft['catid']]['catname'];
			
			include_once DISCUZ_ROOT.'/data/sysdata/cache_micxp_down_language.php';
			$soft['language']=$languagelist[$soft['languageid']]['language'];
			
			include_once DISCUZ_ROOT.'/data/sysdata/cache_micxp_down_softtype.php';
			$soft['softtype']=$softtypelist[$soft['softtypeid']]['softtype'];
			
			include_once DISCUZ_ROOT.'/data/sysdata/cache_micxp_down_sq.php';
			$soft['sqname']=$sqlist[$soft['sqid']]['sqname'];
			
			$djlangkey= $soft['softdj'] ? 'start_'.$soft['softdj'] : 'none';
			
			$soft['djname']=lang("plugin/micxp_down",$djlangkey);
			
			if($soft['aid']) {
				$downatt['attachment'] = getforumimg($soft['aid'], 0, 260, 180);
				$downatt['encodeaid'] = aidencode($soft['aid']);
				$skipaids[] = $soft['aid'];
			}
			if($soft['logoaid']){
				$skipaids[] = $soft['logoaid'];
			}
			
			DB::query("UPDATE ".DB::table('micxp_down_soft')." SET hot=hot+1 WHERE tid='$tid'");
			
			$showmobile = ($_G['uid'] == $soft['uid'] || in_array($_G['adminid'], array(1,2)));
			
			//
			$postcatid = $soft['catid'] ? $soft['catid'] :0 ;
			$postad = C::t('#micxp_down#micxp_down_postad')->fetch($soft['catid']);
			
			if(!empty($postad['logo']) && !empty($postad['url'])){
			$postad['logo']=$_G['setting']['attachurl'].'common/'.$postad['logo'];
				$downad = '<div  style="width:100%;height:80px;text-align:center;float:none;margin-top:10px;"><a href="'.$postad['url'].'" target="_blank"><img src="'.$postad['logo'].'" alt="" border="0" width="100%" height="80px"></a></div>';
			}else{
				$downad = "";
			}
			
			$thunder_pid = intval($_G['cache']['plugin']['micxp_down']['M_thunder_pid']);
			
		}else{
			return '';
		}
		
		include template('micxp_down:down_viewthread');
		return $return;
	}
	
	
	function editpost($fid, $tid) {
		global $_G;
		
		if(DB::result_first("SELECT COUNT(*) FROM ".DB::table('micxp_down_soft')." WHERE tid='$tid'")) {
			$soft = DB::fetch_first("SELECT * FROM ".DB::table('micxp_down_soft')." WHERE tid='$tid'");
			
			include_once libfile("function/downcp","plugin/micxp_down");
			
			$languageselect = language_showselect($soft['languageid']);
			$softtypeselect	= softtype_showselect($soft['softtypeid']);
			
			$sqselect		= sq_showselect($soft['sqid']);
			$djselect		= dj_showselect($soft['softdj']);
			$hj_list		= get_hjlist();
			
			$categoryselect = down_category_showselect('down', 'catid', true,$soft['catid']);
			$soft['updatetime'] = dgmdate($soft['updatetime'], 'Y-m-d');
			
			if($soft['aid']) {
				$downatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($tid))." WHERE aid='{$soft[aid]}'");
				if($downatt['remote']) {
					$downatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$downatt['attachment'];
					$downatt['attachment'] = substr($downatt['attachment'], 0, 7) != 'http://' ? 'http://'.$downatt['attachment'] : $downatt['attachment'];
				} else {
					$downatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$downatt['attachment'];
				}
			}
			
			
			if($soft['logoaid']) {
				$logoatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($tid))." WHERE aid='{$soft[logoaid]}'");
				if($logoatt['remote']) {
					$logoatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$logoatt['attachment'];
					$logoatt['attachment'] = substr($logoatt['attachment'], 0, 7) != 'http://' ? 'http://'.$logoatt['attachment'] : $logoatt['attachment'];
				} else {
					$logoatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$logoatt['attachment'];
				}
			}
			
			
			include template('micxp_down:down_newthread');
			return $return;
		}else{
			return '';
		}
		
	}
	
	
	function editpost_submit($fid, $tid) {
		global $_G,$modnewthreads,$displayorder,$down;
		$this->getdown_gpc();
		$down = $this->down;
		
		if(empty($down['catid'])) {
			micxpshowmessage('m_catid_invalide');
		}
		if(empty($down['softname'])){
			micxpshowmessage('m_name_invalide');
		}
		
		if(empty($down['updatetime'])){
			micxpshowmessage('m_updatetime_invalide');
		}
		if(empty($down['softhj'])){
			micxpshowmessage('m_softhj_invalide');
		}
		if(empty($down['languageid'])){
			micxpshowmessage('m_language_invalide');
		}
		
		if(empty($down['softtypeid'])){
			micxpshowmessage('m_softtype_invalide');
		}
		if(empty($down['sqid'])){
			micxpshowmessage('m_sq_invalide');
		}
		
		if(empty($down['softdj'])){
			micxpshowmessage('m_dj_invalide');
		}
		
		if(empty($down['softsize'])){
			micxpshowmessage('m_softsize_invalide');
		}
		
		if(empty($down['softurl'])){
			micxpshowmessage('m_softurl_invalide');
		}
		
		
	}
	
	
	function editpost_submit_end($fid, $tid) {
		global $_G,$down;
		if(!DB::result_first("SELECT COUNT(*) FROM ".DB::table('micxp_down_soft')." WHERE tid='$tid'")) {
			return ' ';
		}else{
			if($down['downaid'] && DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_attachment_unused')." WHERE aid='{$down[downaid]}' AND uid='{$_G[uid]}'")) {
				$aid=0;
				$aid = DB::result_first("SELECT aid FROM ".DB::table('micxp_down_soft')." WHERE tid='$tid'");
				if($aid) {
					$att = DB::fetch_first("SELECT aid,tid,tableid FROM ".DB::table('forum_attachment')." WHERE aid='$aid'");
					if($att['tableid']) {
						$attach = DB::fetch_first("SELECT tid, pid, attachment, thumb, remote, aid FROM ".DB::table('forum_attachment_'.$att['tableid'])." WHERE aid='$aid'");
						dunlink($attach);
						DB::query("DELETE FROM ".DB::table('forum_attachment_'.$att['tableid'])." WHERE aid='$aid'");
						DB::query("DELETE FROM ".DB::table('forum_attachment')." WHERE aid='$aid'");
			
					}
			
				}
				DB::query("UPDATE ".DB::table('micxp_down_soft')." SET aid='{$down[downaid]}' WHERE tid='$tid'");
				DB::query("UPDATE ".DB::table('forum_thread')." SET attachment=2 WHERE tid='$tid'");
				
				convertunusedattach($down['downaid'], $tid, $_GET['pid']);
			}
			
			
			if($down['logoaid'] && DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_attachment_unused')." WHERE aid='{$down[logoaid]}' AND uid='{$_G[uid]}'")) {
				$aid=0;
				$aid = DB::result_first("SELECT logoaid FROM ".DB::table('micxp_down_soft')." WHERE tid='$tid'");
				if($aid) {
					$att = DB::fetch_first("SELECT aid,tid,tableid FROM ".DB::table('forum_attachment')." WHERE aid='$aid'");
					if($att['tableid']) {
						$attach = DB::fetch_first("SELECT tid, pid, attachment, thumb, remote, aid FROM ".DB::table('forum_attachment_'.$att['tableid'])." WHERE aid='$aid'");
						dunlink($attach);
						DB::query("DELETE FROM ".DB::table('forum_attachment_'.$att['tableid'])." WHERE aid='$aid'");
						DB::query("DELETE FROM ".DB::table('forum_attachment')." WHERE aid='$aid'");
					}
						
				}
				DB::query("UPDATE ".DB::table('micxp_down_soft')." SET logoaid='{$down[logoaid]}' WHERE tid='$tid'");
				DB::query("UPDATE ".DB::table('forum_thread')." SET attachment=2 WHERE tid='$tid'");
			
				convertunusedattach($down['logoaid'], $tid, $_GET['pid']);
			}
			
			DB::update('micxp_down_soft', array(
			'aid' => $down['downaid'],
			'logoaid' => $down['logoaid'],
			'catid' => $down['catid'],
			'softurl'=>$down['softurl'],
			'softdj'=>$down['softdj'],
			'tag'=>'',
			'logo'=>$down['logoaid_url'],
			'thumb'=>$down['downaid_url'],
			'summary'=>$down['summary'],
			'updatetime'=>$down['updatetime'],
			'softsize'=>$down['softsize'],
			'softtypeid'=>$down['softtypeid'],
			'sqid'=>$down['sqid'],
			'languageid'=>$down['languageid'],
			'softhj'=>$down['softhj'],
			'softname'=>$down['softname'],
			),array('tid'=>$tid));
			
				
			
			
		}
		
		
		
	}
	
	function check_gpc(){
		$this->getdown_gpc();
		$down = $this->down;
		
		if(empty($down['catid'])) {
			micxpshowmessage('m_catid_invalide');
		}
		if(empty($down['softname'])){
			micxpshowmessage('m_name_invalide');
		}
		
		if(empty($down['updatetime'])){
			micxpshowmessage('m_updatetime_invalide');
		}
		if(empty($down['softhj'])){
			micxpshowmessage('m_softhj_invalide');
		}
		if(empty($down['languageid'])){
			micxpshowmessage('m_language_invalide');
		}
		
		if(empty($down['softtypeid'])){
			micxpshowmessage('m_softtype_invalide');
		}
		if(empty($down['sqid'])){
			micxpshowmessage('m_sq_invalide');
		}
		
		if(empty($down['softdj'])){
			micxpshowmessage('m_dj_invalide');
		}
		
		if(empty($down['softsize'])){
			micxpshowmessage('m_softsize_invalide');
		}
		
		if(empty($down['softurl'])){
			micxpshowmessage('m_softurl_invalide');
		}

		return $down;
	}
	
	function getdown_gpc(){
		
		$down['catid'] = intval($_GET['catid']);
		$down['softname'] = daddslashes(trim($_GET['softname']));
		$down['updatetime'] = strtotime(daddslashes(trim($_GET['updatetime'])));
		$down['softhj'] = daddslashes(trim($_GET['softhj']));
		$down['languageid'] = intval($_GET['language']);
		$down['softtypeid'] = intval($_GET['softtype']);
		$down['sqid'] = intval($_GET['sq']);
		$down['softdj'] = intval($_GET['dj']);
		$down['softsize'] = intval($_GET['softsize']);
		$down['softurl'] = daddslashes(trim($_GET['softurl']));
		$down['downaid'] = intval($_GET['downaid']);
		$down['downaid_url'] = daddslashes(trim($_GET['downaid_url']));
		$down['logoaid'] = intval($_GET['logoaid']);
		$down['logoaid_url'] = daddslashes(trim($_GET['logoaid_url']));
		
		$down['summary']=down_get_summary($_GET['message']);
		
		
		$this->down = $down;
	}
	
	
}

function micxpshowmessage($str, $url = '') {
	showmessage(lang('plugin/micxp_down', $str), $url);
}

function down_get_summary($message) {
	
	require DISCUZ_ROOT.'./source/function/function_home.php';
	$message = preg_replace(array("/\[attach\].*?\[\/attach\]/", "/\&[a-z]+\;/i", "/\<script.*?\<\/script\>/"), '', $message);
	$message = preg_replace("/\[.*?\].*?\[.*?\]/", '', $message);
	$message = getstr(strip_tags($message), 170);
	return $message;
}

?>