<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/micxp_down/setting.class.php';
MicxpDownSetting::menu();

$Mlang = $scriptlang['micxp_down'];
require_once libfile('function/downcp','plugin/micxp_down');

$catid = isset($_GET['catid']) ? dintval($_GET['catid']) : 0;
$postad = C::t('#micxp_down#micxp_down_postad')->fetch($catid);

if(!submitcheck('editsubmit')) {
	$catselect = down_category_showselect('down','catid',true,$catid);
	
	
	if($postad['logo']) {
		$postadlogo = $_G['setting']['attachurl'].'common/'.$postad['logo'].'?'.random(6);
		$logohtml = '<br /><label><input type="checkbox" class="checkbox" name="deletelogo" value="yes" /> '.$lang['delete'].'</label><br /><img src="'.$postadlogo.'" />';
	}
	
	showformheader("plugins&operation=config&identifier=micxp_down&pmod=postad", 'enctype');
	showtableheader();
	showtablerow('',array('class="td27"',''),array($Mlang['ad_cate']),'');
	showtablerow('', '',array($catselect,''));
	
	showsetting($Mlang['postad_url'], 'urlnew', $postad['url'], 'text');
	showsetting($Mlang['postad_logo'], 'logonew', $postad['logo'], 'filetext', '', 0,$logohtml);
	
	showsubmit('editsubmit');
	showtablefooter();
	showformfooter();
	
	$adminscript =ADMINSCRIPT;
	echo <<<EOT
<script type="text/JavaScript">
	var sdom = document.getElementById('catid');
sdom.onchange=function(){
	var catids = sdom.options[sdom.options.selectedIndex].value;
	location.href="$adminscript?action=plugins&operation=config&identifier=micxp_down&pmod=postad&catid="+catids;
};
</script>
EOT;
	
}else{
	$urlnew = str_replace(array('&amp;'), array('&'), dhtmlspecialchars($_GET['urlnew']));
	$logonew = addslashes($postad['logo']);
	if($_FILES['logonew']) {
		$upload = new discuz_upload();
		if($upload->init($_FILES['logonew'], 'common') && $upload->save()) {
			$logonew = $upload->attach['attachment'];
		}
		@unlink($_G['setting']['attachurl'].'common/'.$postad['logo']);
		
	} else {
		$logonew = daddslashes($_GET['logonew']);
	}
	
	if($_GET['deletelogo'] && $postad['logo']) {
		@unlink($_G['setting']['attachurl'].'common/'.$postad['logo']);
		$logonew = '';
	}
	
	$insertdata = array(
			'catid'=>$catid,
			'logo' => $logonew,
			'url'=>$urlnew,
	);
	$updatedata = array(
			'logo' => $logonew,
			'url'=>$urlnew,
	);
	
	if(empty($postad)){
		C::t('#micxp_down#micxp_down_postad')->insert($insertdata);
	}else{
		C::t('#micxp_down#micxp_down_postad')->update($catid,$updatedata);
	}
	
	cpmsg($Mlang['poatad_save'],dreferer(),'succeed');
	
}





?>