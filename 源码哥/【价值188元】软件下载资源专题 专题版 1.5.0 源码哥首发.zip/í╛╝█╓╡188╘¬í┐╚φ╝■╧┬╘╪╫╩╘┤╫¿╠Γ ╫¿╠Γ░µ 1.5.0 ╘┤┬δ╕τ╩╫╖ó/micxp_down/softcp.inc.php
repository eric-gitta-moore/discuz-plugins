<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/micxp_down/setting.class.php';
MicxpDownSetting::menu();

$Mlang = $scriptlang['micxp_down'];


$op = daddslashes($_GET['op']);
$op = in_array($_GET['op'], array('tuijian','zjbb'))?$_GET['op']:'list';
require_once libfile('function/downcp','plugin/micxp_down');

if($op == 'list') {
	if(submitcheck('managesubmit')){
		$optype = isset($_GET['optype']) ? daddslashes($_GET['optype']) :'';
		if(empty($optype) || !in_array($optype, array('trash','move','tuijian','zjbb'))){
			cpmsg($Mlang['illegal'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp', 'error');
		}
		$ids = daddslashes($_GET['ids']);
		if(empty($ids)){
			cpmsg_error($Mlang['noselect']);
		}
		switch ($_GET['optype']){
			case 'trash':
				$delcatids =$dels=array();
				$res = C::t('#micxp_down#micxp_down_soft')->fetch_all($ids);
				foreach ($res as $resv){
					
					$delcatids[] = intval($resv['catid']);
					$dels[$resv['softid']] = $resv['softid'];
// 					if($resv['logo']){
// 						@unlink($_G['setting']['attachurl'].'common/'.$resv['logo']);
// 					}
// 					if($resv['thumb']){
// 						@unlink($_G['setting']['attachurl'].'common/'.$resv['thumb']);
// 					}
				}
				if($dels) {
					C::t('#micxp_down#micxp_down_soft')->delete($dels);
					$delcatids = array_unique($delcatids);
					if($delcatids) {
						foreach($delcatids as $catid) {
							$cnt = C::t('#micxp_down#micxp_down_soft')->fetch_count_for_cat($catid);
							C::t('#micxp_down#micxp_down_category')->update($catid, array('softs'=>dintval($cnt)));
						}
					}
						
				}
				cpmsg($Mlang['soft_deleted'],'','succeed');
				break;
			case 'move':
				$tocatid = intval($_GET['tocatid']);
				if(empty($tocatid)){
					cpmsg_error($Mlang['soft_move_select_cat']);
				}
				$movecatids =$moves=array();
				$res = C::t('#micxp_down#micxp_down_soft')->fetch_all($ids);
				
				foreach ($res as $resv){
					$movecatids[] = intval($resv['catid']);
					$moves[$resv['softid']] = $resv['softid'];
				}
				if($moves) {
					C::t('#micxp_down#micxp_down_soft')->update($moves, array('catid'=>$tocatid));
					$movecatids[]=$tocatid;
					$movecatids = array_unique($movecatids);
						
					if($movecatids) {
						foreach($movecatids as $catid) {
							$cnt = C::t('#micxp_down#micxp_down_soft')->fetch_count_for_cat($catid);
							C::t('#micxp_down#micxp_down_category')->update($catid, array('softs'=>dintval($cnt)));
						}

					}
						
						
				}
				cpmsg($Mlang['soft_move_succeed'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp', 'succeed');
				break;
			case 'tuijian':
				$tjvalue = isset($_GET['tjvalue']) ? dintval($_GET['tjvalue']) : 0;
				
				C::t('#micxp_down#micxp_down_soft')->update($ids,array('istuijian'=>$tjvalue,'tjtime'=>TIMESTAMP));
				cpmsg($Mlang['soft_tuijian_succeed'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp', 'succeed');
				break;
				
			case 'zjbb':
				$zjvalue = isset($_GET['zjvalue']) ? dintval($_GET['zjvalue']) : 0;
				
				C::t('#micxp_down#micxp_down_soft')->update($ids,array('zjbb'=>$zjvalue,'tjtime'=>TIMESTAMP));
				
				cpmsg($Mlang['soft_zjbb_succeed'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp', 'succeed');
				break;
		}


	}else{
		$extra=array();
		loadcache('downcategory');
		$catid = max(0,intval($_GET['catid']));
		$perpagearr = array(20, 30,40, 50, 100);
		$perpage = isset($_GET['perpage']) && in_array($_GET['perpage'], $perpagearr) ? $_GET['perpage'] :20;

		$istuijian = isset($_GET['istuijian']) ? intval($_GET['istuijian']) : -1;
		$iszjbb = isset($_GET['iszjbb']) ? intval($_GET['iszjbb']) : -1;
		
		$catids = $wherearr = array();
		$category = $_G['cache']['downcategory'];

		if($catid) {
			$extra[] = "catid=$catid";
			$catids = down_category_get_childids('down', $catid);
			$catids[] = $catid;
		}

		
		if($catids) {
			$wherearr[] = " catid IN (".dimplode($catids).")";
		}
		
		if($_GET['searchkey']) {
			$extra[] = "searchkey=$searchkey";

			$_GET['searchkey'] = addslashes(stripsearchkey($_GET['searchkey']));
			$wherearr[] = DB::field("softname", "%$_GET[searchkey]%",'like');
			$_GET['searchkey'] = dhtmlspecialchars($_GET['searchkey']);
		}
		if($istuijian!=-1){
			$extra[] = "istuijian=$istuijian";
			$wherearr[] = DB::field("istuijian", $istuijian);
		}
		if($iszjbb!=-1){
			$extra[] = "iszjbb=$iszjbb";
			$wherearr[] = DB::field("zjbb", $iszjbb);
		}
		
		
		$wheresql = implode(' AND ', $wherearr);
		$page = max(1,intval($_GET['page']));
		$start = ($page-1)*$perpage;
		if($start<0) $start = 0;

		$list = array();
		$multi = '';

		$count = C::t('#micxp_down#micxp_down_soft')->fetch_all_by_sql($wheresql, '', 0, 0, 1);
		
		if($count) {
			$query = C::t('#micxp_down#micxp_down_soft')->fetch_all_by_sql($wheresql, 'ORDER BY softid DESC', $start, $perpage);

			foreach($query as $value) {
				$list[] = $value;
			}

		}

		
		//=========
		$perpagestr='<select name="perpage" class="ps vm">';
		foreach ($perpagearr as $value)	{
			if ($value == $perpage){
				$perpagestr.='<option value="'.$value.'" selected="selected" >'.$Mlang[softcp_perpage].$value.$Mlang[unit].'</option>';
			}else{
				$perpagestr.='<option value="'.$value.'"  >'.$Mlang[softcp_perpage].$value.$Mlang[unit].'</option>';
			}

		}


		$perpagestr.='</select>';
		
		
		//=======
		
		$tjselect='<select name="istuijian" class="ps vm">';
		
		$tjselect.='<option value="-1"  '.get_selected($istuijian,'').'>'.$Mlang[none].'</option>';
		$tjselect.='<option value="0" '.get_selected($istuijian,0).'>'.cplang('no').'</option>';
		$tjselect.='<option value="1" '.get_selected($istuijian,1).'>'.cplang('yes').'</option>';
		$tjselect.='</select>';
		
		
		//=======
		
		$zjselect='<select name="iszjbb" class="ps vm">';
		
		$zjselect.='<option value="-1"  '.get_selected($iszjbb,'').'>'.$Mlang[none].'</option>';
		$zjselect.='<option value="0" '.get_selected($iszjbb,0).'>'.cplang('no').'</option>';
		$zjselect.='<option value="1" '.get_selected($iszjbb,1).'>'.cplang('yes').'</option>';
		$zjselect.='</select>';

		//debug($tjselect);
		showtableheader();
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp', 'searchsubmit');
		showhiddenfields(array('catid'=>$_GET['catid']));
		showsubmit('searchsubmit', $Mlang['search'], $Mlang['keyword'].': <input name="searchkey" value="'.$_GET[searchkey].'" class="txt" />&nbsp;&nbsp;'.$Mlang[istuijian].':&nbsp;'.$tjselect.'&nbsp;&nbsp;'.$Mlang[zjbb].':&nbsp;'.$zjselect.'&nbsp;&nbsp;'.$perpagestr);
		showformfooter();
		showtablefooter();

		showtableheader();
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp', 'managesubmit','cpform1');
		echo '<tr class="header"><th></th><th>'.$Mlang['soft_name'].'</th><th>'.$Mlang['category_name'].'</th><th>'.$Mlang['istuijian'].'</th><th>'.$Mlang['zjbb'].'</th><th>'.$Mlang['operation'].'</th></tr>';

		foreach($list as $soft) {
	
			$tuijianstr = $zjbbstr='';
			if($soft['istuijian']==0){
				$tuijianstr='<a id="t'.$soft['softid'].'" onclick="ajaxget(this.href, this.id, \'\');return false" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp&softid='.$soft['softid'].'&op=tuijian&formhash='.FORMHASH.'">['.$Mlang['tuijian'].']</a>';
			}elseif($soft['istuijian']==1){
				$tuijianstr='<a id="t'.$soft['softid'].'" onclick="ajaxget(this.href, this.id, \'\');return false" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp&softid='.$soft['softid'].'&op=tuijian&formhash='.FORMHASH.'">['.$Mlang['distuijian'].']</a>';
			}
			
			if($soft['zjbb']==0){
				$zjbbstr='<a id="z'.$soft['softid'].'" onclick="ajaxget(this.href, this.id, \'\');return false" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp&softid='.$soft['softid'].'&op=zjbb&formhash='.FORMHASH.'">['.$Mlang['bb'].']</a>';
			}elseif($soft['zjbb']==1){
				$zjbbstr='<a id="z'.$soft['softid'].'" onclick="ajaxget(this.href, this.id, \'\');return false" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp&softid='.$soft['softid'].'&op=zjbb&formhash='.FORMHASH.'">['.$Mlang['disbb'].']</a>';
			}
			
			
			$posts = C::t('forum_post')->fetch_threadpost_by_tid_invisible($soft['tid']);
			$posturl = "forum.php?mod=viewthread&tid=".$posts['tid'];
			$editurl ="forum.php?mod=post&action=edit&fid=".$posts['fid']."&tid=".$posts['tid']."&pid=".$posts['pid']."";
			echo '<tr><td><input type="checkbox" class="checkbox" name="ids[]" value="'.$soft['softid'].'"></td>'.
					'<td><a href ="'.$posturl.'" target="_blank">'.$soft['softname'].'</a></td>'.
					'<td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp&op=list&catid='.$soft['catid'].'">'.$category[$soft['catid']]['catname'].'</a></td>'.
					'<td>'.(empty($soft['istuijian']) ? cplang('no') : '<font color="red">'.cplang("yes").'</font>').'</td>'.
					'<td>'.(empty($soft['zjbb']) ? cplang('no') : '<font color="red">'.cplang("yes").'</font>').'</td>'.
					'<td><a href="'.$editurl.'" target="_blank">['.$lang['edit'].']</a>&nbsp;&nbsp;'.$zjbbstr.'&nbsp;&nbsp;'.$tuijianstr.'</td></tr>';

		}

		if(!empty($extra)){
			$extra='&'.implode('&', $extra);
		}else{
			$extra='';
		}

		$multipage =multi($count, $perpage, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=micxp_down&pmod=softcp$extra");
		$optypehtml = ''
				.'<input type="radio" name="optype" id="optype_trash" value="trash" class="radio" /><label for="optype_trash">'.cplang('delete').'</label>&nbsp;&nbsp;'
						.'<input type="radio" name="optype" id="optype_move" value="move" class="radio" /><label for="optype_move">'.cplang('article_opmove').'</label> '
								.down_category_showselect('down', 'tocatid', true)
								
								.'<input type="radio" name="optype" id="optype_tuijian" value="tuijian" class="radio" /><label for="optype_tuijian">'.$Mlang['tuijian'].'</label> &nbsp;&nbsp;'
								.get_tuijian_select()
								.'<input type="radio" name="optype" id="optype_zjbb" value="zjbb" class="radio" /><label for="optype_zjbb">'.$Mlang['zjbb'].'</label> &nbsp;&nbsp;'
								.get_zjbb_select()
								.'&nbsp;&nbsp;';



		showsubmit('', '', '', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" /><label for="chkall">'.cplang('select_all').'</label>&nbsp;&nbsp;'.$optypehtml.'<input type="submit" class="btn" name="managesubmit" value="'.cplang('submit').'" />', $multipage);
		showformfooter();
		showtablefooter();

	}

}elseif($_GET['op']=="tuijian" && submitcheck('formhash',1)){

	$softid= intval($_GET['softid']);
	$soft = C::t('#micxp_down#micxp_down_soft')->fetch($softid);
	if($soft['istuijian']==0){
		C::t('#micxp_down#micxp_down_soft')->update($softid,array('istuijian'=>1,'tjtime'=>TIMESTAMP));
		ajaxshowheader();
		echo "[$Mlang[distuijian]]";
		ajaxshowfooter();
	}else{
		C::t('#micxp_down#micxp_down_soft')->update($softid,array('istuijian'=>0));
		ajaxshowheader();
		echo "[$Mlang[tuijian]]";
		ajaxshowfooter();
	}
}elseif($_GET['op']=="zjbb" && submitcheck('formhash',1)){
	$softid= intval($_GET['softid']);
	$soft = C::t('#micxp_down#micxp_down_soft')->fetch($softid);
	if($soft['zjbb']==0){
		C::t('#micxp_down#micxp_down_soft')->update($softid,array('zjbb'=>1,'zjtime'=>TIMESTAMP));
		ajaxshowheader();
		echo "[$Mlang[disbb]]";
		ajaxshowfooter();
	}else{
	C::t('#micxp_down#micxp_down_soft')->update($softid,array('zjbb'=>0));
	ajaxshowheader();
	echo "[$Mlang[bb]]";
	ajaxshowfooter();
	}
}



function get_selected($k,$v){
	if($k===$v){
		return ' selected="selected" ';
	}else{
		return '';
	}
}

function get_tuijian_select(){
	$html ='<select name="tjvalue">';
	$html.='<option value="0">'.cplang(no).'</option>';
	$html.='<option value="1">'.cplang(yes).'</option>';
	$html.='</select>';
	return $html;
}

function get_zjbb_select(){
	$html ='<select name="zjvalue">';
	$html.='<option value="0">'.cplang(no).'</option>';
	$html.='<option value="1">'.cplang(yes).'</option>';
	$html.='</select>';
	return $html;
}
?>