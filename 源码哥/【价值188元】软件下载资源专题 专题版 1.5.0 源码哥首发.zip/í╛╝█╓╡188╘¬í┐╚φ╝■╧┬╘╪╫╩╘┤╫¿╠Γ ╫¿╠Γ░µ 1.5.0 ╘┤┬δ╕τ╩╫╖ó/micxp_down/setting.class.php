<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class MicxpDownSetting{
	
	
	function menu() {
	
		echo <<<EOF
<style>
.floattop { display: none; }
.floattopempty { display: none; }
.mymenu { height:35px; }
.mymenu .floattop { display: inline; }
.mymenu .floattopempty { display: inline; }
</style>
EOF;
	
		echo '<div class="mymenu">';
		showsubmenu(lang('plugin/micxp_down', 'menu_root'), array(
		array(array('menu' => lang('plugin/micxp_down', 'menu_shuxing'), 'submenu' => array(
		array(lang('plugin/micxp_down', 'menu_shuxing_language'), 'plugins&operation=config&identifier=micxp_down&pmod=language', $_GET['pmod'] == 'language'),
		array(lang('plugin/micxp_down', 'menu_shuxing_softtype'), 'plugins&operation=config&identifier=micxp_down&pmod=softtype', $_GET['pmod'] == 'softtype'),
		array(lang('plugin/micxp_down', 'menu_shuxing_sq'), 'plugins&operation=config&identifier=micxp_down&pmod=sq', $_GET['pmod'] == 'sq'),
		array(lang('plugin/micxp_down', 'menu_shuxing_hj'), 'plugins&operation=config&identifier=micxp_down&pmod=hj', $_GET['pmod'] == 'hj'),
		))),
		
		array(lang('plugin/micxp_down', 'menu_category'), 'plugins&operation=config&identifier=micxp_down&pmod=category', $_GET['pmod'] == 'category'),
		array(lang('plugin/micxp_down', 'menu_huandeng'), 'plugins&operation=config&identifier=micxp_down&pmod=huandeng', $_GET['pmod'] == 'huandeng'),
		array(lang('plugin/micxp_down', 'menu_softcp'), 'plugins&operation=config&identifier=micxp_down&pmod=softcp', $_GET['pmod'] == 'softcp'),
		array(lang('plugin/micxp_down', 'menu_postad'), 'plugins&operation=config&identifier=micxp_down&pmod=postad', $_GET['pmod'] == 'postad'),
		
		));
		echo '</div>';
	
	}
	
	
	
}