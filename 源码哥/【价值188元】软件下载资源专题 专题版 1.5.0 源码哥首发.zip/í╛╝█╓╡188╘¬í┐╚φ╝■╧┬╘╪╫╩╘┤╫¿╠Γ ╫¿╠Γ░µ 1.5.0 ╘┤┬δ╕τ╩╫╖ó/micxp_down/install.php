<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

$sql= <<<EOF
CREATE TABLE IF NOT EXISTS `cdb_micxp_down_category` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `upid` mediumint(8) unsigned NOT NULL,
  `catname` varchar(255) NOT NULL,
  `softs` mediumint(8) unsigned NOT NULL,
  `displayorder` smallint(6) NOT NULL,
  `url` varchar(255) NOT NULL,
  `uid` mediumint(8) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  `closed` tinyint(1) NOT NULL,
  `description` text NOT NULL,
  `seotitle` text NOT NULL,
  `keyword` text NOT NULL,
  `tplname` varchar(255) NOT NULL,
  `websitetplname` varchar(255) NOT NULL,
  `disallowpublish` tinyint(1) NOT NULL,
  `perpage` smallint(6) NOT NULL,
  `maxpages` smallint(6) NOT NULL,
  `lastpublish` int(10) NOT NULL,
  `foldername` varchar(255) NOT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `cdb_micxp_down_hj` (
  `hjid` int(11) NOT NULL AUTO_INCREMENT,
  `hjname` varchar(50) NOT NULL,
  PRIMARY KEY (`hjid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `cdb_micxp_down_huandeng` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `url` varchar(255) NOT NULL,
  `target` tinyint(1) NOT NULL,
  `available` tinyint(1) NOT NULL,
  `displayorder` tinyint(3) NOT NULL,
  `highlight` tinyint(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `sid` mediumint(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `cdb_micxp_down_language` (
  `languageid` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(60) NOT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`languageid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `cdb_micxp_down_postad` (
  `catid` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

CREATE TABLE IF NOT EXISTS `cdb_micxp_down_soft` (
  `softid` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `softname` varchar(80) NOT NULL,
  `softhj` varchar(255) NOT NULL,
  `languageid` smallint(6) NOT NULL,
  `sqid` smallint(6) NOT NULL,
  `softtypeid` smallint(6) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `softsize` varchar(30) NOT NULL,
  `updatetime` int(10) NOT NULL,
  `comment` int(11) NOT NULL,
  `summary` varchar(255) NOT NULL,
  `verson` varchar(30) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `tag` tinyint(8) NOT NULL,
  `catid` smallint(6) NOT NULL,
  `softdj` smallint(6) NOT NULL,
  `softurl` varchar(255) NOT NULL,
  `aid` int(11) NOT NULL,
  `hot` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `logo` varchar(255) NOT NULL,
  `logoaid` int(11) NOT NULL,
  `istuijian` tinyint(1) NOT NULL DEFAULT '0',
  `tjtime` int(10) NOT NULL DEFAULT '0',
  `zjbb` tinyint(1) NOT NULL DEFAULT '0',
  `zjtime` int(10) NOT NULL DEFAULT '0',
  `downloads` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`softid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `cdb_micxp_down_softtype` (
  `softtypeid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `softtype` varchar(60) NOT NULL,
  `lencord` int(11) NOT NULL DEFAULT '25',
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  `maxnum` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`softtypeid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `cdb_micxp_down_sq` (
  `sqid` int(11) NOT NULL AUTO_INCREMENT,
  `sqname` varchar(60) NOT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sqid`)
) ENGINE=MyISAM;


		
EOF;
runquery($sql);
$finish = TRUE;
?>
