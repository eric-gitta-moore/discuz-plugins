<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/micxp_down/setting.class.php';
MicxpDownSetting::menu();

$Mlang = $scriptlang['micxp_down'];


//������Ȩ
if(!empty($_GET['sqname']) && submitcheck('sqsubmit')){
	$sqname = daddslashes(strip_tags($_GET['sqname']));
	$sqid = C::t("#micxp_down#micxp_down_sq")->fetch_id_by_sqname($sqname);
	if(!empty($sqid)){
		cpmsg($Mlang['exists'],"","error",'','',FALSE);
	}else{
		$sqid = DB::query("INSERT INTO ".DB::table('micxp_down_sq')."(sqname) VALUES ('".$sqname."')");
	}
}
//���²���
if(!empty($_GET['sqname'])  && submitcheck('squpdate')){

	$sqarray = daddslashes($_GET['sqname']);

	$ids = implode(',', array_keys($sqarray));
	$sql = "UPDATE ".DB::table('micxp_down_sq')." SET sqname = CASE sqid ";
	foreach ($sqarray as $id => $sqname) {

		$sql .= sprintf("WHEN %d THEN '%s' ", $id, $sqname);
	}

	$sql .= "END WHERE sqid IN ($ids)";
	DB::query($sql);
}
//�������
if($_GET['op'] == 'delete' && submitcheck('formhash',1)) {
	$id = intval($_GET['id']);
	if(!empty($id)) {
		C::t("#micxp_down#micxp_down_sq")->delete($id);
	}
}

//����Ĭ��
if($_GET['op'] == 'setdefault' && submitcheck('formhash',1)) {
	$id = intval($_GET['id']);
	if(!empty($id)) {
		DB::query("UPDATE ".DB::table('micxp_down_sq')." SET isdefault=0");
		C::t("#micxp_down#micxp_down_sq")->update($id,array('isdefault'=>1));
	}
}

showtableheader();
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=sq', 'sqsubmit');
showsubmit('sqsubmit', $Mlang['add'], $Mlang['sq_name'].': <input name="sqname" value="" class="txt" />');
showformfooter();



showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=sq', 'squpdate');
echo '<tr class="header"><th>ID</th><th>'.$Mlang['sq_name'].'</th><th></th><th>'.$Mlang['isdefault'].'</th><th>'.$Mlang['opration'].'</th></tr>';

$sqlist = C::t("#micxp_down#micxp_down_sq")->range();

//д��������
$cacheArray ='';
$cacheArray .= "\$sqlist=".arrayeval($sqlist).";\n";
writetocache("micxp_down_sq", $cacheArray);

foreach ($sqlist as $key=>$val){

	if($val['isdefault']){
		$isdefault=$Mlang['yes'];
	}else{
		$isdefault=$Mlang['no'];
	}

	echo '<tr><td class="td25">'.$val['sqid'].'</td><td><input name="sqname['.$val['sqid'].']" value="'.$val['sqname'].'" class="txt" type="text"></td><td></td><td>'.$isdefault.'</td><td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=sq&id='.$val['sqid'].'&op=setdefault&formhash='.FORMHASH.'">'.$Mlang['setdefault'].'</a>&nbsp;&nbsp;<a id="d'.$val['sqid'].'"  href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=sq&id='.$val['sqid'].'&op=delete&formhash='.FORMHASH.'" >'.$Mlang['delete'].'</a></td></tr>';

}
showsubmit('squpdate', $Mlang['update']);

showtablefooter();




?>