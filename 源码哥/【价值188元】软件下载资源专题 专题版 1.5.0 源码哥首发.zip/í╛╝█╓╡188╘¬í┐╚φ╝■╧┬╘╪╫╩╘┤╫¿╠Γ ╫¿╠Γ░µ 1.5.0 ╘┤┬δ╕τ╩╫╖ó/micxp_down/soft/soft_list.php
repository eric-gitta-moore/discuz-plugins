<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/downcp','plugin/micxp_down');
$cat = down_category_remake();

$_G['catid'] = $catid = max(0,intval($_GET['catid']));
if(empty($catid)) {
	showmessage('list_choose_category', dreferer());
}

$downcategory = &$_G['cache']['downcategory'];
$curcat = $downcategory[$catid];

if($curcat['level']){
	$showcat = $downcategory[$curcat['upid']]['catid'];
}else{
	$showcat = $catid;
}

//softjx
$subcatids = down_category_get_childids('down', $catid);

$subcatids[] = $catid;
$sqlwhere = " catid IN (".dimplode($subcatids).")";
$sqlwhere.= "AND istuijian=1";
$softjxlist = C::t('#micxp_down#micxp_down_soft')->fetch_all_by_sql($sqlwhere,'ORDER BY tjtime DESC',0,8);
foreach ($softjxlist as $key=>$value){
	
	$value['posturl'] ="forum.php?mod=viewthread&tid=".$value['tid'];
	if($value['logoaid']) {
		$logoatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($value['tid']))." WHERE aid='{$value[logoaid]}'");
		if($logoatt['remote']) {
			$logoatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$logoatt['attachment'];
			$logoatt['attachment'] = substr($logoatt['attachment'], 0, 7) != 'http://' ? 'http://'.$logoatt['attachment'] : $logoatt['attachment'];
		} else {
			$logoatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$logoatt['attachment'];
		}
	
		$value['logo']=$logoatt['attachment'];
	}else{
		$value['logo']="static/image/common/nophotosmall.gif";
	}
	$softjxlist[$key]=$value;
}






if(empty($curcat)) {
	showmessage('list_category_noexist', dreferer());
}

if($curcat['closed']) {
	showmessage('list_category_is_closed', dreferer());
}

if(!empty($curcat['url']))	dheader('location:'.$curcat['url']);


$page = max(1, intval($_GET['page']));

$catseoset = array(
		'seotitle' => $curcat['seotitle'],
		'seokeywords' => $curcat['keyword'],
		'seodescription' => $curcat['description']
);





include template('diy:soft_list', 0, 'source/plugin/micxp_down/template');



function down_category_get_wheresql($cat) {
	$wheresql = '';
	if(is_array($cat)) {
		$catid = $cat['catid'];
		if(!empty($cat['children'])) {
			$subcatids = down_category_get_childids('down', $catid);
			$subcatids[] = $catid;

			$wheresql = "at.catid IN (".dimplode($subcatids).")";
		} else {
			$wheresql = "at.catid='$catid'";
		}
	}
	//$wheresql .= " AND at.status='0'";
	return $wheresql;
}


function down_category_get_list($cat, $wheresql, $page = 1, $perpage = 0) {
	global $_G;
	
	
	$cat['perpage'] = empty($cat['perpage']) ? 15 : $cat['perpage'];
	$cat['maxpages'] = empty($cat['maxpages']) ? 1000 : $cat['maxpages'];
	$perpage = intval($perpage);
	$page = intval($page);
	$perpage = empty($perpage) ? $cat['perpage'] : $perpage;
	$page = empty($page) ? 1 : min($page, $cat['maxpages']);
	$start = ($page-1)*$perpage;
	if($start<0) $start = 0;
	$list = array();
	$pricount = 0;
	$multi = '';
	
	$count = C::t('#micxp_down#micxp_down_soft')->fetch_all_by_sql($wheresql, '', 0, 0, 1, 'at');
	if($count) {
		include_once DISCUZ_ROOT.'/data/sysdata/cache_micxp_down_language.php';
		$query = C::t('#micxp_down#micxp_down_soft')->fetch_all_by_sql($wheresql, 'ORDER BY at.updatetime DESC', $start, $perpage, 0, 'at');
		foreach($query as $value) {
			$value['catname'] = $value['catid'] == $cat['catid'] ? $cat['catname'] : $_G['cache']['downcategory'][$value['catid']]['catname'];
			$value['onerror'] = '';
			$value['updatetime'] = dgmdate($value['updatetime'],'Y-m-d');
			$value['language'] = $languagelist[$value['languageid']]['language'];
			$value['posturl'] ="forum.php?mod=viewthread&tid=".$value['tid'];
			if($value['logoaid']) {
				$logoatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($value['tid']))." WHERE aid='{$value[logoaid]}'");
				if($logoatt['remote']) {
					$logoatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$logoatt['attachment'];
					$logoatt['attachment'] = substr($logoatt['attachment'], 0, 7) != 'http://' ? 'http://'.$logoatt['attachment'] : $logoatt['attachment'];
				} else {
					$logoatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$logoatt['attachment'];
				}
			
				$value['logo']=$logoatt['attachment'];
			}else{
				$value['logo']="static/image/common/nophotosmall.gif";
			}
			
			

			$list[] = $value;
			$pricount++;
	
		}
		if(strpos($cat['caturl'], 'portal.php') === false) {
			$cat['caturl'] .= 'index.php';
		}
		$multi = multi($count, $perpage, $page, $cat['caturl'], $cat['maxpages']);
	}

	return $return = array('list'=>$list,'count'=>$count,'multi'=>$multi,'pricount'=>$pricount);
}