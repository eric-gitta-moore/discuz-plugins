<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//tjzjlist
$tjzjlist = C::t('#micxp_down#micxp_down_soft')->fetch_all_by_sql('istuijian=1 AND zjbb=1', 'ORDER BY tjtime DESC', 0, 50);
$cate = $_G['cache']['downcategory'];
foreach ($tjzjlist as $key=>$value){
	$value['posturl'] ="forum.php?mod=viewthread&tid=".$value['tid'];
	if($value['logoaid']) {
		$logoatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($value['tid']))." WHERE aid='{$value[logoaid]}'");
		if($logoatt['remote']) {
			$logoatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$logoatt['attachment'];
			$logoatt['attachment'] = substr($logoatt['attachment'], 0, 7) != 'http://' ? 'http://'.$logoatt['attachment'] : $logoatt['attachment'];
		} else {
			$logoatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$logoatt['attachment'];
		}
	
		$value['logo']=$logoatt['attachment'];
	}else{
		$value['logo']="static/image/common/nophototiny.png";
	}
	$tjzjlist[$key]=$value;
}


include template('diy:soft_top', 0, 'source/plugin/micxp_down/template');