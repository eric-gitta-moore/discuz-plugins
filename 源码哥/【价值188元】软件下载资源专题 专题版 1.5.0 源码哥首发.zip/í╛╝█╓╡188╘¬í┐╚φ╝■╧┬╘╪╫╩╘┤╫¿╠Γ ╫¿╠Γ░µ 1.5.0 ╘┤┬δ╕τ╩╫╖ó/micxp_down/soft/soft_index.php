<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/downcp','plugin/micxp_down');
$cat = down_category_remake();

$hanudeng = C::t('#micxp_down#micxp_down_huandeng')->fetch_all_sort_available(6);

foreach($hanudeng as $value) {
	if($value['logo']) {
		$value['logo'] = pic_get($value['logo'], 'common');
	}
	if($value['available'] == 1) {
		$value['target'] = $value['target'] ? ' target="_blank" ' : '';
		$hdlist[] = $value;
	}
	
	
}

//zjbb

$zjbbnum = isset($setting['M_zjbbnum']) ? intval($setting['M_zjbbnum']) : 24;
$zjbblist = C::t('#micxp_down#micxp_down_soft')->fetch_all_by_sql('zjbb =1','ORDER BY zjtime DESC',0,$zjbbnum);
foreach ($zjbblist as $key=> $value){
	$value['posturl'] ="forum.php?mod=viewthread&tid=".$value['tid'];
	if($value['logoaid']) {
		$logoatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($value['tid']))." WHERE aid='{$value[logoaid]}'");
		if($logoatt['remote']) {
			$logoatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$logoatt['attachment'];
			$logoatt['attachment'] = substr($logoatt['attachment'], 0, 7) != 'http://' ? 'http://'.$logoatt['attachment'] : $logoatt['attachment'];
		} else {
			$logoatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$logoatt['attachment'];
		}
		
		$value['logo']=$logoatt['attachment'];
	}else{
		$value['logo']="static/image/common/nophotosmall.gif";
	}
	$zjbblist[$key]=$value;
}

//zxtj
$zxtjnum = isset($setting['M_zxtjnum']) ? intval($setting['M_zxtjnum']) : 18;
$zxtjlist = C::t('#micxp_down#micxp_down_soft')->fetch_all_by_sql('istuijian =1','ORDER BY tjtime DESC',0,$zxtjnum);
foreach ($zxtjlist as $key=> $value){
	$value['posturl'] ="forum.php?mod=viewthread&tid=".$value['tid'];
	if($value['logoaid']) {
		$logoatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($value['tid']))." WHERE aid='{$value[logoaid]}'");
		if($logoatt['remote']) {
			$logoatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$logoatt['attachment'];
			$logoatt['attachment'] = substr($logoatt['attachment'], 0, 7) != 'http://' ? 'http://'.$logoatt['attachment'] : $logoatt['attachment'];
		} else {
			$logoatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$logoatt['attachment'];
		}

		$value['logo']=$logoatt['attachment'];
	}else{
		$value['logo']="static/image/common/nophotosmall.gif";
	}
	$zxtjlist[$key]=$value;
}

//cytj
$tjcatids = isset($setting['M_cateids']) ? daddslashes(trim($setting['M_cateids'])) : '';
$cynum = isset($setting['M_cynum']) ? intval($setting['M_cynum']) : 4;
$cytjcate =array();
if(!empty($tjcatids)){
	$tjidarray = explode(",", $tjcatids);
	foreach ($tjidarray as $value){
		$cid = intval($value);
		if(!empty($cid) && !empty($_G['cache']['downcategory'][$cid])){
			$cytjcate[$cid] = $_G['cache']['downcategory'][$cid];
		}
	}
}

if(!empty($cytjcate)){
	
	
	foreach ($cytjcate as $key=>$value){
		$catids =$wherearr= array();
		$wheresql ='';
		$catids = down_category_get_childids('down', $value['catid']);
		
		$catids[] = $value['catid'];
		
		if($catids) {
			$wherearr[] = " catid IN (".dimplode($catids).")";
		}
		$wherearr[] = DB::field('istuijian', 1);
		$wheresql = implode(' AND ', $wherearr);
		$query = C::t('#micxp_down#micxp_down_soft')->fetch_all_by_sql($wheresql, 'ORDER BY tjtime DESC', 0, $cynum);
		
		$list = $logoatt =array();
		foreach($query as $subvalue) {
			
			$subvalue['posturl'] ="forum.php?mod=viewthread&tid=".$subvalue['tid'];
			
			if($subvalue['logoaid']) {
				$logoatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($subvalue['tid']))." WHERE aid='{$subvalue[logoaid]}'");
				if($logoatt['remote']) {
					$logoatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$logoatt['attachment'];
					$logoatt['attachment'] = substr($logoatt['attachment'], 0, 7) != 'http://' ? 'http://'.$logoatt['attachment'] : $logoatt['attachment'];
				} else {
					$logoatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$logoatt['attachment'];
				}
			
				$subvalue['logo']=$logoatt['attachment'];
			}else{
				$value['logo']="static/image/common/nophotosmall.gif";
			}
			
			$list[] = $subvalue;
		}
		
		$cytjcate[$key]['softlist']=$list;
		
		
	}
}

//xzph
$xzphnum = isset($setting['M_downnum']) ? dintval($setting['M_downnum']) : 13;
$xzphlist = C::t('#micxp_down#micxp_down_soft')->fetch_all_by_sql('', 'ORDER BY downloads DESC', 0, $xzphnum);
foreach ($xzphlist as $key=>$value){
	$value['posturl'] ="forum.php?mod=viewthread&tid=".$value['tid'];
	if($value['logoaid']) {
		$logoatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($value['tid']))." WHERE aid='{$value[logoaid]}'");
		if($logoatt['remote']) {
			$logoatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$logoatt['attachment'];
			$logoatt['attachment'] = substr($logoatt['attachment'], 0, 7) != 'http://' ? 'http://'.$logoatt['attachment'] : $logoatt['attachment'];
		} else {
			$logoatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$logoatt['attachment'];
		}
	
		$value['logo']=$logoatt['attachment'];
	}else{
		$value['logo']="static/image/common/nophotosmall.gif";
	}
	$xzphlist[$key]=$value;
	
}
//error_reporting(E_ALL);
$navtitle =$setting['M_seotitle'];
$metadescription = $setting['M_seodescription'];
$metakeywords = $setting['M_seokeywords'];
include template('diy:index_soft', 0, 'source/plugin/micxp_down/template');

