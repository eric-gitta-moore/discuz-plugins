<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(empty($_GET['mod']) || !in_array($_GET['mod'], array('list','top'))) $_GET['mod'] = 'index';


define(MCURMODULE, $_GET['mod']);
$cachearray=array('downcategory');
loadcache($cachearray);
$setting = $_G['cache']['plugin']['micxp_down'];
require DISCUZ_ROOT.'./source/function/function_home.php';
require_once libfile('function/down','plugin/micxp_down');
include_once libfile('soft/'.$_GET['mod'],'plugin/micxp_down');

?>