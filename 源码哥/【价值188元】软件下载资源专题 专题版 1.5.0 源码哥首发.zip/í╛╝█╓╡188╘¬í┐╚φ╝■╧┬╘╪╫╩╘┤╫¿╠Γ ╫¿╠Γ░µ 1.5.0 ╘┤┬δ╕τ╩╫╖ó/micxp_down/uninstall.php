<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$cachearray = glob(DISCUZ_ROOT."/data/sysdata/cache_micxp_down_*.php");
if($cachearray){
	foreach ($cachearray as $val){
		@unlink($val);
	}
}

$sql = <<<EOF
DROP TABLE `cdb_micxp_down_category`, `cdb_micxp_down_hj`, `cdb_micxp_down_huandeng`, `cdb_micxp_down_language`, `cdb_micxp_down_postad`, `cdb_micxp_down_soft`, `cdb_micxp_down_softtype`, `cdb_micxp_down_sq`;
EOF;
runquery($sql);
$finish = TRUE;