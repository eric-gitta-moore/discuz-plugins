<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function deletesoft($sids, $istrash = true) {
	global $_G;
	
	if(empty($sids)) return false;
	$trasharr = $soft = $dels = $attachment = $attachaid = $catids =array();
	$query = C::t('#micxp_down#micxp_down_soft')->fetch_all($sids);
	foreach($query as $value) {
		$catids[] = intval($value['catid']);
		$dels[$value['softid']] = $value['softid'];
		$soft[] = $value;
		
	}
	if($dels) {

			
		C::t('#micxp_down#micxp_down_soft')->delete($dels);
		
		$catids = array_unique($catids);
		if($catids) {
			foreach($catids as $catid) {
				$cnt = C::t('#micxp_down#micxp_down_soft')->fetch_count_for_cat($catid);
				C::t('#micxp_down#micxp_down_category')->update($catid, array('softs'=>dintval($cnt)));
			}
		}	
			

	}
	return $soft;
}

