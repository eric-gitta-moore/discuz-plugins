<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function down_category_remake(){
	global $_G;
	$cat = $_G['cache']['downcategory'];
	if(empty($cat)) return array();
	$newarray = array();
	foreach ($_G['cache']['downcategory'] as $value) {
		
		if($value['upid']==0){
			$value['softs']=down_category_get_num('down', $value['catid']);
			$newarray[$value['catid']] = $value;
			if(!empty($value['children'])){
				foreach ($value['children'] as $subval){
					
					$newarray[$value['catid']]['sub'][]=$_G['cache']['downcategory'][$subval];
					
				}
				
			}

		}
	}

	return $newarray;
}


function get_mode_url($mode){
	
	return "plugin.php?id=micxp_down:micxp_down&mod=".$mode;
	
}
