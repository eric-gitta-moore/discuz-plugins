<?php
function down_category_get_num($type, $catid) {
	global $_G;
	
	loadcache($type.'category');
	$category = $_G['cache'][$type.'category'];
	$numkey =  'softs';
	
	if(! isset($_G[$type.'category_nums'])) {
		
		$_G[$type.'category_nums'] = array();
		$tables = array('down'=>'micxp_down_category');
		
		$query = C::t('#micxp_down#'.$tables[$type])->fetch_all_numkey($numkey);
		foreach ($query as $value) {
			$_G[$type.'category_nums'][$value['catid']] = intval($value[$numkey]);
		}
		
	}
	$nums = $_G[$type.'category_nums'];
	$num = intval($nums[$catid]);
	if($category[$catid]['children']) {
		foreach($category[$catid]['children'] as $id) {
			$num += down_category_get_num($type, $id);
		}
	}
	return $num;
}

function down_category_showselect($type, $name='catid', $shownull=true, $current='') {
	global $_G;
	if(! in_array($type, array('down'))) {
		return '';
	}
	loadcache($type.'category');
	$category = $_G['cache'][$type.'category'];

	$select = "<select id=\"$name\" name=\"$name\" class=\"ps vm\">";
	if($shownull) {
		$select .= '<option value="">'.lang('plugin/micxp_down', 'select_category').'</option>';
	}
	foreach ($category as $value) {
		if($value['level'] == 0) {
			$selected = ($current && $current==$value['catid']) ? 'selected="selected"' : '';
			$select .= "<option value=\"$value[catid]\"$selected>$value[catname]</option>";
			if(!$value['children']) {
				continue;
			}
			foreach ($value['children'] as $catid) {
				$selected = ($current && $current==$catid) ? 'selected="selected"' : '';
				$select .= "<option value=\"{$category[$catid][catid]}\"$selected>-- {$category[$catid][catname]}</option>";
				if($category[$catid]['children']) {
					foreach ($category[$catid]['children'] as $catid2) {
						$selected = ($current && $current==$catid2) ? 'selected="selected"' : '';
						$select .= "<option value=\"{$category[$catid2][catid]}\"$selected>---- {$category[$catid2][catname]}</option>";
					}
				}
			}
		}
	}
	$select .= "</select>";
	return $select;
}
















function down_category_get_childids($type, $catid, $depth=2) {
	global $_G;
	if(! in_array($type, array('down'))) {
		return array();
	}
	loadcache($type.'category');
	$category = $_G['cache'][$type.'category'];
	$catids = array();
	if(isset($category[$catid]) && !empty($category[$catid]['children']) && $depth) {
		
		$catids = $category[$catid]['children'];
		foreach($category[$catid]['children'] as $id) {
			$catids = array_merge($catids, down_category_get_childids($type, $id, $depth-1));
		}
	}
	return $catids;
}




function language_showselect($vl=""){
	$return='<select name="language" id="soft_yy">';
	include_once DISCUZ_ROOT.'/data/sysdata/cache_micxp_down_language.php';
	$return.='<option value="0">'.lang("plugin/micxp_down","select_yy").'</option>';
	if(!empty($languagelist)){
		foreach ($languagelist as $key=>$val){
			if(!empty($vl)){
				if($vl==$val['languageid']){
					$selected ='selected = "selected"';
				}else{
					$selected ="";
				}
				
			}else{
				if($val['isdefault']){
					$selected ='selected = "selected"';
				}else{
					$selected ="";
				}
			}
			$return.='<option value="'.$val['languageid'].'" '.$selected.'>'.$val['language'].'</option>';
		}
	}
	
	$return.='</select/>';
	return $return;
}


function softtype_showselect($vl=""){
	$return='<select name="softtype" id="soft_lx">';
	include_once DISCUZ_ROOT.'/data/sysdata/cache_micxp_down_softtype.php';
	$return.='<option value="0">'.lang("plugin/micxp_down","select_lx").'</option>';
	if(!empty($softtypelist)){
		foreach ($softtypelist as $key=>$val){
			if(!empty($vl)){
				if($vl==$val['softtypeid']){
					$selected ='selected = "selected"';
				}else{
					$selected ="";
				}
				
			}else{
				if($val['isdefault']){
					$selected ='selected = "selected"';
				}else{
					$selected ="";
				}
			}
			$return.='<option value="'.$val['softtypeid'].'" '.$selected.'>'.$val['softtype'].'</option>';
		}
	}
	
	$return.='</select/>';
	return $return;
	
}

function sq_showselect($vl=""){
	$return='<select name="sq" id="soft_sq">';
	include_once DISCUZ_ROOT.'/data/sysdata/cache_micxp_down_sq.php';
	$return.='<option value="0">'.lang("plugin/micxp_down","select_sq").'</option>';
	if(!empty($sqlist)){
		foreach ($sqlist as $key=>$val){
			if(!empty($vl)){
				if($vl==$val['sqid']){
					$selected ='selected = "selected"';
				}else{
					$selected ="";
				}
				
			}else{
				if($val['isdefault']){
					$selected ='selected = "selected"';
				}else{
					$selected ="";
				}
			}
			$return.='<option value="'.$val['sqid'].'" '.$selected.'>'.$val['sqname'].'</option>';

		}
		
	}
	
	$return.='</select/>';
	return $return;
}

function dj_showselect($vl=""){
	
	
	$return='<select name="dj" id="soft_dj">';
	$return.='<option value="0" '.ckvl(0,$vl).'>'.lang("plugin/micxp_down","select_dj").'</option>';
	$return.='<option value="1" '.ckvl(1,$vl).'>'.lang("plugin/micxp_down","start_1").'</option>';
	$return.='<option value="2" '.ckvl(2,$vl).'>'.lang("plugin/micxp_down","start_2").'</option>';
	$return.='<option value="3" '.ckvl(3,$vl).'>'.lang("plugin/micxp_down","start_3").'</option>';
	$return.='<option value="4" '.ckvl(4,$vl).'>'.lang("plugin/micxp_down","start_4").'</option>';
	$return.='<option value="5" '.ckvl(5,$vl).'>'.lang("plugin/micxp_down","start_5").'</option>';
	
	$return.='</select/>';
	return $return;
}

function ckvl($a,$b){
	if(empty($b)){
		return "";
	}else{
		if($a==$b){
			return 'selected = "selected"';
		}else{
			return "";
		}
		
	}
}

function get_hjlist(){
	$return='';
	include_once DISCUZ_ROOT.'/data/sysdata/cache_micxp_down_hj.php';
	if(!empty($hjlist)){
		
		foreach ($hjlist as $val){
			$return.='<input name="check" value="'.$val['hjname'].'" onclick="if(this.checked){AddFj(this.value);}else{DelFj(this.value);}" type="checkbox">'.$val['hjname'].'&nbsp;&nbsp;';
		}
	}else{
		$return.=lang('plugin/micxp_down','hjtips');
	}
	return $return;
}

