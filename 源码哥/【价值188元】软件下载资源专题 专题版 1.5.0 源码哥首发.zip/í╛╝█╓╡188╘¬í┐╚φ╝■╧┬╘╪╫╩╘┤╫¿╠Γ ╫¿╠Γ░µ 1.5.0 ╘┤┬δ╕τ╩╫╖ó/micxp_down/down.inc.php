<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(submitcheck('formhash',1)){
	$softid = dintval($_GET['softid']);
	
	$soft = C::t('#micxp_down#micxp_down_soft')->fetch($softid);
	if(empty($soft) || empty($soft['softurl'])){
		showmessage(lang('plugin/micxp_down','soft_not_find'),dreferer());
	}
	DB::query("UPDATE ".DB::table('micxp_down_soft')." SET downloads=downloads+1 WHERE softid='$softid'");
	
	
	dheader("Location:".$soft['softurl']);
	
	
}

