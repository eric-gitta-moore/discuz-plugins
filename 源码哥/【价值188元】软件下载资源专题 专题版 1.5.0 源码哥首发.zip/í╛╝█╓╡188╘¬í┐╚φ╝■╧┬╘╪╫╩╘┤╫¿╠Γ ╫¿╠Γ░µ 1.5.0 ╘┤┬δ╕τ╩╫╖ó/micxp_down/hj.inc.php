<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/micxp_down/setting.class.php';
MicxpDownSetting::menu();

$Mlang = $scriptlang['micxp_down'];

//���ӻ���
if(!empty($_GET['hjname']) && submitcheck('hjsubmit')){
	$hjname = daddslashes(strip_tags($_GET['hjname']));
	$hjid = C::t("#micxp_down#micxp_down_hj")->fetch_id_by_hjname($hjname);
	if(!empty($hjid)){
		cpmsg($Mlang['exists'],"","error",'','',FALSE);
	}else{
		$hjid = DB::query("INSERT INTO ".DB::table('micxp_down_hj')."(hjname) VALUES ('".$hjname."')");
	}
}


//���²���
if(!empty($_GET['hjname'])  && submitcheck('hjupdate')){

	$hjarray = daddslashes($_GET['hjname']);

	$ids = implode(',', array_keys($hjarray));
	$sql = "UPDATE ".DB::table('micxp_down_hj')." SET hjname = CASE hjid ";
	foreach ($hjarray as $id => $hjname) {

		$sql .= sprintf("WHEN %d THEN '%s' ", $id, $hjname);
	}

	$sql .= "END WHERE hjid IN ($ids)";
	DB::query($sql);
}
//�������
if($_GET['op'] == 'delete' && submitcheck('formhash',1)) {
	$id = intval($_GET['id']);
	if(!empty($id)) {
		C::t("#micxp_down#micxp_down_hj")->delete($id);
	}
}

showtableheader();
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=hj', 'hjsubmit');
showsubmit('hjsubmit', $Mlang['add'], $Mlang['hj_name'].': <input name="hjname" value="" class="txt" />');
showformfooter();

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=hj', 'hjupdate');
echo '<tr class="header"><th>ID</th><th>'.$Mlang['hj_name'].'</th><th></th><th></th><th>'.$Mlang['opration'].'</th></tr>';

$hjlist = C::t("#micxp_down#micxp_down_hj")->range();


//д��������
$cacheArray ='';
$cacheArray .= "\$hjlist=".arrayeval($hjlist).";\n";
writetocache("micxp_down_hj", $cacheArray);


foreach ($hjlist as $key=>$val){

	echo '<tr><td class="td25">'.$val['hjid'].'</td><td><input name="hjname['.$val['hjid'].']" value="'.$val['hjname'].'" class="txt" type="text"></td><td></td><td></td><td><a id="d'.$val['sqid'].'"  href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=hj&id='.$val['hjid'].'&op=delete&formhash='.FORMHASH.'" >'.$Mlang['delete'].'</a></td></tr>';

}
showsubmit('hjupdate', $Mlang['update']);

showtablefooter();

?>