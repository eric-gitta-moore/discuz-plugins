<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_micxp_down_softtype extends discuz_table{
	public function __construct() {
	
		$this->_table = 'micxp_down_softtype';
		$this->_pk    = 'softtypeid';
	
		parent::__construct();
	}
	
	public function fetch_id_by_softtype($softtype){
		return DB::result_first("SELECT softtypeid FROM %t WHERE softtype=%s", array($this->_table, $softtype));
	}
	

	
	
		

}