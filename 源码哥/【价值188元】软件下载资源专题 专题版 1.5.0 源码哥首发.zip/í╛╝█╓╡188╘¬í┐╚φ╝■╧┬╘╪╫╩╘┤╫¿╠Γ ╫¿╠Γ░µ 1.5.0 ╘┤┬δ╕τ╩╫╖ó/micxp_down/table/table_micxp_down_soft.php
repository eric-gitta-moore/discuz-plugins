<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_micxp_down_soft extends discuz_table
{
	public function __construct() {

		$this->_table = 'micxp_down_soft';
		$this->_pk    = 'softid';

		parent::__construct();
	}
	
	public function fetch_count_for_cat($catid) {
		if(empty($catid)) {
			return 0;
		}
		return DB::result_first('SELECT COUNT(*) FROM %t WHERE catid=%d', array($this->_table, $catid));
	}
	
	
	public function fetch_all_for_cat($catid, $status = null, $orderaid = 0, $start = 0, $limit = 0) {
		if(empty($catid)) {
			return array();
		}
		$statussql = $status !== null ? ' AND '.DB::field('status', $status) : '';
		$orderaidsql = $orderaid ? ' ORDER BY softid DESC' : '';
		return DB::fetch_all('SELECT * FROM %t WHERE '.DB::field('catid', $catid).$statussql.$orderaidsql.DB::limit($start, $limit), array($this->_table));
	}
	
	public function update_for_cat($catid, $data) {
		if(empty($catid) || empty($data)) {
			return false;
		}
		return DB::update($this->_table, $data, DB::field('catid', $catid));
	}
	
	
	public function fetch_all_by_sql($where, $order = '', $start = 0, $limit = 0, $count = 0, $alias = '') {
		$where = $where && !is_array($where) ? " WHERE $where" : '';
		if(is_array($order)) {
			$order = '';
		}
		if($count) {
			return DB::result_first('SELECT count(*) FROM '.DB::table($this->_table).'  %i %i %i '.DB::limit($start, $limit), array($alias, $where, $order));
		}
		return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' %i %i %i '.DB::limit($start, $limit), array($alias, $where, $order));
	}
	
	
	
	
	
	
	public function fetch_preaid_by_catid_sid($catid, $sid) {
		$ret = 0;
		if(($catid = intval($catid)) && ($sid = intval($sid))) {
			$ret = DB::result_first('SELECT sid FROM %t WHERE catid=%d AND sid<%d ORDER BY sid DESC LIMIT 1', array($this->_table, $catid, $sid));
		}
		return $ret;
	}
	
	public function fetch_nextaid_by_catid_sid($catid, $sid) {
		$ret = 0;
		if(($catid = intval($catid)) && ($sid = intval($sid))) {
			$ret = DB::result_first('SELECT sid FROM %t WHERE catid=%d AND sid>%d ORDER BY sid ASC LIMIT 1', array($this->_table, $catid, $sid));
		}
		return $ret;
	}
	
	public function fetch_all_sid_by_dateline($dateline, $catids = array(), $startid = 0, $endid = 0) {
		$data = array();
		$where = array();
		if($startid) {
			$where[] = DB::field('sid', intval($startid), '>=');
		}
		if($endid) {
			$where[] = DB::field('sid', intval($endid), '<=');
		}
		if($catids) {
			$where[] = DB::field('catid', dintval($catids, true));
		}
		if($dateline) {
			$where[] = DB::field('dateline', intval($dateline), '>=');
		}
	
		if($where) {
			$data = DB::fetch_all('SELECT sid FROM '.DB::table($this->_table).' WHERE '. implode(' AND ', $where).' LIMIT 200000', NULL, $this->_pk);
		}
		return $data;
	}
	
	public function fetch_by_weburl($url,$sid){
		if($sid){
			$where=" WHERE sid <>%d AND weburl=%s";
			return DB::fetch_first('SELECT weburl FROM %t  '. $where,array($this->_table,$sid,$url));
		}else{
			$where=" WHERE  weburl=%s";
			return DB::fetch_first('SELECT weburl FROM %t  '. $where,array($this->_table,$url));
		}
		
	}
	
	public function fetch_by_weburl_all($url){
		return DB::fetch_first('SELECT * FROM %t WHERE weburl=%s LIMIT 1 ',array($this->_table,$url));
	}

}

?>