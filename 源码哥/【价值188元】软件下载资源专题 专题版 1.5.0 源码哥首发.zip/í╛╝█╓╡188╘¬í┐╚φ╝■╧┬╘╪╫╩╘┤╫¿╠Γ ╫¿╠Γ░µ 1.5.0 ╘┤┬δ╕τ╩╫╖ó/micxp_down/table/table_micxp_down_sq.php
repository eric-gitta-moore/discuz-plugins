<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_micxp_down_sq extends discuz_table{
	public function __construct() {
	
		$this->_table = 'micxp_down_sq';
		$this->_pk    = 'sqid';
	
		parent::__construct();
	}
	
	public function fetch_id_by_sqname($sqname){
		return DB::result_first("SELECT sqid FROM %t WHERE sqname=%s", array($this->_table, $sqname));
	}
	

	
	
		

}