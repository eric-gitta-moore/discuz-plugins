<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_micxp_down_postad extends discuz_table
{
	public function __construct() {

		$this->_table = 'micxp_down_postad';
		$this->_pk    = 'catid';

		parent::__construct();
	}
	
	public function fetch($id, $force_from_db = false){
		$data = array();
		if(!empty($id) || $id===0) {
			if($force_from_db || ($data = $this->fetch_cache($id)) === false) {
				$data = DB::fetch_first('SELECT * FROM '.DB::table($this->_table).' WHERE '.DB::field($this->_pk, $id));
				if(!empty($data)) $this->store_cache($id, $data);
			}
		}
		return $data;
	}


}

?>