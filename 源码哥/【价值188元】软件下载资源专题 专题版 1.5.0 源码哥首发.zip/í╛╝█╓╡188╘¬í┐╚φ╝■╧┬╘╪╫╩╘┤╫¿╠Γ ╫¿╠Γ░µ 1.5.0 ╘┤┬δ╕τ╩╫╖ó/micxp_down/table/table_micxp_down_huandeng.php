<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_micxp_down_huandeng extends discuz_table
{
	public function __construct() {

		$this->_table = 'micxp_down_huandeng';
		$this->_pk    = 'id';

		parent::__construct();
	}
	
	
	public function fetch_all_sort(){
		return DB::fetch_all("SELECT * FROM %t ORDER BY displayorder,id",array($this->_table));
	}
	
	public function fetch_all_sort_available($num){
		return DB::fetch_all("SELECT * FROM %t WHERE available=1 ORDER BY displayorder,id LIMIT %d ",array($this->_table,$num));
	}

}

?>