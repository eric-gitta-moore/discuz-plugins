<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_micxp_down_hj extends discuz_table{
	public function __construct() {
	
		$this->_table = 'micxp_down_hj';
		$this->_pk    = 'hjid';
	
		parent::__construct();
	}
	
	public function fetch_id_by_hjname($hjname){
		return DB::result_first("SELECT hjid FROM %t WHERE hjname=%s", array($this->_table, $hjname));
	}
	

	
	
		

}