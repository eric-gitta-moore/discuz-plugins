<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_micxp_down_language extends discuz_table{
	public function __construct() {
	
		$this->_table = 'micxp_down_language';
		$this->_pk    = 'languageid';
	
		parent::__construct();
	}
	
	public function fetch_id_by_language($language){
		return DB::result_first("SELECT languageid FROM %t WHERE language=%s", array($this->_table, $language));
	}
	

	
	
		

}