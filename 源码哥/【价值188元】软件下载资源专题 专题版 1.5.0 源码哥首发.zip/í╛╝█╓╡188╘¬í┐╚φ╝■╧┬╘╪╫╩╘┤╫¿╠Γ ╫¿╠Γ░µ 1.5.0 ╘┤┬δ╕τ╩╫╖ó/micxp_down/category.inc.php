<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/micxp_down/setting.class.php';
MicxpDownSetting::menu();

$Mlang = $scriptlang['micxp_down'];
$op = daddslashes($_GET['op']);
$op = in_array($op, array('delete', 'move', 'perm', 'add', 'edit')) ? $op : 'list';
loadcache('downcategory',true);
$downcategory = $_G['cache']['downcategory'];

if($op == 'list') {
	if(empty($downcategory) && C::t('#micxp_down#micxp_down_category')->count()) {
		updatecache('micxp_down:downcategory');
		loadcache('downcategory', true);
		$downcategory = $_G['cache']['downcategory'];
		
	}
	
	if(!submitcheck('editsubmit')) {
		$tdstyle = array('width="25"', 'width="60"', '', 'width="45"', 'width="55"', 'width="30"', 'width="30"', 'width="30"', 'width="185"', 'width="100"');
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category');
		echo '<div style="height:30px;line-height:30px;"><a href="javascript:;" onclick="show_all()">'.cplang('show_all').'</a> | <a href="javascript:;" onclick="hide_all()">'.cplang('hide_all').'</a> <input type="text" id="srchforumipt" class="txt" /> <input type="submit" class="btn" value="'.cplang('search').'" onclick="return srchforum()" /></div>';
		showtableheader('', '', 'style="min-width:900px;*width:900px;"');
		showsubtitle(array('', '', $Mlang['category_name'], $Mlang['category_softs'], $Mlang['category_allowpublish'], '', $Mlang['category_is_closed'], '', 'operation', $Mlang['soft_op']), 'header', $tdstyle);
		foreach ($downcategory as $key=>$value) {
			if($value['level'] == 0) {
				echo showcategoryrow($key, 0, '');
			}
		}
		echo '<tbody><tr><td>&nbsp;</td><td colspan="6"><div><a class="addtr" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=add&upid=0">'.$Mlang['category_addcategory'].'</a></div></td><td colspan="3">&nbsp;</td></tr></tbody>';
		showsubmit('editsubmit');
		showtablefooter();
		showformfooter();
		
		
		
	}else{
		//submit code
		if($_GET['name']) {
			$openarr = $closearr = array();
			foreach($_GET['name'] as $key=>$value) {
				$sets = array();
				$value = trim($value);
				if($downcategory[$key] && $downcategory[$key]['catname'] != $value) {
					$sets['catname'] = $value;
				}
				if($downcategory[$key] && $downcategory[$key]['displayorder'] != $_GET['neworder'][$key]) {
					$sets['displayorder'] = $_GET['neworder'][$key];
				}
				if($sets) {
					C::t('#micxp_down#micxp_down_category')->update($key, $sets);
				}
			}
		}
		updatecache('micxp_down:downcategory');
		cpmsg($Mlang['category_update_succeed'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category', 'succeed');
		
		
		
	}
	
	
	
}elseif($op == 'edit' || $op == 'add') {
	
	$_GET['catid'] = intval($_GET['catid']);
	$anchor = in_array($_GET['anchor'], array('basic', 'html')) ? $_GET['anchor'] : 'basic';
	
	if($_GET['catid'] && !$downcategory[$_GET['catid']]) {
		cpmsg($Mlang['catgory_not_found'], '', 'error');
	}
	$cate = $_GET['catid'] ? $downcategory[$_GET['catid']] : array();
	if($op == 'add') {
		$_GET['upid'] = intval($_GET['upid']);
		if($_GET['upid']) {
			$cate['level'] = $downcategory[$_GET['upid']] ? $downcategory[$_GET['upid']]['level']+1 : 0;
			$cate['upid'] = intval($_GET['upid']);
		} else {
			$cate['level'] = 0;
			$cate['upid'] = 0;
		}
		$cate['displayorder'] = 0;
		$cate['closed'] = 1;
	}
	if(!submitcheck('detailsubmit')) {
		$url = 'plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op='.$op.($op == 'add' ? '&upid='.$_GET['upid'] : '&catid='.$_GET['catid']);
		
		showformheader($url);
		showtableheader();
		$catemsg = '';
		
		if($cate['username']) $catemsg .= $Mlang['category_username'].' '.$cate['username'];
		if($cate['dateline']) $catemsg .= ' '.$Mlang['category_dateline'].' '.dgmdate($cate['dateline'],'Y-m-d m:i:s');
		if($cate['upid']) $catemsg .= ' '.$Mlang['category_upname'].': <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=edit&catid='.$cate['upid'].'">'.$downcategory[$cate['upid']]['catname'].'</a>';
		if($catemsg) showtitle($catemsg);
		
		
		showsetting($Mlang['category_name'], 'catname', html_entity_decode($cate['catname']), 'text');
		showsetting($Mlang['display_order'], 'displayorder', $cate['displayorder'], 'text');
		showsetting($Mlang['category_foldername'], 'foldername', $cate['foldername'], 'text');
		showsetting($Mlang['category_url'], 'url', $cate['url'], 'text');
		showsetting($Mlang['category_perpage'], 'perpage', $cate['perpage'] ? $cate['perpage'] : 15, 'text');
		showsetting($Mlang['category_maxpages'], 'maxpages', $cate['maxpages'] ? $cate['maxpages'] : 1000, 'text');
		
		showsetting($Mlang['category_tplname'], 'tplname', html_entity_decode($cate['tplname']), 'text');
		
		showsetting($Mlang['category_editallowpublish'], 'allowpublish', $cate['disallowpublish'] ? 0 : 1, 'radio');
		showsetting($Mlang['category_editis_closed'], 'closed', $cate['closed'] ? 0 : 1, 'radio');
		
		showtablefooter();
		
		showtableheader();
		showsetting($Mlang['down_seotitle'], 'seotitle', $cate['seotitle'], 'text');
		showsetting($Mlang['down_keyword'], 'keyword', $cate['keyword'], 'text');
		showsetting($Mlang['down_summary'], 'description', $cate['description'], 'textarea');
		
		showtablefooter();
		showsubmit('detailsubmit');
		if($op == 'add') showsetting('', '', '', '<input type="hidden" name="level" value="'.$cate['level'].'" />');
		showformfooter();
		
		
		
	}else{
		//add or edit submit code
		//require_once libfile('function/portalcp');
		
		$_GET['closed'] = intval($_GET['closed']) ? 0 : 1;
		$_GET['catname'] = trim($_GET['catname']);
		$foldername = trim($_GET['foldername']);
		$perpage = intval($_GET['perpage']);
		$maxpages = intval($_GET['maxpages']);
		$perpage = empty($perpage) ? 15 : $perpage;
		$maxpages = empty($maxpages) ? 1000 : $maxpages;
		
		$updatecategoryfile = array();
		$editcat = array(
				'catname' => $_GET['catname'],
				'url' => $_GET['url'],
				'closed' => $_GET['closed'],
				'seotitle' => $_GET['seotitle'],
				'keyword' => $_GET['keyword'],
				'description' => $_GET['description'],
				'displayorder' => intval($_GET['displayorder']),
				'disallowpublish' => $_GET['allowpublish'] ? '0' : '1',
				'perpage' => $perpage,
				'maxpages' => $maxpages,
		);
		
		$dir = '';
		if(!empty($foldername)) {
			$oldfoldername = empty($_GET['catid']) ? '' : $downcategory[$_GET['catid']]['foldername'];
			preg_match_all('/[^\w\d\_]/',$foldername,$re);
			if(!empty($re[0])) {
				cpmsg($Mlang['category_foldername_rename_error'].','.$Mlang['return'], NULL, 'error');
			}
			$parentdir = getcategoryfulldir($cate['upid']);
			if($parentdir === false) cpmsg($Mlang['category_parentfoldername_empty'].','.$Mlang['return'], NULL, 'error');
			if($foldername == $oldfoldername) {
				$dir = $parentdir.$foldername;
			} elseif(is_dir(DISCUZ_ROOT.'./'.$parentdir.$foldername)) {
				cpmsg($Mlang['category_foldername_duplicate'].','.$Mlang['return'], NULL, 'error');
			} elseif ($downcategory[$_GET['catid']]['foldername']) {
				$r = rename(DISCUZ_ROOT.'./'.$parentdir.$downcategory[$_GET['catid']]['foldername'], DISCUZ_ROOT.'./'.$parentdir.$foldername);
				if($r) {
					$updatecategoryfile[] = $_GET['catid'];
					$editcat['foldername'] = $foldername;
					
				} else {
					cpmsg($Mlang['category_foldername_rename_error'].','.$Mlang['return'], NULL, 'error');
				}
			} elseif (empty($downcategory[$_GET['catid']]['foldername'])) {
				$dir = $parentdir.$foldername;
				$editcat['foldername'] = $foldername;
			}
		} elseif(empty($foldername) && $downcategory[$_GET['catid']]['foldername']) {
			delcategoryfolder($_GET['catid']);
			$editcat['foldername'] = '';
		}
		
		$editcat['tplname'] = $_GET['tplname'];
		
		$cachearr = array('downcategory');
		if($_GET['catid']) {
			C::t('#micxp_down#micxp_down_category')->update($cate['catid'], $editcat);
			
		} else {
			$editcat['upid'] = $cate['upid'];
			$editcat['dateline'] = TIMESTAMP;
			$editcat['uid'] = $_G['uid'];
			$editcat['username'] = $_G['username'];
			$_GET['catid'] = C::t('#micxp_down#micxp_down_category')->insert($editcat, true);

		}
		
		include_once libfile('function/cache');
		updatecache('micxp_down:downcategory');
		loadcache('downcategory', true);
		$downcategory = $_G['cache']['downcategory'];
		
		if(!empty($updatecategoryfile)) {
			remakecategoryfile($updatecategoryfile);
		}
		
		if($dir) {
			if(!makecategoryfile($dir, $_GET['catid'])) {
				cpmsg($Mlang['category_filewrite_error'].','.$Mlang['return'], NULL, 'error');
			}
			remakecategoryfile($downcategory[$_GET['catid']]['children']);
		}
		updatecache('micxp_down:downcategory');
		
		$url = $op == 'add' ? ADMINSCRIPT."?frames=yes&action=plugins&operation=config&do=$pluginid&identifier=micxp_down&pmod=category#cat".$_GET['catid'] : ADMINSCRIPT."?frames=yes&action=plugins&operation=config&do=$pluginid&identifier=micxp_down&pmod=category&op=edit&catid=".$_GET['catid'];
		cpmsg($Mlang['category_edit_succeed'], $url, 'succeed');
		
		
		
	}//add edit code submit
	
	
	
}elseif($op == 'delete') {
	
	$_GET['catid'] = max(0, intval($_GET['catid']));
	if(!$_GET['catid'] || !$downcategory[$_GET['catid']]) {
		cpmsg($Mlang['catgory_not_found'], '', 'error');
	}
	$catechildren = $downcategory[$_GET['catid']]['children'];
	include_once libfile('function/cache');
	
	if(!submitcheck('deletesubmit')) {
		$softs_count = C::t('#micxp_down#micxp_down_soft')->fetch_count_for_cat($_GET['catid']);
		if(!$softs_count && empty($catechildren)) {
			if($downcategory[$_GET['catid']]['foldername']) delcategoryfolder($_GET['catid']);
			deletecategory($_GET['catid']);
			updatecache('micxp_down:downcategory');
			cpmsg($Mlang['category_delete_succeed'], ADMINSCRIPT."?frames=yes&action=plugins&operation=config&do=$pluginid&identifier=micxp_down&pmod=category", 'succeed');
		}
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=delete&catid='.$_GET['catid']);
		showtableheader();
		if($downcategory[$_GET[catid]]['children']) {
			showsetting($Mlang['category_subcategory_moveto'], '', '',
			'<input type="radio" name="subcat_op" value="trash" id="subcat_op_trash" checked="checked" />'.
			'<label for="subcat_op_trash" />'.cplang('portalcategory_subcategory_moveto_trash').'</label>'.
			'<input type="radio" name="subcat_op" value="parent" id="subcat_op_parent" checked="checked" />'.
			'<label for="subcat_op_parent" />'.cplang('portalcategory_subcategory_moveto_parent').'</label>'
					);
		}
		require libfile('function/downcp','plugin/micxp_down');
		echo "<tr><td colspan=\"2\" class=\"td27\">".$Mlang['category_soft'].":</td></tr>
				<tr class=\"noborder\">
					<td class=\"vtop rowform\">
						<ul class=\"nofloat\" onmouseover=\"altStyle(this);\">
						<li class=\"checked\"><input class=\"radio\" type=\"radio\" name=\"dh_op\" value=\"move\" checked />&nbsp;".$Mlang['category_soft_moveto']."&nbsp;&nbsp;&nbsp;".down_category_showselect('down', 'tocatid', false, $downcategory[$_GET['catid']]['upid'])."</li>
						<li><input class=\"radio\" type=\"radio\" name=\"dh_op\" value=\"delete\" />&nbsp;".cplang('portalcategory_article_delete')."</li>
						</ul></td>
					<td class=\"vtop tips2\"></td>
				</tr>";
		showsubmit('deletesubmit', $Mlang['category_delete']);
		showtablefooter();
		showformfooter();
		
		
	}else{
		if($_GET['dh_op'] == 'delete') {
			if(!$_GET['confirmed']) {
				cpmsg($Mlang['dh_delete_confirm'], "action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=delete&catid=$_GET[catid]", 'form', array(),
				'<input type="hidden" class="btn" id="deletesubmit" name="deletesubmit" value="1" /><input type="hidden" class="btn" id="subcat_op" name="subcat_op" value="'.$_GET[subcat_op].'" />
					<input type="hidden" class="btn" id="article_op" name="dh_op" value="delete" /><input type="hidden" class="btn" id="tocatid" name="tocatid" value="'.$_GET[tocatid].'" />');
			}
		}
		
		if($_GET['dh_op'] == 'move') {
			if($_GET['tocatid'] == $_GET['catid'] || empty($downcategory[$_GET['tocatid']])) {
				cpmsg($Mlang['dhcategory_move_category_failed'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category', 'error');
			}
		}
		
		$delids = array($_GET['catid']);
		$updatecategoryfile = array();
		if($catechildren) {
			if($_GET['subcat_op'] == 'parent') {
				$upid = intval($downcategory[$_GET['catid']]['upid']);
				if(!empty($downcategory[$upid]['foldername']) || ($downcategory[$_GET['catid']]['level'] == '0' && $downcategory[$_GET['catid']]['foldername'])) {
					$parentdir = DISCUZ_ROOT.'/'.getcategoryfulldir($upid);
					foreach($catechildren as $subcatid) {
						if($downcategory[$subcatid]['foldername']) {
							$olddir = DISCUZ_ROOT.'/'.getcategoryfulldir($subcatid);
							rename($olddir, $parentdir.$downcategory[$subcatid]['foldername']);
							$updatecategoryfile[] = $subcatid;
						}
					}
				}
			
				C::t('#micxp_down#micxp_down_category')->update($catechildren, array('upid' => $upid));
			
			}else{
				$delids = array_merge($delids, $catechildren);
				foreach ($catechildren as $id) {
					$value = $downcategory[$id];
					if($value['children']) {
						$delids = array_merge($delids, $value['children']);
					}
				}
				if($_GET['dh_op'] == 'move') {
					if(!$downcategory[$_GET['tocatid']] || in_array($_GET['tocatid'], $delids)) {
						cpmsg('dhcategory_move_category_failed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category', 'error');
					}
				}

			}

		}
		
		if($delids) {
			deletecategory($delids);
			if($_GET['dh_op'] == 'delete') {
				require_once libfile('function/delete','plugin/micxp_down');
				$aidarr = array();
				$query = C::t('#micxp_down#micxp_down_soft')->fetch_all_for_cat($delids);
				foreach($query as $value) {
					$aidarr[] = $value['softid'];
				}
				if($aidarr) {
					deletesoft($aidarr, '0');
				}
			} else {
				C::t('#micxp_down#micxp_down_soft')->update_for_cat($delids, array('catid'=>$_GET['tocatid']));
				$num = C::t('#micxp_down#micxp_down_soft')->fetch_count_for_cat($_GET['tocatid']);
				C::t('#micxp_down#micxp_down_category')->update($_GET['tocatid'], array('softs'=>dintval($num)));
			}
		}
		
		if($downcategory[$_GET['catid']]['foldername']) delcategoryfolder($_GET['catid']);
		
		updatecache('micxp_down:downcategory');
		loadcache('downcategory', true);
		remakecategoryfile($updatecategoryfile);
		cpmsg($Mlang['downcategory_delete_succeed'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category', 'succeed');
			
	}
	
	
}elseif($op == 'move') {
	$_GET['catid'] = intval($_GET['catid']);
	if(!$_GET['catid'] || !$downcategory[$_GET['catid']]) {
		cpmsg($Mlang['catgory_not_found'], '', 'error');
	}
	if(!submitcheck('movesubmit')) {
		$soft_count = C::t('#micxp_down#micxp_down_soft')->fetch_count_for_cat($_GET['catid']);
		if(!$soft_count) {
			cpmsg($Mlang['dhcategory_move_empty_error'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category', 'succeed');
		}
	
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=move&catid='.$_GET['catid']);
		showtableheader();
		include_once libfile('function/downcp','plugin/micxp_down');
		showsetting($Mlang['category_soft_moveto'], '', '', down_category_showselect('down', 'tocatid', false, $downcategory[$_GET['catid']]['upid']));
		showsubmit('movesubmit', $Mlang['dhcategory_move']);
		showtablefooter();
		showformfooter();
	
	} else {
	
		if($_GET['tocatid'] == $_GET['catid'] || empty($downcategory[$_GET['tocatid']])) {
			cpmsg($Mlang['dhcategory_move_category_failed'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category', 'error');
		}
	
		C::t('#micxp_down#micxp_down_soft')->update_for_cat($_GET['catid'], array('catid' => $_GET['tocatid']));
		C::t('#micxp_down#micxp_down_category')->update($_GET['catid'], array('softs'=>0));
		$num = C::t('#micxp_down#micxp_down_soft')->fetch_count_for_cat($_GET['tocatid']);
		C::t('#micxp_down#micxp_down_category')->update($_GET['tocatid'], array('softs'=>$num));
		updatecache('micxp_down:downcategory');
		cpmsg($Mlang['dhcategory_move_succeed'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category', 'succeed');
	}
	
	
	
}

function deletecategory($ids){
	global $_G;
	if(empty($ids)) return false;
	if(!is_array($ids)) $ids = array($ids);
	C::t('#micxp_down#micxp_down_category')->delete($ids);	
	
}

//function
function remakecategoryfile($categorys) {
	
	if(is_array($categorys)) {
		$downcategory = getglobal('cache/downcategory');
		foreach($categorys as $subcatid) {
			$dir = getcategoryfulldir($subcatid);
			makecategoryfile($dir, $subcatid);
			if($downcategory[$subcatid]['children']) {
				remakecategoryfile($downcategory[$subcatid]['children']);
			}
		}
	}
}

function makecategoryfile($dir, $catid) {
	dmkdir(DISCUZ_ROOT.'./'.$dir, 0777, FALSE);
	$downcategory = getglobal('cache/downcategory');
	$prepath = str_repeat('../', $downcategory[$catid]['level']+1);
	if($downcategory[$catid]['level']) {
		$upid = $downcategory[$catid]['upid'];
		while($downcategory[$upid]['upid']) {
			$upid = $downcategory[$upid]['upid'];
		}
		
	}

	$sub_dir = $dir;
	if($sub_dir) {
		$sub_dir = substr($sub_dir, -1, 1) == '/' ? '/'.$sub_dir : '/'.$sub_dir.'/';
	}
	$code = "<?php
	chdir('$prepath');
	define('SUB_DIR', '$sub_dir');
	\$_GET['mod'] = 'list';
	\$_GET['catid'] = '$catid';
	\$_GET['id'] = 'micxp_down';
	require_once './plugin.php';
	?>";
	$r = file_put_contents($dir.'/index.php', $code);
	return $r;
}

function showcategoryrow($key, $level = 0, $last = '') {
	global $_G,$Mlang;
	loadcache('downcategory');
 	$value = $_G['cache']['downcategory'][$key];
	$return = '';
	include_once libfile('function/downcp','plugin/micxp_down');
	$value['softs'] = down_category_get_num('down', $key);
	
	$publish = '';

	if($level == 1) {
		$return = '<tr class="hover" id="cat'.$value['catid'].'"><td>&nbsp;</td><td class="td25"><input type="text" class="txt" name="neworder['.$value['catid'].']" value="'.$value['displayorder'].'" /></td><td><div class="board">'.
				'<input type="text" class="txt" name="name['.$value['catid'].']" value="'.$value['catname'].'" />'.
				'</div>'.
				'</td><td>'.$value['softs'].'</td>'.
				'<td>'.(empty($value['disallowpublish']) ? cplang('yes') : cplang('no')).'</td>'.
				'<td></td>'.
				'<td>'.(empty($value['closed']) ? cplang('yes') : cplang('no')).'</td>'.
				'<td></td>'.
				'<td><a href="'.$value['caturl'].'" target="_blank">'.cplang('view').'</a>&nbsp;
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=edit&catid='.$value['catid'].'">'.cplang('edit').'</a>&nbsp;
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=move&catid='.$value['catid'].'">'.cplang('portalcategory_move').'</a>&nbsp;
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=delete&catid='.$value['catid'].'">'.cplang('delete').'</a>&nbsp;
		</td>
		<td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp&op=list&catid='.$value['catid'].'">'.cplang('portalcategory_articlemanagement').'</a>&nbsp;
		'.$publish.'</td></tr>';
		for($i=0,$L=count($value['children']); $i<$L; $i++) {
			$return .= showcategoryrow($value['children'][$i], 2, $i==$L-1);
		}
	} else {
		$childrennum = count($_G['cache']['downcategory'][$key]['children']);
		$toggle = $childrennum > 25 ? ' style="display:none"' : '';
		$return = '<tbody><tr class="hover" id="cat'.$value['catid'].'"><td onclick="toggle_group(\'group_'.$value['catid'].'\')"><a id="a_group_'.$value['catid'].'" href="javascript:;">'.($toggle ? '[+]' : '[-]').'</a></td>'
				.'<td class="td25"><input type="text" class="txt" name="neworder['.$value['catid'].']" value="'.$value['displayorder'].'" /></td><td><div class="parentboard">'.
				'<input type="text" class="txt" name="name['.$value['catid'].']" value="'.$value['catname'].'" />'.
				'</div>'.
				'</td><td>'.$value['softs'].'</td>'.
				'<td>'.(empty($value['disallowpublish']) ? cplang('yes') : cplang('no')).'</td>'.
				'<td></td>'.
				'<td>'.(empty($value['closed']) ? cplang('yes') : cplang('no')).'</td>'.
				'<td></td>'.
				'<td><a href="'.$value['caturl'].'" target="_blank">'.cplang('view').'</a>&nbsp;
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=edit&catid='.$value['catid'].'">'.cplang('edit').'</a>&nbsp;
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=move&catid='.$value['catid'].'">'.cplang('portalcategory_move').'</a>&nbsp;
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=delete&catid='.$value['catid'].'">'.cplang('delete').'</a>&nbsp;
		</td>
		<td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=softcp&op=list&catid='.$value['catid'].'">'.cplang('portalcategory_articlemanagement').'</a>&nbsp;
		'.$publish.'</td></tr></tbody>
		<tbody id="group_'.$value['catid'].'"'.$toggle.'>';
		for($i=0,$L=count($value['children']); $i<$L; $i++) {
			$return .= showcategoryrow($value['children'][$i], 1, '');
		}
		$return .= '</tdoby><tr><td>&nbsp;</td><td colspan="9"><div class="lastboard"><a class="addtr" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=category&op=add&upid='.$value['catid'].'">'.$Mlang['category_addsubcategory'].'</a></td></div>';
	}

	return $return;
}

function getcategoryfulldir($catid) {
	if(empty($catid)) return '';
	$downcategory = getglobal('cache/downcategory');
	$curdir = $downcategory[$catid]['foldername'];
	$curdir = $curdir ? $curdir : '';
	if($catid && empty($curdir)) return FALSE;
	$upid = $downcategory[$catid]['upid'];
	while($upid) {
		$updir = $downcategory[$upid]['foldername'];
		if(!empty($updir)) {
			$curdir = $updir.'/'.$curdir;
		} else {
			return FALSE;
		}
		$upid = $downcategory[$upid]['upid'];
	}
	return $curdir ? $curdir.'/' : '';
}



function delcategoryfolder($catid) {
	if(empty($catid)) return FALSE;
	$updatearr = array();
	$downcategory = getglobal('cache/downcategory');
	$children = $downcategory[$catid]['children'];
	if($children) {
		foreach($children as $subcatid) {
			if($downcategory[$subcatid]['foldername']) {
				$arr = delcategorysubfolder($subcatid);
				$updatearr = array_merge($updatearr, $arr);
			}
		}
	}

	$dir = getcategoryfulldir($catid);
	if(!empty($dir)) {
		unlink(DISCUZ_ROOT.$dir.'index.html');
		unlink(DISCUZ_ROOT.$dir.'index.php');
		rmdir(DISCUZ_ROOT.$dir);
		$updatearr[] = $catid;
	}
	if(dimplode($updatearr)) {
		C::t('#micxp_down#micxp_down_category')->update($updatearr, array('foldername'=>''));
	}
}

function delcategorysubfolder($catid) {
	if(empty($catid)) return FALSE;
	$updatearr = array();
	$downcategory = getglobal('cache/downcategory');
	$children = $downcategory[$catid]['children'];
	if($children) {
		foreach($children as $subcatid) {
			if($downcategory[$subcatid]['foldername']) {
				$arr = delcategorysubfolder($subcatid);
				$updatearr = array_merge($updatearr, $arr);
			}
		}
	}

	$dir = getcategoryfulldir($catid);
	if(!empty($dir)) {
		unlink(DISCUZ_ROOT.$dir.'index.html');
		unlink(DISCUZ_ROOT.$dir.'index.php');
		rmdir(DISCUZ_ROOT.$dir);
		$updatearr[] = $catid;
	}
	return $updatearr;
}



?>