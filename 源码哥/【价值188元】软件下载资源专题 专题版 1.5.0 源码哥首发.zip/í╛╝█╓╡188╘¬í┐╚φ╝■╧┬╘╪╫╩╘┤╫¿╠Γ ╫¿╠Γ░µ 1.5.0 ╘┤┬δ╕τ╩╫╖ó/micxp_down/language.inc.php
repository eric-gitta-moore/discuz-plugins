<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/micxp_down/setting.class.php';
MicxpDownSetting::menu();

$Mlang = $scriptlang['micxp_down'];

//��������
if(!empty($_GET['language']) && submitcheck('languagesubmit')){
	$language = daddslashes(strip_tags($_GET['language']));
	$languageid = C::t("#micxp_down#micxp_down_language")->fetch_id_by_language($language);
	if(!empty($languageid)){
		cpmsg($Mlang['exists'],"","error",'','',FALSE);
	}else{
		$languageid = DB::query("INSERT INTO ".DB::table('micxp_down_language')."(language) VALUES ('".$language."')");
	}
}

//���²���
if(!empty($_GET['language'])  && submitcheck('languageupdate')){

	$languagearray = daddslashes($_GET['language']);

	$ids = implode(',', array_keys($languagearray));
	$sql = "UPDATE ".DB::table('micxp_down_language')." SET language = CASE languageid ";
	foreach ($languagearray as $id => $language) {

		$sql .= sprintf("WHEN %d THEN '%s' ", $id, $language);
	}
	$sql .= "END WHERE languageid IN ($ids)";
	DB::query($sql);
}

//�������
if($_GET['op'] == 'delete' && submitcheck('formhash',1)) {
	$id = intval($_GET['id']);
	if(!empty($id)) {
		C::t("#micxp_down#micxp_down_language")->delete($id);
	}
}

//����Ĭ��
if($_GET['op'] == 'setdefault' && submitcheck('formhash',1)) {
	$id = intval($_GET['id']);
	if(!empty($id)) {
		DB::query("UPDATE ".DB::table('micxp_down_language')." SET isdefault=0");
		C::t("#micxp_down#micxp_down_language")->update($id,array('isdefault'=>1));
	}
}



showtableheader();
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=language', 'languagesubmit');
showsubmit('languagesubmit', $Mlang['add'], $Mlang['language_name'].': <input name="language" value="" class="txt" />');
showformfooter();



showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=language', 'languageupdate');
echo '<tr class="header"><th>ID</th><th>'.$Mlang['language_name'].'</th><th></th><th>'.$Mlang['isdefault'].'</th><th>'.$Mlang['opration'].'</th></tr>';

$languagelist = C::t("#micxp_down#micxp_down_language")->range();

//д��������
$cacheArray ='';
$cacheArray .= "\$languagelist=".arrayeval($languagelist).";\n";
writetocache("micxp_down_language", $cacheArray);

foreach ($languagelist as $key=>$val){
	
	if($val['isdefault']){
		$isdefault=$Mlang['yes'];
	}else{
		$isdefault=$Mlang['no'];
	}
	
	echo '<tr><td class="td25">'.$val['languageid'].'</td><td><input name="language['.$val['languageid'].']" value="'.$val['language'].'" class="txt" type="text"></td><td></td><td>'.$isdefault.'</td><td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=language&id='.$val['languageid'].'&op=setdefault&formhash='.FORMHASH.'">'.$Mlang['setdefault'].'</a>&nbsp;&nbsp;<a id="d'.$val['languageid'].'"  href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_down&pmod=language&id='.$val['languageid'].'&op=delete&formhash='.FORMHASH.'" >'.$Mlang['delete'].'</a></td></tr>';

}
showsubmit('languageupdate', $Mlang['update']);

showtablefooter();









