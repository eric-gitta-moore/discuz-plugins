<?php
if(!defined('IN_DISCUZ') ||!defined('IN_ADMINCP')) 
{
	exit('Access Denied');
}

$topmenu['addonymg'] = 'addonymg';
$menu['addonymg'][] = array( 'nav_addonymg','addonymg');
$menu['addonymg'][] = array( 'bbs_addonymg','addonymg_bbs');
$menu['addonymg'][] = array( 'vip_addonymg','addonymg_vip');
?>