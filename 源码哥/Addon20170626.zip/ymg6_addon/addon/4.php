<?php
$extend_lang = array
(
	'header_addonymg' => '&#x6e90;&#x7801;&#x54e5;',
	'nav_addonymg' => '&#x8d44;&#x6e90;&#x4e2d;&#x5fc3;',
	'bbs_addonymg' => '&#x6e90;&#x7801;&#x54e5;&#x5b98;&#x7f51;',	
	'vip_addonymg' => '&#x8d5e;&#x52a9;&#x6211;&#x4eec;',	
	'down_addonymg' => '&#x6b63;&#x5728;&#x4e0b;&#x8f7d;',	
);
if( $GLOBALS['action'] == 'addonymg' )
{
	$extend_lang['discuz_message'] = '&#x6e90;&#x7801;&#x54e5;&#x63d0;&#x793a;';
}
$GLOBALS['admincp_actions_normal'][] = 'addonymg';

?>
