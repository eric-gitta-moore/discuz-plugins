<?php
/*
 *源码哥：www.ymg6.com
 *更多商业插件/模版免费下载 就在源码哥
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo '<style type="text/css" />
body, ul, dl, dd, p, h1, h2, h3, h4, h5, h6, form, fieldset {margin: 0;padding: 0;}
.container{ padding:9px 20px 20px; text-align:left; }
.container h3 {margin-bottom: 10px;font-size: 14px;color: #09C;}
.infobox{ clear:both; margin-bottom:10px; padding:30px; text-align:center; border-top:4px solid #DEEFFA; border-bottom:4px solid #DEEEFA; background:#F2F9FD; zoom:1; }
.infotitle1{ margin-bottom:10px; color:#09C; font-size:14px; font-weight:700; }
.infotitle2{ margin-bottom:10px; color:#090; font-size:14px; font-weight:700; }
.infotitle3{ margin-bottom:10px; color:#C00; font-size:14px; font-weight:700; }
</style>';
echo '<div id="cpcontainer" class="container">
        <h3>&#x6e90;&#x7801;&#x54e5;&#x63d0;&#x793a;&#xff1a;&#x63d2;&#x4ef6;&#x5378;&#x8f7d;&#x6210;&#x529f;</h3>
        <div class="infobox">
            <h4 class="infotitle3">&#x5378;&#x8f7d;&#x6210;&#x529f;&#xff0c;&#x4ee5;&#x4e0b;&#x6587;&#x4ef6;&#x9700;&#x8981;&#x624b;&#x52a8;&#x5220;&#x9664;&#xff0c;&#x4f60;&#x4e5f;&#x53ef;&#x4ee5;&#x4fdd;&#x7559;&#x4ee5;&#x4e0b;&#x6587;&#x4ef6;</h4>
            <div>source/admincp/admincp_addonymg.php</div>
			<div>source/admincp/menu/menu_addonymg.php</div>
			<div>source/function/function_addonymg.php</div>
			<div>source/language/lang_admincp_addonymg.php</div>
 			<div>source/admincp/admincp_addonymgbbs.php</div>
 			<div>source/admincp/admincp_addonymgvip.php</div>
        </div>
    </div>';
exit;
