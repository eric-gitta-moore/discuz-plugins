<?php
/*
 *源码哥：www.ymg6.com
 *更多商业插件/模版免费下载 就在源码哥
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

copy(DISCUZ_ROOT.'./source/plugin/ymg6_addon/addon/1.php',DISCUZ_ROOT.'./source/admincp/admincp_addonymg.php');
copy(DISCUZ_ROOT.'./source/plugin/ymg6_addon/addon/2.php',DISCUZ_ROOT.'./source/admincp/menu/menu_addonymg.php');
copy(DISCUZ_ROOT.'./source/plugin/ymg6_addon/addon/3.php',DISCUZ_ROOT.'./source/function/function_addonymg.php');
copy(DISCUZ_ROOT.'./source/plugin/ymg6_addon/addon/4.php',DISCUZ_ROOT.'./source/language/lang_admincp_addonymg.php');
copy(DISCUZ_ROOT.'./source/plugin/ymg6_addon/addon/5.php',DISCUZ_ROOT.'./source/admincp/admincp_addonymgbbs.php');
copy(DISCUZ_ROOT.'./source/plugin/ymg6_addon/addon/6.php',DISCUZ_ROOT.'./source/admincp/admincp_addonymgvip.php');

$finish = true;
