<?php echo '����ģ������www.ymg6.com�������';exit;?>
<!--{template common/header}-->
<!--{template common/header_nav}-->
<div id="pt" class="bm cl lmkj_pt">
	<div class="z">
		
		<a href="$_G[setting][navs][1][filename]">{lang nav_index}</a> <em>&rsaquo;</em>
		<!--{loop $cat[ups] $value}-->
			<a href="{echo getportalcategoryurl($value[catid])}">$value[catname]</a><em>&rsaquo;</em>
		<!--{/loop}-->
		<a href="{echo getportalcategoryurl($cat[catid])}">$cat[catname]</a> <em>&rsaquo;</em>
		{lang view_content}
	</div>
</div>


<!--{ad/text/wp a_t}-->
<style id="diy_style" type="text/css"></style>

<div id="ct" class="ct2 wp cl">
	<div class="lmkj_mn">
		<div class="lmkj_bm vw">
			<div class="h hm">
				<h1 class="almkj_ph">$article[title] <!--{if $article['status'] == 1}-->({lang moderate_need})<!--{elseif $article['status'] == 2}-->({lang ignored})<!--{/if}--></h1>
				<p class="lmkj_pp">
					$article[dateline]<span class="pipe">/</span>
					{lang view_publisher}: <a href="home.php?mod=space&uid=$article[uid]">$article[username]</a><span class="pipe">/</span>
					{lang view_views}: <em id="_viewnum"><!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}--></em><span class="pipe">/</span>
					{lang view_comments}: <!--{if $article[commentnum] > 0}--><a href="$common_url" title="{lang view_all_comments}"><em id="_commentnum">$article[commentnum]</em></a><!--{else}-->0<!--{/if}-->
					<!--{if $article[author]}--><span class="pipe">|</span>{lang view_author_original}: $article[author]<!--{/if}-->
					<!--{if $article[from]}--><span class="pipe">|</span>{lang from}: <!--{if $article[fromurl]}--><a href="$article[fromurl]" target="_blank">$article[from]</a><!--{else}-->$article[from]<!--{/if}--><!--{/if}-->

					
					<!--{hook/view_article_subtitle}-->
				</p>
			</div>

			

			<!--{if $article[summary] && empty($cat[notshowarticlesummay])}--><div class="s"><div class="lmkj_zy">
			<strong>{lang article_description}</strong> $article[summary]</div><!--{hook/view_article_summary}--></div><!--{/if}-->

		

			<div class="lmkj_d">


			
					<!--{ad/article/a_af/1}-->
					<!--{if $content[title]}-->
					<div class="vm_pagetitle xw1">$content[title]</div>
					<!--{/if}-->
					$content[content]
				
				<!--{hook/view_article_content}-->
				<!--{if $multi}--><div class="ptw pbw cl">$multi</div><!--{/if}-->

			

				<!--{if !empty($contents)}-->
				<div id="inner_nav" class="ptn xs1">
					<h3>{lang article_inner_navigation}</h3>
					<ul class="xl xl2 cl">
						<!--{loop $contents $key $value}-->
						<!--{eval $curpage = $key+1;}-->
						<!--{eval $inner_view_url = helper_page::mpurl($viewurl, '&page=', $curpage);}-->
						<li>&bull; <a href="$inner_view_url"{if $key === $start} class="xi1"{/if}>{lang article_inner_page_pre} {$curpage} {lang article_inner_page} $value[title]</a></li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--{/if}-->

				

			</div>
			<!--{if !empty($aimgs[$content[pid]])}-->
				<script type="text/javascript" reload="1">aimgcount[{$content[pid]}] = [<!--{echo implode(',', $aimgs[$content[pid]]);}-->];attachimgshow($content[pid]);</script>
			<!--{/if}-->

			<!--{if !empty($_G['setting']['pluginhooks']['view_share_method'])}-->
				<div class="tshare cl">
					<strong>{lang viewthread_share_to}:</strong>
					<!--{hook/view_share_method}-->
				</div>
			<!--{/if}-->
			
			
<style>
.jiathis_style {margin:10px 5px 20px 0;float:left;}
.lmkj_mg {display: block;float:left;text-align: center;height: 30px;float: left;margin:10px 0;}
</style>
<!-- JiaThis Button BEGIN -->
<div class="jiathis_style"><div style="float: left;margin:0 10px 0 0;">���� :</div>
	<a class="jiathis_button_qzone"></a>
	<a class="jiathis_button_tsina"></a>
	<a class="jiathis_button_tqq"></a>
	<a class="jiathis_button_weixin"></a>
	<a class="jiathis_button_renren"></a>
	<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>
	<a class="jiathis_counter_style"></a>

<script type="text/javascript" src="http://v3.jiathis.com/code_mini/jia.js" charset="utf-8"></script>
<!-- JiaThis Button END --></div>




			<div class="o cl ptm pbm lmkj_mg ">
				<!--{hook/view_article_op_extra}-->
				<a href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" class="lmkj_oshr ofav">{lang favorite}</a>
				
			
				<!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $article['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $article['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
				
					<!--{if $article[status]>0 && ($_G['group']['allowmanagearticle'] || $categoryperm[$value['catid']]['allowmanage'])}-->
						<a href="portal.php?mod=portalcp&ac=article&op=verify&aid=$article[aid]" id="article_verify_$article[aid]" onclick="showWindow(this.id, this.href, 'get', 0);" class="lmkj_oshr ofav">{lang moderate}</a>
						<style></style>
					<!--{else}-->
						<a href="portal.php?mod=portalcp&ac=article&op=delete&aid=$article[aid]" id="article_delete_$article[aid]" onclick="showWindow(this.id, this.href, 'get', 0);" class="lmkj_oshr ofav">{lang delete}</a>
						<style></style>
					<!--{/if}-->
		
				<!--{/if}-->
				
			</div>
			<div style="clear:both"></div>
			<!--{if $article['preaid'] || $article['nextaid']}-->
			<div class="pren lmkj_pbm cl">
				<!--{if $article['prearticle']}--><em><a href="{$article['prearticle']['url']}">{lang pre_article}{$article['prearticle']['title']}</a></em><!--{/if}-->
				<!--{if $article['nextarticle']}--><em><a href="{$article['nextarticle']['url']}">{lang next_article}{$article['nextarticle']['title']}</a></em><!--{/if}-->
			</div>
			<!--{/if}-->
		</div>

	

		<!--{ad/article/mbm hm/2}--><!--{ad/article/mbm hm/3}-->

	
		
		<!--{if $article['allowcomment']==1}-->
			<!--{eval $data = &$article}-->
			<!--{subtemplate portal/portal_comment}-->
		<!--{/if}-->

		


	</div>

</div>

<!--{if $_G['relatedlinks']}-->
	<script type="text/javascript">
		var relatedlink = [];
		<!--{loop $_G['relatedlinks'] $key $link}-->
		relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};
		<!--{/loop}-->
		relatedlinks('article_content');
	</script>
<!--{/if}-->


<input type="hidden" id="portalview" value="1">


<!--{template common/footer}-->