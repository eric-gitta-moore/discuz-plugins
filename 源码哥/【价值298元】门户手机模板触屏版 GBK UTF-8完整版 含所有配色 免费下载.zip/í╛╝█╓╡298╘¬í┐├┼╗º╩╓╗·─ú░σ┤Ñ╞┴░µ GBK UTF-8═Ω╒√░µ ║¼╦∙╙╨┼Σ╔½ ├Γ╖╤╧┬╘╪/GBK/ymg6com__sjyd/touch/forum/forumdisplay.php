<?php echo '����ģ������www.ymg6.com�������';exit;?>
<!--{template common/header}-->
<!--{template common/header_nav}-->
<!-- header start -->

<header class="header">
  <div class="nav">
    <div class="icon_edit y"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_threads}"><span class="none">{lang send_threads}</span></a></div>
    <a href="forum.php?forumlist=1" class="z"><img src="{$_G['siteurl']}template/ymg6com__sjyd/touch/images/icon_back.png" /></a> <span class="category"> 
    <!--{if $subexists && $_G['page'] == 1}--> 
    <span class="display name vm" href="#subname_list">
    <h2 class="tit"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></h2>
    <img src="{$_G['siteurl']}template/ymg6com__sjyd/touch/images/icon_arrow_down.png"> </span>
    <div id="subname_list" class="subname_list" display="true" style="display:none;">
      <ul>
        <!--{loop $sublist $sub}-->
        <li> <a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a> </li>
        <!--{/loop}-->
      </ul>
    </div>
    <!--{else}--> 
    <span class="name"> 
    <!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--> 
    </span> 
    <!--{/if}--> 
    </span> </div>
</header>
<!-- header end -->


<!--{if !$_G[setting][mobile][mobilesimpletype]}--> 
<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || $_G['forum']['threadsorts']}--> 

<!--{if $_G['forum']['threadtypes']}-->
<div class="box ttp lmkj_fl"> <a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="<!--{if $_GET['filter'] != 'typeid'}-->xw1<!--{/if}-->">{lang forum_viewall}</a> 
  <!--{loop $_G['forum']['threadtypes']['types'] $id $name}--> 
  <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]" {if $_GET['filter'] == 'typeid' && $_GET['typeid'] == $id} class="xw1"{/if}>$name</a> 
  <!--{/loop}--> 
</div>
<!--{/if}--> 

<!--{if $_G['forum']['threadsorts']}-->
<div class="box tst lmkj_fl"> 
  
  <!--{loop $_G['forum']['threadsorts']['types'] $id $name}--> 
  <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]" class="<!--{if $_GET[sortid] == $id}-->xw1<!--{/if}-->">$name</a> 
  <!--{/loop}--> 
</div>
<!--{/if}--> 

<!--{/if}--> 
<!--{/if}--> 

<!--{hook/forumdisplay_top_mobile}--> 
<!--{subtemplate forum/search_sortoption}--> 
<!-- main threadlist start --> 

<!--{subtemplate forum/forumdisplay_list}--> 

$multipage 
<!-- main threadlist end --> 
<!--{hook/forumdisplay_bottom_mobile}-->
<div class="pullrefresh" style="display:none;"></div>
<!--{template common/footer}--> 
