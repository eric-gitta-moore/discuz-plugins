<?php echo '本套模版来自www.ymg6.com免费下载';exit;?>
<!--{template common/header}-->


<!--{template common/header_nav}-->
<!-- 头图 --> 
<!--{block/3}-->
<!--头图结束-->

<!-- 新闻资讯 --> 
<!--{block/4}-->
<!--新闻资讯结束-->

<!-- 便民信息 --> 
<!--{block/5}-->
<!--便民信息结束-->

<!-- 旅游户外 --> 
<!--{block/6}-->
<!--旅游户外结束-->


<!-- 美食广场 --> 
<!--{block/7}-->
<!--美食广场结束-->


<!-- 房产楼市 --> 
<!--{block/8}-->
<!--房产楼市结束-->



<!-- 汽车中心 --> 
<!--{block/9}-->
<!--汽车中心结束-->

<!-- 其他 --> 
<!--{block/10}-->
<!--其他结束-->




<div class="pullrefresh" style="display:none;"></div>
<!--{template common/footer}-->
