<?php echo '本套模版来自www.ymg6.com免费下载';exit;?>
<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:portal.php?mod=index&mobile=2');exit;}-->
<!--{/if}-->

<!--{template common/header}-->

 <link rel="stylesheet" type="text/css" href="{$_G['siteurl']}template/ymg6com__sjyd/touch/bbslmstyle.css"/>
<script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.ymg6.com/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>

<!--{if $_GET['visitclient']}-->
  
<header class="header">
    <div class="nav">
		<span>{lang warmtip}</span>
    </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script>

<!--{else}-->


<!--{hook/index_top_mobile}-->
<!-- main forumlist start -->

<div class="wm" id="wp">
	<!--{loop $catlist $key $cat}-->
	<div class="bm bmw fl lmkj_forum">
		<div class="subforumshow bm_h cl" href="#sub_forum_$cat[fid]">
			<span class="o"><img src="{$_G['siteurl']}template/ymg6com__sjyd/touch/images/collapsed_<!--{if !$_G[setting][mobile][mobileforumview]}-->yes<!--{else}-->no<!--{/if}-->.png"></span>
		<h2><a href="javascript:;">$cat[name]</a></h2>
		</div>
		<div id="sub_forum_$cat[fid]" class="sub_forum bm_c">
			<ul>
				<!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->
				<li>
				<div class="lmkj_ioc" style="float:left;" >

			<!--{if $forum[icon]}-->$forum[icon]<!--{else}-->
				<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">	<img src="{$_G['siteurl']}template/ymg6com__sjyd/touch/images/lmkj_ic.png" alt="{$forum[name]}"><!--{/if}--></a>
				</div>
	<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">{$forum[name]}</a></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{/loop}-->
</div>

<div style="clear:both"></div>
<!-- main forumlist end -->
<!--{hook/index_middle_mobile}-->
<script type="text/javascript">
	(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
			$('.sub_forum').css('display', 'block');
		<!--{else}-->
			$('.sub_forum').css('display', 'none');
		<!--{/if}-->
		$('.subforumshow').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
				obj.find('img').attr('src', '{$_G['siteurl']}template/ymg6com__sjyd/touch/images/collapsed_yes.png');
			} else {
				subobj.css('display', 'none');
				obj.find('img').attr('src', '{$_G['siteurl']}template/ymg6com__sjyd/touch/images/collapsed_no.png');
			}
		});
	 })();
</script>

<!--{/if}-->
<!--{template common/footer}-->
