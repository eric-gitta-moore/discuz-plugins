<?php echo '本套模版来自www.ymg6.com免费下载';exit;?>
<script type="text/javascript" src="{$_G['siteurl']}template/ymg6com__sjyd/touch/common.js?{VERHASH}"></script>
<div id="threadlist" class="tl bm bmw"{if $_G['uid']} style="position: relative;"{/if}>
  <div class="bm_c" style="padding:0 5px;"> 
    <!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}--> 
    <script type="text/javascript">var lasttime = $_G['timestamp'];var listcolspan= '{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}6{else}5{/if}';</script> 
    <!--{/if}-->
    <div id="forumnew" style="display:none"></div>
    <form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <input type="hidden" name="listextra" value="$extra" />
      <table summary="forum_$_G[fid]" cellspacing="0" cellpadding="0" id="threadlisttableid">
        <!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->
        <tbody>
          <tr>
            <td class="icn"><img src="{IMGDIR}/ann_icon.gif" alt="{lang announcement}" /></td>
            <!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->
            <td class="o">&nbsp;</td>
            <!--{/if}-->
            <th><strong class="xst">{lang announcement}: <!--{if empty($announcement['type'])}--><a href="forum.php?mod=announcement&id=$announcement[id]#$announcement[id]" target="_blank">$announcement[subject]</a><!--{else}--><a href="$announcement[message]" target="_blank">$announcement[subject]</a><!--{/if}--></strong></th>
            <td class="by"><cite><a href="home.php?mod=space&uid=$announcement[authorid]" c="1">$announcement[author]</a></cite> <em>$announcement[starttime]</em></td>
            <td class="num">&nbsp;</td>
            <td class="by">&nbsp;</td>
          </tr>
        </tbody>
        <!--{/if}--> 
        <!--{if !$separatepos || !$_G['setting']['forumseparator']}-->
        <tbody id="separatorline" class="emptb">
          <tr>
            <td class="icn"></td>
            <!--{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}-->
            <td class="o"></td>
            <!--{/if}-->
            <th></th>
            <!--{if CURMODULE == 'guide'}-->
            <td class="by"></td>
            <!--{/if}-->
            <td class="by"></td>
            <td class="num"></td>
            <td class="by"></td>
          </tr>
        </tbody>
        <!--{/if}--> 
        <!--{if $_G['forum_threadcount']}--> 
        <!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}--> 
        
        <!--{loop $_G['forum_threadlist'] $key $thread}--> 
        <!--{if $_G[setting][forumseparator] == 1 && $separatepos == $key + 1}-->
        <tbody id="separatorline">
          <tr class="ts">
            <td>&nbsp;</td>
            <!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->
            <td>&nbsp;</td>
            <!--{/if}-->
            <th><!--{if empty($_G['forum']['picstyle']) && $_GET['orderby'] == 'lastpost' && !$_GET['filter']}--><a href="javascript:;" onclick="checkForumnew_btn('{$_G['fid']}')" title="{lang showupgrade}" class="forumrefresh">{lang forum_thread}</a><!--{else}-->&nbsp;<!--{/if}--></th>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </tbody>
        <script type="text/javascript">hideStickThread();</script> 
        <!--{/if}--> 
        <!--{if $separatepos <= $key + 1}--> 
        <!--{ad/threadlist}--> 
        <!--{/if}-->
        
        <div class="threadlist lmkj_lists">
          <ul>
            <li> 
			 <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="a">
			 <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--> 
              <span class="icon_top">置顶</span> 
              <!--{elseif $thread['digest'] > 0}--> 
              <span class="icon_jh">精华</span> 
              <!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}--> 
              <span class="icon_tu">图文</span>
			    <!--{/loop}-->
			  {$thread[subject]}
              <div id="reading"><em>$thread[author]</em> - <em>$thread[lastpost] </em><span class="fangwen"><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span><span class="huifu">{$thread[replies]}</span></div>
              </a> 
              
               </li>
            
          
            
          </ul>
        </div>
        
        <!--{else}-->
        <li>{lang forum_nothreads}</li>
        <!--{/if}-->
      </table>
      <!-- end of table "forum_G[fid]" branch 1/3 --> 
      <!--{if $_G['hiddenexists']}-->
      <div id="hiddenthread"{if $thread['hidden']} class="last"{/if}><a href="javascript:;" onclick="display_blocked_thread()">{lang other_reply_hide}</a></div>
      <!--{/if}--> 
      <!--{else}-->
      </table>
      <!-- end of table "forum_G[fid]" branch 2/3 -->
      
 	<ul id="waterfall" class="ml waterfall lmkj_tuq cl">
							<!--{loop $_G['forum_threadlist'] $key $thread}-->
							<!--{if $_G['hiddenexists'] && $thread['hidden']}-->
								<!--{eval continue;}-->
							<!--{/if}-->
							<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
								<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
							<!--{/if}-->
							<!--{eval $waterfallwidth = $_G[setting][forumpicstyle][thumbwidth] + 24; }-->
							<li class="lmkj_ps">
							
								<div class="c cl lmkj_pbimg">
									<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" class="z">
										<!--{if $thread['cover']}-->
											<img src="$thread[coverpath]" alt="$thread[subject]" /
											style="display: inline; visibility: visible1;">
										<!--{else}-->
											<span class="nopic" style="width:{$_G[setting][forumpicstyle][thumbwidth]}px; height:{$_G[setting][forumpicstyle][thumbwidth]}px;"></span>
										<!--{/if}-->
									</a>
								</div>
								<h3 class="xw0">
									<!--{hook/forumdisplay_thread $key}-->
									<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]">$thread[subject]</a>
								</h3>
							            <div id="reading"><em><span class="pire"></span>$thread[author]</em>
										<span>
										<em class="fangwen"><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></em><em class="huifu">{$thread[replies]}</em></span></div>
							</li>
							<!--{/loop}-->
						</ul>
						      <div id="tmppic" style="display: none;"></div>
						<script type="text/javascript" src="{$_G['siteurl']}template/ymg6com__sjyd/touch/redef.js?{VERHASH}"></script>
						<script type="text/javascript" reload="1">
						var wf = {};

						_attachEvent(window, "load", function () {
							if(jq("waterfall")) {
								wf = waterfall();
							}

							<!--{if $page < $_G['page_next'] && !$subforumonly}-->
								var page = jqpage + 1,
									maxpage = Math.min(jqpage + 10,jqmaxpage + 1),
									stopload = 0,
									scrolltimer = null,
									tmpelems = [],
									tmpimgs = [],
									markloaded = [],
									imgsloaded = 0,
									loadready = 0,
									showready = 1,
									nxtpgurl = 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&page=',
									wfloading = "<img src=\"{IMGDIR}/loading.gif\" alt=\"\" width=\"16\" height=\"16\" class=\"vm\" /> {lang onloading}...",
									pgbtn = jq("pgbtn").getElementsByTagName("a")[0];

								function loadmore() {
									var url = nxtpgurl + page + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
									var x = new Ajax("HTML");
									x.get(url, function (s) {
										s = s.replace(/\n|\r/g, "");
										if(s.indexOf("id=\"pgbtn\"") == -1) {
											jq("pgbtn").style.display = "none";
											stopload++;
											window.onscroll = null;
										}

										s = s.substring(s.indexOf("<ul id=\"waterfall\""), s.indexOf("<div id=\"tmppic\""));
										s = s.replace("id=\"waterfall\"", "");
										jq("tmppic").innerHTML = s;
										loadready = 1;
									});
								}

								window.onscroll = function () {
									if(scrolltimer == null) {
										scrolltimer = setTimeout(function () {
											try {
												if(page < maxpage && stopload < 2 && showready && ((document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.clientHeight + 500) >= document.documentElement.scrollHeight) {
													pgbtn.innerHTML = wfloading;
													loadready = 0;
													showready = 0;
													loadmore();
													tmpelems = jq("tmppic").getElementsByTagName("li");
													var waitingtimer = setInterval(function () {
														stopload >= 2 && clearInterval(waitingtimer);
														if(loadready && stopload < 2) {
															if(!tmpelems.length) {
																page++;
																pgbtn.href = nxtpgurl + Math.min(page, jqmaxpage);
																pgbtn.innerHTML = "{lang next_page_extra}";
																showready = 1;
																clearInterval(waitingtimer);
															}
															for(var i = 0, j = tmpelems.length; i < j; i++) {
																if(tmpelems[i]) {
																	tmpimgs = tmpelems[i].getElementsByTagName("img");
																	imgsloaded = 0;
																	for(var m = 0, n = tmpimgs.length; m < n; m++) {
																		tmpimgs[m].onerror = function () {
																			this.style.display = "none";
																		};
																		markloaded[m] = tmpimgs[m].complete ? 1 : 0;
																		imgsloaded += markloaded[m];
																	}
																	if(imgsloaded == tmpimgs.length) {
																		jq("waterfall").appendChild(tmpelems[i]);
																		wf = waterfall({
																			"index": wf.index,
																			"totalwidth": wf.totalwidth,
																			"totalheight": wf.totalheight,
																			"columnsheight": wf.columnsheight
																		});
																	}
																}
															}
														}
													}, 40);
												}
											} catch(e) {}
											scrolltimer = null;
										}, 320);
									}
								};
							<!--{/if}-->

						});

						</script>
  
          <div id="tmppic" style="display: none;"></div>
      <!--{/if}--> 
      <!--{else}-->
      <tbody class="bw0_all">
        <tr>
          <th colspan="{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}6{else}5{/if}"><p class="emp">{lang forum_nothreads}</p></th>
        </tr>
      </tbody>
      </table>
      <!-- end of table "forum_G[fid]" branch 3/3 --> 
      <!--{/if}-->
      
    </form>
  </div>
</div>
<div style="clear:both;margin-bottom:5px;"></div>
