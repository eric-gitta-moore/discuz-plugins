<?php echo '本套模版来自www.ymg6.com免费下载';exit;?>
<!-- 导航 -->
<!-- 导航包含 -->
<nav>
  <div class="lmkj_dh">
    <ul>
      <li><a href="portal.php?mod=index&mobile=2">门户首页</a></li>
	  <li><a href="forum.php?forumlist=1&mobile=2">社区论坛</a></li>
      <li><a href="portal.php?mod=list&catid=5">新闻资讯</a></li>
      <li><a href="search.php?mod=forum&mobile=2">搜索中心</a></li>
  
      <li><a href="#">便民信息</a></li>
      <li><a href="home.php?mod=space&uid=1&do=profile&mycenter=1&mobile=2">个人中心</a></li>
      <li><a href="#">美食广场</a></li>
 
     
      <li class="w5" id="lmkj_dh_more"><span><img src="{$_G['siteurl']}template/ymg6com__sjyd/touch/images/more.png" width="8" height="6"/><a>更多</a></span></li>
    </ul>
    <ul id="nav_more" style="display:none;">
   
      <li><a href="#">数码科技</a></li>
      <li><a href="#">汽车中心</a></li>
      <li><a href="#">教育资讯</a></li>
      <li><a href="#">健康生活</a></li>
      <li><a href="#">历史文化</a></li>
      <li><a href="#">财经频道</a></li>
      <li><a href="#">房产中心</a></li>
    
 
      <li class="w5" id="lmkj_dh_back"><span><img src="{$_G['siteurl']}template/ymg6com__sjyd/touch/images/more.png" width="8" height="6"/><a>收起</a></span></li>
    </ul>
  </div>
</nav>
<div style="clear:both"></div>
