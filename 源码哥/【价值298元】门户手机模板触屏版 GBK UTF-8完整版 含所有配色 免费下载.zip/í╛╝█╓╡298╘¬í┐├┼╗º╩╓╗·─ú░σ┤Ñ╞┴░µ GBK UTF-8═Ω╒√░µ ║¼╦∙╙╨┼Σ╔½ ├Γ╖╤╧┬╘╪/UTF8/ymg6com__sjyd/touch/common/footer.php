<?php echo '本套模版来自www.ymg6.com免费下载';exit;?>
<a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a> 
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.ymg6.com/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.ymg6.com/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.ymg6.com/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

<script src="{$_G['siteurl']}template/ymg6com__sjyd/touch/lmkj_tu.min.js"></script>
<script type="text/javascript">

TouchSlide({ 
	slideCell:"#slideBox",
	titCell:".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
	mainCell:".bd ul", 
	effect:"leftLoop", 
	autoPage:true,//自动分页
	autoPlay:true //自动播放
});
$(".hd ul li").html("<i></i>");

//全局命名空间
var GLOBAL={};
//声明命名空间函数
GLOBAL.namespace=function(str){
    var arr=str.split("."),o=GLOBAL;
    for(i=(arr[0]=="GLOBAL")?1:0;i<arr.length;i++){
        o[arr[i]]=o[arr[i]] || {};
        o=o[arr[i]];
    }
}

$(document).ready(function(){
	$("#lmkj_dh_more").click(function(){
		$(".lmkj_dh").css("height","120px");
		$("#nav_more").show();
		$("#lmkj_dh_more").hide();
	});
	$("#lmkj_dh_back").click(function(){
		$(".lmkj_dh").css("height","60px");
		$("#nav_more").hide();
		$("#lmkj_dh_more").show();
	});
	
	var pagenum = '';
	if(pagenum > 1)
	{
		$("#category_more").show();
		$("#category_pic_more").show();
	}
	
	onclick_category_more()
	onclick_category_pic_more()

});



</script>

<div id="mask" style="display:none;"></div>
<!--{if !$nofooter}-->
<div class="footer">
  <div> 
    <!--{if !$_G[uid] && !$_G['connectguest']}--> 
    <a href="forum.php">{lang mobilehome}</a> | <a href="member.php?mod=logging&action=login" title="{lang login}">{lang login}</a> | <a href="<!--{if $_G['setting']['regstatus']}-->member.php?mod={$_G[setting][regname]}<!--{else}-->javascript:;" style="color:#D7D7D7;<!--{/if}-->" title="{$_G['setting']['reglinkname']}">{lang register}</a> 
    <!--{else}--> 
    <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1">{$_G['member']['username']}</a> , <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" title="{lang logout}" class="dialog">{lang logout}</a> 
    <!--{/if}--> 
  </div>
  <div> <a href="{$_G['setting']['mobile']['simpletypeurl'][0]}">{lang no_simplemobiletype}</a> | <a href="javascript:;" style="color:#0A0A0A;">{lang mobile2version}</a> | <a href="{$_G['setting']['mobile']['nomobileurl']}">{lang nomobiletype}</a> | 
    <!--{if $clienturl}--><a href="$clienturl">{lang clientversion}</a><!--{/if}--> 
  </div>
  <p>&copy; <a href="http://www.ymg6.com/">源码哥</a> Inc.</p>
</div>
<!--{/if}-->
</body></html><!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
<!--{eval output();}-->
<!--{else}-->
<!--{eval output_preview();}-->
<!--{/if}-->