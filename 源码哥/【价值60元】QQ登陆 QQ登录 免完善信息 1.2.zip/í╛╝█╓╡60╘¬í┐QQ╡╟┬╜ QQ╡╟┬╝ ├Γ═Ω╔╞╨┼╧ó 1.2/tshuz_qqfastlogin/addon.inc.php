<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
?>
<script type="text/javascript">location.href="http://www.ymg6.com/gg/addon.php?/?@838.developer";</script>