<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
echo lang("plugin/zhikai_wxlogin", "logy_m_g");