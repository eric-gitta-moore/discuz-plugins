<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_dc_sell_log`;
EOF;

runquery($sql);

$finish = TRUE;

?>