<?php
/*
 *      [Discuz! X] (C)2012-2012 zyshare.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: payview.inc.php 557 2012-06-28 12:20:20Z yanyuxiaoyao $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$cvar= $_G['cache']['plugin']['dc_sell'];
$pid=intval($_GET['pid']);
$cid=intval($_GET['cid']);
if($_G['uid']){
	$loglist = array();
	$loglist=C::t('#dc_sell#dc_sell_log')->fetch_by_pcid(array('pid'=>$pid,'cid'=>$cid));
	foreach($loglist as $k=>$log)
		$loglist[$k]['dateline'] = dgmdate($log['dateline']);
	include template('dc_sell:sellview');
}else{
	showmessage('to_login', NULL, array(), array('login' => 1));
}
?>