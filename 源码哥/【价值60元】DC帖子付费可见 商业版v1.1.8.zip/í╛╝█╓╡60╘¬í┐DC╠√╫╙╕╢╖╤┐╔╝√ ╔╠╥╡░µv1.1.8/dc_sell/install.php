<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_dc_sell_log`;
CREATE TABLE pre_dc_sell_log (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `uname` varchar(45) DEFAULT NULL,
  `dateline` int(10) NULL DEFAULT '0',
  `pay` int(11) DEFAULT NULL,
  `extcredit` int(11) DEFAULT NULL,
  `authorid` int(11) DEFAULT NULL,
  `authorincome` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
)TYPE=MyISAM;
EOF;
runquery($sql);
$finish = TRUE;
?>