<?php


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$dclang = @include DISCUZ_ROOT.'/source/plugin/dc_sell/config/lang.php';
if(submitcheck('submit')) {
	$dlang=$_GET['dc'];
	$configdata = 'return '.var_export($dlang, true).";\n\n";
	if($fp = @fopen(DISCUZ_ROOT.'/source/plugin/dc_sell/config/lang.php', 'wb')) {
		fwrite($fp, "<?php\n//plugin dc_sell lang file, DO NOT modify me!\n//Identify: ".md5($k.$configdata)."\n\n$configdata?>");
		fclose($fp);
		cpmsg(plang('cpsucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_sell&pmod=lang', 'succeed');
	}
	cpmsg(plang('cperror'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_sell&pmod=lang', 'error');
}
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_sell&pmod=lang');
showtips(plang('langtips'));
showtableheader('', '');
showsetting(plang('cphide'), 'dc[hidetext]', plang('hidetext'), 'text');
showsetting(plang('cpselltext'), 'dc[selltext]', plang('selltext'), 'text');
showsetting(plang('cppayfor'), 'dc[payfor]', plang('payfor'), 'text');
showsetting(plang('cppay'), 'dc[sellinfo]', plang('sellinfo'), 'text');
showsetting(plang('cpnocredit'), 'dc[nocredit]', plang('nocredit'), 'text');
showsetting(plang('cppaysucceed'), 'dc[paysucceed]', plang('paysucceed'), 'text');
showsetting(plang('cpcarticle'), 'dc[carticle]', plang('carticle'), 'text');
showsubmit('submit', 'submit');
showtablefooter();
showformfooter();

function plang($str) {
	global $dclang;
	if(!empty($dclang[$str]))
		return $dclang[$str];
	else
		return lang('plugin/dc_sell', $str);
}
?>