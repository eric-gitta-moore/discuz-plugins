<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_dc_sell {
	var $cvar=null;
	var $open=false;
	var $free=false;
	var $extcredits=null;
	var $lang=null;
	var $reprule = null;
	var $sellrule = null;
	public function __construct(){
		global $_G;
		$this->cvar = $_G['cache']['plugin']['dc_sell'];
		if(!$this->cvar['open']||(!in_array($_G['fid'], (array)unserialize($this->cvar['fids']))&&$_G['fid']))
			return;
		$this->open=true;
		if(in_array($_G['groupid'], (array)unserialize($this->cvar['free'])))
			$this->free = true;
		$ext=array();
		foreach($_G['setting']['extcredits'] as $k=>$v){
			$ext[]=$k;
		}
		$extstr=implode('|',$ext);
		$this->reprule = '/\[sell=([\d+]+?),('.$extstr .')\]([\s\S]+?)((\[\/sell\])|\.\.\.|$)/is';
		$this->sellrule = '/\[sell=([\d+]+?),('.$extstr .')\]([\s\S]+?)\[\/sell\]/is';
		$this->lang = @include DISCUZ_ROOT.'/source/plugin/dc_sell/config/lang.php';
	}
	public function discuzcode($p) {
		global $_G;
		if($p['caller']=='messagecutstr'||(defined('IN_MOBILE')&&(IN_MOBILE===true||IN_MOBILE!=2))){
			$_G['discuzcodemessage'] = preg_replace($this->reprule, $this->lang('nopayhide'), $_G['discuzcodemessage']);
		}else{
			if($_GET['from']=='preview'||$_GET['action']=='printable')
				$_G['discuzcodemessage'] = preg_replace($this->sellrule, $this->lang('nopayhide'), $_G['discuzcodemessage']);
		}
	}
	function lang($str){
		if(!empty($this->lang[$str]))
			return $this->lang[$str];
		else
			return lang('plugin/dc_sell', $str);
	}
}
class plugin_dc_sell_forum extends plugin_dc_sell{
	function viewthread_postbottom_output() {
		global $_G, $postlist,$post;
		if(!$this->open)
			return;
		if(!empty($postlist)){
			foreach($postlist as $id => $p) {
				$postlist[$id] = $this->sellcodeprase($p);
			}
		}
		if(!empty($post)){
			$post=$this->sellcodeprase($post);
		}
	}
	function sellcodeprase($post){
		global $_G;
		$message = $post['message'];
		$pid = $post['pid'];
		if(!in_array($post['groupid'], (array)unserialize($this->cvar['allow'])))
			return $post;
		preg_match_all($this->sellrule,$message,$matches);
		if(!count($matches[3]))
			return $post;
		$plarr=C::t('#dc_sell#dc_sell_log')->fetch_by_pcuid(array('pid'=>$pid,'uid'=>$_G['uid']));
		$sell=array();
		foreach($plarr as $r){
			$sell[$r['cid']]['display']=1;
		}
		for($i=0;$i<count($matches[3]);$i++){
			if($sell[$i]['display']==1||$this->free||$post['authorid']==$_G['uid']||$_G['dc_plugin']['vip']['hook']['dc_sell']['view'])
				$message = preg_replace($this->sellrule, $this->sell_reply($pid,$i), $message,1);
			else
				$message = preg_replace($this->sellrule, $this->sell_reply_hidden($pid,$post['authorid'],$matches[1][$i],$matches[2][$i],$i), $message,1);
		}
		$post['message']=$message;
		return $post;
	}
	function sell_reply_hidden($pid,$authorid,$price,$credit,$i){
		global $_G;
		if($price>$this->cvar['maxprice'])
			$price=$this->cvar['maxprice'];
		$ck=substr(md5($_G['uid'].'|'.$pid.'|'.$authorid.'|'.$i.'|'.$price.'|'.$credit.'|'. TIMESTAMP .'|'.$_G['config']['security']['authkey']), 0, 8);
		$sid=base64_encode($pid.'|'.$authorid.'|'.$i.'|'.$price.'|'.$credit.'|'.TIMESTAMP.'|'.$ck);
		$hidetext = str_replace(array('{username}','{price}'),array($_G['uid']?$_G['username']:lang('forum/template', 'guest'),$price.$_G['setting']['extcredits'][$credit]['unit'].$_G['setting']['extcredits'][$credit]['title']),$this->lang('hidetext'));
		if(defined('IN_MOBILE')&&IN_MOBILE==2){
			$str = '<div class="grey quote"><a href="plugin.php?id=dc_sell:pay&sid='.$sid.'&tid='.$_G['tid'].'" class="viewpay" title="'.$this->lang('paytext').'">'.$hidetext.'</a></div>';
		}else{
			$str = '<div class="locked">';
			$str .= $hidetext;
			$str .= '<a href="javascript:;" class="y viewpay" title="'.$this->lang('paytext').'" onclick="showWindow(\'dc_sell\', \'plugin.php?id=dc_sell:pay&sid='.$sid.'&tid='.$_G['tid'].'\')">'.$this->lang('payfor').'</a></div>';
		}
		return $str;
	}
	function sell_reply($pid,$i){
		global $_G;
		if(defined('IN_MOBILE')&&IN_MOBILE==2){
			$str = '<div class="quote">\\3</div>';
			
		}else{
			$str = '<div class="showhide"><h4>'.$this->lang('selltext').($this->cvar['islog']?'      <a href="javascript:;" title="'.$this->lang('selllog').'" onclick="showWindow(\'dc_sellview\', \'plugin.php?id=dc_sell:sellview&pid='.$pid.'&cid='.$i.'\')">'.$this->lang('selllog').'</a>':'').' </h4>\\3</div>';
		}
		return $str;
	}
	function ad_headerbanner($params){
		global $postlist;
		if(defined('IN_ARCHIVER')){
			foreach($postlist as $key => $post){
				$post['message'] = preg_replace($this->reprule, $this->lang('nopayhide'), $post['message']);
				$postlist[$key]=$post;
			}
		}
		return $params['content'];
	}
	function post_editorctrl_left() {
		global $_G;
		if(!$this->open)
			return;
		if(!in_array($_G['groupid'], (array)unserialize($this->cvar['allow'])))
			return;
		return '<style type="text/css">
.b2r #e_dcsell	{ background:transparent url("source/plugin/dc_sell/img/b2r.gif") no-repeat 0 0; overflow: hidden;background-position: 7px 4px;background-position: 0px 1px; }
.b1r #e_dcsell	{ background:transparent url("source/plugin/dc_sell/img/b1r.gif") no-repeat 0 0; overflow: hidden;background-position: 7px 4px;background-position: 0px 1px; }
</style>
<a id="e_dcsell" title="'.$this->lang('sellinsert').'">'.$this->lang('sell').'</a>';
	}
	function post_middle_output(){
		global $_G;
		if(!$this->open)
			return;
		if(!in_array($_G['groupid'], (array)unserialize($this->cvar['allow'])))
			return;
		$creditstr = '';
		foreach($_G['setting']['extcredits'] as $k =>$v){
		if($k==$this->cvar['credit'])
			$creditstr .= '<option value="'.$k.'" selected>'.$v['title'].'</option>';
		else
			$creditstr .= '<option value="'.$k.'">'.$v['title'].'</option>';
		}
		$str = $this->lang('sellinmsg').'';
		$return=<<<EOF
		<script type="text/javascript">
		EXTRAFUNC['showEditorMenu']['dcsell']='ext_dcsell';
		function ext_dcsell(tag,flag){
			if(tag != 'dcsell') {
				return false;
			}
			if(flag==1){
				var mincredits = parseInt($('e_dcsell_param_2').value);
				var credits = parseInt($('e_dcsell_param_3').value);
				if(mincredits > 0) {
					if(mincredits>{$this->cvar[maxprice]}&&{$this->cvar[maxprice]}!=0){
						showDialog('{$this->lang(pricetoomuch)};', 'error');
						doane();return;
					}
					opentag = '[sell=';
					opentag += mincredits+','+(credits?credits:'{$this->cvar[credit]}');
					opentag += ']';
				} else {
					opentag = '[sell=';
					opentag += '{$this->cvar[price]},'+(credits?credits:'{$this->cvar[credit]}');
					opentag += ']';
				}
				str = $('e_dcsell_param_1') && $('e_dcsell_param_1').value ? $('e_dcsell_param_1').value : (selection ? selection : '');
				str = opentag + str + '[/sell]';
				insertText(str, strlen(opentag), 7, false, EXTRASEL);
				dcsellclear();
				doane();
			}
		}
		function dcsellclear(){
			$('e_dcsell_param_1').value='';
			$('e_dcsell_param_2').value='';
			$('e_dcsell_param_3').value={$this->cvar[credit]};
		}
		</script>
		<div class="p_pof upf" id="e_dcsell_menu" style="width: 270px;display: none">
		<div class="p_opt cl"><span class="y" style="margin:-10px -10px 0 0"><a onclick="hideMenu();return false;" class="flbc" href="javascript:;">{$this->lang(close)}</a></span><div>
	{$this->lang(sellinmsg)}<br /><textarea id="e_dcsell_param_1" style="width: 98%" cols="50" rows="5" class="txtarea"></textarea><br />{$this->lang(sellprice)}:</label> <input type="text" size="3" id="e_dcsell_param_2" class="px pxs" /><select id="e_dcsell_param_3">{$creditstr}</select><br />{$this->lang(nowritesellmsg)}<font color="#FF0000">{$this->cvar[price]}{$_G[setting][extcredits][$this->cvar[credit]][title]}</font>,{$this->lang(maxwriteprice)}<font color="#FF0000">{$this->cvar[maxprice]}{$_G[setting][extcredits][$this->cvar[credit]][title]}</font>.
</div><div class="pns mtn"><button type="submit" id="e_dcsell_submit" class="pn pnc"><strong>{$this->lang(confirms)}</strong></button></div></div>
</div>
		
EOF;
		return $return;
	}
}
class plugin_dc_sell_search extends plugin_dc_sell{
	function forum_top_output(){
		global $threadlist;
		foreach($threadlist as $key => $post){
			$post['message'] = preg_replace($this->reprule, $this->lang('nopayhide'), $post['message']);
				$threadlist[$key]=$post;
		}
	}
}
class plugin_dc_sell_portal extends plugin_dc_sell{
	function portalcp_bottom_output(){
		global $thread,$article_content,$_G;
		if(!$_GET['from_idtype']=='tid'||!$_GET['from_id'])
			return;
		if(!$this->cvar['open']||!in_array($thread['fid'], (array)unserialize($this->cvar['fids'])))
			return;
		$u=C::t('common_member')->fetch($thread['authorid']);
		if(!in_array($u['groupid'], (array)unserialize($this->cvar['allow'])))
			return;
		$article_content['content'] = preg_replace($this->sellrule, str_replace('{tid}',$_GET['from_id'],$this->lang('carticle')), $article_content['content']);
	}
}
class mobileplugin_dc_sell extends plugin_dc_sell{}
class mobileplugin_dc_sell_forum extends plugin_dc_sell_forum{
	function viewthread_postbottom_mobile_output() {
		$this->viewthread_postbottom_output();
	}
}
?>