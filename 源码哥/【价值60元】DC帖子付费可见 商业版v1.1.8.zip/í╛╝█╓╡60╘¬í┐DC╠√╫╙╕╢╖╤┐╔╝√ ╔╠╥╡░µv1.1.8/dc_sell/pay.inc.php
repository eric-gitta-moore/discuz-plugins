<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$dclang = @include DISCUZ_ROOT.'/source/plugin/dc_sell/config/lang.php';
$cvar= $_G['cache']['plugin']['dc_sell'];
if(!$_G['uid'])
	showmessage('to_login', NULL, array(), array('login' => 1));
@list($pid, $authorid, $cid, $price, $extcredit,$t,$ck) = explode('|', base64_decode($_GET['sid']));
if($ck!=substr(md5($_G['uid'].'|'.$pid.'|'.$authorid.'|'.$cid.'|'.$price.'|'.$extcredit.'|'.$t.'|'.$_G['config']['security']['authkey']), 0, 8))
	showmessage(plang('error'));
if($_G['uid']==$authorid)showmessage(plang('isauthorid'));
$tid=dintval($_GET['tid']);
$referer = $_G['siteurl'].'forum.php?mod=viewthread&tid='.$tid;
$r = C::t('common_member_count')->fetch($_G['uid']);
$credit=$r['extcredits'.$extcredit];
$rs = C::t('#dc_sell#dc_sell_log')->fetch_by_pcuid(array('pid'=>$pid,'cid'=>$cid,'uid'=>$_G['uid']));
if($rs)showmessage(plang('ispayfor'));
if($credit<$price)
	showmessage(str_replace('{credit}',$_G['setting']['extcredits'][$extcredit]['title'],plang('nocredit')));
if(submitcheck('submit')){
	$tax=(int)(($price*$cvar['salestax'])/100);
	$fhcredit = floor(($price*$fhbl)/100);
	if($_G['setting']['version']=='X2.5'){
		updatemembercount($_G['uid'], array('extcredits'.$extcredit => "-".$price), true, '', 0, '');
		updatemembercount($authorid, array('extcredits'.$extcredit => $price-$tax), true, '', 0, '');
	}else{
		updatemembercount($_G['uid'], array('extcredits'.$extcredit => "-".$price), true, '', 0, '',plang('notictextpay'),str_replace("{pid}",$pid,plang('notictextpaymsg')));
		updatemembercount($authorid, array('extcredits'.$extcredit => $price-$tax), true, '', 0, '',plang('notictextsell'),'<a href="home.php?mod=space&uid='.$_G['uid'].'" target="_blank">'.$_G['username'].'</a>'.str_replace("{pid}",$pid,plang('notictextsellmsg')));
	}
	$data=array(
		'pid'=>$pid,
		'cid'=>$cid,
		'uid'=>$_G['uid'],
		'uname'=>$_G['username'],
		'authorid'=>$authorid,
		'authorincome'=>$price-$tax,
		'pay'=>$price,
		'extcredit'=>$extcredit,
		'dateline'=>$_G['timestamp'],
	);
	C::t('#dc_sell#dc_sell_log')->insert($data);
	showmessage(plang('paysucceed'),$referer,array('tid'=>$tid,'pid'=>$pid));
}
$sellinfo = str_replace('{price}',$price.$_G['setting']['extcredits'][$extcredit]['unit'].$_G['setting']['extcredits'][$extcredit]['title'],plang('sellinfo'));
$paytext = plang('paytext');
include template('dc_sell:pay');

function plang($str) {
	global $dclang;
	if(!empty($dclang[$str]))
		return $dclang[$str];
	else
		return lang('plugin/dc_sell', $str);
}
?>