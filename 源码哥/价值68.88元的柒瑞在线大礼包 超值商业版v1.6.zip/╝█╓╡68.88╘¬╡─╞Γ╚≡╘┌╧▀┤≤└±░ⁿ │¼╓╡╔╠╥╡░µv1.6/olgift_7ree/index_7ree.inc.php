<?php
/*
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 *//*
	ID: olgift_7ree
	[www.7ree.com] (C)2007-2012 7ree.com.
	This is NOT a freeware, use is subject to license terms
	Update: 18:51 2013/1/3
	Agreement: http://www.7ree.com/agreement.html
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$vars_7ree = $_G['cache']['plugin']['olgift_7ree'];
		
if(!$vars_7ree[agreement_7ree]) showmessage('olgift_7ree:php_lang_agree_7ree');

$pagenum_7ree = 10;
$i_7ree = 1;
$navtitle = lang('plugin/olgift_7ree', 'php_lang_olgift_7ree');
		
$_GET['code'] = intval($_GET['code']);
$_GET['page'] = intval($_GET['page']);

		if(!$_GET['code']){
			$ranktime_7ree[0] = 0 ;
			$ranktime_7ree[1] = "" ;
		}else{
			$rankcycle_7ree = $_GET['code']+1;
			$ranktime_7ree = gettime_7ree($rankcycle_7ree);
		}
				
if($_G[uid] ){
//ɾ�������������
     if(!$_GET['page']){
	$todaytime_7ree = gmdate("Y-m-d", $_G[timestamp] + ($_G[setting][timeoffset] * 3600));
	$timewhere_7ree = strtotime($todaytime_7ree);			
	//ɾ����������
	DB::query("DELETE FROM ".DB::table('olgift_log_7ree')." WHERE btime_7ree < {$timewhere_7ree} AND etime_7ree =0 AND extnum_7ree = 0 LIMIT 100");
     }
		
	//�ҵ���Ϣ 1������ȡ���������		
		$mygiftnum_7ree = DB::result_first("SELECT COUNT(*) FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0 AND uid_7ree = '{$_G[uid]}'");		

	//�ҵ���Ϣ 1���ҵ�����
		$myrank_7ree = 1;
		$query = DB::query("SELECT count(*) as numssss_7ree FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0 GROUP BY uid_7ree ORDER BY numssss_7ree DESC");
		while($table_7ree = DB::fetch($query)){
			if($table_7ree[numssss_7ree]>$mygiftnum_7ree) $myrank_7ree +=1;
			if($myrank_7ree>100) break; 
		}
		
}		
		
		
//�������ݶ�ȡ
				$querynum_7ree = DB::result_first("SELECT count(distinct uid_7ree) FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0");
				$page = max(1, intval($_GET['page']));
				$startpage = ($page - 1) * $pagenum_7ree;		
		
				$query = DB::query("SELECT uid_7ree, user_7ree, COUNT(id_7ree) AS nums_7ree FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0 GROUP BY uid_7ree ORDER BY nums_7ree DESC LIMIT {$startpage}, {$pagenum_7ree}");
				while($table_7ree = DB::fetch($query)){
					$table_7ree[rankid_7ree] = $startpage + $i_7ree;
					$table_7ree[rankcss_7ree]='big_7ree';
					if($table_7ree[rankid_7ree]==1) $table_7ree[rankcss_7ree]='bigred_7ree';
					if($table_7ree[rankid_7ree]==2 || $table_7ree[rankid_7ree]==3) $table_7ree[rankcss_7ree]='bigorange_7ree';
						
					$rank_7ree[] = $table_7ree;
					$i_7ree++;
				}
				$multipage = multi($querynum_7ree, $pagenum_7ree, $page, "plugin.php?id=olgift_7ree:index_7ree&code=".$_GET['code']);


include template('olgift_7ree:index_7ree');


		function gettime_7ree($format_7ree){
		global $_G;
		$return_7ree = array();

		switch ($format_7ree){
		case 1://����
		  	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benri_7ree');
		  	break;
		case 2://����
		  	$return_7ree[0] = mktime(0, 0, 0, gmdate("m",strtotime("last Monday") + $_G[setting][timeoffset] * 3600),date("d",strtotime("last Monday") + $_G[setting][timeoffset] * 3600),date("Y",strtotime("last Monday") + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benzhou_7ree');
		  	break;
		case 3://����
  			$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),1,gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benyue_7ree');
  			break;
		case 4://������
			$season = ceil((gmdate("n",$_G[timestamp] + $_G[setting][timeoffset] * 3600))/3);
			$return_7ree[0] = mktime(0, 0, 0,$season*3-3+1,1,date('Y'));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benji_7ree');
		  	break;
		case 5://�����
		  	$return_7ree[0] = mktime(0,0,0,1,1,gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_bennian_7ree');
 		 	break;
		default:
 		 	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benri_7ree');
		}

		return $return_7ree;

}

?>