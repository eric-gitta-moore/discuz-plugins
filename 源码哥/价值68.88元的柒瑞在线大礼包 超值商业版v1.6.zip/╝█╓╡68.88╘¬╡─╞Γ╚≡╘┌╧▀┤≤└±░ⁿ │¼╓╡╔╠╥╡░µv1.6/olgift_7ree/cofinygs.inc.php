<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
echo lang("plugin/olgift_7ree", "logy_m_g");