<?php
/*
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 *//*
    ID: olgift_7ree
	[www.7ree.com] (C)2007-2012 7ree.com.
	This is NOT a freeware, use is subject to license terms
	Update: 16:29 2013/1/1
    Agreement: http://www.7ree.com/agreement.html
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
		$vars_7ree = $_G['cache']['plugin']['olgift_7ree'];
		
		
		if(!$vars_7ree[agreement_7ree]) showmessage('olgift_7ree:php_lang_agree_7ree');
		
		
		if($_G[uid]){

	
					
		$todaytime_7ree = gmdate("Y-m-d", $_G[timestamp] + ($_G[setting][timeoffset] * 3600));
		$timewhere_7ree = strtotime($todaytime_7ree); 
		
		$_GET[return_7ree] = intval($_GET[return_7ree]);
		
		
		$ranktime_7ree = gettime_7ree($vars_7ree['rankcycle_7ree']);
		@include(DISCUZ_ROOT.'./source/plugin/olgift_7ree/data_7ree/rank_cache_7ree.php');

		if(!$_GET[return_7ree]){//��ȡ����ajax����


		$mylog_7ree = DB::fetch_first("SELECT * FROM ".DB::table('olgift_log_7ree')." 
									   WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree > {$timewhere_7ree} 
									   ORDER BY id_7ree DESC LIMIT 1");
									   
									   
		$giftext_7ree ="exttype".$mylog_7ree[type_7ree]."_7ree";
		$giftnum_7ree = "giftnum".$mylog_7ree[type_7ree]."_7ree";
		$oltime_var = "oltime".$mylog_7ree[type_7ree]."_7ree";
			
		$extname_7ree = "extcredits".$vars_7ree[$giftext_7ree];
		$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree[$giftext_7ree]][title];
		$oltime_7ree = $vars_7ree[$oltime_var] * 60;


			
					
			if(!$mylog_7ree[extnum_7ree]){
			//�ж��Ƿ�������������Ҫ��
			
			if(!$mylog_7ree[btime_7ree] || ($_G[timestamp] - $mylog_7ree[btime_7ree] < $oltime_7ree)) showmessage('olgift_7ree:php_lang_oltimenotenought_7ree');
			//�����û�����
			updatemembercount($_G[uid], array($vars_7ree[$giftext_7ree] => $vars_7ree[$giftnum_7ree]));
			
			$pmnotice_7ree = lang('plugin/olgift_7ree', 'php_lang_returnmsg1_7ree').$todaytime_7ree.lang('plugin/olgift_7ree', 'php_lang_returnmsg2_7ree').$vars_7ree[$oltime_var].lang('plugin/olgift_7ree', 'php_lang_returnmsg3_7ree').$mylog_7ree[type_7ree].lang('plugin/olgift_7ree', 'php_lang_returnmsg4_7ree').$vars_7ree[$giftnum_7ree].$exttitle_7ree.lang('plugin/olgift_7ree', 'php_lang_returnmsg5_7ree');
			//������Ϣ����
			if(!$vars_7ree['noticeoff_7ree']) notification_add($_G[uid], 'system', $pmnotice_7ree, $notevar, 1);
			
			//��д�콱״̬����ʱ��
			$updatevalue_7ree = array('etime_7ree' => $_G['timestamp'],
									  'extnum_7ree' => $vars_7ree[$giftnum_7ree],
									  'exttitle_7ree' => $exttitle_7ree,
									  );
			$wherevalue_7ree = array('id_7ree' => $mylog_7ree[id_7ree]);			
			DB::update('olgift_log_7ree', $updatevalue_7ree, $wherevalue_7ree);
			
			
			//�콱����
			if($vars_7ree[fid_7ree]){
			
			require_once DISCUZ_ROOT.'./source/function/function_forum.php'; 
			require_once DISCUZ_ROOT.'./source/function/function_post.php';
			
				$weekarray_7ree=array(lang('plugin/olgift_7ree', 'php_lang_week0_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week1_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week2_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week3_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week4_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week5_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week6_7ree'));
				$vars_7ree[subject_7ree] = str_replace("{week_7ree}",$weekarray_7ree[gmdate("w", $_G[timestamp] + ($_G[setting][timeoffset] * 3600))],$vars_7ree[subject_7ree]);
				$subject_7ree = str_replace("{data_7ree}",gmdate("m".lang('plugin/olgift_7ree', 'php_lang_yue_7ree')."d".lang('plugin/olgift_7ree', 'php_lang_ri_7ree'), $_G[timestamp] + ($_G[setting][timeoffset] * 3600)),$vars_7ree[subject_7ree]);
				$post_array_7ree = (array)explode('||||||',str_replace("\n","||||||",$vars_7ree[post_7ree]));
				$key_7ree=array_rand($post_array_7ree); 
				$post_array_7ree[$key_7ree] = str_replace("{giftnum_7ree}",$vars_7ree[$giftnum_7ree]."[b]".$exttitle_7ree."[/b]",$post_array_7ree[$key_7ree]);
				$post_7ree = str_replace("{n_7ree}","[b]".$mylog_7ree[type_7ree]."[/b]",$post_array_7ree[$key_7ree]);

				$todaytime_7ree = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));

				$tid = DB::result_first("SELECT tid FROM ".DB::table('forum_thread')." WHERE subject ='{$subject_7ree}' AND dateline > $todaytime_7ree AND fid = '{$vars_7ree[fid_7ree]}' LIMIT 1");


			if(!$tid){
				DB::query("INSERT INTO ".DB::table('forum_thread')." (fid, author, authorid, subject, dateline, lastpost, lastposter)
		VALUES ('$vars_7ree[fid_7ree]', '{$_G[username]}', '{$_G[uid]}', '{$subject_7ree}', '{$_G[timestamp]}', '{$_G[timestamp]}', '{$_G[username]}')");
				$tid = DB::insert_id();	
			}

				$pid = insertpost(array(
				'fid' => $vars_7ree[fid_7ree],
				'tid' => $tid,
				'first' => '1',
				'author' => $_G['username'],
				'authorid' => $_G['uid'],
				'subject' => $subject_7ree,
				'dateline' => $_G['timestamp'],
				'message' => $post_7ree,
				'useip' => $_G['clientip'],
				'invisible' => $pinvisible,
				'anonymous' => $isanonymous,
				'usesig' => $usesig,
				'htmlon' => $htmlon,
				'bbcodeoff' => $bbcodeoff,
				'smileyoff' => $smileyoff,
				'parseurloff' => $parseurloff,
				'attachment' => '0',
				'tags' => $tagstr,
				'replycredit' => 0,
				'status' => (defined('IN_MOBILE') ? 8 : 0)
			));
			
		
			DB::query("UPDATE ".DB::table('forum_thread')." SET lastposter='$_G[username]', lastpost='$_G[timestamp]', replies=replies+1 WHERE tid='{$tid}'", 'UNBUFFERED');		
				
			$lastpost = "$tid\t{$subject_7ree}\t{$_G[timestamp]}\t{$_G[username]}";
			DB::query("UPDATE ".DB::table('forum_forum')." SET lastpost='$lastpost', threads=threads+1, posts=posts+1, todayposts=todayposts+1 WHERE fid='{$vars_7ree[fid_7ree]}'", 'UNBUFFERED');
			}
			
			
			
			
			
			}


			if($mylog_7ree[type_7ree]<3){//��ʼ�µĵ���ʱ
			$type_7ree = $mylog_7ree[type_7ree] + 1;
			$insertvalue_7ree = array(
             						'uid_7ree' => $_G['uid'],
		     						'user_7ree' => $_G['username'],
		     						'btime_7ree' => $_G['timestamp'],
		     						'ip_7ree' => $_G['clientip'],
		     						'type_7ree' => $type_7ree,
			   						);
		   	DB::insert('olgift_log_7ree', $insertvalue_7ree);
		}elseif($mylog_7ree[type_7ree]==3){
			$mylog_7ree[extnum_7ree] = $vars_7ree[$giftnum_7ree];
		}
	
			
			include template('olgift_7ree:ajaxget_7ree');
			
		}else{//��ȡ���ص���ʱҳ��ajax����
			
			
			
			
		$mylog_7ree = DB::fetch_first("SELECT * FROM ".DB::table('olgift_log_7ree')." 
									   WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree > {$timewhere_7ree} 
									   ORDER BY id_7ree DESC LIMIT 1");
									   
									   
		$giftext_7ree ="exttype".$mylog_7ree[type_7ree]."_7ree";
		$giftnum_7ree = "giftnum".$mylog_7ree[type_7ree]."_7ree";
		$oltime_var = "oltime".$mylog_7ree[type_7ree]."_7ree";
			
		$extname_7ree = "extcredits".$vars_7ree[$giftext_7ree];
		$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree[$giftext_7ree]][title];
		$oltime_7ree = $vars_7ree[$oltime_var] * 60;
			
			
		$remaining_time_7ree = $oltime_7ree - ($_G[timestamp] - $mylog_7ree[btime_7ree]);
		
		
		
		if($_G[timestamp] - $rankcachetime_7ree > $vars_7ree['rankcachecycle_7ree']*3600){
				
				$RankCache_7ree = "<?php \n//olgift_7ree cache file, DO NOT modify me! \n//(c) www.7ree.com\n//upload: ".gmdate("Y-m-d H:i:s", $_G[timestamp] + $_G[setting][timeoffset] * 3600)." \n\n";
				$RankCache_7ree .= "\$rankcachetime_7ree = '".$_G[timestamp]."';\n\n";
				
				$query = DB::query("SELECT uid_7ree, user_7ree, COUNT(id_7ree) AS nums_7ree FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0 GROUP BY uid_7ree ORDER BY nums_7ree DESC LIMIT 12");
				while($table_7ree = DB::fetch($query)){
					$table_7ree[user2_7ree] = cutstr($table_7ree[user_7ree],10,'');
			    	$rank_7ree[] = $table_7ree;
				}
				require_once libfile('function/cache');
				$RankCache_7ree .= "\$rank_cache=".arrayeval($rank_7ree).";\n\n\n?>";
				@$fp = fopen("source/plugin/olgift_7ree/data_7ree/rank_cache_7ree.php","w");
				if(!$fp){
					exit();
				}else {
            		fwrite($fp,$RankCache_7ree);
            		fclose($fp);
    			}        	
			}
		


			include template('olgift_7ree:ajaxagain_7ree');
		}

		}else{
		 	showmessage('olgift_7ree:php_lang_loginfirst_7ree');
		}



		function gettime_7ree($format_7ree){
		global $_G;
		$return_7ree = array();

		switch ($format_7ree){
		case 1://����
		  	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benri_7ree');
		  	break;
		case 2://����
		  	$return_7ree[0] = mktime(0, 0, 0, gmdate("m",strtotime("last Monday") + $_G[setting][timeoffset] * 3600),date("d",strtotime("last Monday") + $_G[setting][timeoffset] * 3600),date("Y",strtotime("last Monday") + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benzhou_7ree');
		  	break;
		case 3://����
  			$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),1,gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benyue_7ree');
  			break;
		case 4://������
			$season = ceil((gmdate("n",$_G[timestamp] + $_G[setting][timeoffset] * 3600))/3);
			$return_7ree[0] = mktime(0, 0, 0,$season*3-3+1,1,date('Y'));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benji_7ree');
		  	break;
		case 5://�����
		  	$return_7ree[0] = mktime(0,0,0,1,1,gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_bennian_7ree');
 		 	break;
		default:
 		 	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benri_7ree');
		}

		return $return_7ree;

}

?>