<?php
/*
 *Դ��������www.ymg6.com
 *��������www.fx8.cc
 *���ྫƷ��Դ�����Դ���ٷ���վ��ѻ�ȡ
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 *//*
    ID: olgift_7ree
	[www.7ree.com] (C)2007-2012 7ree.com.
	This is NOT a freeware, use is subject to license terms
	Update: 16:28 2013/1/1
    Agreement: http://www.7ree.com/agreement.html
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



class plugin_olgift_7ree{

		function global_footerlink() {
			global $_G;
			$return = "";
			$vars_7ree = $_G['cache']['plugin']['olgift_7ree'];
			$ranktime_7ree = $this->gettime_7ree($vars_7ree['rankcycle_7ree']);
			$vars_7ree[postop_7ree] = intval($vars_7ree[postop_7ree]) > 1 ? 0.2 : $vars_7ree[postop_7ree];
			
			@include(DISCUZ_ROOT.'./source/plugin/olgift_7ree/data_7ree/rank_cache_7ree.php');
			

			if($_G[timestamp] - $rankcachetime_7ree > $vars_7ree['rankcachecycle_7ree']*3600){
				
				$RankCache_7ree = "<?php \n//olgift_7ree cache file, DO NOT modify me! \n//(c) www.7ree.com\n//upload: ".gmdate("Y-m-d H:i:s", $_G[timestamp] + $_G[setting][timeoffset] * 3600)." \n\n";
				$RankCache_7ree .= "\$rankcachetime_7ree = '".$_G[timestamp]."';\n\n";
				
				$query = DB::query("SELECT uid_7ree, user_7ree, COUNT(id_7ree) AS nums_7ree FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0 GROUP BY uid_7ree ORDER BY nums_7ree DESC LIMIT 12");
				while($table_7ree = DB::fetch($query)){
					$table_7ree[user2_7ree] = cutstr($table_7ree[user_7ree],10,'');
			    	$rank_7ree[] = $table_7ree;
				}
				require_once libfile('function/cache');
				$RankCache_7ree .= "\$rank_cache=".arrayeval($rank_7ree).";\n\n\n?>";
				@$fp = fopen("source/plugin/olgift_7ree/data_7ree/rank_cache_7ree.php","w");
				if(!$fp){
					exit();
				}else {
            		fwrite($fp,$RankCache_7ree);
            		fclose($fp);
    			}        	
			}	
		
			if($vars_7ree[agreement_7ree] && $_G[uid]){	
				$todaytime_7ree = gmdate("Y-m-d", $_G[timestamp] + ($_G[setting][timeoffset] * 3600));
				$timewhere_7ree = strtotime($todaytime_7ree);  
			
				//ɾ����������
				DB::query("DELETE FROM ".DB::table('olgift_log_7ree')." WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree < {$timewhere_7ree} AND etime_7ree =0 AND extnum_7ree = 0");
			
			$mylog_7ree = DB::fetch_first("SELECT * FROM ".DB::table('olgift_log_7ree')." WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree > {$timewhere_7ree} ORDER BY id_7ree DESC LIMIT 1");
		
			if(!$mylog_7ree[type_7ree]){
				$insertvalue_7ree = array(
             						'uid_7ree' => $_G['uid'],
		     						'user_7ree' => $_G['username'],
		     						'btime_7ree' => $_G['timestamp'],
		     						'ip_7ree' => $_G['clientip'],
		     						'type_7ree' => 1,
			   						);
		   		DB::insert('olgift_log_7ree', $insertvalue_7ree);
		   		$mylog_7ree = DB::fetch_first("SELECT * FROM ".DB::table('olgift_log_7ree')." WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree > {$timewhere_7ree} ORDER BY id_7ree DESC LIMIT 1");
			}
		
			$giftext_7ree ="exttype".$mylog_7ree[type_7ree]."_7ree";
			$giftnum_7ree = "giftnum".$mylog_7ree[type_7ree]."_7ree";
			$oltime_var = "oltime".$mylog_7ree[type_7ree]."_7ree";
			
			$extname_7ree = "extcredits".$vars_7ree[$giftext_7ree];
			$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree[$giftext_7ree]][title];
			$oltime_7ree = $vars_7ree[$oltime_var] * 60;

			//ʣ��ʱ�����
				
			$remaining_time_7ree = $oltime_7ree - ($_G[timestamp] - $mylog_7ree[btime_7ree]);


			}
			
		
			if($vars_7ree['agreement_7ree'] && ($vars_7ree['finishonoff_7ree'] || $mylog_7ree[type_7ree]<3 || $mylog_7ree[extnum_7ree]==0)) include template('olgift_7ree:olgift_7ree');

			return $return;
	
		}
		

		function post() {
			global $_G;
			$vars_7ree = $_G['cache']['plugin']['olgift_7ree'];

			$todaytime_7ree = gmdate("Y-m-d", $_G[timestamp] + ($_G[setting][timeoffset] * 3600));
			$timewhere_7ree = strtotime($todaytime_7ree);  
			$unlimitgid_7ree = $vars_7ree['unlimitgid_7ree'] ? unserialize($vars_7ree['unlimitgid_7ree']) : array();
			$ban_7ree = 0;

			if(!in_array($_G['groupid'],$unlimitgid_7ree)){
					if($vars_7ree[postlimit_7ree]) $gifttype_7ree = DB::result_first("SELECT type_7ree FROM ".DB::table('olgift_log_7ree')." WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree > {$timewhere_7ree} AND extnum_7ree > 0 ORDER BY id_7ree DESC LIMIT 1");
				
						if(!$vars_7ree[postlimit_7ree]){
							$ban_7ree = 0;
						}elseif($vars_7ree[postlimit_7ree]==1){
							$ban_7ree = $gifttype_7ree ? 0 : 1 ;
						}elseif($vars_7ree[postlimit_7ree]==2){
							$ban_7ree = $gifttype_7ree > 1 ? 0 : 1 ;
						}elseif($vars_7ree[postlimit_7ree]==3){
							$ban_7ree = $gifttype_7ree > 2 ? 0 : 1;
						}
						if(!empty($_POST) && $ban_7ree) {					
							showmessage(lang('plugin/olgift_7ree', 'php_lang_banmsg1_7ree').$vars_7ree[postlimit_7ree].lang('plugin/olgift_7ree', 'php_lang_banmsg2_7ree')."<br>".$vars_7ree['limittip_7ree']);
						}
					}
		}

		

		
		
		function gettime_7ree($format_7ree){
		global $_G;
		$return_7ree = array();

		switch ($format_7ree){
		case 1://����
		  	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benri_7ree');
		  	break;
		case 2://����
		  	$return_7ree[0] = mktime(0, 0, 0, gmdate("m",strtotime("last Monday") + $_G[setting][timeoffset] * 3600),date("d",strtotime("last Monday") + $_G[setting][timeoffset] * 3600),date("Y",strtotime("last Monday") + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benzhou_7ree');
		  	break;
		case 3://����
  			$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),1,gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benyue_7ree');
  			break;
		case 4://������
			$season = ceil((gmdate("n",$_G[timestamp] + $_G[setting][timeoffset] * 3600))/3);
			$return_7ree[0] = mktime(0, 0, 0,$season*3-3+1,1,date('Y'));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benji_7ree');
		  	break;
		case 5://�����
		  	$return_7ree[0] = mktime(0,0,0,1,1,gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_bennian_7ree');
 		 	break;
		default:
 		 	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benri_7ree');
		}

		return $return_7ree;

}
		
		
		
		
}			
		
		
		

class plugin_olgift_7ree_forum extends plugin_olgift_7ree{
}

class plugin_olgift_7ree_group extends plugin_olgift_7ree{
}
?>

