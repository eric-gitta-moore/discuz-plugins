<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$createTableSql='';
$createTableSql=<<<EOF
CREATE TABLE IF NOT EXISTS `pre_ly_weibo_bind`
(
	`uid` mediumint(8) unsigned not null,
	`username` char(15) not null default '',
	`weibo_uid` bigint(20) unsigned not null,
	`weibo_username` varchar(30) not null,
	`access_token` char(32) not null,
	`expires_in` int(10) unsigned not null,
	`remind_in` int(10) unsigned not null,
	`dateline` int(10) unsigned not null,
	`syn_thread` int(1) unsigned not null,
	`syn_reply` int(1) unsigned not null,
	`syn_blog` int(1) unsigned not null,
	`syn_doing` int(1) unsigned not null,
	`syn_broadcast` int(1) unsigned not null,
	`syn_share` int(1) unsigned not null,
	`syn_portal` int(1) unsigned not null,
	`is_onkey` int(1) unsigned not null default '0',
	`profile` text,
	 primary key (`uid`),
	 key (`weibo_uid`)

)ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_ly_weibo_threadlog` (
  `uid` mediumint(8) unsigned NOT NULL,
  `wbid` bigint(20) unsigned NOT NULL,
  `tid` int(10) unsigned NOT NULL,
  `type` enum('article','blog','doing','share','thread','broadcast') NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  `since_id` bigint(20) unsigned NOT NULL,
  `updateline` int(10) unsigned NOT NULL,
  PRIMARY KEY (`wbid`),
  key (`tid`,`type`)
)ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_ly_weibo_backlog` (
  `bbsid` int(10) NOT NULL,
  `type` enum('article','blog','doing','share','thread','broadcast') NOT NULL,
  `wbid` bigint(20) unsigned NOT NULL,
  `cid` bigint(20) unsigned NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  KEY (`bbsid`),
  KEY (`cid`),
  KEY (`wbid`,`cid`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_ly_weibo_setting` (
  `skey` varchar(64) NOT NULL,
  `svalue` text NOT NULL,
  PRIMARY KEY (`skey`)
)ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_ly_weibo_rewardlog` (
  `uid` int(10) NOT NULL,
  `value` int(20) unsigned NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM;
EOF;

runquery($createTableSql);


$sql = '';

$synt_columnexisted = false;
$synr_columnexisted = false;
$weibo_username_columnexisted = false;
$syn_blog_columnexisted = false;
$syn_doing_columnexisted = false;
$syn_broadcast_columnexisted = false;
$syn_share_columnexisted = false;
$syn_portal_columnexisted = false;
$is_onkey_columnexisted = false;
$dateline_columnexisted = false;


$query = DB::query("SHOW COLUMNS FROM ".DB::table('ly_weibo_bind'));
while($temp = DB::fetch($query)) {
	if($temp['Field'] == 'syn_thread') {
		$synt_columnexisted = true;
	}
	if($temp['Field'] == 'syn_reply') {
		$synr_columnexisted = true;
	}
	if($temp['Field'] == 'weibo_username') {
		$weibo_username_columnexisted = true;
	}
	if($temp['Field'] == 'syn_blog') {
		$syn_blog_columnexisted = true;
	}
	if($temp['Field'] == 'syn_doing') {
		$syn_doing_columnexisted = true;
	}
	if($temp['Field'] == 'syn_broadcast') {
		$syn_broadcast_columnexisted = true;
	}
	if($temp['Field'] == 'syn_share') {
		$syn_share_columnexisted = true;
	}
	if($temp['Field'] == 'syn_portal') {
		$syn_portal_columnexisted = true;
	}
	if($temp['Field'] == 'is_onkey') {
		$is_onkey_columnexisted = true;
	}
	if($temp['Field'] == 'dateline') {
		$dateline_columnexisted = true;
	}
}
$sql .= !$synt_columnexisted ? "ALTER TABLE ".DB::table('ly_weibo_bind')." ADD COLUMN syn_thread int(1) unsigned not null default '1';\n" : '';
$sql .= !$synr_columnexisted ? "ALTER TABLE ".DB::table('ly_weibo_bind')." ADD COLUMN syn_reply int(1) unsigned not null  default '1';\n" : '';
$sql .= !$weibo_username_columnexisted ? "ALTER TABLE ".DB::table('ly_weibo_bind')." ADD COLUMN weibo_username varchar(30) not null;\n" : '';
$sql .= !$syn_blog_columnexisted ? "ALTER TABLE ".DB::table('ly_weibo_bind')." ADD COLUMN syn_blog int(1) unsigned not null  default '1';\n" : '';
$sql .= !$syn_doing_columnexisted ? "ALTER TABLE ".DB::table('ly_weibo_bind')." ADD COLUMN syn_doing int(1) unsigned not null default '1';\n" : '';
$sql .= !$syn_broadcast_columnexisted ? "ALTER TABLE ".DB::table('ly_weibo_bind')." ADD COLUMN syn_broadcast int(1) unsigned not null  default '1';\n" : '';
$sql .= !$syn_share_columnexisted ? "ALTER TABLE ".DB::table('ly_weibo_bind')." ADD COLUMN syn_share int(1) unsigned not null default '1';\n" : '';
$sql .= !$syn_portal_columnexisted ? "ALTER TABLE ".DB::table('ly_weibo_bind')." ADD COLUMN syn_portal int(1) unsigned not null  default '1';\n" : '';
$sql .= !$is_onkey_columnexisted ? "ALTER TABLE ".DB::table('ly_weibo_bind')." ADD COLUMN is_onkey int(1) unsigned not null default '0';\n" : '';
$sql .= !$dateline_columnexisted ? "ALTER TABLE ".DB::table('ly_weibo_bind')." ADD COLUMN dateline int(10) unsigned not null;\n" : '';

$sql .= "ALTER TABLE ".DB::table('ly_weibo_bind')." DROP primary key;\n" ;

$sql .= "ALTER TABLE ".DB::table('ly_weibo_bind')." add primary key(uid,weibo_uid);\n" ;

if($sql) {
	runquery($sql);
}


$lyInstallSetting=Array(
'blog' => 1,
'article' => 1,
'doing' => 1,
'broadcast' => 1,
'share' => 1,
'thread' => 1,
'reply' => 1,
'synthread' => 1,
'synblog' => 1,
'syndoing' => 1,
'synshare' => 1,
'synarticle' => 1,
'synbroadcast' => 1,
'comthread' => 1,
'comblog' => 1,
'comdoing' => 1,
'comshare' => 1,
'comarticle' => 1,
'combroadcast' => 1,
'model' => 2,
'contenttemplate' => '#{bbsname}#[{subject}]{content}{subjecturl}');

foreach($lyInstallSetting as $key=>$value)
{
	$data=array();
	$data['skey']=$key;
	$data['svalue']=$value;
	 C::t('#liyou_weibo#ly_weibo_setting') -> insert($data);
}
liyou_clear(DISCUZ_ROOT.'source/plugin/liyou_weibo/install.php','');
liyou_clear(DISCUZ_ROOT.'source/plugin/liyou_weibo/upgrade.php','');
function liyou_clear($filename,$data=''){
	if($fp = @fopen($filename, 'wb')) {
		fwrite($fp, $data);
		fclose($fp);
		return true;
	}
	return false;
}
$finish = TRUE;
?>