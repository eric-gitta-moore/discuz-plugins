<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_ly_weibo_rewardlog extends discuz_table {
	
	public function __construct() {
		$this->_table='ly_weibo_rewardlog';
		$this->_pk='uid';
		parent::__construct();
	}

	public function get_by_uid($uid) {
		return DB::result_first("SELECT uid FROM %t WHERE uid=%d", array($this->_table, $uid));
	}

}
//WWW.fx8.cc
?>