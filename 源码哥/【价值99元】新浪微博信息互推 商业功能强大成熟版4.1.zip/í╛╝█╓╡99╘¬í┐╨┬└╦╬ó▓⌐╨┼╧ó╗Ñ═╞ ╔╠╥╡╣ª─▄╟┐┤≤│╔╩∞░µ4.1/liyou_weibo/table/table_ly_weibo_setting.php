<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_ly_weibo_setting extends discuz_table {
	
	public function __construct() {
		$this->_table='ly_weibo_setting';
		$this->_pk='skey';
		parent::__construct();
	}
    public function insert($data)
    {
        if(empty($data['skey']))
        {
            return 0;
        }
        return DB::insert($this->_table, $data, FALSE, TRUE);
    }

    public function delete($skey)
    {
        return DB::delete($this->_table, "skey = $skey");
    }

    public function fetchAll()
    {
        return DB::fetch_all("SELECT * FROM " . DB::table($this->_table) . " ");
    }

    public function update($data,$skey)
    {
        return DB::update($this->_table,$data,"skey = '$skey'");
    }
	public function getValue($skey)
    {
    	$s = DB::fetch_first("SELECT `svalue` FROM " . DB::table($this->_table) . " where skey='$skey'");
		return $s['svalue'];
	}
}
//WWW.fx8.cc
?>