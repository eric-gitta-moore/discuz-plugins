<?php
/*
 * ������Դ���
 * ����: Www.fx8.cc
 * ������ַ: www.ymg6.com (���ղر���!)
 * ����֧��/����ά����QQ 154606914
 * 
 */
if (!defined('IN_DISCUZ')) {
	exit ('Access Denied');
}
//error_reporting(E_ALL);
class mobileplugin_liyou_weibo {
	var $allow = false;
	var $module = null;
	function mobileplugin_liyou_ask(){
		global $_G;
		if(!defined('IN_MOBILE')) {
			return;
		}
		$this->allow = true;
	}

	function index_top_mobile(){
		return '';
	}

	function global_footer_mobile(){
		global $_G;
		if(!$_G['cache']['plugin']['liyou_weibo']['ly_miblie']) return ;
		$in=LyweiboMobile::get_instance();
		return $in->_init();
	}
}

class mobileplugin_liyou_weibo_forum extends mobileplugin_liyou_weibo {

	function index_middle_mobile(){
		
	}

}

class LyweiboMobile{
	static $instance=null;
	static function get_instance(){
		if (self::$instance===null) {
			self::$instance=new LyweiboMobile();
		}
		return self::$instance;
	}

	private function __construct(){
		
	}

	public function _init(){
		$module=CURSCRIPT;
		$action='_'.$_GET['action'];
		if (method_exists($this, $action)) {
			return $this->$action();
		}else{
			return '';
		}
	}

	public function _login(){
		return '<div style="text-align:center;"><a href="plugin.php?id=liyou_weibo:loginm"><img src="source/plugin/liyou_weibo/image/login_btn.png"/></a></div>';
	}
}