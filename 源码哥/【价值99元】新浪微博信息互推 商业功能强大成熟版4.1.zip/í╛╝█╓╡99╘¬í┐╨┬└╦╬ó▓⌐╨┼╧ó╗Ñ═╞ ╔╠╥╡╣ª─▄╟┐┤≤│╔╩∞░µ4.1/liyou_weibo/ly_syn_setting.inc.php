<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/config/config.php';
require_once DISCUZ_ROOT.'./source/plugin/liyou_weibo/liyou.func.php';
$lysetting=array();

if(isset($_POST['lyweiboset'])) {
	if (submitcheck('lyweiboset')) {
		$_POST['setting']=array_merge($lysetting,$_POST['setting']);
		
		foreach($_POST['setting'] as $key=>$value)
		{
			$data=array();
			$data['skey']=$key;
			$data['svalue']=$value;
			 C::t('#liyou_weibo#ly_weibo_setting') -> insert($data);
		}
	}
}
$lyweiboSetting=C::t('#liyou_weibo#ly_weibo_setting') -> fetchAll();
foreach($lyweiboSetting as $key=>$value)
{
	$lysetting[$value['skey']]=$value['svalue'];
}
include_once  template("liyou_weibo:liyou_syn_setting");
?>