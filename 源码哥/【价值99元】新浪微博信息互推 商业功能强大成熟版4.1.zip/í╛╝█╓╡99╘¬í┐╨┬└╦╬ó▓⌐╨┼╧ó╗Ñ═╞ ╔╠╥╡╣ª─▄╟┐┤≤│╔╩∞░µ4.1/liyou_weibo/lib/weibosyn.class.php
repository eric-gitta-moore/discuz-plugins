<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class Weibosyn {

	var $threadlog;
	var $processname;

	function __construct(){

	}

	function weibo_back($arg)
	{
		global $_G;
		if(!$this->_init($arg)) return false;

		$exter='';

		if ($arg['type']=='thread') {
			$thread = C::t('forum_thread')->fetch($arg['tid']);
			if(!$thread || $thread['closed'] == 1 || $thread['displayorder'] < 0 || $thread['special']>1){
				discuz_process::unlock($this->processname);
				return;
			}
			$exter=$thread;
		}else if ($arg['type']=='article') {
			$article = C::t('portal_article_title')->fetch($arg['tid']);
			if(!$article || $article['allowcomment'] != 1 || $article['status'] != 0 ) {
				discuz_process::unlock($this->processname);
				return;
			}
			$exter=$article;
		}else if($arg['type']=='blog'){
			$blog = C::t('home_blog')->fetch($arg['tid']);
			if(!$blog || $blog['noreply']!=0 || $blog['status']!=0) {
				discuz_process::unlock($this->processname);
				return;
			}
			$exter=$blog;		
		}else if($arg['type']=='doing'){
			$doing = C::t('home_doing')->fetch($arg['tid']);
			if(!$doing || $doing['status']!=0) {
				discuz_process::unlock($this->processname);
				return;
			}
			$exter=$doing;		
		}else if($arg['type']=='broadcast'){
			$thread = C::t('forum_thread')->fetch($arg['tid']);
			if(!$thread || $thread['closed'] == 1 || getstatus($thread['status'], 3) || $thread['displayorder'] < 0 ) {
				discuz_process::unlock($this->processname);
				return;
			}
			$exter=$thread;	
		}else if($arg['type']=='share'){
			$share = C::t('home_share')->fetch($arg['tid']);
			if(!$share || $share['status']!=0) {
				discuz_process::unlock($this->processname);
				return;
			}
			$exter=$share;		
		}
		$threadloglist = C::t('#liyou_weibo#ly_weibo_threadlog')->fetch_all_threadlog_by_tid($arg['tid'],$arg['type']);
		foreach($threadloglist as $key11=>$valuess){
		$threadlog=$valuess;
		if($_G['timestamp'] > $threadlog['updateline'] + $_G['liyou_weibo_setting']['model']){
			$userInfo=C::t('#liyou_weibo#ly_weibo_bind')->fetch_by_discuz_uid($threadlog['uid']);
			//$bindlist=C::t('#liyou_weibo#ly_weibo_bind')->fetch_all_by_discuz_uid($threadlog['uid']);
			$oClient=new SaeTClientV2(APP_KEY,APP_SECRET,$userInfo['access_token']);

			$comments=$oClient->get_comments_by_sid($threadlog['wbid'], $page = 1, $count = 20, $since_id = $threadlog['since_id']);
			$reposts=$oClient->repost_timeline($threadlog['wbid'], $page = 1, $count = 20, $since_id = $threadlog['since_id']);
			if(isset($comments['comments']['0']['idstr']) && isset($reposts['reposts']['0']['idstr']) && $comments['comments']['0']['idstr']<$reposts['reposts']['0']['idstr']){
				$comments['comments']['0']['idstr']=$reposts['reposts']['0']['idstr'];
			}
			foreach($reposts['reposts'] as $val)
			{
				$comments['comments'][]=$val;
			}

			if($comments && count($comments['comments'])>0) {
				$responseinfo = array();
				if(!isset($response['data']['info'][0])) {
					$responseinfo[] = $response['data']['info'];
				} else {
					$responseinfo = $response['data']['info'];
					krsort($responseinfo);
				}
				$resultComents=array_reverse($comments['comments']);
				$handler = '_'.$arg['type'];
				foreach($resultComents as $post) {
					$back = C::t('#liyou_weibo#ly_weibo_backlog')->get_by_cid($post['idstr']);
					if($back) continue;
					$post = LywbFunc::fromWeibo($post);
					$bbsid=$this->$handler($arg['tid'],$post,$exter);
					$backlog=array(
						'bbsid'=>$bbsid,
						'wbid'=>$threadlog['wbid'],
						'cid'=>$post['idstr'],
						'type'=>$arg['type'],
						'dateline'=>TIMESTAMP,
						);
					 C::t('#liyou_weibo#ly_weibo_backlog')->insert($backlog);
				}
				$setarr['since_id'] = trim($comments['comments']['0']['idstr']);
			}

			$setarr['updateline'] = $_G['timestamp'];
			C::t('#liyou_weibo#ly_weibo_threadlog')->update($threadlog['wbid'], $setarr);
		}
		}
		discuz_process::unlock($this->processname);
	}

	private function _init($arg){
		global $_G;
		$r = false;
		$op = $arg['type'];
		$tid = $arg['tid'];
		$allowOp=array('thread','article','blog','doing','broadcast','share');
		if(!in_array($arg['type'], $allowOp))  return $r;
		$processname = 'liyou_'.$arg['type'].'_'.$arg['tid'].'_cache';
		$time = $_G['liyou_weibo_setting']['model'];
		if(discuz_process::islocked($processname,$time)) return $r;
		$threadlog = C::t('#liyou_weibo#ly_weibo_threadlog')->fetch_threadlog_by_tid($tid,$op);
		if(empty($threadlog) || ($_G['timestamp'] < $threadlog['updateline'] + $_G['liyou_weibo_setting']['model'])) {
			discuz_process::unlock($processname);
			return $r;
		}
		$r=true;
		$this->processname=$processname;
		$this->threadlog=$threadlog;
		return $r;
	}

	private function _filter($post){
			$message = preg_replace("/((https?|ftp|gopher|news|telnet|rtsp|mms|callto):\/\/|www\.)([a-z0-9\/\-_+=.~!%@?#%&;:$\\()|]+\s*)/i", '', $post['text']);
			$message = preg_replace("/\[.*?\]/mi", '', $message);
			return $message;
	}

	private function _init_user($post){
		$user['username'] = $post['user']['screen_name'];
		return $user;
	}

	private function _thread($id,$post,$exter){
		include_once libfile('function/forum');
		$thread = $exter;
		$message = $this->_filter($post);
		$user = $this->_init_user($post);
		return $this->_insert_comment($thread['fid'],$id,$message,$user,$exter);
	}



	private function _insert_comment($fid,$tid,$message,$user,$exter){
		global $_G;
		$thread=$exter;
		$pid = insertpost(array(
			'fid' => $fid,
			'tid' => $tid,
			'first' => '0',
			'author' => $user['username'],
			'authorid' => '0',
			'subject' => '',
			'dateline' => $_G['timestamp'],
			'message' => $message,
			'useip' => '',
			'invisible' => '0',
			'anonymous' => '0',
			'usesig' => '0',
			'htmlon' => '1',
			'bbcodeoff' => '0',
			'smileyoff' => '0',
			'parseurloff' => '0',
			'attachment' => '0',
			'status' => 16,
		));
		if ($pid) {
			$fieldarr = array('lastposter' => array(''),'replies'=>1);
			C::t('forum_thread')->increase($tid, $fieldarr);
			$postionid = C::t('forum_post')->fetch_maxposition_by_tid($thread['posttableid'], $tid);
			C::t('forum_thread')->update($tid, array('maxposition' => $postionid));

			$lastpost = "$thread[tid]\t$thread[subject]\t$_G[timestamp]\t".'';
			C::t('forum_forum')->update($fid, array('lastpost' => $lastpost));
			C::t('forum_forum')->update_forum_counter($fid,0,1,1);
		}
		return $pid;
	}

	private function _article($id,$post,$exter){
		global $_G;
		$message = $this->_filter($post);
		$user = $this->_init_user($post);
		$setarr = array(
			'uid' => '0',
			'username' => '0',
			'id' => $id,
			'idtype' => 'aid',
			'postip' => 0,
			'dateline' => $_G['timestamp'],
			'status' => 0,
			'message' => $message
		);
		$pcid = C::t('portal_comment')->insert($setarr, true);
		C::t('portal_article_count')->increase($id, array('commentnum' => 1));
		return $pcid;
	}

	private function _blog($id,$post,$exter){
		global $_G;
		$message = $this->_filter($post);
		$user = $this->_init_user($post);
		$setarr = array(
			'uid' => $exter['uid'],
			'id' => $exter['blogid'],
			'idtype' => 'blogid',
			'authorid' => '0',
			'author' => '',
			'dateline' => $_G['timestamp'],
			'message' => $message,
			'ip' => $_G['clientip'],
			'status' => 0,
		);
		$cid = C::t('home_comment')->insert($setarr, true);
		C::t('home_blog')->increase($exter['blogid'], 0, array('replynum'=>1));
		$stattype='blogcomment';
		if($stattype) {
			include_once libfile('function/stat');
			updatestat($stattype);
		}
		return $cid;
	}

	private function _doing($id,$post,$exter){
		global $_G;
		$message = $this->_filter($post);
		$user = $this->_init_user($post);
		$setarr = array(
			'doid' => $exter['doid'],
			'upid' => '0',
			'uid' => '0',
			'username' => '',
			'dateline' => $_G['timestamp'],
			'message' => $message,
			'ip' => $_G['clientip'],
			'grade' => '1'
		);
		$cid = C::t('home_docomment')->insert($setarr, true);
		C::t('home_doing')->update_replynum_by_doid(1, $exter['doid']);
		include_once libfile('function/stat');
		updatestat('docomment');
		return $cid;
	}

	private function _broadcast($id,$post,$exter){
		global $_G;
		include_once libfile('function/forum');
		$message = $this->_filter($post);
		$user = $this->_init_user($post);
		return $this->_insert_comment($exter['fid'],$id,$message,$user,$exter);
	}

	private function _share($id,$post,$exter){
		global $_G;
		$message = $this->_filter($post);
		$user = $this->_init_user($post);
		$setarr = array(
			'uid' => $exter['uid'],
			'id' => $exter['sid'],
			'idtype' => 'sid',
			'authorid' => '0',
			'author' => '',
			'dateline' => $_G['timestamp'],
			'message' => $message,
			'ip' => $_G['clientip'],
			'status' => 0,
		);
		$cid = C::t('home_comment')->insert($setarr, true);
		$stattype='sharecomment';
		if($stattype) {
			include_once libfile('function/stat');
			updatestat($stattype);
		}
		return $cid;
	}
	
}