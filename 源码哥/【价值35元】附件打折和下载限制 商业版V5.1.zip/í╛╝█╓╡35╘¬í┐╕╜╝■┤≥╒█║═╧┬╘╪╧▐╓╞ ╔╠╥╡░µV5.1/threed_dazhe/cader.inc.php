<?php
/**
 *	[����ѡ�(threed_tab.{modulename})] (C)2014-2099 Powered by 3D�����.
 *	Version: ��ҵ��
 *	Date: 2014-11-7 19:49
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
?>
<script type="text/javascript">
window.location.href="http://www.3dcader.com";
</script>