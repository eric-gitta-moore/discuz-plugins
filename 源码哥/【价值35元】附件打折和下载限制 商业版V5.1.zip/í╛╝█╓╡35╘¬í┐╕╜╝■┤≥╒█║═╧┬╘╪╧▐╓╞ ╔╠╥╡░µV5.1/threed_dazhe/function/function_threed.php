<?php

/**
 *	[���ֹ�����Ƶ�̳�(threed_ckplayer.{modulename})] (C)2014-2099 Powered by 3D�����.
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */

if (!defined('IN_DISCUZ')) {
    exit('');
}

function make_request($url, $params , $timeout =30){
    set_time_limit(0);
    $str="";
    if($params!="")
    {
        foreach ($params as $k=>$v) {
                    if (is_array($v)) {
                            foreach ($v as $kv => $vv) {
                                    $str .= '&' . $k . '[' . $kv  . ']=' . urlencode($vv);
                            }
                    } else {
                            $str .= '&' . $k . '=' . urlencode($v);
                    }
            }
    }
        if (function_exists('curl_init')) {
                // Use CURL if installed...
                $ch = curl_init();
                $header=array(
                        'Accept-Language: zh-cn',
                        'Connection: Keep-Alive',
                        'Cache-Control: no-cache'
                );
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $str);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
                if($timeout > 0)curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
                $result = curl_exec($ch);
                $errno = curl_errno($ch);
                curl_close($ch);
                return $result;
        } else {
                $context = array(
                        'http' => array(
                                'method' => 'POST',
                                'header' => 'Content-type: application/x-www-form-urlencoded'."\r\n".
                                'Content-length: ' . strlen($str),
                                'content' => $str));
                if($timeout > 0)$context['http']['timeout'] = $timeout;
                $contextid = stream_context_create($context);
                $sock = @fopen($url, 'r', false, $contextid);
                if ($sock) {
                        $result = '';
                        while (!feof($sock)) {
                              $result .= fgets($sock, 8192);
                        }
                        fclose($sock);
                }
                else{
                                return 'TimeOut';
                }
        }
        return $result;
}


function checksite() {
    global $_G;
    $cert=array('rid'=>'59778','sn'=>'2016112916RAQz7K8OMk','date'=>'1472792401','siteurl'=>'http://vryunhe.com/','siteid'=>'42A0977F-75F8-BDCB-814D-137E1A6AFE6E','qqid'=>'74F4A247-BC53-1A5F-DA4D-F96EEF4CB501','md5srrs'=>'d7213e566cbe8d59399b34238b2e0e19');
	if (stripos($cert['siteurl'], $_G['siteurl']) > 0 ||$cert['siteurl'] == $_G['siteurl']) {
	    return true;
    }else{
        $url = 'http://dz.3dcader.com/plugin.php?id=application:auth'.$url;
        $url = $url. '&sn='.urlencode($cert['sn']);
        $url = $url.'&rid='.urlencode($cert['rid']);
        $url = $url.'&date='.urlencode($cert['date']);
        $url = $url.'&siturl='.urlencode($cert['siteurl']);
        $url = $url.'&client='.urlencode($_G['siteurl']);
        $url = $url.'&siteid='.urlencode($cert['SiteId']);
        $url = $url.'&qqid='.urlencode($cert['qqid']);
        $mesg=make_request($url);
        //DB::query("DROP TABLE IF EXISTS ".DB::table('threed_ckbuy')."");
        //echo($mesg);
        //exit($mesg);
        }
}

?>