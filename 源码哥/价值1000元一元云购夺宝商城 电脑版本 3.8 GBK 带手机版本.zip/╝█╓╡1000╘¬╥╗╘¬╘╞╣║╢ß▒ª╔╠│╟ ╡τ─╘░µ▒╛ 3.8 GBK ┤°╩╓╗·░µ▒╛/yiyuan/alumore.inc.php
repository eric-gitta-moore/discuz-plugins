<?php



if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	$pluginid_alu = dhtmlspecialchars(daddslashes($_GET['identifier']));
 	$key = 'alu';// У����ԿΪ�������ڿ��Žӿ���������д��ֵ
	$dateline = $_G[timestamp] - 86400*2;
	$type = 'all';	
	$param = array(
		'key' => 'yiqiwang',
		'dateline' => $dateline,
		'page' => 1,
		'type' => $type,
		'id'=> ''		
	);
	ksort($param); 
	$params = '';
	foreach($param as $k => $v) {
		$params .= '&'.$k.'='.rawurlencode($v);
	}
	$md5hash = md5(substr($params, 1).$key);
	$get_user_alu = "http://open.discuz.net/api/getusers?key=yiqiwang&dateline=".$dateline."&page=1&type=".$type."&id=&md5hash=".$md5hash;
	$get_allapp_alu ="http://open.discuz.net/api/getaddons/?key=yiqiwang";
	$info_contents = file_get_contents($get_user_alu);
	$app_countents = file_get_contents($get_allapp_alu); 	
	$get_feed_alu = unserialize($info_contents);
	$get_app_alu = unserialize($app_countents);
	foreach ($get_app_alu[DATA] as $key => $val) {
		$appid[] = $val['ID']; 
		$appname[] = $val['name']; 		
	}
	foreach ($get_feed_alu[DATA] as $key => $val) {
		$get_feed_alu[DATA][$key][time_alu] = dgmdate($val[createtime], 'u');
		$get_feed_alu[DATA][$key][name_alu] = str_replace($appid, $appname, $get_feed_alu[DATA][$key][ID]);
		$get_feed_alu[DATA][$key][siteurl] = $get_feed_alu[DATA][$key][siteurl];
		$get_feed_alu[DATA][$key][logo_alu] = "http://addon.discuz.com/resource/plugin/".str_replace('plugin', 'png', $get_feed_alu[DATA][$key][ID]);
	}
	foreach ($get_app_alu[DATA] as $key => $val){
		$get_app_alu[DATA][$key][lastupdate] = dgmdate($val['lastupdate'], 'Y-m-d');
	}	
	include template($pluginid_alu.':alumore');

?>
