<?php



if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!submitcheck('submit')) {

	showformheader('plugins&operation=config&identifier=yiyuan&pmod=cate');
	showtableheader();
		echo '<tr><th class="td25"></th><th><strong>'.$lang['display_order'].'</stong></th><th style="width:350px"><strong>'.lang('plugin/yiyuan', '��������').'</strong></th><th></th></tr>';

		$perlist = $relist = array();
		$list = $selectlist = '';
		$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_cate')." ORDER BY display ASC");
		while($result = DB::fetch($query)) {
			if(empty($result['acid'])) {
				$perlist[$result['cid']] = $result;
				$selectlist .= "<option value=\"$result[cid]\">$result[title]</option>";
			} else {
				$relist[$result['acid']][] = $result;
			}
		}

		foreach($perlist as $parent) {
			$disabled = !empty($relist[$parent['cid']]) ? 'disabled' : '';
			showtablerow('', array('', 'class="td23 td28"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$parent[cid]\" $disabled>",
				"<input type=\"text\" class=\"txt\" size=\"3\" name=\"display[$parent[cid]]\" value=\"$parent[display]\">",
				"<div class=\"parentnode\"><input type=\"text\" class=\"txt\" size=\"30\" name=\"title[$parent[cid]]\" value=\"".dhtmlspecialchars($parent['title'])."\"></div>"
			));
			if(!empty($relist[$parent['cid']])) {
				foreach($relist[$parent['cid']] as $sub) {
					showtablerow('', array('', 'class="td23 td28"'), array(
						"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$sub[cid]\">",
						"<input type=\"text\" class=\"txt\" size=\"3\" name=\"display[$sub[cid]]\" value=\"$sub[display]\">",
						"<div class=\"node\"><input type=\"text\" class=\"txt\" size=\"30\" name=\"title[$sub[cid]]\" value=\"".dhtmlspecialchars($sub['title'])."\"></div>"
					));
				}
			}
			echo '<tr><td></td><td></td><td colspan="2"><div class="lastnode"><a href="###" onclick="addrow(this, 1, '.$parent['cid'].')" class="addtr">'.lang('plugin/yiyuan', '���Ӷ�������').'</a></div></td></tr>';
		}
		echo '<tr><td></td><td></td><td colspan="2"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">'.lang('plugin/yiyuan', '����һ������').'</a></div></td></tr>';

		echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
	[[1,''], [1,'<input name="newdisplay[]" value="" size="3" type="text" class="txt">', 'td25'], [1, '<input name="newtitle[]" value="" size="30" type="text" class="txt">'], [1, '<input type="hidden" name="newacid[]" value="0" />']],
	[[1,''], [1,'<input name="newdisplay[]" value="" size="3" type="text" class="txt">', 'td25'], [1, '<div class=\"node\"><input name="newtitle[]" value="" size="30" type="text" class="txt"></div>'], [1, '<input type="hidden" name="newacid[]" value="{1}" />']]
];
</script>
EOT;

		showsubmit('submit', 'submit', 'del');
		showtablefooter();
		showformfooter();

} else {

		if($cids = dimplode($_GET['delete'])) {
			DB::query("DELETE FROM	".DB::table('alu_yiyuan_cate')." WHERE cid IN ($cids)");
		}

		if(is_array($_GET['title'])) {
			foreach($_GET['title'] as $cid => $val) {
				DB::update('alu_yiyuan_cate', array(
					'display' => $_GET['display'][$cid],
					'title' => $_GET['title'][$cid],
				), array('cid' => $cid));
			}
		}

		if(is_array($_GET['newtitle'])) {
			foreach($_GET['newtitle'] as $k => $v) {
				$v = trim($v);
				if($v) {
					DB::insert('alu_yiyuan_cate', array('acid' => intval($_GET['newacid'][$k]), 'display' => intval($_GET['newdisplay'][$k]), 'title' => $v));
				}
			}
		}

		cpmsg(lang('plugin/yiyuan','�����б����³ɹ�'), 'action=plugins&operation=config&identifier=yiyuan&pmod=cate', 'succeed');

}

?>