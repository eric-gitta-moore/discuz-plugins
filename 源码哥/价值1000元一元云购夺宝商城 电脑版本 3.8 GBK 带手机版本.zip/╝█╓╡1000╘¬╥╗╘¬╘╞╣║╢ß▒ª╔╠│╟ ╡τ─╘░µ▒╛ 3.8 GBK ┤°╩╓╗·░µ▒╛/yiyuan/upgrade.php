<?php

// +----------------------------------------------------------------------
// | www.tmd9.com
// +----------------------------------------------------------------------

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = '';

$query = DB::query("SHOW COLUMNS FROM ".DB::table('alu_yiyuan'));
while($row = DB::fetch($query)) {
	if($row['Field'] == 'caid') {
		$caid = true;
		continue;
	}
	if($row['Field'] == 'manual') {
		$manual = true;
		continue;
	}
}

$sql .= !$caid ? "ALTER TABLE ".DB::table('alu_yiyuan')." ADD caid MEDIUMINT(8) NOT NULL DEFAULT '0' AFTER aid;\n" : '';
$sql .= !$manual ? "ALTER TABLE ".DB::table('alu_yiyuan')." ADD manual TINYINT(1) NOT NULL DEFAULT '0' AFTER display;\n" : '';

if($sql) {
	runquery($sql);
}
$finish = true;

?>