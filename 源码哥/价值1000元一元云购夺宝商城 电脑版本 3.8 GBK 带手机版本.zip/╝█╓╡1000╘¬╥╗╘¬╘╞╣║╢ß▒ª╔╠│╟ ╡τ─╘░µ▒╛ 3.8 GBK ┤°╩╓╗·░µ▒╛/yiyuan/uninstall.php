<?php



if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_alu_yiyuan;
DROP TABLE IF EXISTS pre_alu_yiyuan_album;
DROP TABLE IF EXISTS pre_alu_yiyuan_cate;
DROP TABLE IF EXISTS pre_alu_yiyuan_comment;
DROP TABLE IF EXISTS pre_alu_yiyuan_duobao;

EOF;
runquery($sql);
$finish = TRUE;

?>