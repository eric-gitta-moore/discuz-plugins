<?php





if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$_G['disabledwidthauto'] = 1;
$aid = intval($_GET['aid']);
$cid = intval($_GET['cid']);
$acid = intval($_GET['acid']);
$admingroups = unserialize($_G['cache']['plugin']['yiyuan']['admingroups']);
$yiyuangroups = unserialize($_G['cache']['plugin']['yiyuan']['yiyuangroups']);
$yiyuancredit = $_G['cache']['plugin']['yiyuan']['yiyuancredit'];
$creditname = $_G['setting']['extcredits'][$yiyuancredit]['title'];
require_once DISCUZ_ROOT.'./source/plugin/yiyuan/function_yiyuan.php';
$aluslidelist = displayarray($_G['cache']['plugin']['yiyuan']['aluslide']);
$CFG['rewrite'] = $_G['cache']['plugin']['yiyuan']['rewrite'] ? $_G['cache']['plugin']['yiyuan']['rewrite'] : 0;
$index = $CFG['rewrite'] ? 'yiyuan.html' : 'plugin.php?id=yiyuan';
$urllist = $CFG['rewrite'] ? 'yiyuan/list-0-0-0-0.html' : 'plugin.php?id=yiyuan&ac=list';
$lottery = $CFG['rewrite'] ? 'yiyuan/lottery.html' : 'plugin.php?id=yiyuan&ac=lottery';
$shaidan = $CFG['rewrite'] ? 'yiyuan/shaidan.html' : 'plugin.php?id=yiyuan&ac=shaidan';
$help = $CFG['rewrite'] ? 'yiyuan/help.html' : 'plugin.php?id=yiyuan&ac=help';
$help1 = $CFG['rewrite'] ? 'yiyuan/help/1.html' : 'plugin.php?id=yiyuan&ac=help&cid=1';
$help2 = $CFG['rewrite'] ? 'yiyuan/help/2.html' : 'plugin.php?id=yiyuan&ac=help&cid=2';
$help3 = $CFG['rewrite'] ? 'yiyuan/help/3.html' : 'plugin.php?id=yiyuan&ac=help&cid=3';
$help4 = $CFG['rewrite'] ? 'yiyuan/help/4.html' : 'plugin.php?id=yiyuan&ac=help&cid=4';
$help5 = $CFG['rewrite'] ? 'yiyuan/help/5.html' : 'plugin.php?id=yiyuan&ac=help&cid=5';
$help6 = $CFG['rewrite'] ? 'yiyuan/help/6.html' : 'plugin.php?id=yiyuan&ac=help&cid=6';
$help7 = $CFG['rewrite'] ? 'yiyuan/help/7.html' : 'plugin.php?id=yiyuan&ac=help&cid=7';
$help8 = $CFG['rewrite'] ? 'yiyuan/help/8.html' : 'plugin.php?id=yiyuan&ac=help&cid=8';
$help9 = $CFG['rewrite'] ? 'yiyuan/help/9.html' : 'plugin.php?id=yiyuan&ac=help&cid=9';
$help10 = $CFG['rewrite'] ? 'yiyuan/help/10.html' : 'plugin.php?id=yiyuan&ac=help&cid=10';
$userbuylist = $CFG['rewrite'] ? 'yiyuan/userbuylist.html' : 'plugin.php?id=yiyuan&ac=userbuylist';

if(empty($_GET['ac'])) {

	$cidlist = $parent = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_cate')." ORDER BY display ASC");
	while($result = DB::fetch($query)) {
		if(empty($result['acid'])) {
			$cidlist[$result['cid']] = $result;
		} else {
			$parent[$result['acid']][] = $result;
		}
	}

	$todaytime = strtotime(dgmdate(TIMESTAMP, 'Ymd'));
	$startlist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan')." WHERE status='1' AND display='1' ORDER BY number DESC LIMIT 0, 8");
	while($result = DB::fetch($query)) {
		$result['dateline'] = dgmdate($result['dateline'], 'u');
		$result['title'] = cutstr($result['title'], 30);
		$result['url'] = $CFG['rewrite'] ? 'yiyuan/duobao-'.$result[aid].'.html' : 'plugin.php?id=yiyuan&ac=view&aid='.$result[aid];
		$result['pic'] = $result['img_1'] ? $_G['setting']['attachurl'].'category/'.getimgthumbname($result['img_1']) : 'source/plugin/yiyuan/images/nopic.gif';
		$startlist[] = $result;
	}

	$astartlist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan')." WHERE status='1' AND display='2' ORDER BY dateline DESC LIMIT 0, 8");
	while($result = DB::fetch($query)) {
		$result['dateline'] = dgmdate($result['dateline'], 'u');
		$result['title'] = cutstr($result['title'], 30);
		$result['url'] = $CFG['rewrite'] ? 'yiyuan/duobao-'.$result[aid].'.html' : 'plugin.php?id=yiyuan&ac=view&aid='.$result[aid];
		$result['pic'] = $result['img_1'] ? $_G['setting']['attachurl'].'category/'.getimgthumbname($result['img_1']) : 'source/plugin/yiyuan/images/nopic.gif';
		$astartlist[] = $result;
	}

	$navtitle = str_replace('{bbname}', $_G['setting']['bbname'], $_G['cache']['plugin']['yiyuan']['title']);
	$metakeywords = $_G['cache']['plugin']['yiyuan']['keywords'];
	$metadescription = cutstr($_G['cache']['plugin']['yiyuan']['description'], 190);

} elseif($_GET['ac'] == 'list') {

	$cidlist = $parent = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_cate')." ORDER BY display ASC");
	while($result = DB::fetch($query)) {
		if(empty($result['acid'])) {
			$cidlist[$result['cid']] = $result;
		} else {
			$parent[$result['acid']][] = $result;
		}
	}

	if($cid) {
		$cidinfo = get_cate_info($cid);
	}
	if($acid) {
		$acidinfo = get_cate_info($acid);
	}
	if($_GET['cid']) {
		$wheres[] = 'cid='.intval($_GET['cid']);
	}
	if($_GET['acid']) {
		$wheres[] = 'acid='.intval($_GET['acid']);
	}
	if($_GET['title']) {
		$wheres[] = "title LIKE '%".stripsearchkey(addslashes($_GET['title']))."%'";
	}

	$sort = intval($_GET['sort']) ? intval($_GET['sort']) : 0;

	if(empty($_GET['sort'])) {
		$where .= ' ORDER BY number DESC';
	} elseif($_GET['sort'] == 1) {
		$where .= ' ORDER BY dateline DESC';
	} elseif($_GET['sort'] == 2) {
		$where .= ' ORDER BY number DESC';
	} elseif($_GET['sort'] == 3) {
		$where .= ' ORDER BY price ASC';
	} elseif($_GET['sort'] == 4) {
		$where .= ' ORDER BY residue DESC';
	}
	$wheres[] = "status='1'";
	$wheresql = $wheres ? implode(' AND ', $wheres) : '1';
	$perpage = 12;
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$start = ($page - 1) * $perpage;
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan')." WHERE $wheresql ");
	if(empty($CFG['rewrite'])) {
		$multi = multi($count, $perpage, $page, 'plugin.php?id=yiyuan&ac=list&cid='.intval($_GET['cid']).'&acid='.intval($_GET['acid']).'&sort='.intval($_GET['sort']).'&title='.stripsearchkey(addslashes($_GET['title'])));
	} else {
		$multi = multi($count, $perpage, $page, "yiyuan/list-$cid-$acid-$sort-$page.html");
		$multi = preg_replace("/-[0-9]*(\.html)\?page=([0-9]*)/i", "-\$2\$1", $multi);
	}
	if($count) {
	$list = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan')." WHERE {$wheresql}{$where} LIMIT $start, $perpage");
	while($result = DB::fetch($query)) {
			$result['dateline'] = dgmdate($result['dateline'], 'u');
			$result['title'] = cutstr($result['title'], 25);
			$result['url'] = $CFG['rewrite'] ? 'yiyuan/duobao-'.$result[aid].'.html' : 'plugin.php?id=yiyuan&ac=view&aid='.$result[aid];
			$result['pic'] = $result['img_1'] ? $_G['setting']['attachurl'].'category/'.getimgthumbname($result['img_1']) : 'source/plugin/yiyuan/images/nopic.gif';
			$list[] = $result;
		}
	}
	$navtitle = '������Ʒ';

} elseif($_GET['ac'] == 'lottery') {

	$cidlist = $parent = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_cate')." ORDER BY display ASC");
	while($result = DB::fetch($query)) {
		if(empty($result['acid'])) {
			$cidlist[$result['cid']] = $result;
		} else {
			$parent[$result['acid']][] = $result;
		}
	}

	if($cid) {
		$cidinfo = get_cate_info($cid);
	}
	if($acid) {
		$acidinfo = get_cate_info($acid);
	}
	if($_GET['cid']) {
		$wheres[] = 'cid='.intval($_GET['cid']);
	}
	if($_GET['acid']) {
		$wheres[] = 'acid='.intval($_GET['acid']);
	}

	$wheres[] = "status='2'";
	$wheresql = $wheres ? implode(' AND ', $wheres) : '1';
	$perpage = 12;
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$start = ($page - 1) * $perpage;
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan')." WHERE $wheresql ");
	$multi = multi($count, $perpage, $page, 'plugin.php?id=yiyuan&ac=lottery&cid='.intval($_GET['cid']).'&acid='.intval($_GET['acid']).'&sort='.intval($_GET['sort']));
	if($count) {
	$list = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan')." WHERE {$wheresql} ORDER BY lastdate DESC LIMIT $start, $perpage");
	while($result = DB::fetch($query)) {
			$duobaoinfo = unserialize($result['duobaocodes']);
			$result['dateline'] = dgmdate($result['dateline'], 'u');
			$result['lastuser'] = $duobaoinfo['lastuser'];
			$result['title'] = cutstr($result['title'], 25);
			$result['url'] = $CFG['rewrite'] ? 'yiyuan/duobao-'.$result[aid].'.html' : 'plugin.php?id=yiyuan&ac=view&aid='.$result[aid];
			$result['pic'] = $result['img_1'] ? $_G['setting']['attachurl'].'category/'.getimgthumbname($result['img_1']) : 'source/plugin/yiyuan/images/nopic.gif';
			$list[] = $result;
		}
	}

	$navtitle = '������Ʒ';

} elseif($_GET['ac'] == 'shaidan') {

	if(empty($_GET['cid'])) {

	$perpage = 10;
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$start = ($page - 1) * $perpage;
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan_album')." ");
	$multi = multi($count, $perpage, $page, 'plugin.php?id=yiyuan&ac=shaidan');
	if($count) {
	$shaidanlist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_album')." ORDER BY dateline DESC LIMIT $start, $perpage");
	while($result = DB::fetch($query)) {
			$result['dateline'] = dgmdate($result['dateline'], 'Y-m-d H:i');
			$result['url'] = $CFG['rewrite'] ? 'yiyuan/duobao-album-'.$result[aid].'.html' : 'plugin.php?id=yiyuan&ac=view&at=album&aid='.$result[aid];
			$result['pic'] = $result['img_1'] ? $_G['setting']['attachurl'].'category/'.getimgthumbname($result['img_1']) : 'source/plugin/yiyuan/images/nopic.gif';
			$aids[] = $result['aid'];
			$result['summary'] = cutstr($result['summary'], 250);
			$shaidanlist[] = $result;
		}
	}
	if($aids) {
		if ($yiyuan = get_yiyuan_aids($aids)) {
			foreach($shaidanlist as $key => $val) {
				$shaidanlist[$key]['yiyuan'] = $yiyuan[$val['aid']];
			}
		}
	}

	} else {

	}

	$navtitle = 'ɹ������';

} elseif($_GET['ac'] == 'view') {

	if(empty($aid)) {
		showmessage('��Ϣ�����ڣ�', 'plugin.php?id=yiyuan', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	$aluinfo = get_yiyuan_info($aid);
	if(empty($aluinfo['aid'])) {
		showmessage('��Ϣ�����ڣ�', 'plugin.php?id=yiyuan');
	}
	if($aluinfo['uid'] != $_G['uid'] && $aluinfo['status'] == 0 && !in_array($_G['groupid'], $admingroups)) {
		showmessage('��Ϣ��û����ˣ�', 'plugin.php?id=yiyuan');
	}
	$aluinfo['pic'] = $aluinfo['img_1'] ? $_G['setting']['attachurl'].'category/'.getimgthumbname($aluinfo['img_1']) : 'source/plugin/yiyuan/images/nopic.gif';

	require_once libfile('function/discuzcode');
	$aluinfo['summary'] = discuzcode($aluinfo['summary']);
	$duobaoinfo = unserialize($aluinfo['duobaocodes']);

	if($aluinfo['caid']) {
		$caidlist = array();
		$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan')." WHERE caid='$aluinfo[caid]' ORDER BY dateline ASC LIMIT 0, 500");
		while($result = DB::fetch($query)) {
			$result['url'] = $CFG['rewrite'] ? 'yiyuan/duobao-'.$result[aid].'.html' : 'plugin.php?id=yiyuan&ac=view&aid='.$result[aid];
			$caidlist[] = $result;
		}
	}

	if(empty($_GET['at'])) {

	} elseif($_GET['at'] == 'duobao') {

	$perpage = 20;
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$start = ($page - 1) * $perpage;
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aluinfo[aid]' AND uid>0");
	$multi = multi($count, $perpage, $page, 'plugin.php?id=yiyuan&ac=view&at=duobao&aid='.$aid);
	if($count) {
	include libfile('function/misc');
	$duobaolist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aluinfo[aid]' AND uid>0 ORDER BY dateline DESC LIMIT $start, $perpage");
	while($result = DB::fetch($query)) {
		$result['iparea'] = trim(convertip($result['ip']),'-');
		$redateline = dgmdate($result['dateline'], 'Y-m');
		$result['duobao_count'] = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aluinfo[aid]' AND uid='$result[uid]' AND uid>0");
		$result['dateline'] = dgmdate($result['dateline'], 'm-d H:i:s');
			$duobaolist[] = $result;
		}
	}

	} elseif($_GET['at'] == 'album') {

	$albumlist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_album')." WHERE aid='$aluinfo[aid]' ORDER BY dateline DESC LIMIT 0, 10");
	while($result = DB::fetch($query)) {
		$result['dateline'] = dgmdate($result['dateline'], 'Y-m-d H:i:s');
		$albumlist[] = $result;
	}

	} elseif($_GET['at'] == 'comment') {

	$perpage = 15;
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$start = ($page - 1) * $perpage;
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan_comment')." WHERE aid='$aluinfo[aid]' AND status<'1'");
	$multi = multi($count, $perpage, $page, 'plugin.php?id=yiyuan&ac=view&at=comment&aid='.$aluinfo['aid']);
	if($count) {
	$commentlist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_comment')." WHERE aid='$aluinfo[aid]' AND status<'1' ORDER BY dateline DESC LIMIT $start, $perpage");
	while($result = DB::fetch($query)) {
			$result['dateline'] = dgmdate($result['dateline'], 'u');
			$result['comment'] = discuzcode($result['comment']);
			$commentlist[] = $result;
		}
	}

	}

	if($aluinfo['status'] == 1 && $aluinfo['number'] == $aluinfo['price']) {
		if($aluinfo['manual'] == 1) {
			$duobao_user = get_duobao_user($aid);
		}
	}

	if($aluinfo['status'] == 2) {
		$duobaodata = get_duobao_by_aid($aid, $duobaoinfo['lastuid']);
		$duobaodata = preg_replace("/(?<=[\s\"\]>()]|[\x7f-\xff]|^)(".preg_quote($aluinfo[orderid], '/').")(([.,:;-?!()\s\"<\[]|[\x7f-\xff]|$))/siU", "<b><font color=\"#FF0000\">\\1</font></b>\\2", $duobaodata);
	} else {
		$duobaocount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aluinfo[aid]' AND uid='$_G[uid]' AND uid>0");
		$duobaodata = get_duobao_by_aid($aid, $_G['uid']);
	}

	DB::update('alu_yiyuan', array('views' => $aluinfo['views']+1, 'residue' => round($aluinfo['price'] - $aluinfo['number'], 0)), array('aid' => $aid));
	$navtitle = str_replace('{bbname}', $_G['setting']['bbname'], $aluinfo['title'] .' - '. $_G['cache']['plugin']['yiyuan']['title']);
	$metakeywords = $aluinfo['title'] .','. $_G['cache']['plugin']['yiyuan']['keywords'];
	$metadescription = cutstr($aluinfo[summary], 190);

} elseif($_GET['ac'] == 'duobao') {

	if(empty($_G['uid'])) {
		showmessage('���¼��ע���Ա�������', null, array(), array('showmsg' => true, 'login' => 1));
	}
	if(empty($aid)) {
		showmessage('û��ѡ����Ʒ��', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	$yiyuan = get_yiyuan_info($aid);
	if($yiyuan['status'] == 2) {
		showmessage('�ᱦ�����ˣ��н����Ѿ�������', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if($yiyuan['number'] == $yiyuan['price']) {
		showmessage('��ܰ��ʾ {price} �˴��Ѿ����ˣ���׼��������', '', array('price' => $yiyuan['price']), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if($_GET['applynum'] > ($yiyuan['price'] - $yiyuan['number'])) {
		showmessage('��ܰ��ʾ: ����������������� {price} �˴Σ�', '', array('price' => ($yiyuan['price'] - $yiyuan['number'])), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	$usercredit = getuserprofile('extcredits'.$yiyuancredit);
	if(submitcheck('formhash')) {
		if(!is_numeric($_GET['applynum'])) {
			showmessage('��д������������ȷ�Ķᱦ������', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
		}
		$extcreditsnum = round($_GET['applynum'] * $_G['cache']['plugin']['yiyuan']['duobaonum'], 0);
		if($usercredit < $extcreditsnum) {
			showmessage('����{title}���� {num}�����ֵ{title}������ᱦ��', '', array('num' => $extcreditsnum, 'title' => $_G['setting']['extcredits'][$yiyuancredit]['title']), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
		}
		if($_GET['mobile'] && $_G['cache']['plugin']['yiyuan']['remobile']) {
			DB::update('common_member_profile', array('mobile' => addslashes($_GET['mobile'])), array('uid' => intval($_G['uid'])));
		}
		$duobao = get_yiyuan_duobao($_GET['aid'], $_GET['applynum']);
		updatemembercount($_G['uid'], array($yiyuancredit => -$extcreditsnum));
		showmessage('�ᱦ�ɹ����ȴ�������', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
	}

} elseif($_GET['ac'] == 'aluinfo') {

	if(empty($_G['uid'])) {
		showmessage('���¼��ע���Ա�������', null, array(), array('showmsg' => true, 'login' => 1));
	}
	if(!in_array($_G['groupid'], $admingroups)) {
		showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	$catelist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_cate')." WHERE acid='0' ORDER BY display ASC");
	while($result = DB::fetch($query)) {
		$catelist[] = $result;
	}

	$aluinfo = get_yiyuan_info($aid);
	$data['caid'] = intval($_GET['caid']);
	$data['cid'] = intval($_GET['cid']);
	$data['acid'] = intval($_GET['acid']);
	$data['title'] = addslashes($_GET['title']);
	$data['summary'] = addslashes($_GET['summary']);
	$data['yiyuanprice'] = intval(1);
	//$data['startdate'] = strtotime($_GET['startdate']);
	//$data['endsdate'] = strtotime($_GET['endsdate']);
	$data['original'] = addslashes($_GET['original']);
	if($_G['uid'] == 1) $data['codes'] = intval($_GET['codes']);
	$data['manual'] = intval($_GET['manual']);
	$data['display'] = intval($_GET['display']);

	if($aid) {
	if(submitcheck('formhash')) {

		if($_GET['delimg_1']) {
			$img_1 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_1']);
		} else {
			if($_FILES['img_1']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_1']);
				$img_1 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_1'], 'icon', 600, 600);
				$thumb = thumbpath($img_1, 300, 300);
			} else {
				$img_1 = $aluinfo['img_1'];
			}
		}
		if($_GET['delimg_2']) {
			$img_2 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_2']);
		} else {
			if($_FILES['img_2']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_2']);
				$img_2 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_2'], 'icon', 600, 600);
			} else {
				$img_2 = $aluinfo['img_2'];
			}
		}
		if($_GET['delimg_3']) {
			$img_3 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_3']);
		} else {
			if($_FILES['img_3']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_3']);
				$img_3 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_3'], 'icon', 600, 600);
			} else {
				$img_3 = $aluinfo['img_3'];
			}
		}
		if($_GET['delimg_4']) {
			$img_4 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_4']);
		} else {
			if($_FILES['img_4']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_4']);
				$img_4 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_4'], 'icon', 600, 600);
			} else {
				$img_4 = $aluinfo['img_4'];
			}
		}
		if($_GET['delimg_5']) {
			$img_5 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_5']);
		} else {
			if($_FILES['img_5']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_5']);
				$img_5 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6)), $_FILES['img_5'], 'icon');
			} else {
				$img_5 = $aluinfo['img_5'];
			}
		}
		if($_GET['delimg_6']) {
			$img_6 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_6']);
		} else {
			if($_FILES['img_6']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_6']);
				$img_6 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6)), $_FILES['img_6'], 'icon');
				$thumb = thumbpath($img_6, 150, 150);
			} else {
				$img_6 = $aluinfo['img_6'];
			}
		}

		$data['img_1'] = addslashes($img_1);
		$data['img_2'] = addslashes($img_2);
		$data['img_3'] = addslashes($img_3);
		$data['img_4'] = addslashes($img_4);
		$data['img_5'] = addslashes($img_5);
		$data['img_6'] = addslashes($img_6);

		if($aluinfo['uid'] != $_G['uid'] && !in_array($_G['groupid'], $admingroups)) {
			showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
		}
		if(empty($_GET['delete'])) {
			DB::update('alu_yiyuan', $data, array('aid' => intval($_GET['aid'])));
			showmessage('���³ɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
		} else {
			DB::query("DELETE FROM ".DB::table('alu_yiyuan')." WHERE aid='$aid'");
			showmessage('ɾ���ɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
		}
	}
	} else {

	if(submitcheck('formhash')) {

		if($_GET['delimg_1']) {
			$img_1 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_1']);
		} else {
			if($_FILES['img_1']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_1']);
				$img_1 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_1'], 'icon', 600, 600);
				$thumb = thumbpath($img_1, 300, 300);
			} else {
				$img_1 = $aluinfo['img_1'];
			}
		}
		if($_GET['delimg_2']) {
			$img_2 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_2']);
		} else {
			if($_FILES['img_2']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_2']);
				$img_2 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_2'], 'icon', 600, 600);
			} else {
				$img_2 = $aluinfo['img_2'];
			}
		}
		if($_GET['delimg_3']) {
			$img_3 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_3']);
		} else {
			if($_FILES['img_3']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_3']);
				$img_3 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_3'], 'icon', 600, 600);
			} else {
				$img_3 = $aluinfo['img_3'];
			}
		}
		if($_GET['delimg_4']) {
			$img_4 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_4']);
		} else {
			if($_FILES['img_4']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_4']);
				$img_4 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_4'], 'icon', 600, 600);
			} else {
				$img_4 = $aluinfo['img_4'];
			}
		}
		if($_GET['delimg_5']) {
			$img_5 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_5']);
		} else {
			if($_FILES['img_5']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_5']);
				$img_5 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6)), $_FILES['img_5'], 'icon');
			} else {
				$img_5 = $aluinfo['img_5'];
			}
		}
		if($_GET['delimg_6']) {
			$img_6 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_6']);
		} else {
			if($_FILES['img_6']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_6']);
				$img_6 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6)), $_FILES['img_6'], 'icon');
				$thumb = thumbpath($img_6, 150, 150);
			} else {
				$img_6 = $aluinfo['img_6'];
			}
		}

		$data['img_1'] = addslashes($img_1);
		$data['img_2'] = addslashes($img_2);
		$data['img_3'] = addslashes($img_3);
		$data['img_4'] = addslashes($img_4);
		$data['img_5'] = addslashes($img_5);
		$data['img_6'] = addslashes($img_6);
		$data['price'] = addslashes($_GET['price']);
		$data['uid'] = intval($_G['uid']);
		$data['dateline'] = addslashes($_G['timestamp']);
		DB::insert('alu_yiyuan', $data, 1);
		$taid = DB::insert_id();
		content_get_go_codes($data['price'], $taid);
		showmessage('���ӳɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
	}

	}

} elseif($_GET['ac'] == 'userbuylist') {

	if(empty($_G['uid'])) {
		showmessage('���¼��ע���Ա�������', null, array(), array('showmsg' => true, 'login' => 1));
	}

	$uid = intval($_GET['uid']) ? intval($_GET['uid']) : $_G['uid'];

	if(empty($_GET['at'])) {

	$perpage = 10;
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$start = ($page - 1) * $perpage;
	$count = DB::result_first("SELECT COUNT(DISTINCT aid) FROM ".DB::table('alu_yiyuan_duobao')." WHERE uid='$uid'");
	$multi = multi($count, $perpage, $page, 'plugin.php?id=yiyuan&ac=userbuylist&at='.$_GET['at'].'&uid='.$uid);
	if($count) {
	$duobaolist = array();
	$query = DB::query("SELECT COUNT(*) AS number, cid, aid, username, ip, dateline FROM ".DB::table('alu_yiyuan_duobao')." WHERE uid='$uid' GROUP BY aid ORDER BY dateline DESC LIMIT $start, $perpage");
	while($result = DB::fetch($query)) {
		$result['dateline'] = dgmdate($result['dateline'], 'Y-m-d H:i:s');
			$aids[] = $result['aid'];
			$result['cidinfo'] = get_duobao_by_aid($result['aid'], $uid);
			$duobaolist[] = $result;
		}
	}
	if($aids) {
		if ($yiyuan = get_yiyuan_aids($aids)) {
			foreach($duobaolist as $key => $val) {
				$duobaolist[$key]['yiyuan'] = $yiyuan[$val['aid']];
			}
		}
	}

	} elseif($_GET['at'] == 'duobao') {

	$perpage = 10;
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$start = ($page - 1) * $perpage;
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan_duobao')." WHERE uid='$uid' AND status='1'");
	$multi = multi($count, $perpage, $page, 'plugin.php?id=yiyuan&ac=userbuylist&at='.$_GET['at'].'&uid='.$uid);
	if($count) {
	$duobaolist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_duobao')." WHERE uid='$uid' AND status='1' ORDER BY dateline DESC LIMIT $start, $perpage");
	while($result = DB::fetch($query)) {
		$result['dateline'] = dgmdate($result['dateline'], 'Y-m-d H:i:s');
			$aids[] = $result['aid'];
			$duobaolist[] = $result;
		}
	}
	if($aids) {
		if ($yiyuan = get_yiyuan_aids($aids)) {
			foreach($duobaolist as $key => $val) {
				$duobaolist[$key]['yiyuan'] = $yiyuan[$val['aid']];
			}
		}
	}

	} elseif($_GET['at'] == 'album') {

	$perpage = 10;
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$start = ($page - 1) * $perpage;
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan_album')." WHERE uid='$uid'");
	$multi = multi($count, $perpage, $page, 'plugin.php?id=yiyuan&ac=userbuylist&at=album&uid='.$uid);
	if($count) {
	$albumlist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_album')." WHERE uid='$uid' ORDER BY dateline DESC LIMIT $start, $perpage");
	while($result = DB::fetch($query)) {
		$result['dateline'] = dgmdate($result['dateline'], 'Y-m-d H:i:s');
			$aids[] = $result['aid'];
			$albumlist[] = $result;
		}
	}
	if($aids) {
		if ($yiyuan = get_yiyuan_aids($aids)) {
			foreach($albumlist as $key => $val) {
				$albumlist[$key]['yiyuan'] = $yiyuan[$val['aid']];
			}
		}
	}

	} elseif($_GET['at'] == 'address') {

		$alufile = DB::fetch_first("SELECT * FROM ".DB::table('common_member_profile')." WHERE uid='$uid' LIMIT 0, 1");
		if(submitcheck('formhash')) {

			DB::update('common_member_profile', array(
				'realname' => addslashes($_GET['realname']),
				'mobile' => addslashes($_GET['mobile']),
				'address' => addslashes($_GET['address']),
				'qq' => addslashes($_GET['qq'])
			), array('uid' => $uid));
			showmessage('��ϵ��ַ���³ɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
		}

	}

	$navtitle = '�ҵ�һԪ��';

} elseif($_GET['ac'] == 'album') {

	if(empty($_G['uid'])) {
		showmessage('���¼��ע���Ա�������', null, array(), array('showmsg' => true, 'login' => 1));
	}

	$aluinfo = DB::fetch_first("SELECT * FROM ".DB::table('alu_yiyuan_album')." WHERE cid='$cid' LIMIT 0, 1");

	$data['summary'] = addslashes($_GET['summary']);

	if($cid) {
	if(submitcheck('formhash')) {

		if($_GET['delimg_1']) {
			$img_1 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_1']);
		} else {
			if($_FILES['img_1']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_1']);
				$img_1 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_1'], 'icon', 600, 600);
				$thumb = thumbpath($img_1, 300, 300);
			} else {
				$img_1 = $aluinfo['img_1'];
			}
		}
		if($_GET['delimg_2']) {
			$img_2 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_2']);
		} else {
			if($_FILES['img_2']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_2']);
				$img_2 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_2'], 'icon', 600, 600);
			} else {
				$img_2 = $aluinfo['img_2'];
			}
		}
		if($_GET['delimg_3']) {
			$img_3 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_3']);
		} else {
			if($_FILES['img_3']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_3']);
				$img_3 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_3'], 'icon', 600, 600);
			} else {
				$img_3 = $aluinfo['img_3'];
			}
		}

		$data['img_1'] = addslashes($img_1);
		$data['img_2'] = addslashes($img_2);
		$data['img_3'] = addslashes($img_3);

		if($aluinfo['uid'] != $_G['uid'] && !in_array($_G['groupid'], $admingroups)) {
			showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
		}
		if(empty($_GET['delete'])) {
			DB::update('alu_yiyuan_album', $data, array('cid' => intval($_GET['cid'])));
			showmessage('ɹ�����³ɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
		} else {
			DB::query("DELETE FROM ".DB::table('alu_yiyuan_album')." WHERE cid='$cid'");
			showmessage('ɾ���ɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
		}
	}
	} else {

	$duobaolist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_duobao')." WHERE uid='$_G[uid]' AND status='1' AND hide='0' ORDER BY dateline DESC LIMIT 0, 20");
	while($result = DB::fetch($query)) {
		$result['dateline'] = dgmdate($result['dateline'], 'Y-m-d H:i:s');
			$aids[] = $result['aid'];
			$duobaolist[] = $result;
	}
	if($aids) {
		if ($yiyuan = get_yiyuan_aids($aids)) {
			foreach($duobaolist as $key => $val) {
				$duobaolist[$key]['yiyuan'] = $yiyuan[$val['aid']];
			}
		}
	}

	if(empty($aids)) {
		showmessage('��û���н���¼����ɹ�����Ͻ�ȥ�ᱦ�ɣ�', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}

	if(submitcheck('formhash')) {

		if($_GET['delimg_1']) {
			$img_1 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_1']);
		} else {
			if($_FILES['img_1']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_1']);
				$img_1 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_1'], 'icon', 600, 600);
				$thumb = thumbpath($img_1, 300, 300);
			} else {
				$img_1 = $aluinfo['img_1'];
			}
		}
		if($_GET['delimg_2']) {
			$img_2 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_2']);
		} else {
			if($_FILES['img_2']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_2']);
				$img_2 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_2'], 'icon', 600, 600);
			} else {
				$img_2 = $aluinfo['img_2'];
			}
		}
		if($_GET['delimg_3']) {
			$img_3 = '';
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_3']);
		} else {
			if($_FILES['img_3']['name']) {
				@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_3']);
				$img_3 = upload_image($extid = array('extid' => dgmdate(TIMESTAMP, 'His').random(6), 'status' => 3), $_FILES['img_3'], 'icon', 600, 600);
			} else {
				$img_3 = $aluinfo['img_3'];
			}
		}

		$data['img_1'] = addslashes($img_1);
		$data['img_2'] = addslashes($img_2);
		$data['img_3'] = addslashes($img_3);
		$data['aid'] = intval($_GET['aid']);
		$data['uid'] = intval($_G['uid']);
		$data['username'] = addslashes($_G['username']);
		$data['dateline'] = addslashes($_G['timestamp']);
		DB::insert('alu_yiyuan_album', $data, 1);
		DB::update('alu_yiyuan_duobao', array('hide' => 2), array('cid' => DB::result_first("SELECT cid FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aid' AND status='1' AND hide='0'")));
		showmessage('ɹ�����ӳɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
	}

	}

} elseif($_GET['ac'] == 'admin') {

	if(!in_array($_G['groupid'], $admingroups)) {
		showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}

	$catelist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_cate')." WHERE acid='0' ORDER BY display ASC");
	while($result = DB::fetch($query)) {
		$catelist[] = $result;
	}
	if($cid) {
	$cidcate = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_cate')." WHERE acid='$cid' ORDER BY display ASC");
	while($rult = DB::fetch($query)) {
		$cidcate[] = $rult;
	}
	}
	if($_GET['lastdate']) {
		$order = 'ORDER BY lastdate DESC';
	} else {
		$order = 'ORDER BY dateline DESC';
	}
	if($_GET['cid']) {
		$wheres[] = 'cid='.intval($_GET['cid']);
	}
	if($_GET['acid']) {
		$wheres[] = 'acid='.intval($_GET['acid']);
	}
	if($_GET['title']) {
		$wheres[] = "title LIKE '%".stripsearchkey(addslashes($_GET['title']))."%'";
	}
	$wheresql = $wheres ? implode(' AND ', $wheres) : '1';
	$perpage = 20;
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$start = ($page - 1) * $perpage;
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan')." WHERE $wheresql ");
	$multi = multi($count, $perpage, $page, 'plugin.php?id=yiyuan&ac=admin&cid='.intval($_GET['cid']).'&acid='.intval($_GET['acid']).'&lastdate='.intval($_GET['lastdate']).'&title='.stripsearchkey(addslashes($_GET['title'])));
	if($count) {
	$list = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan')." WHERE $wheresql $order LIMIT $start, $perpage");
	while($result = DB::fetch($query)) {
			$result['dateline'] = dgmdate($result['dateline'], 'u');
			$result['lastdate'] = dgmdate($result['lastdate'], 'Y-m-d H:i:s');
			if($result['orderid']) {
				$result['member'] = get_member_profile_codes($result['aid'], $result['orderid']);
			}
			$list[] = $result;
		}
	}
	$navtitle = '��̨���ݹ���';

} elseif($_GET['ac'] == 'doval') {

	if(!in_array($_G['groupid'], $admingroups)) {
		showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	$aids = array();
	$aidarr = implode(',', $_GET['aids']);
	$status = intval($_GET['status']);
	if(empty($aidarr)) {
		showmessage('��û��ѡ��Ҫ��˵���Ϣ��', '', array(), array('showdialog' => 1));
	}
	if($_GET['status'] == '0') {
		DB::query("UPDATE ".DB::table('alu_yiyuan')." SET status='$status' WHERE aid IN($aidarr)");
	} elseif($_GET['status'] == '1' || $_GET['status'] == '2') {
		DB::query("UPDATE ".DB::table('alu_yiyuan')." SET status='$status' WHERE aid IN($aidarr)");
	} elseif($_GET['status'] == '3') {
		$aids = explode(',', $aidarr);
		foreach ($aids as $aid) {
			$aluinfo = get_yiyuan_info($aid);
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_1']);
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_2']);
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_3']);
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_4']);
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_5']);
			@unlink($_G['setting']['attachurl'].'category/'.$aluinfo['img_6']);
			@unlink($_G['setting']['attachurl'].'category/'.getimgthumbname($aluinfo['img_1']));
			$album = get_yiyuan_album($aid);
			@unlink($_G['setting']['attachurl'].'category/'.$album['img_1']);
			@unlink($_G['setting']['attachurl'].'category/'.$album['img_2']);
			@unlink($_G['setting']['attachurl'].'category/'.$album['img_3']);
			@unlink($_G['setting']['attachurl'].'category/'.getimgthumbname($album['img_1']));
		}
		DB::query("DELETE FROM ".DB::table('alu_yiyuan')." WHERE aid IN($aidarr)");
		DB::query("DELETE FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid IN($aidarr)");
		DB::query("DELETE FROM ".DB::table('alu_yiyuan_album')." WHERE aid IN($aidarr)");
	}
	showmessage('�����ɹ���ף���������ġ���죡', 'plugin.php?id=yiyuan&ac=admin&page='.intval($_GET['page']));

} elseif($_GET['ac'] == 'manual') {

	if(!in_array($_G['groupid'], $admingroups)) {
		showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if(empty($_GET['aid']) || !$aluinfo = get_yiyuan_info($aid)) {
		showmessage('��û��ѡ����������ݣ�', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if($aluinfo['status'] > 1) {
		showmessage('�Ѿ��������벻Ҫ�ظ�������', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if($aluinfo['number'] < $aluinfo['price']) {
		showmessage('��������δ�������ܿ�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if($aluinfo['manual'] == 1) {
		showmessage('�Ѿ������Զ������벻Ҫ�����ֶ�������', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if(submitcheck('formhash')) {
		if(!$codes = stripsearchkey(addslashes($_GET['codes']))) {
			showmessage('��������û����д��', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
		}
		if(!DB::result_first("SELECT codes FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aid' AND codes='$codes'")) {
			showmessage('�������벻���ڣ�����ϸ�˶��ٲ�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
		}
		DB::update('alu_yiyuan_duobao', array('status' => 1), array('aid' => intval($aid), 'codes' => $codes));
		$duobao_user = get_duobao_user($aid);
		showmessage('�ֹ������ɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
	}

} elseif($_GET['ac'] == 'notice') {

	if(!in_array($_G['groupid'], $admingroups)) {
		showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if(empty($_GET['cid'])) {
		showmessage('��û��ѡ����������ݣ�', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	$aluinfo = DB::fetch_first("SELECT * FROM ".DB::table('alu_yiyuan_duobao')." WHERE cid='$cid' LIMIT 0, 1");
	if(submitcheck('formhash')) {
		if(empty($_GET['notice'])) {
			showmessage('���ʧ�ܣ���˱�ע��Ϣû����д��', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
		}
		DB::update('alu_yiyuan_duobao', array('notice' => addslashes($_GET['notice']), 'hide' => 1), array('cid' => intval($_GET['cid'])));
		notification_add($aluinfo['uid'], 'system', '�����ʾ����һԪ�ᱦ����Ʒ��˷����У�{notice} <a href="plugin.php?id=yiyuan&ac=userbuylist&at=duobao" target="_blank" class="lit">�鿴�ᱦ��¼ &rsaquo;</a>', array('notice' => $_GET['notice']));
		showmessage('��˳ɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
	}

} elseif($_GET['ac'] == 'pm') {

	if(!in_array($_G['groupid'], $admingroups)) {
		showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if(!$uid = intval($_GET['uid'])) {
		showmessage('��û��ѡ�������û���', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if(submitcheck('formhash')) {
		if(empty($_GET['notice'])) {
			showmessage('������Ϣû����д��', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
		}
		notification_add($uid, 'system', '��ܰ��ʾ��{notice} <a href="plugin.php?id=yiyuan&ac=userbuylist&at=address" target="_blank" class="lit">�����ʼĵ�ַ &rsaquo;</a>', array('notice' => $_GET['notice']));
		showmessage('���ѷ��ͳɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
	}

} elseif($_GET['ac'] == 'cate') {

	$cateselect = get_cateselect($_GET['cid'], $_GET['acid']);
	include template('common/header_ajax');
	include template('yiyuan:ajax_cate');
	include template('common/footer_ajax');
	dexit();

} elseif($_GET['ac'] == 'help') {

	$navtitle = '��������';

} elseif($_GET['ac'] == 'admincomment') {

	if(!in_array($_G['groupid'], $admingroups)) {
		showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	$perpage = 15;
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$start = ($page - 1) * $perpage;
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan_comment')." ");
	$multi = multi($count, $perpage, $page, 'plugin.php?id=yiyuan&ac=admincomment');
	if($count) {
	require_once libfile('function/discuzcode');
	$commentlist = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_comment')." ORDER BY dateline DESC LIMIT $start, $perpage");
	while($result = DB::fetch($query)) {
			$result['dateline'] = dgmdate($result['dateline'], 'u');
			$result['comment'] = discuzcode($result['comment']);
			$commentlist[] = $result;
		}
	}

	$navtitle = '���۹���';

} elseif($_GET['ac'] == 'docot') {

	if(!in_array($_G['groupid'], $admingroups)) {
		showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	$cids = array();
	$cidarr = implode(',', $_GET['cids']);
	$status = intval($_GET['status']);
	if(empty($cidarr)) {
		showmessage('��û��ѡ��Ҫ������������Ϣ��', '', array(), array('showdialog' => 1));
	}
	if(empty($status)) {
		showmessage('��û��ѡ��Ҫ�����Ĺ���ѡ�', '', array(), array('showdialog' => 1));
	}
	if($_GET['status'] == '0') {
		DB::query("UPDATE ".DB::table('alu_yiyuan_comment')." SET status='$status' WHERE cid IN($cidarr)");
	} elseif($_GET['status'] == '1') {
		DB::query("UPDATE ".DB::table('alu_yiyuan_comment')." SET status='$status' WHERE cid IN($cidarr)");
	} elseif($_GET['status'] == '2') {
		DB::query("DELETE FROM ".DB::table('alu_yiyuan_comment')." WHERE cid IN($cidarr)");

	}
	showmessage('�����ɹ���ף���������ġ���죡', 'plugin.php?id=yiyuan&ac=admincomment&page='.intval($_GET['page']));

} elseif($_GET['ac'] == 'comment') {

	if(empty($_G['uid'])) {
		showmessage('���ȵ�¼��ע���Ա����ܼ���...', null, array(), array('showmsg' => true, 'login' => 1));
	}

	$data['comment'] = addslashes($_GET['comment']);

	if($cid) {
	$aluinfo = DB::fetch_first("SELECT * FROM ".DB::table('alu_yiyuan_comment')." WHERE cid='$cid' LIMIT 0, 1");
	if(submitcheck('formhash')) {
		if($aluinfo['uid'] != $_G['uid'] && !in_array($_G['groupid'], $admingroups)) {
			showmessage('��û��Ȩ�޲�����', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
		}
		if(empty($_GET['delete'])) {
			DB::update('alu_yiyuan_comment', $data, array('cid' => intval($_GET['cid'])));
			showmessage('���۸��³ɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
		} else {
			DB::query("DELETE FROM ".DB::table('alu_yiyuan_comment')." WHERE cid='$cid'");
			showmessage('����ɾ���ɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
		}
	}
	} else {

	$commentinfo = DB::fetch_first("SELECT * FROM ".DB::table('alu_yiyuan_comment')." WHERE aid='$aid' AND uid='$_G[uid]' LIMIT 0, 1");
	if($_G['timestamp'] - $commentinfo['dateline'] <= 3600) {
		showmessage('����Ϣ����������ۣ�', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
	}
	if(empty($_GET['aid'])) {
		showmessage('��û��ѡ��������Ʒ��', '', array(), array('alert'=> 'right', 'closetime' => true, 'showdialog' => 1));
	}
	if(submitcheck('formhash')) {
		if(empty($_GET['comment'])) {
			showmessage('��û����д�������ݣ�', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
		}
		$data['uid'] = intval($_G['uid']);
		$data['aid'] = intval($_GET['aid']);
		$data['username'] = addslashes($_G['username']);
		$data['ip'] = $_G['clientip'];
		$data['dateline'] = $_G['timestamp'];
		DB::insert('alu_yiyuan_comment', $data);
		if($_GET['uid'] != $_G['uid']) notification_add($_GET['uid'], 'system', '<a href="home.php?mod=space&uid={uid}" target="_blank" class="xi2">{username}</a> �����������Ƭ <a href="plugin.php?id=yiyuan&ac=view&order=album&aid={aid}" target="_blank" class="lit">����鿴 &rsaquo;</a>', array('aid' => $data['aid'], 'uid' => $_G['uid'], 'username' => $_G['username']));
		showmessage('���۳ɹ���', dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
	}
	}

}

//loadcache('diytemplatename');
//include template('diy:yiyuanlist', 0, 'source/plugin/yiyuan/template');
include template('yiyuan:yiyuanlist');

?>