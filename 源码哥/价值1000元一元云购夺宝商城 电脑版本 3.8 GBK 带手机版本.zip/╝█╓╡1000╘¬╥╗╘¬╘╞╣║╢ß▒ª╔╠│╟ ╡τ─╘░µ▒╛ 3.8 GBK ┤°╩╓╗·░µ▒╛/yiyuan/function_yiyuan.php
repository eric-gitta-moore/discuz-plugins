<?php



if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function get_duobao_user($aid) {
	global $_G;
	if(empty($aid)) {
		return false;
	}
	$aid = intval($aid);
	$aluinfo = get_yiyuan_info($aid);
	if($aluinfo['status'] == 1) {
		get_yiyuan_duobao_lottery($aid, $aluinfo['codes']);
		if($duobao = DB::fetch_first("SELECT * FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aid' AND status='1' LIMIT 0, 1")) {
			$data['lastuid'] = $duobao['uid'];
			$data['lastuser'] = $duobao['username'];
			$data['duobaodate'] = $duobao['dateline'];
			$data['duobaocount'] = DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aid' AND uid='$duobao[uid]'");
			DB::update('alu_yiyuan', array('status' => 2, 'duobaocodes' => serialize($data), 'lastdate' => $_G['timestamp'], 'orderid' => $duobao['codes']), array('aid' => $aid));
			notification_add($duobao['uid'], 'system', '{username} ��ϲ���ɹ����С�{title}����<a href="plugin.php?id=yiyuan&ac=userbuylist" target="_blank" class="lit">�ҵĶ��� &rsaquo;</a>', array('title' => $aluinfo['title'], 'username' => $duobao['username']));
			$user_info = get_profile_uid($duobao['uid']);
			if($user_info['mobile'] && $_G['cache']['plugin']['yiyuan']['remobile']) {
				require_once DISCUZ_ROOT.'./source/plugin/yiyuan/function_mobile.php';
				if(aismobile($user_info['mobile'])) {
					$content = '�𾴵Ļ�Ա��'.$duobao['username'].' ���ڣ�'.dgmdate($data['dateline'], 'Y-m-d H:i').' ���ۣ�100�ƹ�ҹ��� �ɹ����������ƹ�����';
					sendalusms($user_info['mobile'], $content);
				}
			}
		}
	}
	return true;
}

function get_yiyuan_duobao($aid, $num) {
	global $_G;
	if(empty($aid) || empty($num)) {
		return false;
	}
	$aid = intval($aid);
	if($num >= 1) {
		for($i = 0; $i < intval($num); $i++) {
			DB::query("UPDATE ".DB::table('alu_yiyuan_duobao')." SET uid='$_G[uid]', username='$_G[username]', ip='$_G[clientip]', dateline='$_G[timestamp]' WHERE aid='$aid' AND uid=0 ORDER BY rand() LIMIT 1");
		}
		DB::update('alu_yiyuan', array('number' => DB::result_first("SELECT COUNT(*) FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aid' AND uid>0")), array('aid' => $aid));
	}
}

function get_yiyuan_duobao_lottery($aid, $codes) {
	global $_G;
	if(empty($aid)) {
		return false;
	}
	if($codes) {
		$duobao = DB::update('alu_yiyuan_duobao', array('status' => 1), array('aid' => intval($aid), 'codes' => $codes));
		if(empty($duobao)) {
			DB::query("UPDATE ".DB::table('alu_yiyuan_duobao')." SET status='1' WHERE aid='$aid' ORDER BY rand() LIMIT 1");
		}
	} else {
		DB::query("UPDATE ".DB::table('alu_yiyuan_duobao')." SET status='1' WHERE aid='$aid' ORDER BY rand() LIMIT 1");
	}
	return true;
}

function content_get_go_codes($count = null, $aid = null) {	
	global $_G;
	if (empty($count) || empty($aid)) {
		return false;
	}
	if($aid) {
		$codes = array();
		for($i = 1; $i <= $count; $i++) {
			$codes = 10000+$i;
			DB::insert('alu_yiyuan_duobao', array('aid' => $aid, 'codes' => $codes), 1);
		};
		unset($codes);
	}
	return true;
}

function get_yiyuan_aids($aids) {
	global $_G;
	if (!is_array($aids) OR sizeof($aids) == 0) {
		return false;
	}
	array_walk_recursive($aids, 'intval_string');
	$list = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan')." WHERE aid IN (".implode(',', $aids).")");
		while($result = DB::fetch($query)) {
		$result['dateline'] = dgmdate($result['dateline'], 'm-d H:i:s');
		$result['pic'] = $result['img_1'] ? $_G['setting']['attachurl'].'category/'.getimgthumbname($result['img_1']) : 'source/plugin/yiyuan/images/nopic.gif';
		$list[] = $result;
	}
	foreach ($list as $key => $val) {
		$result[$val['aid']] = $val;
	}
	return $result;
}

function get_duobao_by_aid($aid, $uid) {
	global $_G;
	if (empty($aid) || empty($uid)) {
		return false;
	}
	$list = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aid' AND uid='$uid'");
		while($result = DB::fetch($query)) {
		$codes[] = $result['codes'];
		$list[] = $result;
	}
	return implode(', ', $codes);
}

function get_member_profile_codes($aid, $codes) {
	global $_G;
	if(empty($codes) || empty($aid)) {
		return false;
	}
	$duobao = DB::fetch_first("SELECT * FROM ".DB::table('alu_yiyuan_duobao')." WHERE aid='$aid' AND codes='$codes' LIMIT 0, 1");
	$member = DB::fetch_first("SELECT * FROM ".DB::table('common_member_profile')." WHERE uid='$duobao[uid]' LIMIT 0, 1");
	$member['notice'] = $duobao['notice'];
	$member['hide'] = $duobao['hide'];
	$member['cid'] = $duobao['cid'];
	return $member;
}

function get_profile_uid($uid) {
	global $_G;
	if (empty($uid)) {
		return false;
	}
	$uid = intval($uid);
	return DB::fetch_first("SELECT * FROM ".DB::table('common_member_profile')." WHERE uid='$uid' LIMIT 0, 1");
}

function get_cate_info($cid) {
	global $_G;
	if(empty($cid)) {
		return false;
	}
	$cid = intval($cid);
	return DB::fetch_first("SELECT * FROM ".DB::table('alu_yiyuan_cate')." WHERE cid='$cid' LIMIT 0, 1");
}

function get_yiyuan_album($aid) {
	global $_G;
	if(empty($aid)) {
		return false;
	}
	$aid = intval($aid);
	return DB::fetch_first("SELECT * FROM ".DB::table('alu_yiyuan_album')." WHERE aid='$aid' LIMIT 0, 1");
}

function get_yiyuan_info($aid) {
	global $_G;
	if(empty($aid)) {
		return false;
	}
	$aid = intval($aid);
	return DB::fetch_first("SELECT * FROM ".DB::table('alu_yiyuan')." WHERE aid='$aid' LIMIT 0, 1");
}

function get_cateselect($cid, $acid) {
	global $_G;
	if(empty($cid)) {
		return false;
	}
	$cid = intval($cid);
	$acid = intval($acid);
	$cate = array();
	$query = DB::query("SELECT * FROM ".DB::table('alu_yiyuan_cate')." WHERE acid='$cid' ORDER BY display ASC");
	while($result = DB::fetch($query)) {
		$cate[] = $result;
	}
	foreach ($cate AS $key => $value) {
		$selectstr = $value[cid] == $acid ? 'selected="selected"' : '';
		$catelect .= "<option value=\"$value[cid]\"$selectstr>$value[title]</option>";
	}
	return $catelect;
}

function thumbpath($attach, $width, $height) {
	global $_G;
	require_once libfile('class/image');
	$image = new image();
	$replacevalue = $_G['setting']['attachurl'].'category/'.$attach;
	$thumbpath = '';
	$_imgurl = $image->Thumb($replacevalue, $thumbpath, $width, $height, 2);
	return true;
}

function upload_image(&$data, $file, $type, $width, $height) {
	global $_G;
	$data['extid'] = empty($data['extid']) ? $data['fid'] : $data['extid'];
	if(empty($data['extid'])) return '';

	if($data['status'] == 3 && $_G['setting']['group_imgsizelimit']) {
		$file['size'] > ($_G['setting']['group_imgsizelimit'] * 1024) && showmessage('file_size_overflow', '', array('size' => $_G['setting']['group_imgsizelimit'] * 1024));
	}
	$upload = new discuz_upload();
	$uploadtype = $data['status'] == 3 ? 'category' : 'category';

	if(!$upload->init($file, $uploadtype, $data['extid'], $type)) {
		return false;
	}

	if(!$upload->save()) {
		if(!defined('IN_ADMINCP')) {
			showmessage($upload->errormessage());
		} else {
			cpmsg($upload->errormessage(), '', 'error');
		}
	}
	if($data['status'] == 3 && $type == 'icon') {
		require_once libfile('class/image');
		$img = new image;
		$img->Thumb($upload->attach['target'], './'.$uploadtype.'/'.$upload->attach['attachment'], $width, $height, 'fixwr');
	}
	return $upload->attach['attachment'];
}

function displayarray($c) {
	global $_G;
	return explode("\n", str_replace(array("\r"), '', $c));
}