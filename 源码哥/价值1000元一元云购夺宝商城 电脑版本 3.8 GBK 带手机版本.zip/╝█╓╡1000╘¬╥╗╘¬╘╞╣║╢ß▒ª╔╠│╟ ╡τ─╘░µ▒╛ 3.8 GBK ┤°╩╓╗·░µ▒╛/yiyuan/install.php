<?php



if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_alu_yiyuan;
CREATE TABLE pre_alu_yiyuan (
  aid mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  caid mediumint(8) unsigned NOT NULL DEFAULT '0',
  uid mediumint(8) unsigned NOT NULL DEFAULT '0',
  cid smallint(6) unsigned NOT NULL DEFAULT '0',
  acid smallint(6) unsigned NOT NULL DEFAULT '0',
  title varchar(255) NOT NULL,
  img_1 varchar(255) NOT NULL,
  img_2 varchar(255) NOT NULL,
  img_3 varchar(255) NOT NULL,
  img_4 varchar(255) NOT NULL,
  img_5 varchar(255) NOT NULL,
  img_6 varchar(255) NOT NULL,
  summary text NOT NULL,
  duobaocodes text NOT NULL,
  codes int(10) NOT NULL,
  `number` int(10) NOT NULL DEFAULT '0',
  original int(10) NOT NULL DEFAULT '0',
  price int(10) NOT NULL DEFAULT '0',
  residue int(10) NOT NULL DEFAULT '0',
  yiyuanprice int(10) NOT NULL DEFAULT '0',
  views int(10) NOT NULL DEFAULT '0',
  orderid int(10) NOT NULL DEFAULT '0',
  lastdate int(10) NOT NULL DEFAULT '0',
  dateline int(10) NOT NULL DEFAULT '0',
  display tinyint(3) NOT NULL DEFAULT '0',
  manual tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (aid),
  KEY caid (caid),
  KEY cid (cid),
  KEY acid (acid),
  KEY dateline (dateline)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS pre_alu_yiyuan_album;
CREATE TABLE pre_alu_yiyuan_album (
  cid int(10) NOT NULL AUTO_INCREMENT,
  aid mediumint(8) unsigned NOT NULL DEFAULT '0',
  uid mediumint(8) NOT NULL DEFAULT '0',
  username char(15) NOT NULL,
  img_1 varchar(255) NOT NULL,
  img_2 varchar(255) NOT NULL,
  img_3 varchar(255) NOT NULL,
  summary text NOT NULL,
  dateline int(10) NOT NULL,
  hide tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (cid),
  KEY aid (aid)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS pre_alu_yiyuan_cate;
CREATE TABLE pre_alu_yiyuan_cate (
  cid int(11) NOT NULL AUTO_INCREMENT,
  acid int(11) NOT NULL,
  title varchar(255) NOT NULL,
  display int(10) NOT NULL,
  PRIMARY KEY (cid),
  KEY acid (acid,display)
) ENGINE=MyISAM;

INSERT INTO pre_alu_yiyuan_cate (cid, acid, title, display) VALUES
(1, 0, '���õ���', 0),
(2, 0, '�ֻ�����', 0),
(3, 0, '���԰칫', 0),
(4, 0, '�˶�����', 0),
(5, 0, '��Ʒ����ӱ�', 0),
(6, 0, '����', 0),
(7, 1, '��ҵ�', 0),
(8, 1, '�������', 0),
(9, 1, '��������', 0),
(10, 1, '���˽���', 0),
(11, 1, '������', 0),
(12, 1, '��������', 0),
(13, 2, '�ֻ����', 0),
(14, 2, '��Ӱ����', 0),
(15, 2, '�������', 0),
(16, 2, 'ʱ��Ӱ��', 0),
(17, 3, '��������', 0),
(18, 3, '�������', 0),
(19, 3, '�����Ʒ', 0),
(20, 3, '�����Ʒ', 0),
(21, 3, '�칫��ӡ', 0),
(22, 3, '�칫����', 0),
(23, 4, '����Ь��', 0),
(24, 4, '����װ��', 0),
(25, 4, '�˶���е', 0),
(26, 4, '�����٤', 0),
(27, 4, '��������', 0),
(28, 4, '��������', 0),
(29, 5, '����Ů��', 0),
(30, 5, 'ʱ���а�', 0),
(31, 5, '�������', 0),
(32, 5, '�ݳ�Ʒ', 0),
(33, 5, '�ӱ�', 0),
(34, 6, '������Ʒ', 0);

DROP TABLE IF EXISTS pre_alu_yiyuan_comment;
CREATE TABLE pre_alu_yiyuan_comment (
  cid mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  aid mediumint(8) unsigned NOT NULL DEFAULT '0',
  uid mediumint(8) unsigned NOT NULL DEFAULT '0',
  username varchar(15) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  ip varchar(20) NOT NULL DEFAULT '',
  dateline int(10) unsigned NOT NULL DEFAULT '0',
  aidtype tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (cid),
  KEY aid (aid),
  KEY uid (uid)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS pre_alu_yiyuan_duobao;
CREATE TABLE pre_alu_yiyuan_duobao (
  cid int(10) NOT NULL AUTO_INCREMENT,
  aid mediumint(8) unsigned NOT NULL DEFAULT '0',
  uid mediumint(8) NOT NULL DEFAULT '0',
  username char(15) NOT NULL,
  codes varchar(15) NOT NULL DEFAULT '',
  ip char(15) NOT NULL,
  notice varchar(255) NOT NULL,
  dateline int(10) NOT NULL,
  `number` tinyint(3) NOT NULL DEFAULT '1',
  hide tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (cid),
  KEY aid (aid)
) ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = TRUE;

?>