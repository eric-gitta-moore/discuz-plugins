<?php



$cert = array(
'',
'1',
'',
'http://127.0.0.1/',
);
$sign = '';

?>
