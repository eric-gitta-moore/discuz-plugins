// JavaScript Document
function navList(id) {
	var jq = jQuery.noConflict(); 
    var jqobj = jq("#juheweb"), jqitem = jq("#J_nav_" + id);
    jqitem.addClass("on").parent().removeClass("none").parent().addClass("selected");
    jqobj.find("h4").hover(function () {
        jq(this).addClass("hover");
    }, function () {
        jq(this).removeClass("hover");
    });
    jqobj.find("p").hover(function () {
        if (jq(this).hasClass("on")) { return; }
        jq(this).addClass("hover");
    }, function () {
        if (jq(this).hasClass("on")) { return; }
        jq(this).removeClass("hover");
    });
    jqobj.find("h4").click(function () {
        var jqdiv = jq(this).siblings(".list-item");
        if (jq(this).parent().hasClass("selected")) {
            jqdiv.slideUp(200);
            jq(this).parent().removeClass("selected");
        }
        if (jqdiv.is(":hidden")) {
            jq("#juheweb li").find(".list-item").slideUp(200);
            jq("#juheweb li").removeClass("selected");
            jq(this).parent().addClass("selected");
            jqdiv.slideDown(200);

        } else {
            jqdiv.slideUp(200);
        }
    });

  jq(".cateory").click(function() {

		jq(this).find("ul").toggle('fast', function() {

			jq(this).parent().siblings().find("ul").hide()

		});

	});
	jq('.letter-filter-mod a').click(function(){

		jq(this).addClass("cur");

		jq(this).siblings().removeClass("cur");

	})

}
