<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
@extract($_G['cache']['plugin']['xlwsq_faq']);
$p = $_GET['p'];
$p = $p ? $p : 'index';
$appurls = $_G['siteurl'] . "plugin.php?id=xlwsq_faq:xlwsq_faq_user";
$navtitle = $title;
$admins = explode(",", $groupso);
if (!$_G['groupid'] == "1" || !in_array($_G['uid'], $admins)){showmessage(lang('plugin/xlwsq_faq', 'wuquanxiancaozuo'));}
if ($p == 'adminalllist'||$p == 'index') {
    $where="";
    if($_GET['key']){
      $key=stripsearchkey($_GET['key']);
	  $where="WHERE title like '%".addcslashes(addslashes($key), '%')."%'";
	  $keync=urlencode($key);
	  $pageadd="&key=$keync";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "WHERE cate IN ($cate_id,$subids)";
        } else {
            $wb = "WHERE cate=$cate_id";
        }
        $pageadds = "&a=$cate_id";
    }
    $sd = intval($_GET['b']);
    if ($sd) {
        $wc = "AND cate='$sd'";
        $pageaddx = "&b=$sd";
    }

    $r_id = intval($_GET['a']);
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $local[$row['id']] = $row;
    }
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
	    $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_faq_item') . "  $where $wb $wc ");
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_item') . "  $where $wb $wc ORDER BY  diynum DESC,dateline DESC, display DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $appurl = $_G['siteurl'] . "plugin.php?id=xlwsq_faq:xlwsq_faq_user&p=adminalllist";
        $multir = "<div class='pages cl' style='margin:10px 0;'>" . multi($countr, 20, $pager, $appurl . $pageadd .$pageadds .$pageaddx) . "</div>";
    if (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
           DB::query("DELETE FROM " . DB::table('plugin_xlwsq_faq_item') . " WHERE id = '$aid'");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_faq', 'shanchuok') , dreferer());
    }
} elseif ($p == 'add') {
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    if (submitcheck('applysubmit')) {
        $title = addslashes($_GET['title']);
		$cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
        $info = addslashes($_GET['info']);
        $display = intval($_GET['display']);
		$diynum=intval($_GET['diynum']);
        DB::insert('plugin_xlwsq_faq_item', array(
           'id' => '',
           'uid' => $_G['uid'],
           'author' => $_G['username'],
            'title' => $title,
            'cate' => $cate,
            'info' => $info,
            'display' => $display,
            'diynum' => $diynum,
            'dateline' => $_G['timestamp']
        ));
        showmessage(lang('plugin/xlwsq_faq', 'fabuchenggong') , 'plugin.php?id=xlwsq_faq:xlwsq_faq_user&p=index', array() , array('alert' => right));
    }
} elseif ($p == 'edit') {
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_faq_item') . " WHERE id='$id'");
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE id='$active[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $active['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    if (submitcheck('applysubmit')) {
        $title = addslashes($_GET['title']);
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
        $info = addslashes($_GET['info']);
        $display = intval($_GET['display']);
        $diynum = intval($_GET['diynum']);
        DB::update('plugin_xlwsq_faq_item', array(
            'title' => $title,
            'cate' => $cate,
            'info' => $info,
            'display' => $display,
            'diynum' => $diynum,
        ) , "id='$id'");
        showmessage(lang('plugin/xlwsq_faq', 'gengxinok') , dreferer());
     }
} elseif ($p == 'shenheok') {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_faq_item') . " SET display='1' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_faq', 'gengxinok') , dreferer());
        }
} elseif ($p == 'qxshenhe') {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_faq_item') . " SET display='0' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_faq', 'gengxinok') , dreferer());
        }
} elseif ($p == 'del') {
        $sid = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
		     DB::query("DELETE FROM " . DB::table('plugin_xlwsq_faq_item') . " WHERE id = '$sid'");
             showmessage(lang('plugin/xlwsq_faq', 'shanchuok') , dreferer());
        }
}
include (template("xlwsq_faq:xlwsq_faq_user"));
?>