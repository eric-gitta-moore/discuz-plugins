<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_plugin_xlwsq_faq_cate`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_faq_item`;
EOF;
runquery($sql);
$finish = TRUE;
?>
