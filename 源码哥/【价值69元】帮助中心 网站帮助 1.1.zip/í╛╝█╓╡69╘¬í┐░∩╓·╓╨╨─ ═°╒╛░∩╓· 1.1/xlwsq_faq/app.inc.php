<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	$pluginid_xlwsq = dhtmlspecialchars($_GET['identifier']);
 	$key = 'xlwsq2015';
	$allapp="http://open.discuz.net/api/getaddons/?key=xlwsq2015";
	$countents = dfsockopen($allapp); 	
	$app = unserialize($countents);
	foreach ($app_[DATA] as $key => $value) {
		$appid[] = $value['ID']; 
		$appname[] = $value['name']; 		
	}
	include template($pluginid_xlwsq.':moreapp');
?>