<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
@extract($_G['cache']['plugin']['xlwsq_faq']);
$appurl = $_G['siteurl'] . "plugin.php?id=xlwsq_faq";
$admins = explode(",", $groupso);
$navtitle = $title;
if (!$_GET['mod']) {
    $where="";
    if($_GET['key']){
      $key=stripsearchkey($_GET['key']);
	  $where="title like '%".addcslashes(addslashes($key), '%')."%' AND display!='0' AND";
	  $keync=urlencode($key);
	  $pageadd="&key=$keync";
    }
    //����
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
        $av_d[$cate_id] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $sd = intval($_GET['b']);
    if ($sd) {
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
        $av_d[$sd] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
	$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_faq_item') . " WHERE $where $wb $wc display!='0'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_item') . " WHERE $where $wb $wc display!='0' ORDER BY diynum DESC,dateline DESC LIMIT $starts,$eacha");
        while ($mythread = DB::fetch($query)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE id = '$cate[upid]'");
                $mythread['cate'] = $cate['subject'];
                $mythread['b'] = $cate['id'];
                $mythread['a'] = $cate['upid'];
            } else {
                $mythread['cate'] = $cate['subject'];
                $mythread['a'] = $cate['id'];
                $mythread['b'] = '0';
            }
            $mythread['title']=str_replace($key,"<font color='#ff0000'>$key</font>",$mythread['title']);
            $mythread['sinfo']=strip_tags($mythread['info']);
			
            $mythreads[] = $mythread;
        }
    }
	$multis = "<div class='pages cl' style='margin:10px;'>" . multi($counts,$eacha,$pages,$appurl.$pageadd.$pageadds.$pageaddx) . "</div>";

    $typequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
    $typedata = array();
    $upiddata = array();
    while ($type = DB::fetch($typequery)) {
        $typedata[$type['id']] = $type;
        $upidquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " where upid = " . $type['id'] . "  ORDER BY  displayorder DESC,id ASC");
        while ($upid = DB::fetch($upidquery)) {
            $upiddata[$type['id']][$upid['id']] = $upid;
        }
    }
    include template('xlwsq_faq:list');
} elseif ($_GET['mod'] == 'view') {
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_faq_item') . " WHERE id = '$sid' and display!='0'");
    !$mythread ? showmessage(lang('plugin/xlwsq_faq', 'error') , "plugin.php?id=xlwsq_faq") : '';
	$prev = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_faq_item')." WHERE id>'$sid' AND display!='0' AND cate ='$mythread[cate]' ORDER BY id ASC LIMIT 0,1");
	$next = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_faq_item')." WHERE id<'$sid' AND display!='0' AND cate ='$mythread[cate]'  ORDER BY id DESC LIMIT 0,1");
	$infolength=mb_strlen($mythread['info'], $_G['charset'] ) ;
    $navtitle = $mythread['title'] . " - " . $title;
	$metakeywords = $mythread['biaoqian'];
    $metadescription = cutstr(strip_tags($mythread['info']) , 80, '...');
    include template('xlwsq_faq:view');
//�ֻ���˵�
} elseif ($_GET['mod'] == 'cate') {
    $typequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
    $typedata = array();
    $upiddata = array();
    while ($type = DB::fetch($typequery)) {
        $typedata[$type['id']] = $type;
        $upidquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_faq_cate') . " where upid = " . $type['id'] . "   ORDER BY  displayorder DESC,id ASC");
        while ($upid = DB::fetch($upidquery)) {
            $upiddata[$type['id']][$upid['id']] = $upid;
        }
    }
    include template('xlwsq_faq:cate');
}
?>
