<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	$action = addslashes($_GET['action']);
	$bl_name= addslashes($_GET['bl']);
	if($action == 'cate') {
		$lid = intval($_GET['lid']);
		$show = '';
		if($lid) {
			$subid = DB::result_first("SELECT subid FROM ".DB::table('plugin_xlwsq_faq_cate')." WHERE id='$lid' ORDER BY displayorder DESC,id ASC");
			if($subid) {
				$show = '<select class="ps" name="'.$bl_name.'" id="'.$bl_name.'">';
				$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_faq_cate')." WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
				while($row = DB::fetch($query)) {
					$show .= '<option value="'.$row['id'].'">'.$row['subject'].'</option>';
				}
				$show .= '</select>';
			} else {
				$show = '';
			}
		}
	}
    include template("xlwsq_faq:select");
?>
