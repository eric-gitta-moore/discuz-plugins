<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . 'source/plugin/e6_signature/admin_function.php';
$sig_temporary = $sig;
!is_array($sig_temporary) && $sig_temporary = array();
if (empty($_POST['step'])) {
	$query = DB::query("SELECT `groupid`,`grouptitle` FROM ".DB::table('common_usergroup')." ORDER BY `groupid` ASC");
	while ($rt = DB::fetch($query)) {
		$group_list[$rt['groupid']] = $rt['grouptitle'];
	}
print <<<EOT
<form name="e6_form" method="post" autocomplete="off">
<input type="hidden" name="step" value="2">
<table class="tb tb2 ">
<tbody>
EOT;
	e6_sig_type_radio('open', $e6_sig_lang['edit_01'], "<a href=\"http://www.6ie6.com\" target=\"_blank\">{$e6_sig_lang['edit_02']}</a>");
	e6_sig_type_radio('free', $e6_sig_lang['edit_03'], $e6_sig_lang['edit_04']);
print <<<EOT
	<tr>
		<td class="td27">{$e6_sig_lang['edit_05']}</td>
		<td class="vtop tips2">{$e6_sig_lang['edit_06']}</td>
	</tr>
	<tr class="noborder">
		<td class="vtop rowform" colspan="2">
			<input name="sig[free_day]" value="{$sig['free_day']}" type="text" class="txt" /> {$e6_sig_lang['edit_07']}
		</td>
	</tr>
EOT;
	e6_sig_type_radio('msg', $e6_sig_lang['edit_08'], $e6_sig_lang['edit_09']);
	e6_sig_type_checkbox('group', $group_list, $e6_sig_lang['edit_10'], $e6_sig_lang['edit_11']);
print <<<EOT
	<tr>
		<td class="td27">{$e6_sig_lang['edit_12']}</td>
		<td class="vtop tips2">{$e6_sig_lang['edit_13']}<font color="red">{$e6_sig_lang['edit_14']}</font></td>
	</tr>
EOT;
foreach ($group_list as $key => $value) {
	if (in_array($key,$sig['group'])) {
print <<<EOT
	<tr class="noborder">
		<td class="vtop rowform" colspan="2" style="width:100%">
			<ul class="nofloat" style="width:100%" onmouseover="altStyle(this);">
				<li style="float: left; width: 10%">{$value}</li>
EOT;
for ($n=1; $n<=4; $n++) {
print <<<EOT
				<li style="float: left; width: 22%">
					<input name="sig[buy_group][{$key}][{$n}][day]" type="text" value="{$sig['buy_group'][$key][$n]['day']}" style="width:25px;" class="txt" />{$e6_sig_lang['edit_15']}/ 
					<input name="sig[buy_group][{$key}][{$n}][money]" type="text" value="{$sig['buy_group'][$key][$n]['money']}" style="width:25px;" class="txt" /> 
					<select name="sig[buy_group][{$key}][{$n}][type]" style="width:70px;">
EOT;
foreach ($money_title as $k=>$v) {
	if ($k == $sig['buy_group'][$key][$n]['type']) {
		$selected = 'selected';
	} else {
		$selected = '';
	}
print <<<EOT
				<option value="{$k}" {$selected}>{$v}</option>
EOT;
}
print <<<EOT
			</select>
				</li>
EOT;
}
print <<<EOT
			</ul>
		</td>
	</tr>
EOT;
	}
}
print <<<EOT
	<tr>
		<td colspan="15">
			<div class="fixsel">
				<input type="submit" class="btn" name="e6_submit" title="{$e6_sig_lang['edit_16']}" value="{$e6_sig_lang['edit_17']}" />
			</div>
		</td>	
	</tr>
</tbody>
</table>
</form>
EOT;
} else {
	$sig = $_POST['sig'];
	foreach ($sig['buy_group'] as $key => $value) {
		foreach ($value as $k => $v) {
			if (!$v['day'] or !$v['money']) {
				unset($sig['buy_group'][$key][$k]);
			} else {
				$value['Y'] = 1;
			}
		}
		if (!$value['Y']){
			unset($sig['buy_group'][$key]);
		}
	}
	$data = array_merge($sig_temporary,$sig);
	$data = e6_sig_export($data);
	$data = "\$sig=$data;\r\n";
	e6_sig_writeover($sig_config_file,"<?php\r\n".$data."?>");
	cpmsg($e6_sig_lang['edit_18'], 'action=plugins&operation=config&identifier=e6_signature&pmod=admin_edit', 'succeed');
}
?>