<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . 'source/plugin/e6_signature/admin_function.php';
foreach($money_title as $k => $v){
	$money_type .= '<option value="'.$k.'" >'.$v.'</option>';
}
$page = empty($_GET['page']) ? 1 : intval($_GET['page']);
if($page<1) $page = 1;
$perpage = 15;
$start = ($page-1)*$perpage;
$theurl = 'admin.php?action=plugins&operation=config&identifier=e6_signature&pmod=admin_log';
$multi = '';
$where = 'WHERE 1=1';
e6_sig_getgpc_arr(array('username', 'type', 'logtype', 'sdate', 'edate'));
if ($username) {
	$username = daddslashes($username);
	$where .= " AND username='{$username}'";
	$theurl .='&username='.$username;	
}
if ($type) {
	$type = intval($type);
	$where .= " AND type='{$type}'";
	$theurl .='&type='.$type;
}
if ($logtype) {
	$logtype = intval($logtype);
	$where .= " AND logtype='{$logtype}'";
	$theurl .='&logtype='.$logtype;
}
if ($sdate) {
	if ($_POST['sdate']) {
		$sdate = strtotime($sdate);
	}
	$sdate = intval($sdate);
	$where .= " AND date>'{$sdate}'";
	$theurl .='&sdate='.$sdate;
}
if ($edate) {
	if ($_POST['edate']) {
		$edate = strtotime($edate);
	}
	$edate = intval($edate);
	$where .= " AND date<'{$edate}'";
	$theurl .='&edate='.$edate;
}
$count = DB::result(DB::query("SELECT count(*) FROM ".DB::table('e6_sig_credit')." $where "), 0);
if ($count) {
	$n = ($page-1)*$perpage+1;
	$query = DB::query("SELECT * FROM ".DB::table('e6_sig_credit')." $where ORDER BY `date` DESC LIMIT $start,$perpage");
	while($value = DB::fetch($query)) {
		$value['n'] = $n;
		$value['logtype'] = $log_type_arr[$value['logtype']];
		$value['type'] = $money_title[$value['type']];
		$value['date']= dgmdate($value['date'],'m-d H:i:s');
		$list[] = $value;
		$n++;
	}
	$multi = multi($count, $perpage, $page, $theurl);
}
include template('e6_signature:log');
?>