<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$e6_sig_lang = $scriptlang['e6_signature'];
function e6_sig_export($str, $indent = '') {
	switch (gettype($str)){
		case 'string' :
			return "'" . str_replace(array("\\", "'"), array("\\\\", "\'"), $str) . "'";
		case 'array' :
			$output = "array(\r\n";
			foreach ($str as $key => $value) {
				$output .= $indent . "\t" . e6_sig_export($key, $indent . "\t") . ' => ' . e6_sig_export($value, $indent . "\t");
				$output .= ",\r\n";
			}
			$output .= $indent . ')';
			return $output;
		case 'boolean' :
			return $str ? 'true' : 'false';
		case 'NULL' :
			return 'NULL';
		case 'integer' :
		case 'double' :
		case 'float' :
			return "'" . (string) $str . "'";
	}
	return 'NULL';
}
function e6_sig_writeover($filename ,$data, $method = 'rb+', $iflock = 1, $check = 1, $chmod = 1) {
	$check && strpos($filename, '..') !== false && exit('Error_6e');
	touch($filename);
	$handle = fopen($filename, $method);
	$iflock && flock($handle, LOCK_EX);
	fwrite($handle, $data);
	$method == 'rb+' && ftruncate($handle, strlen($data));
	fclose($handle);
	$chmod && @chmod($filename, 0777);
}
function e6_sig_type_radio($name, $title, $explain = NULL) {
	global $sig,$e6_sig_lang;
	${'sig_'.$sig[$name]} = "checked";
print <<<EOT
	<tr>
		<td class="td27">{$title}</td>
		<td class="vtop tips2">{$explain}</td>
	</tr>
	<tr class="noborder">
		<td class="vtop rowform" colspan="2">
			<ul onmouseover="altStyle(this);">
				<li class="{$sig_1}">
					<input class="radio" type="radio" name="sig[{$name}]" value="1" {$sig_1} /> {$e6_sig_lang['high_32']}
				</li>
				<li class="{$sig_0}">
					<input class="radio" type="radio" name="sig[{$name}]" value="0" {$sig_0} /> {$e6_sig_lang['high_33']}
				</li>
			</ul>
		</td>
	</tr>
EOT;
}
function e6_sig_type_checkbox($name, $array, $title, $explain = NULL) {
	global $sig;
print <<<EOT
	<tr>
		<td class="td27">{$title}</td>
		<td class="vtop tips2">{$explain}</td>
	</tr>
	<tr class="noborder">
		<td class="vtop rowform" colspan="2" style="width:100%">
			<ul class="nofloat" style="width:100%" onmouseover="altStyle(this);">
EOT;
foreach ($array as $key => $value) {
	if (in_array($key, $sig[$name])) {
		$checked = 'checked';
	} else {
		$checked = '';
	}
print <<<EOT
				<li style="float: left; width: 18%" class="{$checked}"><input class="checkbox" type="checkbox" name="sig[{$name}][]" value="{$key}" class="checkbox" {$checked} />&nbsp;{$value}</li>
EOT;
}
print <<<EOT
			</ul>
		</td>
	</tr>
EOT;
}
require_once DISCUZ_ROOT . 'source/plugin/e6_signature/e6_function.php';
?>