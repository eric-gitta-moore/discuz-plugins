<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!function_exists('e6_sig_msg')) { 
	require_once DISCUZ_ROOT . 'source/plugin/e6_signature/e6_function.php';
}
if(empty($_G['uid'])) Showmessage(e6_sig_pl('e6_01'), 'member.php?mod=logging&action=login');
e6_sig_getgpc_arr(array('nav', 'step', 'uid' ,'ok' ,'order'));
$nav = daddslashes($nav);
$step = intval($step);
$uid = intval($uid);
$ok = intval($ok);
$order = daddslashes($order);
if ($nav == 'ban' or $nav == 'report') {
	if ($uid) {
		$Y = DB::result_first("SELECT `uid` FROM ".DB::table('e6_sig_user')." WHERE `uid`='$uid'");
		!$Y && DB::query("INSERT INTO ".DB::table('e6_sig_user')." SET `uid`='$uid'");
		if ($nav == 'ban' && in_array($_G['groupid'], $sig['admin_group'])) {
			DB::query("UPDATE ".DB::table('e6_sig_user')." SET `type`='4' WHERE `uid`='$uid'");
		} elseif ($nav == 'report') {
			DB::query("UPDATE ".DB::table('e6_sig_user')." SET `ok`='1' WHERE `uid`='$uid'");
		}
		showmessage('do_success', dreferer(), array(), array('showdialog'=>1, 'showmsg' => true, 'closetime' => true));
	}
	showmessage(e6_sig_pl('e6_02'));
	exit;
}
!$nav && $nav = 'buy';
$e6_nav = array('buy'=> e6_sig_pl('e6_03'), 'sell' => e6_sig_pl('e6_04'), 'mysig'=>e6_sig_pl('e6_05'), 'edit' => e6_sig_pl('e6_06'));
$e6_nav_name = $e6_nav[$nav];
$e6_nav_css[$nav] = 'a';
if ($nav == 'buy') {
	if ($sig['transaction'] == 1) {
		e6_sig_msg();
		if (in_array($_G['groupid'],$sig['buysig_group'])) {
			if ($ok == 1) {
				!$uid && showmessage(e6_sig_pl('e6_02'));
				$sig_user = DB::fetch_first("SELECT * FROM ".DB::table('e6_sig_user')." WHERE `uid`='$uid'");
				if ($sig_user['type'] != 2) showmessage(e6_sig_pl('e6_02'));
				$overdate = $_G['timestamp'] + $sig_user['buydate'] * 86400;
				$usermoney_A = e6_sig_user_money($sig_user['buytype']);
				if ($sig['buy_money'] && $sig['buy_type']) {
					$showmoney = $sig_user['buydate'] * $sig['buy_money'];
					if ($sig_user['type'] == $sig['buy_type']) {
						if ($usermoney_A < ($sig_user['buymoney'] + $showmoney)) {
							showmessage(e6_sig_pl('e6_07') . $money_title[$sig_user['buytype']] . e6_sig_pl('e6_08'));
						}
					} else {
						$usermoney_B = e6_sig_user_money($sig['buy_type']);
						if ($usermoney_A < $sig_user['buymoney']) {
							showmessage(e6_sig_pl('e6_07') . $money_title[$sig_user['buytype']] . e6_sig_pl('e6_08'));
						}
						if ($usermoney_B < $showmoney) {
							showmessage(e6_sig_pl('e6_07') . $money_title[$sig['buy_type']] . e6_sig_pl('e6_08'));
						}
					}
				} else {
					if ($usermoney_A < $sig_user['buymoney']) {
						showmessage(e6_sig_pl('e6_07') . $money_title[$sig_user['buytype']] . e6_sig_pl('e6_08'));
					}
				}
				DB::query("UPDATE ".DB::table('e6_sig_user')." SET `date`='$overdate',`type`='3',`buyuid`='$_G[uid]' WHERE `uid`='$uid'");
				$overdate = dgmdate($overdate,"Y-m-d H:i:s");
				$username = e6_sig_username($uid);
				e6_sig_money(-$sig_user['buymoney'], $sig_user['buytype'], 2, '', array($username, $sig_user['buydate'], $overdate));
				$showmoney && e6_sig_money(-$showmoney, $sig['buy_type'], '2e', '', array($username, $sig_user['buydate'], $overdate));
				e6_sig_money($sig_user['buymoney'], $sig_user['buytype'], 3, $uid, array($_G['username'], $overdate));
				showmessage(e6_sig_pl('e6_09'), 'plugin.php?id=e6_signature&nav=mysig&uid=$uid');
			} else {
				if ($sig['buy_money'] && $sig['buy_type']) {
					$e6_prompt = e6_sig_pl('e6_10') . $sig['buy_money'] . $_G['setting']['extcredits'][$sig['buy_type']]['title'] . ' /' . e6_sig_pl('e6_11');
				}
				if ($uid) {
					$uid == $_G['uid'] && showmessage(e6_sig_pl('e6_12'));
					$rvatar = avatar($uid, 'small');
					$sig_user = DB::fetch_first("SELECT * FROM ".DB::table('e6_sig_user')." WHERE `uid`='$uid'");
					if ($sig_user['type'] != 2) showmessage(e6_sig_pl('e6_02'));
					$sig_user['moneyname'] = $money_title[$sig_user['buytype']];
					$posts = DB::result_first("SELECT `posts` FROM ".DB::table('common_member_count')." WHERE `uid`='$uid'");
					$username = e6_sig_username($uid);
					if ($sig['buy_money'] && $sig['buy_type']) {
						$showmoney = $sig_user['buydate'] * $sig['buy_money'];
						if ($sig_user['type'] == $sig['buy_type']) {
							$buymoney = $sig_user['buymoney'] + $showmoney;
							$allmoney = $buymoney . $sig_user['moneyname'] . (e6_sig_pl('e6_13') . $sig_user['buydate'] . e6_sig_pl('e6_14'));
						} else {
							$allmoney = $sig_user['buymoney'] . $sig_user['moneyname'].' + '.$showmoney . $money_title[$sig['buy_type']] . '(' . e6_sig_pl('e6_15') . ')';
						}
					} else {	
						$allmoney = $sig_user['buymoney'] . $sig_user['moneyname'] . '(' . e6_sig_pl('e6_16') .')';
					}
					@include template("e6_signature:index_user");
					exit;
				} else {
					$order_arr = array(
						'buymoney'	=> e6_sig_pl('e6_17'),
						'buydate' 	=> e6_sig_pl('e6_18'), 
						'money' 	=> e6_sig_pl('e6_19'),
						'posts'		=> e6_sig_pl('e6_20')
					);
					!$order && $order = 'buymoney';
					foreach ($order_arr as $key => $value) {
						if ($key == $order) {
							$order_style = 'class="a"';
						} else {
							$order_style = '';
						}
						$order_list .= "<a href=\"plugin.php?id=e6_signature&nav=buy&order={$key}\" {$order_style}>{$value}</a>";
						if ($key != 'posts') {
							$order_list .='<span class="pipe">|</span>';
						}
					}
					$page = empty($_GET['page']) ? 1 : intval($_GET['page']);
					if($page<1) $page=1;
					$perpage = 16;
					$start = ($page-1)*$perpage;
					$theurl = 'plugin.php?id=e6_signature&nav='.$nav.'&order='.$order;
					$multi = '';
					$count = DB::result(DB::query("SELECT count(*) AS sum FROM ".DB::table('e6_sig_user')." WHERE type='2'"), 0);
					$page_num = ((int)($count/$perpage))+1;
					if ($count) {
						$query = DB::query("SELECT c.posts,c.threads,m.username,u.buydate,u.uid,u.buymoney,u.buytype,u.buymoney/u.buydate money FROM ".DB::table('e6_sig_user')." u ".
							"LEFT JOIN ".DB::table('common_member_count')." c ON u.uid=c.uid ".
							"LEFT JOIN ".DB::table('common_member')." m ON u.uid=m.uid ".
							"WHERE u.type='2' ORDER BY $order DESC LIMIT $start,$perpage");
						$n = ($page-1) * $perpage + 1;
						while($rt = DB::fetch($query)){
							$rt['n'] = $n; $n++;
							$rt['moneyname'] = $money_title[$rt['buytype']];
							$rt['rvatar'] = avatar($rt['uid'], 'small');
							$list[]=$rt;
						}
						$multi = multi($count, $perpage, $page, $theurl);
						$n--;
					}
				}
			}	
		} else {
			if ($uid or $ok) {
				showmessage(e6_sig_pl('e6_23'));
			}
			$e6_prompt = e6_sig_pl('e6_22');
		}
	} else {
		$e6_prompt = e6_sig_pl('e6_23');
	}
} elseif ($nav  == 'sell') {
	$sig_user = DB::fetch_first("SELECT * FROM ".DB::table('e6_sig_user')." WHERE `uid`='$_G[uid]'");
	if ($sig['transaction'] == 1 && in_array($_G['groupid'],$sig['sell_group'])) {
		if ($sig_user['type'] == 2) {
			$e6_prompt = e6_sig_pl('e6_24') . $sig_user['buymoney'] . $money_title[$sig_user['buytype']] . '/'.e6_sig_pl('e6_25');
			$sell_ok = 1;
		} elseif ($sig_user['type'] == 3) {
			$sig_user['date'] = dgmdate($sig_user['date'],'Y-m-d H:i:s');
			$e6_prompt = e6_sig_pl('e6_26') . $sig_user['date'];
		} elseif ($sig_user['type'] == 4) {
			$e6_prompt = e6_sig_pl('e6_27');
		} else {
			$sell_ok = 1;
		}
	} else {
		$e6_prompt = e6_sig_pl('e6_28');
	}
	$sell_ok != 1 && $disabled = 'disabled="disabled"';
	if ($step == 3) {
		if ($sig_user['type'] == 2) {
			DB::query("UPDATE ".DB::table('e6_sig_user')." SET `type`='1' WHERE `uid`='$_G[uid]'");
			Showmessage(e6_sig_pl('e6_09'), $_SERVER['HTTP_REFERER']);
		} else {
			Showmessage(e6_sig_pl('e6_02'));
		}
	} elseif ($step == 2) {
		$sell_ok != 1 && showmessage(e6_sig_pl('e6_29'));
		e6_sig_getgpc_arr(array('buymoney', 'buydate', 'buytype'));
		$buymoney = intval($buymoney);
		$buydate = intval($buydate);
		$buytype = intval($buytype);
		if ($buymoney && $buydate && $buytype) {
			if ($buymoney>99999) {
				showmessage(e6_sig_pl('e6_30') . $money_title[$buytype]);
			}
			if ($buydate>365){
				showmessage(e6_sig_pl('e6_31'));
			}
			if ($sig_user['uid']) {
				DB::query("UPDATE ".DB::table('e6_sig_user')." SET `type`='2',`buymoney`='$buymoney',`buytype`='$buytype',`buydate`='$buydate' WHERE `uid`='$_G[uid]'");
			} else {
				DB::query("INSERT INTO ".DB::table('e6_sig_user')." SET `type`='2',`buymoney`='$buymoney',`buytype`='$buytype',`buydate`='$buydate',`uid`='$_G[uid]'");
			}
			Showmessage(e6_sig_pl('e6_09'), 'plugin.php?id=e6_signature&nav=sell');
		} else {
			showmessage(e6_sig_pl('e6_32'));
		}
	} else {
		foreach ($money_title as $key=>$value) {
			if ($key == $sig_user['buytype']) {
				$selected = 'selected';
			} else {
				$selected = '';
			}
			$sig_option .="<option value=\"{$key}\" {$selected}>{$value}</option>";
		}
	}
} elseif ($nav == 'mysig') {
	if ($uid) {
		if ($step == 2) {
			$img_url = e6_sig_update($uid);
			if ($img_url) {
				echo $img_url;exit;
			}
			e6_sig_edit_sightml($uid);
			Showmessage(e6_sig_pl('e6_09'), 'plugin.php?id=e6_signature&nav=mysig&uid='.$uid);
		} else {
			$username = e6_sig_username($uid);
			$e6_prompt = e6_sig_pl('e6_33') . '[<font color="blue">' . $username . '</font>] ' . e6_sig_pl('e6_34');
			$sightml = DB::result_first("SELECT `sightml` FROM ".DB::table('common_member_field_forum')." WHERE `uid`='$uid'");
			require_once libfile('function/editor');
			$sightml = html2bbcode($sightml);
			if ($_G['group']['allowsigimgcode'] && $sig['img_user'] == 1 && in_array($_G['groupid'],$sig['img_group'])) {
				$img_open = 1;
			}
			@include template("e6_signature:index_mysiguser");
			exit;
		}
	} else {
		e6_sig_msg();
		$page = empty($_GET['page']) ? 1 : intval($_GET['page']);
		if($page<1) $page=1;
		$perpage = 15;
		$start = ($page-1)*$perpage;
		$theurl = 'plugin.php?id=e6_signature&nav='.$nav;
		$multi = '';
		$count = DB::result(DB::query("SELECT count(*) AS sum FROM ".DB::table('e6_sig_user')." WHERE `buyuid`='$_G[uid]'"), 0);
		if ($count) {
			$query = DB::query("SELECT u.*,c.sightml,m.username FROM ".DB::table('e6_sig_user')." u ".
			" LEFT JOIN " .DB::table('common_member_field_forum'). " c ON u.uid=c.uid ".
			" LEFT JOIN " .DB::table('common_member'). " m ON u.uid=m.uid ".
			" WHERE u.buyuid='$_G[uid]' AND u.type=3 AND u.date>'$_G[timestamp]' LIMIT $start,$perpage");
			$n = ($page-1) * $perpage + 1;
			while($rt = DB::fetch($query)){
				$rt['n'] = $n; $n++;
				$rt['date'] = dgmdate($rt['date'],"Y-m-d H:i:s");
				$rt['buytype'] = $money_title[$rt['buytype']];
				$list[]=$rt;
			}
			$multi = multi($count, $perpage, $page, $theurl);
		}			
	}
} elseif ($nav == 'edit') {
	$sig_user = DB::fetch_first("SELECT * FROM ".DB::table('e6_sig_user')." WHERE `uid`='$_G[uid]'");
	if (empty($step)){
		e6_sig_msg($_G['uid']);
		!$sig_user['uid'] && DB::query("INSERT INTO ".DB::table('e6_sig_user')." SET `uid`='$_G[uid]'");
		$sig_user['date'] && $sig_user['date'] = dgmdate($sig_user['date'],'Y-m-d H:i:s');
		if (!in_array($_G['groupid'], $sig['group']) or (in_array($_G['groupid'], $sig['group']) && !$sig['buy_group'][$_G['groupid']])) {
			$sig_user['type'] == 1 && DB::query("UPDATE ".DB::table('e6_sig_user')." SET `type`='0' WHERE `uid`='$_G[uid]'");
		}
		if ($sig_user['type'] == 4) {
			$e6_prompt = e6_sig_pl('e6_35');
		} elseif ($sig_user['type'] == 3) {
			$e6_prompt = e6_sig_pl('e6_36') . $sig_user['date'];
		} elseif ($sig_user['type'] == 2) {
			$e6_prompt = e6_sig_pl('e6_37') . '&nbsp; <a href="plugin.php?id=e6_signature&nav=sell&step=3" style="color:red;">' . e6_sig_pl('e6_38') . '</a>';
		} elseif ($sig_user['type'] == 1) {
			$e6_prompt = e6_sig_pl('e6_39') . $sig_user['date'];
			$sig_edit = 1;
		} else {
			if (in_array($_G['groupid'], $sig['group'])) {
				if ($sig['buy_group'][$_G['groupid']]) {
					if (!$sig_user['date'] && $sig['free_day'] && $sig['free'] == 1) {
						$free_option = "<option value=\"free\">".e6_sig_pl('e6_40') . $sig['free_day'] . e6_sig_pl('e6_41') ."</option>";
						$e6_prompt = e6_sig_pl('e6_42') . $sig['free_day'] . e6_sig_pl('e6_41') . ' !';
					}
					$sig_edit = 1;
				} else {
					if ($sig['transaction'] == 1 && in_array($_G['groupid'],$sig['buysig_group'])) {
						$e6_prompt = e6_sig_pl('e6_43') . ' &nbsp; <a href="plugin.php?id=e6_signature" style="color:red;">' . e6_sig_pl('e6_01') . '</a>';
					} else {
						$e6_prompt = e6_sig_pl('e6_45');
					}
				}
			} else {
				$e6_prompt = e6_sig_pl('e6_46');
				$sig_edit = 2;
			}
		}
		$sightml = DB::result_first("SELECT `sightml` FROM ".DB::table('common_member_field_forum')." WHERE `uid`='$_G[uid]'");
		if ($sig_edit == 1) {
			foreach ($sig['buy_group'][$_G['groupid']] as $key => $value) {	
				$user_sig_option .= "<option value=\"{$key}\">" .$value['day'] . e6_sig_pl('e6_41') . " / {$value['money']}{$money_title[$value['type']]}</option>";
			}
			require_once libfile('function/editor');
			$sightml = html2bbcode($sightml);
		}
		if ($_G['group']['allowsigimgcode'] && $sig_edit>0 && $sig['img_user'] == 1 && in_array($_G['groupid'],$sig['img_group'])) {
			$img_open = 1;
		}
		if ($sig_edit>0 && $sig['transaction'] == 1 && in_array($_G['groupid'],$sig['sell_group'])) {
			$sell_srt = "<a href=\"plugin.php?id=e6_signature&nav=sell\" style=\"color:#FF6600;font-weight:bolder;\">" . e6_sig_pl('e6_47') . "</a>";
		}
	} else {
		$img_url = e6_sig_update();
		if ($img_url) {
			echo $img_url;exit;
		}
		if (in_array($_G['groupid'], $sig['group']) && $_POST['sig_money']) {
			if ($_POST['sig_money'] == 'free' && !$sig_user['date']) {
				$overdate = $sig['free_day'] * 86400 + $_G['timestamp'];
			} else {
				$sig_day = $sig['buy_group'][$_G['groupid']][$_POST['sig_money']]['day'];
				if ($sig_user['date'] > $_G['timestamp']) {
					$overdate = $sig_user['date'] + $sig_day * 86400;
				} else {
					$overdate = $_G['timestamp'] + $sig_day * 86400;
				}
				$sig_type = $sig['buy_group'][$_G['groupid']][$_POST['sig_money']]['type'];
				$sig_money = $sig['buy_group'][$_G['groupid']][$_POST['sig_money']]['money'];
				$user_money = e6_sig_user_money($sig_type);
				if ($user_money < $sig_money) {
					showmessage(e6_sig_pl('e6_48') . $money_title[$sig_type] . e6_sig_pl('e6_49'), 'home.php?mod=spacecp&ac=plugin&op=profile&id=e6_signature:user_signature');
					exit;
				}
			}
			DB::query("UPDATE ".DB::table('e6_sig_user')." SET `date`='$overdate',`type`='1' WHERE `uid`='$_G[uid]'");
			$overdate = dgmdate($overdate, "Y-m-d H:i:s");
			$sig_money && e6_sig_money(-$sig_money, $sig_type, 1, false, array($sig_day, $overdate));
			$e6_sig_msg = e6_sig_pl('e6_50') . $overdate;
		} else {
			$e6_sig_msg = e6_sig_pl('e6_09');
		}
		e6_sig_edit_sightml();
		showmessage($e6_sig_msg, 'plugin.php?id=e6_signature&nav=edit');
	}
} else {
	showmessage(e6_sig_pl('e6_02'));
}
@include template("e6_signature:index_{$nav}");
?>