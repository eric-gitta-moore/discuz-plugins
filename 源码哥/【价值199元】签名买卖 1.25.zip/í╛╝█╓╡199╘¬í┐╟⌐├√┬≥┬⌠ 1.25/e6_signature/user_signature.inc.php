<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!function_exists('e6_sig_msg')) { 
	require_once DISCUZ_ROOT . 'source/plugin/e6_signature/e6_function.php';
}
if ($sig['open'] != 1) {
	showmessage(e6_sig_pl('user_01'), 'home.php?mod=spacecp');
	exit;
}
$sig_user = DB::fetch_first("SELECT * FROM ".DB::table('e6_sig_user')." WHERE `uid`='$_G[uid]'");
if (empty($_POST['step'])) {
	e6_sig_msg($_G['uid']);
	!$sig_user['uid'] && DB::query("INSERT INTO ".DB::table('e6_sig_user')." SET `uid`='$_G[uid]'");
	$sig_user['date'] && $sig_user['date'] = dgmdate($sig_user['date'],'Y-m-d H:i:s');
	if (!in_array($_G['groupid'], $sig['group']) or (in_array($_G['groupid'], $sig['group']) && !$sig['buy_group'][$_G['groupid']])) {
		$sig_user['type'] == 1 && DB::query("UPDATE ".DB::table('e6_sig_user')." SET `type`='0' WHERE `uid`='$_G[uid]'");
	}
	if ($sig_user['type'] == 4) {
		$e6_sig_remind = e6_sig_remind(e6_sig_pl('user_02'));
	} elseif ($sig_user['type'] == 3) {
		$e6_sig_remind = e6_sig_remind(e6_sig_pl('user_03').$sig_user['date']);
	} elseif ($sig_user['type'] == 2) {
		$e6_sig_remind = e6_sig_remind(e6_sig_pl('user_04') . ' &nbsp; <a href="plugin.php?id=e6_signature&nav=sell&step=3" style="color:red;">'.e6_sig_pl('user_05').'</a>');
	} elseif ($sig_user['type'] == 1) {
		$e6_sig_remind = e6_sig_remind(e6_sig_pl('user_06').$sig_user['date']);
		$sig_edit = 1;
	} else {
		if (in_array($_G['groupid'], $sig['group'])) {
			if ($sig['buy_group'][$_G['groupid']]) {
				if (!$sig_user['date'] && $sig['free_day'] && $sig['free'] == 1) {
					$free_option = "<option value=\"free\">" . e6_sig_pl('user_07') . $sig['free_day'] . e6_sig_pl('user_08') . "</option>";
					$e6_sig_remind = e6_sig_remind(e6_sig_pl('user_09') . $sig['free_day'] . e6_sig_pl('user_10'));
				}
				$sig_edit = 1;
			} else {
				if ($sig['transaction'] == 1 && in_array($_G['groupid'],$sig['buysig_group'])) {
					$e6_sig_remind = e6_sig_remind(e6_sig_pl('user_11') . ' &nbsp; <a href="plugin.php?id=e6_signature" style="color:red;">' . e6_sig_pl('user_12') . '</a>');
				} else {
					$e6_sig_remind = e6_sig_remind(e6_sig_pl('user_13'));
				}
			}
		} else {
			$e6_sig_remind = e6_sig_remind(e6_sig_pl('user_14'));
			$sig_edit = 2;
		}
	}
	$sightml = DB::result_first("SELECT `sightml` FROM ".DB::table('common_member_field_forum')." WHERE `uid`='$_G[uid]'");
	if ($sig_edit == 1) {
		foreach ($sig['buy_group'][$_G['groupid']] as $key => $value) {	
			$user_sig_option .= "<option value=\"{$key}\">" . $value['day'] . e6_sig_pl('user_08') . " / {$value['money']}{$money_title[$value['type']]}</option>";
		}
		require_once libfile('function/editor');
		$sightml = html2bbcode($sightml);
	}
	if ($_G['group']['allowsigimgcode'] && $sig_edit>0 && $sig['img_user'] == 1 && in_array($_G['groupid'],$sig['img_group'])) {
		$img_open = 1;
	}
	if ($sig_edit>0 && $sig['transaction'] == 1 && in_array($_G['groupid'],$sig['sell_group'])) {
		$sell_srt = "<a href=\"plugin.php?id=e6_signature&nav=sell\" style=\"color:#FF6600;font-weight:bolder;\">". e6_sig_pl('user_15') ."</a>";
	}
} else {
	$img_url = e6_sig_update();
	if ($img_url) {
		echo $img_url;exit;
	}
	$sig_money = daddslashes($_POST['sig_money']);
	if (in_array($_G['groupid'], $sig['group']) && $sig_money) {
		if ($sig_money == 'free' && !$sig_user['date']) {
			$overdate = $sig['free_day'] * 86400 + $_G['timestamp'];
		} else {
			$sig_day = $sig['buy_group'][$_G['groupid']][$sig_money]['day'];
			if ($sig_user['date'] > $_G['timestamp']) {
				$overdate = $sig_user['date'] + $sig_day * 86400;
			} else {
				$overdate = $_G['timestamp'] + $sig_day * 86400;
			}
			$sig_type = $sig['buy_group'][$_G['groupid']][$sig_money]['type'];
			$sig_money = $sig['buy_group'][$_G['groupid']][$sig_money]['money'];
			$user_money = e6_sig_user_money($sig_type);
			if ($user_money < $sig_money) {
				showmessage(e6_sig_pl('user_16') . $money_title[$sig_type] . e6_sig_pl('user_17'), 'home.php?mod=spacecp&ac=plugin&op=profile&id=e6_signature:user_signature');
				exit;
			}
		}
		DB::query("UPDATE ".DB::table('e6_sig_user')." SET `date`='$overdate',`type`='1' WHERE `uid`='$_G[uid]'");
		$overdate = dgmdate($overdate, "Y-m-d H:i:s");
		$sig_money && e6_sig_money(-$sig_money, $sig_type, 1, false, array($sig_day, $overdate));
		$e6_sig_msg = e6_sig_pl('user_18') . $overdate;
	} else {
		$e6_sig_msg = e6_sig_pl('user_19');
	}
	e6_sig_edit_sightml();
	showmessage($e6_sig_msg, 'home.php?mod=spacecp&ac=plugin&op=profile&id=e6_signature:user_signature');
}
?>