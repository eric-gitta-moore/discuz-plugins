<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sig_config_file = DISCUZ_ROOT . 'data/e6_signature.config.php';
@include ($sig_config_file);
$e6_sig_lang = $scriptlang['e6_signature'];
if (!function_exists('e6_sig_pl')) {
	function e6_sig_pl($str) {
		return lang('plugin/e6_signature', $str);
	}
}
$log_type_arr = array(1 => e6_sig_pl('function_01'), 2 => e6_sig_pl('function_02'), 3 => e6_sig_pl('function_03'));
if (empty($money_title)) {
	foreach ($_G['setting']['extcredits'] as $key => $value) {
		$money_title[$key] = $value['title'];
	}
}
function e6_sig_username($uid) {
	$uid = intval($uid);
	$username = DB::result_first("SELECT `username` FROM ".DB::table('common_member')." WHERE `uid`='$uid'");
	return $username;
}
function e6_sig_user_money($type, $uid = NULL) {
	if (empty($uid)) {
		global $_G;
		$uid = $_G['uid'];
	}
	if ($uid) {
		$uid = intval($uid);
		$type = intval($type);
		$money = DB::result_first("SELECT `extcredits{$type}` FROM ".DB::table('common_member_count')." WHERE `uid`='$uid'");
		return $money;
	}
}
function e6_sig_getgpc_arr($arr){
	foreach ($arr as $value) {
		$GLOBALS[$value] = getgpc($value);
	}
}
function e6_sig_money($change, $type, $logtype, $uid = false, $alternate = false) {
	global $_G,$money_title;
	if ($uid) {
		$username = e6_sig_username($uid);
	} else {
		$uid = $_G['uid'];
		$username = $_G['username'];
	}
	$ip = $_G['clientip'];
	$date = $_G['timestamp'];
	$smoney = e6_sig_user_money($type, $uid);
	DB::query("UPDATE " .DB::table('common_member_count'). " SET `extcredits{$type}`=`extcredits{$type}`+'$change' WHERE uid='$uid'");
	$emoney = e6_sig_user_money($type, $uid);
	$log_array = array(
		'1'	=> e6_sig_pl('function_04') . $alternate[0] . e6_sig_pl('function_05') . $alternate[1] . e6_sig_pl('function_06') . '<font color="red">' . $change . $money_title[$type] . '</font>',
		'2'	=> e6_sig_pl('function_07') . '<font color="blue">' . $alternate[0] . '</font>' . e6_sig_pl('function_08') . $alternate[1] . e6_sig_pl('function_09') . '<font color="red">' .$change . $money_title[$type]. '</font>' . e6_sig_pl('function_10') . $alternate[2],
		'2e'=> e6_sig_pl('function_11') . '<font color="blue">' . $alternate[0] . '</font>' . e6_sig_pl('function_12') . $alternate[1] . e6_sig_pl('function_13') . '<font color="red">' . $change . $money_title[$type]. '</font>' . e6_sig_pl('function_14') . $alternate[2],
		'3'	=> e6_sig_pl('function_15') . '<font color="blue">' . $alternate[0] . '</font>' . e6_sig_pl('function_16') . '<font color="red">' . $change . $money_title[$type] . '</font>' . e6_sig_pl('function_17') . $alternate[1],
	);
	$logtype = (float)$logtype;
	$describe = $log_array[$logtype];
	DB::query("INSERT INTO ".DB::table('e6_sig_credit')." (`uid`,`username`,`type`,`logtype`,`smoney`,`emoney`,`change`,`date`,`ip`,`describe`) ".
	" VALUES ('$uid','$username','$type','$logtype','$smoney','$emoney','$change','$date','$ip','$describe')");
}
function e6_sig_msg($uid = NULL) {
	global $sig,$_G;
	$uid && $uid = intval($uid);
	$uid && $where = " `uid` IN($uid) AND ";
	if ($sig['msg'] == 1) {
		$query = DB::query("SELECT `uid`,`date`,`buyuid`,`type` FROM ".DB::table('e6_sig_user')." WHERE $where `date`<'$_G[timestamp]' AND (`type`='1' or `type`='3')");
		while($rt = DB::fetch($query)) {
			$rt['date'] = dgmdate($rt['date'], 'Y-m-d H:i:s');
			if ($rt['type'] == 3) {
				$content = e6_sig_pl('function_18') . $rt['date'] . e6_sig_pl('function_19');
				$username = e6_sig_username($rt['uid']);
				$buy_content = e6_sig_pl('function_20') . $username . e6_sig_pl('function_21') . $rt['date'] . e6_sig_pl('function_22');
				$rt['buyuid'] && notification_add($rt['buyuid'], 'system', 'system_notice', array('subject' => e6_sig_pl('function_23'), 'message' => $buy_content), 1);
			} else {
				$content = e6_sig_pl('function_24') . $rt['date'] . e6_sig_pl('function_25');
			}
			notification_add($rt['uid'], 'system', 'system_notice', array('subject' => e6_sig_pl('function_26'), 'message' => $content), 1);
		}
		
	}
	DB::query("UPDATE ".DB::table('e6_sig_user')." SET `type`='0' WHERE $where (`type`='1' or `type`='3') AND `date`<'$_G[timestamp]'");
}
function e6_sig_remind($str) {
	return "<div class=\"e6_sig_remind\">{$str}</div>";
}
function e6_sig_update($id = NULL) {
	if (empty($id)) {
		global $_G;
		$id = $_G['uid'];
	}
	$id = intval($id);
	global $_FILES;
	if ($_FILES['e6_file']['tmp_name'] || file_exists($_FILES['e6_file']['tmp_name'])) {
		$upload = new discuz_upload();
		$extname = $upload->fileext($_FILES['e6_file']['name']);
		if($upload->is_image_ext($extname)){
			if ($id > 1000) {
				$file_num = intval($_G['uid']/1000);
			} else {
				$file_num = 0;
			}
			$file_name_f = DISCUZ_ROOT.'data/e6_sig/';
			$img_name =  $id .'.'. $extname;
			if ($upload->make_dir($file_name_f)) {
				$file_name = $file_name_f . $file_num . '/'; 
				if ($upload->make_dir($file_name)) {
					$upload->save_to_local($_FILES['e6_file']['tmp_name'], $file_name.$img_name);
				}
			}
		}
		return "[img]data/e6_sig/{$file_num}/{$img_name}[/img]";
	}
}
function e6_sig_edit_sightml($uid = NULL) {
	global $_POST,$_G;
	!$uid && $uid = $_G['uid'];
	$uid = intval($uid);
	loadcache(array('smilies', 'smileytypes'));
	$_POST['sightml'] = cutstr($_POST['sightml'], $_G['group']['maxsigsize'], '');
	foreach($_G['cache']['smilies']['replacearray'] AS $key => $value) {
		$_G['cache']['smilies']['replacearray'][$key] = '[img]'.$_G['siteurl'].'static/image/smiley/'.$_G['cache']['smileytypes'][$_G['cache']['smilies']['typearray'][$key]]['directory'].'/'.$value.'[/img]';
	}
	$_POST['sightml'] = preg_replace($_G['cache']['smilies']['searcharray'], $_G['cache']['smilies']['replacearray'], trim($_POST['sightml']));
	require_once libfile('function/discuzcode');
	$sightml = discuzcode($_POST['sightml'], 1, 0, 0, 0, $_G['group']['allowsigbbcode'], $_G['group']['allowsigimgcode'], 0, 0, 1);
	$sightml = daddslashes($sightml);
	DB::query("UPDATE ".DB::table('common_member_field_forum')." SET `sightml`='$sightml' WHERE `uid`='$uid'");
}
?>