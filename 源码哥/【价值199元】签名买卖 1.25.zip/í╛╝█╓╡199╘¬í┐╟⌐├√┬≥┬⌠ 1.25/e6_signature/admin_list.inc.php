<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . 'source/plugin/e6_signature/admin_function.php';
$sig_type_arr = array(1 => $e6_sig_lang['list_01'], 2 => $e6_sig_lang['list_02'], 3 => $e6_sig_lang['list_03'], 4 => $e6_sig_lang['list_04'], 5 => $e6_sig_lang['list_05']);
if ($_POST['step'] == 3) {
	$uid = intval($_POST['uid']);
	$type = intval($_POST['type']);
	if ($uid) {
		$Y = DB::result_first("SELECT `uid` FROM ".DB::table('e6_sig_user')." WHERE `uid`='$uid'");
		!$Y && DB::query("INSERT INTO ".DB::table('e6_sig_user')." SET `uid`='$uid'");
		@include libfile('function/discuzcode');
		$sightml = discuzcode($_POST['sightml'], 1, 0, 0, 0, 1, 1, 0, 0, 1);
		$sightml = daddslashes($sightml);
		DB::query("UPDATE ".DB::table('common_member_field_forum')." SET `sightml`='$sightml' WHERE `uid`='$uid'");
		$_POST['date'] && $date = strtotime($_POST['date']);
		$date = intval($date);
		if ($type == 5) {
			DB::query("UPDATE ".DB::table('e6_sig_user')." SET `ok`='1',`date`='$date' WHERE `uid`='$uid'");
		} else {
			$type == 6 && $date>$_G['timestamp'] && $type = 1;
			DB::query("UPDATE ".DB::table('e6_sig_user')." SET `ok`='0',`type`='$type',`date`='$date' WHERE `uid`='$uid'");
		}
	}
	cpmsg($e6_sig_lang['list_06'], 'action=plugins&operation=config&identifier=e6_signature&pmod=admin_list', 'succeed');
} elseif ($_GET['empty']) {
	$uid = intval($_GET['empty']);
	DB::query("UPDATE ".DB::table('common_member_field_forum')." SET `sightml`='' WHERE `uid`='$uid'");
	DB::query("UPDATE ".DB::table('e6_sig_user')." SET `type`='0',`ok`='0',`buyuid`='0' WHERE `uid`='$uid'");
	cpmsg($e6_sig_lang['list_06'], 'action=plugins&operation=config&identifier=e6_signature&pmod=admin_list', 'succeed');
} elseif ($_GET['shielded']) {
	$uid = intval($_GET['shielded']);
	$Y = DB::result_first("SELECT `uid` FROM ".DB::table('e6_sig_user')." WHERE `uid`='$uid'");
	if ($Y) {
		DB::query("UPDATE ".DB::table('e6_sig_user')." SET `type`='4' WHERE `uid`='$uid'");
	} else {
		DB::query("INSERT INTO ".DB::table('e6_sig_user')." SET `uid`='$uid',`type`='4'");
	}
	cpmsg($e6_sig_lang['list_06'], 'action=plugins&operation=config&identifier=e6_signature&pmod=admin_list', 'succeed');
} elseif ($_GET['remove']) {
	$uid = intval($_GET['remove']);
	$Y = DB::result_first("SELECT `uid` FROM ".DB::table('e6_sig_user')." WHERE `uid`='$uid'");
	if ($Y) {
		DB::query("UPDATE ".DB::table('e6_sig_user')." SET `type`='1' WHERE `uid`='$uid'");
	} else {
		DB::query("INSERT INTO ".DB::table('e6_sig_user')." SET `uid`='$uid',`type`='1'");
	}
	cpmsg($e6_sig_lang['list_06'], 'action=plugins&operation=config&identifier=e6_signature&pmod=admin_list', 'succeed');
} elseif ($_GET['edit']) {
	$uid = intval($_GET['edit']);
	$user = DB::fetch_first("SELECT m.username,m.groupid,u.* FROM ".DB::table('common_member')." m LEFT JOIN ".DB::table('e6_sig_user')." u ON m.uid=u.uid WHERE m.uid='$uid'");
	if ($user['type']) {
		if ($user['type'] == 3 && $user['buyuid']) {
			$buyusername = e6_sig_username($user['buyuid']);
		} else {
			if ($user['ok'] == 1) {
				$user['type'] = 5;
			}
		}
	} else {
		if (in_array($user['groupid'], $sig['group'])) {
			if ($sig['buy_group'][$user['groupid']]) {
				$sig_type_option = '<option value="6" selected>'.$e6_sig_lang['list_07'].'</option>';
			} else {
				$sig_type_option = '<option value="7" selected>'.$e6_sig_lang['list_08'].'</opiton>';
			}
		} else {
			$user['type'] = 1;
		}
	}
	foreach ($sig_type_arr as $key => $value) {
		if ($key == $user['type']) {
			$selected = 'selected';
		} else {
			$selected = '';
		}
		$sig_type_option .= "<option value=\"$key\" {$selected}>$value</option>";
	}
	$sightml = DB::result_first("SELECT `sightml` FROM ".DB::table('common_member_field_forum')." WHERE `uid`='$uid'");
	require_once libfile('function/editor');
	$sightml = html2bbcode($sightml);
	$user['date'] && $date = dgmdate($user['date'],'Y-m-d H:i:s');
} else {
	e6_sig_msg();
	$page = empty($_GET['page']) ? 1 : intval($_GET['page']);
	if($page<1) $page = 1;
	$perpage = 15;
	$start = ($page-1)*$perpage;
	$theurl = 'admin.php?action=plugins&operation=config&identifier=e6_signature&pmod=admin_list';
	$multi = '';
	$where = 'WHERE 1=1';
	e6_sig_getgpc_arr(array('type', 'sdate', 'edate', 'username'));
	if ($type) {
		$type = intval($type);
		if ($type == 5) {
			$where .= " AND s.ok='1' ";
		} else {
			$where .= " AND s.type='{$type}' ";
		}
		$theurl .='&type='.$type;
	}
	if ($sdate) {
		if ($_POST['sdate']) {
			$sdate = strtotime($sdate);
		}
		$sdate = intval($sdate);
		$where .= " AND s.date>'{$sdate}' ";
		$theurl .= '&sdate='.$sdate;
	}
	if ($edate) {
		if ($_POST['edate']) {
			$edate = strtotime($edate);
		}
		$edate = intval($edate);
		$where .= " AND s.date<'{$edate}' ";
		$theurl .= '&edate='.$edate;
	}
	if ($username) {
		$username = daddslashes($username);
		$uid = DB::result_first("SELECT `uid` FROM ".DB::table('common_member')." WHERE `username`='$username'");
		if ($type == 3) {
			$where .= " AND s.buyuid='{$uid}'";
		} else {
			if ($type) {
				$where .= " AND s.uid='{$uid}'";
			} else {
				$where .= " AND c.uid='{$uid}'";
			}
		}
		$theurl .='&username='.$username;
	}
	if (!$username && ($type or $sdate or $edate)) {
		$count = DB::result(DB::query("SELECT count(*) FROM ".DB::table('e6_sig_user')." s $where "), 0);
	} else {
		$count = DB::result(DB::query("SELECT count(*) FROM " .DB::table('common_member_field_forum'). " WHERE `sightml`<>''"));
	}
	!$type && !$count && $count = 1;
	if ($count) {
		$n = ($page-1) * $perpage + 1;
		$query = DB::query("SELECT c.sightml,m.username,m.uid,m.groupid,s.date,s.type,s.buyuid,s.ok FROM " . DB::table('common_member_field_forum') . " c LEFT JOIN " . DB::table('common_member') . " m ON c.uid=m.uid LEFT JOIN ".DB::table('e6_sig_user')." s ON c.uid=s.uid $where AND c.sightml<>'' ORDER BY s.date DESC,m.uid DESC LIMIT $start,$perpage");
		while($rt = DB::fetch($query)) {
			$rt['n'] = $n;
			$rt['types'] = $rt['type'];
			if ($rt['type'] == 3 && $rt['buyuid']) {
				$rt['buyusername'] = e6_sig_username($rt['buyuid']);
			}
			$rt['type'] = $sig_type_arr[$rt['type']];
			if (!$rt['type']){
				if (in_array($rt['groupid'],$sig['group'])) {
					if ($sig['buy_group'][$rt['groupid']]) {
						$rt['type'] = $e6_sig_lang['list_09'];
					} else {
						$rt['type'] = $e6_sig_lang['list_10'];
					}
				} else {
					$rt['type'] = $e6_sig_lang['list_11'];
				}
			}
			if ($rt['ok'] == 1) {
				$rt['type'] .= '<font color="blue">['.$e6_sig_lang['list_12'].']</font>';
			}
			if ($rt['date'] > $_G['timestamp']) {
				$rt['date'] = dgmdate($rt['date'],'Y-m-d H:i:s');
			} else {
				$rt['date'] = '';
			}
			$list[] = $rt;
			$n++;
		}
		$multi = multi($count, $perpage, $page, $theurl);
	}
}
include template('e6_signature:list');
?>