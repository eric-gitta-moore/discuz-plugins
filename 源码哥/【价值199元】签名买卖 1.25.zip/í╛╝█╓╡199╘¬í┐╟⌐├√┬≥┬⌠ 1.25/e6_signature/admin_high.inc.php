<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . 'source/plugin/e6_signature/admin_function.php';
$sig_temporary = $sig;
!is_array($sig_temporary) && $sig_temporary = array();
if (empty($_POST['step'])) {
	$query = DB::query("SELECT `groupid`,`grouptitle` FROM ".DB::table('common_usergroup')." ORDER BY `groupid` ASC");
	while ($rt = DB::fetch($query)) {
		$group_list[$rt['groupid']] = $rt['grouptitle'];
	}
	!$sig['html'] && $sig['html'] = $e6_sig_lang['high_01'] . '{sigmoney} &nbsp; <a href="plugin.php?id=e6_signature&nav=buy&uid={siguid}" style="color:red">' .$e6_sig_lang['high_02']. '</a>';
print <<<EOT
<form name="e6_form" method="post" autocomplete="off" action="">
<input type="hidden" name="step" value="2" />
<table class="tb tb2">
<tbody>
EOT;
	e6_sig_type_radio('img_user', $e6_sig_lang['high_03'], $e6_sig_lang['high_04']);
print <<<EOT
	<tr>
		<td class="td27">{$e6_sig_lang['high_05']}</td>
		<td class="vtop tips2">{$e6_sig_lang['high_06']}</td>
	</tr>
	<tr class="noborder">
		<td class="vtop rowform" colspan="2">
			<input name="sig[buy_money]" type="text" value="{$sig['buy_money']}" class="txt" style="width:50px;" /> 
			<select name="sig[buy_type]" style="width:70px;">
EOT;
foreach ($money_title as $k=>$v) {
	if ($k == $sig['buy_type']) {
		$selected = 'selected';
	} else {
		$selected = '';
	}
print <<<EOT
				<option value="{$k}" {$selected}>{$v}</option>
EOT;
}
print <<<EOT
			</select> / {$e6_sig_lang['high_07']}
		</td>
	</tr>
EOT;
	e6_sig_type_checkbox('img_group', $group_list, $e6_sig_lang['high_08'], $e6_sig_lang['high_09'].'[img]'.$e6_sig_lang['high_10']);
	e6_sig_type_radio('transaction', $e6_sig_lang['high_11'], $e6_sig_lang['high_12']);
print <<<EOT
	<tr>
		<td class="td27">{$e6_sig_lang['high_13']}</td>
		<td class="vtop tips2">{$e6_sig_lang['high_14']}</td>
	</tr>
	<tr class="noborder">
		<td class="vtop rowform">
			<textarea rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" name="sig[html]" cols="50" class="tarea" >{$sig['html']}</textarea>
		</td>
		<td class="vtop tips2" style="color:blue;">{$e6_sig_lang['high_15']} <br>{siguid} = {$e6_sig_lang['high_16']} <br>{sigusername} = {$e6_sig_lang['high_17']}<br>{sigmoney} = {$e6_sig_lang['high_18']}</td>
	</tr>
EOT;
	e6_sig_type_checkbox('sell_group', $group_list, $e6_sig_lang['high_19'], $e6_sig_lang['high_20']);
	e6_sig_type_checkbox('buysig_group', $group_list, $e6_sig_lang['high_21'], $e6_sig_lang['high_22']);
	e6_sig_type_checkbox('admin_group', $group_list, $e6_sig_lang['high_23'], $e6_sig_lang['high_24']);
	require_once libfile('function/forumlist');
	$forum_option = forumselect(FALSE, 0, $sig['fid'], TRUE);
print <<<EOT
	<tr>
	<tr>
		<td class="td27">��ֹ��ʾǩ�����:</td>
		<td class="vtop tips2">ѡ�еİ�齫����ʾǩ��</td>
	</tr>
	<tr class="noborder">
		<td class="vtop rowform">
			<select multiple="multiple" size="10" name="sig[fid][]">
			<option value="">��ѡ���κΰ��</option>
			{$forum_option}
			</select>
		</td>
		<td class="vtop tips2"><br><br>��ס CTRL ��ѡ</td>
	</tr>
	<tr>
		<td colspan="15">
			<div class="fixsel">
				<input type="submit" class="btn" name="e6_submit" title="{$e6_sig_lang['high_25']}" value="{$e6_sig_lang['high_26']}" />
			</div>
		</td>	
	</tr>
</tbody>
</table>
</form>
EOT;
} else {
	$sig = $_POST['sig'];
	$data = array_merge($sig_temporary,$sig);
	$data = e6_sig_export($data);
	$data = "\$sig=$data;\r\n";
	e6_sig_writeover($sig_config_file,"<?php\r\n".$data."?>");
	cpmsg($e6_sig_lang['high_27'], 'action=plugins&operation=config&identifier=e6_signature&pmod=admin_high', 'succeed');
}
?>