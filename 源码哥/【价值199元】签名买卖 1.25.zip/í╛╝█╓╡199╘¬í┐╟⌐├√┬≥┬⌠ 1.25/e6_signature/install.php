<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_e6_sig_user` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL,
  `buyuid` mediumint(8) unsigned NOT NULL,
  `ok` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `buydate` smallint(5) unsigned NOT NULL,
  `buymoney` smallint(5) unsigned NOT NULL,
  `buytype` tinyint(2) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`date`),
  KEY `type` (`type`,`buyuid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_e6_sig_credit` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(15) NOT NULL,
  `type` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `logtype` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `smoney` int(10) unsigned NOT NULL DEFAULT '0',
  `emoney` int(10) unsigned NOT NULL DEFAULT '0',
  `change` mediumint(6) NOT NULL DEFAULT '0',
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL,
  `describe` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;
SQL;
runquery($sql);
$finish = TRUE;
?>