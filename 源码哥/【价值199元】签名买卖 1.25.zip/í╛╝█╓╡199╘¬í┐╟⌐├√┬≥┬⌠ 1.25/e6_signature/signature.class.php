<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_e6_signature {
}
class plugin_e6_signature_home extends plugin_e6_signature {
	function spacecp_profile_top_output() {
		@include DISCUZ_ROOT.'data/e6_signature.config.php';
$e6_js = <<<EOT
<style>
#sig_img {
    height: 0;
    overflow: visible;
    position: relative;
    width: 100%;
}
#sig_img img {
	position: absolute;
    left: 50px;
    top: -40px;
}
</style>
<script type="text/javascript" src="source/plugin/e6_signature/js/jquery.js"></script> 
<script type="text/javascript">
e6(function(){
EOT;
		if ($sig['open'] == 1) {
			$e6_js .= 'e6("#td_sightml").parent().remove();';
			$e6_js .= 'e6(".tb.cl a:last").html(\'<font color="#F26C4F"><b>'.e6_sig_pl('class_04').'</b></font><div id="sig_img"><img src="source/plugin/e6_signature/image/new.gif"></div>\')';
		} else {
			$e6_js .= 'var s= e6(".tb.cl a:last").hide();';
		}
$e6_js .= <<<EOT
});
</script>
EOT;
		return $e6_js;
	}
}
class plugin_e6_signature_forum extends plugin_e6_signature {
	function viewthread_e6_signature_output(){
		global $postlist,$_G;
		if (!function_exists('e6_sig_msg')) { 
			require_once DISCUZ_ROOT . 'source/plugin/e6_signature/e6_function.php';
		}
		if ($sig['open'] == 1) {
			foreach ($postlist as $value) {
				$sig_uid[] = $value['authorid'];
			}
			$sig_uid = implode(',',array_filter(array_unique($sig_uid)));
			$sig_uid = preg_replace('/,$/i','',$sig_uid);
			if ($sig_uid) {
				e6_sig_msg($sig_uid);
				$query = DB::query("SELECT * FROM ".DB::table('e6_sig_user')." WHERE `uid` IN ($sig_uid)");
				while ($rt = DB::fetch($query)) {
					$sig_user[$rt['uid']] = $rt;
				}
			}
			foreach ($postlist as $key => $value) {
				if (in_array($_G['fid'],$sig['fid'])) {
					$postlist[$key]['signature'] = '';
				} else {
					if ($sig_user[$value['authorid']]['type'] == 4) {
						$postlist[$key]['signature'] = '';
					} elseif ($sig_user[$value['authorid']]['type'] == 2) {
						$sig_money = $sig_user[$value['authorid']]['buymoney'] . $_G['setting']['extcredits'][$sig_user[$value['authorid']]['buytype']]['title'] .' / ' . $sig_user[$value['authorid']]['buydate'] . e6_sig_pl('class_01');
						$sig_search = array("/{siguid}/","/{sigusername}/","/{sigmoney}/");
						$sig_str = array($value['authorid'],$value['author'],$sig_money);
						$postlist[$key]['signature'] = preg_replace($sig_search,$sig_str,$sig['html']);	
					} elseif ($sig_user[$value['authorid']]['type'] == 0) {
						if (in_array($value['groupid'],$sig['group'])) {
							$postlist[$key]['signature'] = '';
						}
					}
					if (in_array($_G['groupid'],$sig['admin_group'])) {
						$postlist[$key]['signature'] && $postlist[$key]['signature'] = $postlist[$key]['signature'] . '<a class="forbid" style="display: none;" href="javascript:;" onclick="showWindow(\'win\', \'plugin.php?id=e6_signature&nav=ban&uid='.$value['authorid'].'\');return false;">'.e6_sig_pl('class_02').'</a>';
					} elseif ($_G['uid'] && $sig_user[$value['authorid']]['type'] != 2) {
						$postlist[$key]['signature'] && $postlist[$key]['signature'] = $postlist[$key]['signature'] . '<a class="forbid" style="display: none;" href="javascript:;" onclick="showWindow(\'win\', \'plugin.php?id=e6_signature&nav=report&uid='.$value['authorid'].'\');return false;">'.e6_sig_pl('class_03').'</a>';
					}
				}
			}
			return $postlist;
		}
	}
	function viewthread_bottom_output(){
		global $_G;
		if ($_G['uid']) {
return <<<EOT
<style>
.sign {
	position: relative;
}
.forbid {
    background: url("source/plugin/e6_signature/image/forbid.png") no-repeat scroll 0 center #FFFFFF;
    color: #FF0000;
    display: inline-block;
    height: 20px;
    line-height: 20px;
    margin-left: 50px;
	margin-top: 10px;
	padding-left:20px;
    position: absolute;
    right: 0;
    top: 0;
}
</style>
<script type="text/javascript" src="source/plugin/e6_signature/js/jquery.js"></script>
<script type="text/javascript">
e6(function(){
	e6(".sign").hover(function(){
		e6(this).find(".forbid").show();
	},function(){
		e6(this).find(".forbid").hide();
	});
});
</script>
EOT;
		}
	}
}
if (!function_exists('e6_sig_pl')) {
	function e6_sig_pl($str) {
		return lang('plugin/e6_signature', $str);
	}
}
?>