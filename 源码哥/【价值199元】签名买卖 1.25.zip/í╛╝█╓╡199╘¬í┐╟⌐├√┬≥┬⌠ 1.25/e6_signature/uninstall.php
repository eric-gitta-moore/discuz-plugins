<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql = "DROP TABLE `pre_e6_sig_user`, `pre_e6_sig_credit`;";
runquery($sql);
$finish = TRUE;
?>