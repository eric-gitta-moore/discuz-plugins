<?php
/*
 * CopyRight  : [fx8.cc!] (C)2014-2016
 * Document   : Դ��磺www.fx8.cc��www.ymg6.com
 * Created on : 2016-06-18,19:54:56
 * Author     : Դ���(QQ��154606914) wWw.fx8.cc $
 * Description: This is NOT a freeware, use is subject to license terms.
 *              Դ����Ʒ ������Ʒ��
 *              Դ���Դ����̳ ȫ���׷� http://www.fx8.cc��
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
//$st=strtotime('1417001314');
//debug($st);
//$id=rand(1,3);
//echo "1417683963<br>";
//$sst=date('Y-m-d');
//$st2=strtotime($sst);
//echo $st2;
//
//echo TIMESTAMP;
//exit();

if($_G['uid']==0){
		showmessage($_G[lang][core][title_newest_activity], '', array(), array('login' => true));
}

require_once './source/class/class_core.php';
require_once './source/function/function_home.php';
require_once './source/function/function_credit.php';
$discuz = C::app();
$discuz->init();

loadcache('plugin');
$var=$_G['cache']['plugin']['ymg6com_1469788659'];
$extcredits=$_G['setting']['extcredits'][$var['post_jifen']];

$jifen_title=$extcredits['title'];
$jifen_num  =getuserprofile('extcredits'.$var['post_jifen']);

$type=$_GET['type'];
if ($type=="edit"){

	$rst=DB::fetch_first("select *  from ".DB::table('ymg6com_1469788659')." where aId=".$_GET['aid']); 
}elseif ($type=="add"){

	$rst=DB::fetch_first("select *  from ".DB::table('ymg6com_1469788659')." where aId=".$_GET['aid']); 
	if ($_GET['mm']==1){ 
		switch($_GET['miao']){
			case "5":
			$jieguo=$var['pricea'];
			break;
		  
			case "10":
			$jieguo=$var['priceb'];
			break;
		
			case "20":
			$jieguo=$var['pricec'];
			break;
		   
			case "30":
			$jieguo=$var['priced'];
			break;
		}	
		
		if ($jieguo*$_GET['dnum']>$jifen_num){
			showmessage($jifen_title."�������㣡".$jieguo*$_GET['dnum']." ���ȳ�ֵ����",'plugin.php?id=ymg6com_1469788659:admin_ads&type=browse',array(),array('alert'=>'error'));
		}
			
			$id=DB::query("UPDATE ".DB::table('ymg6com_1469788659')." set aNum=aNum+".$_GET['dnum']." where aId=".$_GET['aid']); 
			if($id>0){
				$money=$jieguo*$_GET['dnum']; 
				$money=abs($money);
				_updatemembercount($_G['uid'], array('extcredits'.$var[post_jifen] => -($money)), false, '', '', '','���ѿ۳�','��������������');
				showmessage('������,���������ɹ�!','plugin.php?id=ymg6com_1469788659:admin_ads&type=browse',array(),array('alert'=>'right'));
			}
			else {
				showmessage('���������쳣ʧ��');
			}
	}
}elseif ($type=="yesno"){

	$id=DB::query("UPDATE ".DB::table('ymg6com_1469788659')." set aYesno=".$_GET['act']." where aId=".$_GET['aid']); 
			if($id>0){
				 
				showmessage('������,״̬�ı�ɹ�!','plugin.php?id=ymg6com_1469788659:admin_ads&type=browse',array(),array('alert'=>'right'));
			}
			else {
				showmessage('״̬�ı��쳣ʧ��');
			}
	exit();
}else{
	$action=$_GET['action'];	
	if ($action=='add'){
	
		switch($_GET['miao']){
		
			case "5":
			$jieguo=$var['pricea'];
			break;
		  
			case "10":
			$jieguo=$var['priceb'];
			break;
		
			case "20":
			$jieguo=$var['pricec'];
			break;
		   
			case "30":
			$jieguo=$var['priced'];
			break;
		}	
		if (empty($_GET['title'])||empty($_GET['miaosu'])||empty($_GET['url'])||empty($_GET['dnum'])){
			showmessage("��Ϣ��ȫ�� �뽫����,����,����,�������д���ƣ�",'plugin.php?id=ymg6com_1469788659:post',array(),array('alert'=>'error'));
		}
		
		if ($_GET['dnum']<$var['num']){
			showmessage("����������㣡 �뷢�����ڵ���".$var['num']."����",'plugin.php?id=ymg6com_1469788659:post',array(),array('alert'=>'error'));
		}
		
		if ($jieguo*$_GET['dnum']>$jifen_num){
			showmessage($jifen_title."�������㣡".$jieguo*$_GET['dnum']." ���ȳ�ֵ����",'plugin.php?id=ymg6com_1469788659:post',array(),array('alert'=>'error'));
		}
	
		$InsertArray=array(
		'aUser'=>$_G['username'],
		'aName'=>$_GET['title'],
		'aDesc'=>$_GET['miaosu'],
		'aDurl'=>$_GET['url'],
		'aNum'=>$_GET['dnum'],
		'aMoney'=>$jieguo,
		'aMiao'=>$_GET['miao'],
		'dateline'=>time()
		);
		
		$result=DB::insert('ymg6com_1469788659',$InsertArray,true);
		
		if ($result>0) {
			
			$money=$jieguo*$_GET['dnum']; 
			$money=abs($money);
			_updatemembercount($_G['uid'], array('extcredits'.$var[post_jifen] => -($money)), false, '', '', '','���ѿ۳�','�������������');
			//updatecreditbyaction("�������������",$_G['uid'],array('extcredits'.$var[post_jifen] => -($money)));
			showmessage('�ɹ�����!','plugin.php?id=ymg6com_1469788659',array(),array('alert'=>'right'));
		}
		else {
			showmessage('�����쳣ʧ��');
		}
	
	}elseif ($action=='edit'){
		if ($_GET['username']==$_G['username']){ 
			$UpdateArray=array(
			'aName'=>$_GET['title'],
			'aDesc'=>$_GET['miaosu'],
			'aDurl'=>$_GET['url']
			);
			$id=DB::update('ymg6com_1469788659',$UpdateArray,"aId=".$_GET['aid']);
			if($id>0){
				showmessage('������,�޸ĳɹ�!','plugin.php?id=ymg6com_1469788659:admin_ads&type=browse',array(),array('alert'=>'right'));
			}
			else {
				showmessage('�޸��쳣ʧ��');
			}
		}else{
			showmessage('�㲻�Ǵ������Ĺ����!');
		}
	}
}//type
include template('ymg6com_1469788659:post');























?>