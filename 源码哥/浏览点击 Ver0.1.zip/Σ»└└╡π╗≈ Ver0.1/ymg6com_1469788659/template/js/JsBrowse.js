﻿
function StartSurf(num,yzm,url,time,taid,tpage)
{	
	document.getElementById("url"+taid).style.color='#8f8f8f';
	if(num==yzm){
		
		aid=taid;
		page=tpage;
		
		start=time;
		isStartSurf=1;
		tisi.style.display="none";
		waitpic.style.display="";
		win=window.open(url);
		setTimeout("gourl()",5000);
		return false}
	else{
		alert("验证码错误!");
		document.location.href="plugin.php?id=ymg6com_1469788659";
		}

}

function gourl()
{	if(isStartSurf==1){
	waitpic.style.display="none";
	waitmiao.style.display="";
	Tcount();
	}else{return false;}
}

function Tcount()
{	
if(isStartSurf==1)
	{
		if(win.closed==true)
			{
				waitmiao.style.display="none";
				goon.style.display="";
			return false
			}else{win.focus();}

		if(start < 0){
			chkHitLogin(aid,page);
			//document.getElementById("waitmiao2").innerHTML = "完成";
			}
    else{
		document.getElementById("waitmiao2").innerHTML = start;	
		start -= 1;
		setTimeout("Tcount()",1000);}
	}else{return false;}
}	


function chkHitLogin(aid,page){

var temp1=page;
var temp2=aid;
//方法一,框架
//document.getElementsByTagName("iframe")[0].src='plugin.php?id=ymg6com_1469788659&action=check';
//方法二,中转
document.location.href="plugin.php?id=ymg6com_1469788659&action=check&page="+temp1+"&aid="+temp2;
}

