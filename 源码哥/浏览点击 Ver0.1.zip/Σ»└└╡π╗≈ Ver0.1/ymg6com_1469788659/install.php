<?php
/*
Author:��.��.��
Website:www.fx8.cc
Qq:2575-163-778
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_ymg6com_1469788659`;
CREATE TABLE IF NOT EXISTS `pre_ymg6com_1469788659` (
  `aId` int(10) NOT NULL auto_increment,
  `aUser` varchar(255) NOT NULL default '',
  `aName` varchar(255) NOT NULL default '',
  `aDesc` varchar(255) NOT NULL default '',
  `aDurl` varchar(255) NOT NULL default '',
  `aPic` varchar(255) NOT NULL default '',
  `aNum` int(11) NOT NULL default '0',
  `aMoney` int(10) unsigned NOT NULL default '0',
  `aMiao` smallint(6) NOT NULL default '10',
  `aJubao` int(11) NOT NULL default '0',
  `aYesno` tinyint(2) NOT NULL default '0',
  `aHighlight` tinyint(2) NOT NULL default '0',
  `aBold` tinyint(2) NOT NULL default '0',
  `aXian` tinyint(2) NOT NULL default '0',
  `dateline` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`aId`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `pre_ymg6com_1469788659user`;
CREATE TABLE IF NOT EXISTS `pre_ymg6com_1469788659user` (
  `aId` int(10) NOT NULL auto_increment,
  `dId` int(11) NOT NULL default '0',
  `dUser` varchar(255) NOT NULL default '',
  `dIp` varchar(255) NOT NULL default '',
  `dateline` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`aId`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=1 ;
EOF;
runquery($sql);
$finish = TRUE;
?>