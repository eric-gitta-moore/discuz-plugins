<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_ymg6com_1469788659`;
DROP TABLE IF EXISTS `pre_ymg6com_1469788659user`;
EOF;

runquery($sql);	
$finish = TRUE;
?>
