<?php

/*
Author:��.��.��
Website:www.fx8.cc
Qq:154-6069-14
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


	$mobile_file = DISCUZ_ROOT."./source/plugin/yaoqing_robot/module_mobile.php";
	if(!file_exists($mobile_file))
	{
		$admin_module_batch_notexist_tips = lang('plugin/yaoqing_robot', 'admin_module_notexist_tips');
		showtips($admin_module_batch_notexist_tips);
		die();
	}
	else
	{
		$admin_module_batch_notexist_tips = lang('plugin/yaoqing_robot', 'admin_module_exist_tips');
		showtips($admin_module_batch_notexist_tips);

	}
	
?>