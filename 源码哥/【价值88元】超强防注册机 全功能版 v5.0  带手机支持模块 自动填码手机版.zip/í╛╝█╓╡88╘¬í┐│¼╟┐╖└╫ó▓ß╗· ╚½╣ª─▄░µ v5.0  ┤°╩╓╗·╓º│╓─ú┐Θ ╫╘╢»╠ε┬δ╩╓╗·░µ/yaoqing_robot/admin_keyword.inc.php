<?php
/**
*
* ��ǿ��ע�����̨����
* 
* @author ��.��.��
* @copyright fx8.cc  2016-5-22
* 
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!submitcheck('submit')) {
	
		$admin_keyword_tips=lang('plugin/yaoqing_robot','admin_keyword_plugin_tips');
		
		showtips($admin_keyword_tips);
		
}
else
{
	$openkeyword =  daddslashes($_POST['openkeyword']);
	$exemptwords =  daddslashes($_POST['exemptwords']);
	$operatemode =  daddslashes($_POST['operatemode']);
	$toadmin =  daddslashes($_POST['toadmin']);
			
		//���µ�ѡ��
	DB::update('yaoqing_robot_setting', array(	'svalue' => $openkeyword),"skey='keyword'");
	DB::update('yaoqing_robot_setting', array(	'svalue' => $exemptwords),"skey='exemptwords'");
	DB::update('yaoqing_robot_setting', array(	'svalue' => $operatemode),"skey='operatemode'");
	DB::update('yaoqing_robot_setting', array(	'svalue' => $toadmin),"skey='toadmin'");
	
	cpmsg(lang('plugin/yaoqing_robot', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=yaoqing_robot&pmod=admin_keyword', 'succeed');
}
//From:www_FX8_co
?>