<?php
/**
 *	[yaoqing_robot(yaoqing_robot.{modulename})] (C)2012-2099 Powered by Դ���.
 *	Version: 1.0
 *	Date: 2012-7-11 11:14
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	$config = array();
	$config = $_G['cache']['plugin']['yaoqing_robot'];
	
	
	if($_GET["method"]=="yaoqing")
	{
		
		if($_G['setting']['regstatus']==2)
		{
			$yq_robot = DB::fetch_first("SELECT code FROM ".DB::table('common_invite')." where fuid=0 and uid=".trim(intval($config['tp_uid']))." LIMIT 0,1");
			
			//�����ֱ��ʽ
			$tiptype = $_POST['pg'];
			if($tiptype == 'insert')
			{
					echo $yq_robot[code];
					die(); 
			}
			
			if($yq_robot == "")
			{
				showmessage(lang('plugin/yaoqing_robot', 'dispcomplete'),null,array(),array('alert' => error));
			}
			else
			{
				showmessage(lang('plugin/yaoqing_robot', 'code').$yq_robot[code],null,array(),array('alert' => right));
			}
		}
		else
		{
			showmessage(lang('plugin/yaoqing_robot', 'notyaoqing'),null,array(),array('alert' => error));
		}
		
	}
	
	function generateyaoqing($length=8)  
{ 

     $chars = array_merge(range(0,9),  

                      range('a','z'),  

                      range('A','Z'));  

     shuffle($chars);  

     $password = '';  

     for($i=0; $i<6; $i++) {  

         $password .= $chars[$i];  
     }  

     return $password;  

}

	if($_GET["method"]=="yao")
	{
		showmessage(lang('plugin/yaoqing_robot', 'code').generateyaoqing(),null,array(), array('alert' => 'right'));
	}
//From:www_FX8_co
?>