<?php

//define('APPTYPEID', 127);
//define('CURSCRIPT', 'plugin');


				require_once '../../../source/class/class_core.php';
				$discuz = & discuz_core::instance();
				$discuz->init_setting = true;
				$discuz->init_user = false;
				$discuz->init_session = false;
				$discuz->init_cron = false;
				$discuz->init_misc = false;
				$discuz->init_memory = false;
				$discuz->init();

/*			
require '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
*/
/*
function generateyaoqing($length=8)  
{ 

     $chars = array_merge(range(0,9),  

                      range('a','z'),  

                      range('A','Z'));  

     shuffle($chars);  

     $password = '';  

     for($i=0; $i<6; $i++) {  

         $password .= $chars[$i];  
     }  

     return $password;  

}
*/
showmessage(lang('plugin/yaoqing_robot', 'code'),'',array(), array('showdialog' => true, 'alert' => 'right'));
	
?>