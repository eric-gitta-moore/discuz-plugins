<?php
/*
	[fx8.cc!] (C)2001-2013 Inc.
	BY QQ:154606914  tp
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = '';


$sql = <<<EOF
DROP TABLE IF EXISTS `pre_yaoqing_robot_setting`;
EOF;


runquery($sql);

$finish = TRUE;

?>