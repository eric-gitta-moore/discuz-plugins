<?php
/*
 * CopyRight  : [fx8.cc!] (C)2014-2016
 * Document   : Դ��磺www.fx8.cc��www.ymg6.com
 * Created on : 2016-04-24,10:22:10
 * Author     : Դ���(QQ��154606914) wWw.fx8.cc $
 * Description: This is NOT a freeware, use is subject to license terms.
 *              Դ����Ʒ ������Ʒ��
 *              Դ�������� ȫ���׷� http://www.fx8.cc��
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(!submitcheck('submit')) {


	showtips(lang('plugin/yaoqing_robot', 'admin_area_tips'));
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='area'");
	$exam_timu_yes=lang('plugin/tp_exam', 'yaoqing_robot_yes');
	$area = $skey;

	$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='reg_city_province'");
	$reg_city_province = $skey;
	

	$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='provincelist'");
	$provincelist = $skey;
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='citylist'");
	$citylist = $skey;
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='regusertips'");
	$regusertips = $skey;
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='reg_in_else'");
	$reg_in_else = $skey;
	
	
	include_once template($_G['gp_identifier'] .':admin_area');
	
}
//WWW.fx8.cc
?>