<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_yaoqing_robot_setting` (
  `skey` varchar(255) NOT NULL,
  `svalue` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `pre_yaoqing_robot_setting` (`skey`, `svalue`) VALUES
('keyword', '0'),
('exemptwords', ''),
('area', '0'),
('operatemode', '4'),
('toadmin', '1'),
('reg_city_province', '1'),
('provincelist', ''),
('citylist', ''),
('regusertips', ''),
('reg_in_else', '1');

EOF;

runquery($sql);


$sValue = DB::fetch_first("SELECT svalue  FROM `".DB::table('common_setting')."` WHERE skey = 'inviteconfig'");
$invite = unserialize($sValue[svalue]);
$invite['buyinvitecode'] =1 ;
$invite = serialize($invite);
$sql = <<<EOF
UPDATE `pre_common_setting` SET `svalue` = '$invite' WHERE `pre_common_setting`.`skey` = 'inviteconfig';
UPDATE `pre_common_usergroup` SET `maxinviteday` = '300' WHERE `pre_common_usergroup`.`groupid` = '1';
EOF;
runquery($sql);

$sql = <<<EOF
UPDATE `pre_common_setting` SET `svalue` = '2' WHERE `pre_common_setting`.`skey` = 'regstatus';
EOF;
runquery($sql);

$connect = C::t('common_setting')->fetch('connect', true);
$connect['register_invite'] = 1;
C::t('common_setting')->update('connect', serialize($connect));

updatecache('setting');

$finish = TRUE;

?>