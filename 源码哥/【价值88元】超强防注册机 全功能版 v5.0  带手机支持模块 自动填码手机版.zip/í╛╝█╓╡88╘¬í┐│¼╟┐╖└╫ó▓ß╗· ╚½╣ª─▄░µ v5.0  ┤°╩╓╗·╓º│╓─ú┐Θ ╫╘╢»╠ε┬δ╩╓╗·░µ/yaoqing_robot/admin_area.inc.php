<?php
/**
*
* ��ǿ��ע�����̨����
* 
* @author ��.��.��
* @copyright fx8.cc  2016-5-22
* 
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


if(!submitcheck('submit')) {
	
		$admin_area_tips=lang('plugin/yaoqing_robot','admin_area_plugin_tips');
		
		showtips($admin_area_tips);

}
else
{
	$openarea =  daddslashes($_POST['openarea']);
	$reg_city_province =  daddslashes($_POST['reg_city_province']);
	$provincelist =  daddslashes($_POST['provincelist']);
	$citylist =  daddslashes($_POST['citylist']);
	$regusertips =  daddslashes($_POST['regusertips']);
	$reg_in_else =  daddslashes($_POST['reg_in_else']);
	
	//���µ�ѡ��
	DB::update('yaoqing_robot_setting', array(	'svalue' => $openarea),"skey='area'");
	DB::update('yaoqing_robot_setting', array(	'svalue' => $reg_city_province),"skey='reg_city_province'");
	DB::update('yaoqing_robot_setting', array(	'svalue' => $provincelist),"skey='provincelist'");
	DB::update('yaoqing_robot_setting', array(	'svalue' => $citylist),"skey='citylist'");
	DB::update('yaoqing_robot_setting', array(	'svalue' => $regusertips),"skey='regusertips'");
	DB::update('yaoqing_robot_setting', array(	'svalue' => $reg_in_else),"skey='reg_in_else'");
	
	cpmsg(lang('plugin/yaoqing_robot', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=yaoqing_robot&pmod=admin_area', 'succeed');
}
//WWW.fx8.cc
?>