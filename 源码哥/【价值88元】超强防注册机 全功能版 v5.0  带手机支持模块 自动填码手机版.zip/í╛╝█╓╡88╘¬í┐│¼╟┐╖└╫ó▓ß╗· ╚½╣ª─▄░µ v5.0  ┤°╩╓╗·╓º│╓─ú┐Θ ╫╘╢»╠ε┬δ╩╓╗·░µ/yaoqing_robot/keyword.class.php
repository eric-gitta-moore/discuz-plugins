<?php
	
	if(!defined('IN_DISCUZ')) {
       exit('Access Denied'); 
}


class plugin_yaoqing_robot {

    function plugin_yaoqing_robot() {
        global $_G;
       
       	$config = array();
		   	$config = $_G['cache']['plugin']['yaoqing_robot'];
	
        return;
    }
    
}
//WWW.fx8.cc
?>