<?php
/*
 * ������Դ���
 * ����: Www.fx8.cc
 * ������ַ: www.ymg6.com (���ղر���!)
 * ����֧��/����ά����QQ 154606914
 * 
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

  function banpostuser($uid, $bangroupid = 4, $bantime = 0) {

  	if ($bantime == 0){

  		DB::query("UPDATE ".DB::table('common_member')." SET adminid = -1,groupid = 4  WHERE uid='$uid'");         
  	}else{ 
      	$member = DB::fetch_first("SELECT adminid, groupid FROM ".DB::table('common_member')." WHERE uid='$uid]'");
				if($member && $member['groupid'] != 4) {      
  			        $banexpiry = TIMESTAMP + $bantime * 86400; 
					$groupterms = array();
	     	        $groupterms['main'] = array('time' => $banexpiry, 'adminid' => $member['adminid'], 'groupid' => $member['groupid']);
			        $groupterms['ext'][4] = $banexpiry;
 	                DB::query("UPDATE ".DB::table('common_member')." SET adminid = -1,groupid = 4,groupexpiry = '$banexpiry'   WHERE uid='$uid'");         
   			        DB::query("UPDATE ".DB::table('common_member_field_forum')." SET groupterms='".addslashes(serialize($groupterms))."' WHERE uid='$uid'");   
                }
        }
    return true;
  }        


	function get_current_client_city()
	{
		$ip=get_json_data();

		$user_city = iconv("utf-8","gbk",$ip['city']);
		
		return $user_city;
	}
	
	function get_current_client_province()
	{
			$ip=get_json_data();

			$user_province = iconv("utf-8","gbk",$ip['region']);
		return $user_province;
	}
	
 	function get_json_data()
	{   global $_G;
		
			$userip = $_G['clientip'];
			$url = "http://ip.taobao.com/service/getIpInfo.php?ip=";
			$url .= $userip;
			
			$queryip=file_get_contents($url);
			
			$jsonobj = json_decode($queryip);
			
			$jsondata = (array) $jsonobj->data;
			return $jsondata;
	}

  function PrivinceIn($clientip)
 	{
 		global $_G;
		$find = 0;
		
 		$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='provincelist'");
		$provincelist = $skey;
		$provincearr = explode("|",$provincelist);
		
		$client_por = get_current_client_province();
	
		//Ѱ��ʡ����
		foreach($provincearr as $val)
		{
			//ͳһת��ΪGBK���ʡ��
			if($_G['charset'] == 'utf-8')
			{
				$c_pro = iconv("utf-8","gbk",$val);
			}
			else
			{
				$c_pro = $val;
			}
			

			if(preg_match("/^{$c_pro}/",$client_por))
			{
				$find = 1;
			}		
		}
		

		return $find;
 	}
 
 /*
 ����1 �������棬����ע��
 ����0�������棬��ע��
 */
 	function PrivinceOut(){
 		global $_G;
		$find = 0;
		
 		$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='provincelist'");
		$provincelist = $skey;
		$provincearr = explode("|",$provincelist);
			
		$client_por = get_current_client_province();
		
		//Ѱ��ʡ����
		foreach($provincearr as $val)
		{
			//ͳһת��ΪGBK���ʡ��
			if($_G['charset'] == 'utf-8')
			{
				$c_pro = iconv("utf-8","gbk",$val);
			}
			else
			{
				$c_pro = $val;
			}
			
			if(preg_match("/^{$c_pro}/",$client_por))
			{
				$find = 1;
			}		
		}
	
		return $find;	
 	}
 	
 	function CityIn($clientip)
 	{
 	 	global $_G;
 	 	
		$find = 0;
 		$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='citylist'");
		$citylist = $skey;
	
		$client_city = get_current_client_city();
		
		//Ѱ��ʡ����
		foreach($citylist as $val)
		{
			//ͳһת��ΪGBK���ʡ��
			if($_G['charset'] == 'utf-8')
			{
				$c_city = iconv("utf-8","gbk",$val);
			}
			else
			{
				$c_city = $val;
			}
			
			if(preg_match("/^{$c_city}/",$client_city))
			{
				$find = 1;	

			}		
		}

		return $find;	
 	}
 	
 	function CityOut(){
 	 	global $_G;
 	 	
		$find = 1;
 		$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='citylist'");
		$citylist = $skey;
	
		$client_city = get_current_client_city();
		
		//Ѱ��ʡ����
		foreach($citylist as $val)
		{
			//ͳһת��ΪGBK���ʡ��
			if($_G['charset'] == 'utf-8')
			{
				$c_city = iconv("utf-8","gbk",$val);
			}
			else
			{
				$c_city = $val;
			}
			
			if(preg_match("/^{$c_city}/",$client_city))
			{
				$find = 0;	

			}		
		}

		return $find;		
 	}
 	
	function CheckAreaIn($clientip)
	{
		
		$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='reg_city_province'");
		$reg_city_province = $skey;
		$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='regusertips'");
		$regusertips = $skey;
		$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='reg_in_else'");
		$reg_in_else = $skey;
			
		if($reg_city_province)
		{
			$inPriv = PrivinceIn($clientip);
			if(!$inPriv){
				showmessage($regusertips);
			}


		}
		else
		{
			$inCity = CityIn($clientip);
			if($inPriv){
				showmessage($regusertips);
			}
		}
		
	}
	
	
	function CheckAreaOut($clientip)
	{
			$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='reg_city_province'");
			$reg_city_province = $skey;
			$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='regusertips'");
			$regusertips = $skey;
			
			if($reg_city_province)
			{
				$outPriv = PrivinceOut();
				if($outPriv){
					showmessage($regusertips);
				}
			}
			else
			{
				$cityOut = CityOut();
				if($cityOut){
					showmessage($regusertips);
				}
			}
			
	}
	
	function CheckArea($clientip)
	{
			$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='reg_in_else'");
			$reg_in_else = $skey;
			
			if($reg_in_else){
				CheckAreaIn($clientip);
			}
			else{
				CheckAreaOut($clientip);
			}
	
	}	

?>