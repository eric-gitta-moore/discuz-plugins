<?php
/**
*
* ��ǿ��ע�����̨����
* 
* @author ��.��.��
* @copyright fx8.cc  2016-5-22
* 
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$config=$_G['cache']['plugin']['yaoqing_robot'];
$allowaction = array('list', 'delete','deleteall', 'add');
$op = in_array($_G['gp_op'], $allowaction) ? $_G['gp_op'] : 'list';
$perpage = 20;
$page = max(1, intval(daddslashes($_GET['page'])));
$i=1;
		
switch ($op){
	case 'list':
		showformheader("plugins&operation=config&do=$do&identifier=yaoqing_robot&pmod=datamgr&op=add",'enctype');
	  showtableheader();

	  $count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('common_invite'));
	  $query = DB::query("SELECT id,uid,code FROM ".DB::table('common_invite')." ORDER BY id  LIMIT ".(($page - 1) * $perpage).",$perpage");

	  echo '<tr class="header"><th>'.'ID'.'</th><th>'.lang('plugin/yaoqing_robot', 'invitecode').'</th><th>'.lang('plugin/yaoqing_robot', 'inviterid').'</th><th><a id="p'.$i.'"  href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=yaoqing_robot&pmod=datamgr&op=deleteall">'.lang('plugin/yaoqing_robot', 'delallyaoqing').'</a></th><th></th></tr>';

		$id = "";
			while($data = DB::fetch($query)) {
			$i++;
			$id=$data['id'];
			echo '<tr><td>'.$id.'</td>'.
				'<td>'.$data['code'].'</td>'.
				'<td>'.$data['uid'].'</td>';
				
			echo '<td><a id="p'.$i.'"  href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier=yaoqing_robot&pmod=datamgr&op=delete&id='.$id.'">'.lang('plugin/yaoqing_robot', 'delyaoqing').'</a></td></tr>';
		}	

		showtablefooter();
  	echo multi($count, $perpage, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$do&identifier=yaoqing_robot&pmod=datamgr$extra");
		break;
		
	case 'add':
		if(submitcheck('editsubmit')){
			cpmsg(lang('plugin/yaoqing_robot', 'delete'), 'action=plugins&operation=config&do=$do&identifier=yaoqing_robot&pmod=datamgr', 'succeed');
		}
	break;
	
	case'delete':
			DB::query("DELETE FROM " . DB::table('common_invite') . " WHERE id = ". intval($_GET['id']));
			cpmsg(lang('plugin/yaoqing_robot', 'delete'), 'action=plugins&operation=config&do=$do&identifier=yaoqing_robot&pmod=datamgr', 'succeed');
	break;
	
	case 'deleteall':
			DB::query("DELETE FROM " . DB::table('common_invite'));
			cpmsg(lang('plugin/yaoqing_robot', 'deleteall'), 'action=plugins&operation=config&do=$do&identifier=yaoqing_robot&pmod=datamgr', 'succeed');
	break;
	
	}


?>