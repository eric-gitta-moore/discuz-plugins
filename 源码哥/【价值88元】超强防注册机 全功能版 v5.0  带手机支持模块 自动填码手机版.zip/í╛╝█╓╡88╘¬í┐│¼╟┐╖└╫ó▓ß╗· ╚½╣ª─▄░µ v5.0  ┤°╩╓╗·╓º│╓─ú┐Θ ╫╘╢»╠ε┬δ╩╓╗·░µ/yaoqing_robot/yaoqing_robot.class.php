<?php
/**
 *	[yaoqing_robot(yaoqing_robot.{modulename})] (C)2012-2099 Powered by Դ���.
 *	Version: 1.0
 *	Date: 2012-7-11 11:14
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	require_once DISCUZ_ROOT."./source/plugin/yaoqing_robot/include/func.inc.php";

class plugin_yaoqing_robot{
	
	function plugin_yaoqing_robot() {
	      $this->operatemode  = 4;
        $this->istoadmin   = intval(0);
        $this->objectlength = intval(300); 
        $this->adminuids = trim(1);
				$this->bantime = 0;
	}
	
}

class plugin_yaoqing_robot_member extends plugin_yaoqing_robot{


	function register()
	{
			global $_G;
			$config = $_G['cache']['plugin']['yaoqing_robot'];

			$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='area'");
			$area = $skey;
			
			if($area){
				CheckArea($_G['clientip']);
			}

			$yq_robot = DB::fetch_first("SELECT code FROM ".DB::table('common_invite')." where fuid=0 and uid=".trim(intval($config['tp_uid']))." LIMIT 0,1");

			if($yq_robot['code'] == "")
			{
				$uid = trim(intval($config['tp_uid']));
				$code = strtoupper(random(6));
				$dateline = mktime();
				$endtime = mktime(0,0,0,date("m"),date("d")+300,date("Y"));
				DB::query("INSERT INTO ".DB::table('common_invite')." (uid, code, dateline, endtime, inviteip) VALUES ('$uid', '$code', '$dateline', '$endtime', '$_G[clientip]')");
				$yq_robot = DB::fetch_first("SELECT code FROM ".DB::table('common_invite')." where fuid=0 and uid=".trim(intval($config['tp_uid']))." LIMIT 0,1");
			}
	}


	function  register_top()
	{
			global $_G;
			$rand = 0;
			
			$config = array();
			$config = $_G['cache']['plugin']['yaoqing_robot'];
			$hunxiao = $config['tp_hunxiao'];
			$tiptype = $config['tp_yaoqing_tiptype']; //��ʾ��ʽ
			

					
			$btnindex = 1;
			
			$btn = "<div class=\"bitbtn\"><a href=\"javascript:;\" onclick=\"yaoqing_btn_click(this,".$btnindex.",".$tiptype.");\" id=\"yaoqing_select\"><img src=\"source/plugin/yaoqing_robot/images/normal.gif\" width=95 height=33 class=\"btnimg".$btnindex."\"></a></div>";
			$item = $btn;
			
			if($hunxiao < 0)
			{
				$hunxiao = 1;
			}
			
			
			if($hunxiao > 2)
			{
				$hunxiao = 2;
			}
				
				unset($item);
				unset($btnarr);
				
				$btnarr = array($hunxiao);
				
				for($i = 0; $i < $hunxiao + 1; $i++)
				{
					$btnarr[$i] = $btn;
					$btnindex++;
					$btn = "<div class=\"bitbtn\"><a href=\"javascript:;\" onclick=\"yaoqing_btn_click(this,".$btnindex.",".$tiptype.");\" id=\"yaoqing_select\"><img src=\"source/plugin/yaoqing_robot/images/normal.gif\" width=95 height=33 class=\"btnimg".$btnindex."\"></a></div>";
				}
				
				list($msec, $sec) = explode(' ', microtime());
				$seed =  (float) $sec;

				$fid=array('0'=>lang('plugin/yaoqing_robot', 'red'),'1'=>lang('plugin/yaoqing_robot', 'green'),'2'=>lang('plugin/yaoqing_robot', 'black'));
				srand($seed);
				$color =  rand(0,2);

				$selectcolor = $fid[$color];
				
				sleep(1);
				$local = rand(0,$hunxiao);
				

				switch ($color)
				{
					case 0:
  					$src="source/plugin/yaoqing_robot/images/red.gif";
  					break;
					case 1:
  					$src="source/plugin/yaoqing_robot/images/yellow.gif";
  					break;
					case 2:
  					$src="source/plugin/yaoqing_robot/images/black.gif";
  					break;
					default:
  					$src="source/plugin/yaoqing_robot/images/normal.gif";
				}
				
				$btnindex = $local + 1;
				$btn = "<div class=\"bitbtn\"><a href=\"javascript:;\" onclick=\"yaoqing_btn_click(this,".$btnindex.",".$tiptype.");\" id=\"yaoqing_select\"><img src=\"".$src."\" width=95 height=33 class=\"btnimg".$btnindex."\"></a></div>";
				$btnarr[$local] = $btn;

				foreach($btnarr as $k=>$v)
				{
					$item .= $v;
				}
				
			
				$yaoqing_tip = $config['tp_yaoqing_tip'];
				$hunxiao_tip = $config['tp_hunxiao_tip'];
				
				if($hunxiao == 0)
				{
					return 	"<script id=\"js\" src=\"source/plugin/yaoqing_robot/template/js.js\" data=\"".$local."\" type=\"text/javascript\"></script><div class=\"myrfm\"><table><tr><th><span class=\"rq\">*".lang('plugin/yaoqing_robot', 'click').$selectcolor.lang('plugin/yaoqing_robot', 'get')."</span></th><td>".$item."</td><td><span>".$yaoqing_tip."</span></tr></table></div>";	
				}
				else
				{
					return 	"<script id=\"js\" src=\"source/plugin/yaoqing_robot/template/js.js\" data=\"".$local."\" type=\"text/javascript\"></script><div class=\"myrfm\"><table><tr><th><span class=\"rq\">*".lang('plugin/yaoqing_robot', 'click').$selectcolor.lang('plugin/yaoqing_robot', 'get')."</span></th><td>".$item."</td><td><span>".$hunxiao_tip."</span></tr></table></div>";
				}
			
	}
	
	
}


class plugin_yaoqing_robot_forum extends plugin_yaoqing_robot{

		function viewthread_posttop_output(){

		global $_G, $thread, $postlist;
		$skey = DB::result_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." where skey='keyword'");
		$openkeyword = $skey;
		if(!$openkeyword) return $return;
	
	
	 $pstarlength = $starlength  = 0;
	 $subjectarr = $psubjectarr = array();
	 $isrepost = 0;
	 $posttable = getposttablebytid($_G['tid']);
	 $preturn = array();
	 
		//����
     if ($this->objectlength) {
     	$sobjectlength =  $this->objectlength;
     }else {
     	$sobjectlength =  300;
     }

		 $isrepost = $tid = 0;

			$subject = strtolower($_G['thread']['subject']);
			$message = '';
 			$isrepost = 0;
			$tid = $_G['tid'];
		  
		  $gbk_subject = '';
		  $gbk_message = '';
		  
		  $postmess = DB::fetch_first("SELECT message FROM ".DB::table($posttable)." WHERE tid = '$_G[tid]' AND first = 1 "); 
      $message = $postmess['message'];  
      $message  = cutstr($message, $sobjectlength, $dot = '');
       
      $skey = DB::fetch_first("SELECT svalue FROM ".DB::table('yaoqing_robot_setting')." WHERE skey='exemptwords'");
      $exemptwords = trim($skey['svalue']);
      

		  if(!empty($exemptwords))  {
		 	
				$issubjectmatch = 1;
      	$ismessagematch = 1;
      	
      	$sub_find = true;
      	$mess_find = true;
      	
				//�Ƚ��ͻ���
				$word_row_arr = explode("\r\n",$exemptwords);
				
				$all_sub_find = false;
				$all_mess_find = false;
				

				foreach($word_row_arr as $k=>$value)
				{
      		$wordarr = explode("|",$value);

				$sub_match_num = 0;
				$mess_match_num = 0;

      		foreach($wordarr as $n=>$val)
      		{
						//ͳһת��ΪGBK���
						if($_G['charset'] == 'utf-8')
						{
							$c_key = iconv("utf-8","gbk",$val);
							$gbk_subject = iconv("utf-8","gbk",$subject);
							$gbk_message = iconv("utf-8","gbk",$message);
						}
						else
						{
							$c_key = $val;
							$gbk_subject = $subject;
							$gbk_message = $message;
						}
					
						if(preg_match("/$c_key/",$gbk_subject,$regs))
						{
						 // echo 'subject = '.$subject.' find' .$c_key ."<br>";
							$sub_match_num = $sub_match_num +1;
						}
						
						if(preg_match("/$c_key/",$gbk_message,$regs))
						{
							// echo 'content ='.$message.' find'.$c_key."<br>";
							$mess_match_num = $mess_match_num + 1;
						}
						
      		}
      		
      		
      	if($sub_match_num == count($wordarr) || $mess_match_num == count($wordarr) ) 
					{
						//echo '<br>has touched!!<br>';
						$isrepost = 100;
						break;
					}
      		
      		 unset($wordarr);
   	    }
   	    

      }
      

			//simi
		 if ($isrepost == 100)
		 {
    switch ($this->operatemode) {
 	 case 1:           
       DB::query("UPDATE ".DB::table('forum_thread')." SET displayorder = -2  WHERE tid='".$_G[tid]."'"); 
       updatemoderate('tid', $_G['tid']);      
       $opmode = lang('plugin/tp_addefense_thread', 'lopck1'); 
       $url1 = 'admin.php?action=moderate&operation=threads';
       break;
     case 2:           
       DB::query("UPDATE ".DB::table('forum_thread')." SET displayorder = -1  WHERE tid='".$_G[tid]."'");        
      $opmode = lang('plugin/tp_addefense_thread', 'lopck2'); 
       $url1 = 'admin.php?action=recyclebin';
       break; 
     case 3: 
    if ($_G ['adminid'] != 1  ){
    $modaction = 'WRN';
    $reason = $opmode = lang('plugin/tp_addefense_thread', 'lreason'); 
        	$lanrpsystem  = lang('plugin/tp_addefense_thread','lanrpsystem');
			DB::query("UPDATE ".DB::table($posttable)." SET status=status|2 WHERE pid=' $_G[forum_firstpid]'", 'UNBUFFERED');
			DB::query("INSERT INTO ".DB::table('forum_warning')." (pid, operatorid, operator, authorid, author, dateline, reason) VALUES (' $_G[forum_firstpid]', '1','$lanrpsystem','$_G[uid]', '$_G[username]', '$_G[timestamp]', '$reason')", 'UNBUFFERED');
			$authorwarnings = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_warning')." WHERE authorid='$uid' AND dateline>=$_G[timestamp]-".$_G[setting][warningexpiration]*86400);
			if($authorwarnings >= $_G['setting']['warninglimit']) {
				$bantime = $_G['setting']['warningexpiration'];
				banuser($_G['uid'],4,$bantime);
	        }
    }
      $opmode = lang('plugin/tp_addefense_thread', 'lopck3');
      $url1 =  'forum.php?mod=viewthread&tid='.$_G['tid']; 
     break; 

   case 4:
         DB::query("UPDATE ".DB::table('forum_thread')." SET displayorder = -2  WHERE tid='".$_G[tid]."'");

         updatemoderate('tid', $_G['tid']);

      		if ($_G ['adminid'] != 1  ){

            banuser($_G['uid'],4,$this->bantime );
       }
       $opmode = lang('plugin/tp_addefense_thread', 'lopck4');
       $url1 = 'admin.php?action=moderate&operation=threads';
       break; 
     case 5: 
        DB::query("UPDATE ".DB::table('forum_thread')." SET displayorder = -1  WHERE tid='".$_G[tid]."'");
      if ($_G ['adminid'] != 1  ){  
         banuser($_G['uid'],4,$this->bantime );      
     	}
       $opmode = lang('plugin/tp_addefense_thread', 'lopck5'); 
       $url1 = 'admin.php?action=recyclebin';
       break; 
     case 6: 
       $opmode = lang('plugin/tp_addefense_thread', 'lopck6'); 
       $url1 =  'forum.php?mod=viewthread&tid='.$_G['tid']; 
       break;    
        
     }
     

      $notevars = array(
          'url1' => 'forum.php?mod=viewthread&tid='.$_G['tid'],
          'subject1'  => $_G['thread']['subject'] ,
          'url2' => "forum.php?mod=redirect&goto=findpost&ptid='$tid'&pid='$pid'" ,
          'subject2' => $subject2, 
          'continuous' => $isrepost,
          'opmod' => $opmode,
          'rpuser' => "<a href=\"home.php?mod=space&uid=".$_G['uid']."\">".$_G['member']['username']."</a>"
       ); 
                
      if ($this->istoadmin){

   	  if ($this->adminuids) {

       $adminuids = array();
   	   $adminuids = explode('|',$this->adminuids); 
       foreach($adminuids as $adminuid){
       		notification_add($adminuid, 'nds_antirrepost', lang('plugin/yaoqing_robot','notice'),$notevars, 1);
       }
  	  }else{
   	  	 	notification_add($_G['config']['admincp']['founder'], 'nds_antirrepost', lang('plugin/tp_addefense_thread','notice'),$notevars, 1);
          }
   		}
   
     	 
     }
	
		}
		
		
}
//From:www_FX8_co
?>