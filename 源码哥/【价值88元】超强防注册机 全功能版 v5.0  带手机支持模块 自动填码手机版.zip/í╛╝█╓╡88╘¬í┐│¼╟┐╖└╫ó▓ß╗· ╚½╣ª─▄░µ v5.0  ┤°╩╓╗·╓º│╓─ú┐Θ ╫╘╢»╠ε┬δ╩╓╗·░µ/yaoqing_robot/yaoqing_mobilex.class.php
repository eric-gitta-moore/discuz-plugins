<?php

/**
 * yaoqing_robot For Discuz!X 2.0+
 * ============================================================================
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�ʹ�ã�
 * �������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
 * @package    yaoqing_robot
 * @module	   showcase 
 * @date	   2012-12-25
 * @author	   fx8.cc
 * @copyright  Copyright (c) 2012 yaoqing_robot FX8 Inc. (http://www.fx8.cc)
 */

/*
//--------------Tall us what you think!----------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


loadcache('plugin');

class mobileplugin_yaoqing_robot  {
	function global_header_mobile() {
		global $_G;
		
	  $m = daddslashes($_GET['mobile']);
		$mod =  daddslashes($_GET['mod']);
		
		$config = $_G['cache']['plugin']['yaoqing_robot'];
		$mobiletip = $config['mobiletip'];
		
		if(!empty($m)&&  (CURSCRIPT == 'member'))
		{

			$mobile_file = DISCUZ_ROOT."./source/plugin/yaoqing_robot/module_mobile.php";
			if(!file_exists($mobile_file))
			{
					return $return;
			}
			
			require_once DISCUZ_ROOT."./source/plugin/yaoqing_robot/module_mobile.php";
			
			return  '<div style="border:1px solid #ff0000; background: none repeat scroll 0 0 #ffff00;color:#ff0000; text-align: center;">'.$mobiletip.$yq_robot['code'].'</div>';
		}		
		return $return;
	}
}

/*
class mobileplugin_yaoqing_robot {

		function index_top_mobile() {
		global $_G;

		//include template ( 'yaoqing_robot:reg' );

		return "<div>index_top_mobile</div>";
	}
	
	function global_header_mobile() {
		global $_G;

		return "<div>global_header_mobile</div>";
	}
}*/

class mobileplugin_yaoqing_robot_forum extends mobileplugin_yaoqing_robot {

	function global_header_mobile(){
		global $_G;

		return "<div>global_header_mobile</div>";
	}
	
}


?>